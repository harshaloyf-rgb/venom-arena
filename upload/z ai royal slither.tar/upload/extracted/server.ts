import express from 'express';
import http from 'http';
import path from 'path';
import { Server, Socket } from 'socket.io';
import { createServer as createViteServer } from 'vite';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { initializeApp as initClientApp } from 'firebase/app';
import { getFirestore as getClientFirestore, doc as clientDoc, getDoc as clientGetDoc, setDoc as clientSetDoc, query as clientQuery, collection as clientCollection, where as clientWhere, getDocs as clientGetDocs, serverTimestamp } from 'firebase/firestore';
import firebaseConfig from './firebase-applet-config.json';

// Initialize server-side Firebase Client SDK (to bypass IAM service account restrictions)
const clientApp = initClientApp(firebaseConfig);
const clientDb = firebaseConfig.firestoreDatabaseId
  ? getClientFirestore(clientApp, firebaseConfig.firestoreDatabaseId)
  : getClientFirestore(clientApp);

// Compatibility db adapter that redirects users/ collection accesses to players/
const db = {
  doc: (pathStr: string) => {
    if (pathStr.startsWith('users/')) {
      const email = pathStr.replace('users/', '').toLowerCase();
      return {
        get: async () => {
          const q = clientQuery(clientCollection(clientDb, 'players'), clientWhere('email', '==', email));
          const snap = await clientGetDocs(q);
          if (snap.empty) {
            return { exists: false, data: () => null };
          }
          const docSnap = snap.docs[0];
          const data = docSnap.data();
          return {
            exists: true,
            data: () => ({
              email: data.email,
              passwordHash: data.passwordHash,
              userTag: data.userTag,
              createdAt: data.updatedAt?.toDate?.()?.toISOString?.() || new Date().toISOString()
            })
          };
        },
        set: async (data: any, options?: { merge?: boolean }) => {
          const userTag = data.userTag;
          const playerRef = clientDoc(clientDb, 'players', userTag);
          await clientSetDoc(playerRef, {
            email: data.email,
            passwordHash: data.passwordHash,
            userTag,
            updatedAt: serverTimestamp()
          }, { merge: true });
        }
      };
    }

    // Default players / other collections
    const docRef = clientDoc(clientDb, pathStr);
    return {
      get: async () => {
        const snap = await clientGetDoc(docRef);
        return {
          exists: snap.exists(),
          data: () => snap.data()
        };
      },
      set: async (data: any, options?: { merge?: boolean }) => {
        await clientSetDoc(docRef, {
          ...data,
          updatedAt: serverTimestamp()
        }, options || { merge: true });
      }
    };
  }
};

const PORT = 3000;
const WORLD_SIZE = 8000;
const JWT_SECRET = process.env.JWT_SECRET || 'venom_arena_jwt_secret_token_key_2026';

function getMapRadius(elapsedTimeMs: number): number {
  const baseRadius = 3800; // Large 3800 radius within 8000x8000 world coordinates
  const cycleTime = (elapsedTimeMs % 10000) / 10000;
  const sinVal = Math.sin(cycleTime * Math.PI * 2);
  return baseRadius + sinVal * 40; // Breathes by +/- 40 pixels
}
const INITIAL_BODY_LENGTH = 12;

// Server logs state for admin console
const systemLogs: string[] = [];
function addLog(message: string) {
  const timestamp = new Date().toISOString().substring(11, 19);
  const logStr = `[${timestamp}] ${message}`;
  console.log(logStr);
  systemLogs.unshift(logStr);
  if (systemLogs.length > 50) systemLogs.pop();
}

// Banned and Muted registers
const bannedUserTags = new Set<string>();
const mutedSocketIds = new Set<string>();

// Bot names & Skins for spawning
const BOT_NAMES = [
  'ViperStrike', 'NeonFang', 'CyberCobra', 'ToxicPython', 'ShadowAdder',
  'ChronoKrait', 'QuantumMamba', 'AeroBoa', 'SavageSerpent', 'GlitchViper',
  'ApexPredator', 'GhostScale', 'MatrixAsp', 'VenomStrike', 'Synthetix',
  'CyberCrawler', 'StaticFang', 'VectorVenom', 'OmegaSlink', 'BetaByte'
];

const BOT_SKINS = [
  { color: '#22c55e', secondaryColor: '#15803d' }, // Toxic Slime
  { color: '#a855f7', secondaryColor: '#6b21a8' }, // Venom Stryker
  { color: '#06b6d4', secondaryColor: '#0891b2' }, // Cyber Grid
  { color: '#ec4899', secondaryColor: '#3b82f6' }, // Chameleon Aurora
  { color: '#3b82f6', secondaryColor: '#1d4ed8' }  // Neon Glow
];

// Server-authoritative Arena configs matching client ARENA_TIERS
const SERVER_ARENAS: { [key: string]: { botsCount: number; buyIn: number; minExtract: number; rewardMultiplier: number } } = {
  'tier-1': { botsCount: 25, buyIn: 10, minExtract: 15, rewardMultiplier: 1.0 },
  'tier-2': { botsCount: 30, buyIn: 100, minExtract: 150, rewardMultiplier: 1.5 },
  'tier-3': { botsCount: 35, buyIn: 500, minExtract: 750, rewardMultiplier: 2.2 },
  'tier-4': { botsCount: 40, buyIn: 2500, minExtract: 4000, rewardMultiplier: 3.5 },
  'tier-5': { botsCount: 45, buyIn: 15000, minExtract: 25000, rewardMultiplier: 5.0 },
  'tier-6': { botsCount: 45, buyIn: 100000, minExtract: 180000, rewardMultiplier: 8.0 },
  'tier-7': { botsCount: 50, buyIn: 1000000, minExtract: 1500000, rewardMultiplier: 15.0 },
  'practice-easy': { botsCount: 30, buyIn: 0, minExtract: 0, rewardMultiplier: 0.0 },
  'practice-medium': { botsCount: 50, buyIn: 0, minExtract: 0, rewardMultiplier: 0.0 },
  'practice-hard': { botsCount: 75, buyIn: 0, minExtract: 0, rewardMultiplier: 0.0 }
};

// Food Interface
interface Food {
  id: string;
  x: number;
  y: number;
  size: number;
  value: number;
  isStarChip: boolean;
  color: string;
}

// Powerup Interface
interface PowerUp {
  id: string;
  x: number;
  y: number;
  type: 'shield' | 'magnet' | 'double' | 'freeze';
  color: string;
  pulse: number;
}

// Player Session State
interface PlayerSession {
  id: string; // Socket ID
  name: string;
  userTag: string;
  level: number;
  points: { x: number; y: number }[];
  angle: number;
  targetAngle: number;
  speed: number;
  size: number;
  carriedChips: number;
  score: number;
  isExtracting: boolean;
  isDead: boolean;
  color: string;
  secondaryColor?: string;
  trailColor?: string;
  useCustomSkin?: boolean;
  isBot: false;
  isPlayer: true;
  lastUpdated: number;
  extractionProgress: number; // in milliseconds
  kills: number;
  wantsBoost: boolean;
  spawnProtectedTimer: number; // in ms
  shieldActive: boolean;
  magnetTimer: number; // in ms
  doubleTimer: number; // in ms
  freezeTimer: number; // in ms
  chatMessage?: string;
  chatTimer?: number;
  frameCount: number;
}

// Bot Session State
interface BotSession {
  id: string; // Unique ID
  name: string;
  points: { x: number; y: number }[];
  angle: number;
  targetAngle: number;
  speed: number;
  size: number;
  color: string;
  secondaryColor?: string;
  isBot: true;
  isPlayer: false;
  botType: 'scavenger' | 'opportunist' | 'hunter' | 'extractor' | 'coward' | 'ally';
  carriedChips: number;
  isExtracting: boolean;
  extractionProgress: number; // in ms
  score: number;
  isDead: boolean;
  spawnProtectedTimer: number; // in ms
  chatMessage?: string;
  chatTimer?: number;
}

// Active Arena State Room
interface ArenaRoom {
  arenaId: string;
  foods: Map<string, Food>;
  addedFoods: Map<string, Food>;
  removedFoods: Set<string>;
  players: Map<string, PlayerSession>;
  bots: Map<string, BotSession>;
  powerUps: Map<string, PowerUp>;
  gameTimeElapsed: number; // in ms
  bossSpawned: boolean;
  bossAlert: string | null;
  frameCount: number;
}

const arenaRooms = new Map<string, ArenaRoom>();

// High-Performance incremental food managers to prevent 30Hz room-state network choking
function addFoodToRoom(room: ArenaRoom, id: string, food: Food) {
  room.foods.set(id, food);
  room.addedFoods.set(id, food);
  room.removedFoods.delete(id);
}

function removeFoodFromRoom(room: ArenaRoom, id: string) {
  const exists = room.foods.delete(id);
  if (exists) {
    room.addedFoods.delete(id);
    room.removedFoods.add(id);
  }
}

// Generate static body segments
function generateInitialBody(x: number, y: number, angle: number, length = INITIAL_BODY_LENGTH): { x: number; y: number }[] {
  const points: { x: number; y: number }[] = [];
  for (let i = 0; i < length; i++) {
    points.push({
      x: x - Math.cos(angle) * (i * 10),
      y: y - Math.sin(angle) * (i * 10)
    });
  }
  return points;
}

// Generate static food supply
function populateRoomFood(room: ArenaRoom) {
  const colors = ['#38bdf8', '#818cf8', '#fb7185', '#34d399', '#fbbf24', '#a78bfa', '#22d3ee', '#f472b6'];
  const targetFoodCount = 1200;
  
  while (room.foods.size < targetFoodCount) {
    const foodId = `food-${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
    const isStarChip = false; // Star chips are only dropped by real players when they die carrying chips!
    
    const currentRadius = getMapRadius(room.gameTimeElapsed) - 100;
    const angle = Math.random() * Math.PI * 2;
    const r = Math.sqrt(Math.random()) * currentRadius;
    const x = WORLD_SIZE / 2 + Math.cos(angle) * r;
    const y = WORLD_SIZE / 2 + Math.sin(angle) * r;

    const value = Math.floor(Math.random() * 5) + 2;
    const size = 4 + Math.random() * 3;
    const color = colors[Math.floor(Math.random() * colors.length)];
    
    addFoodToRoom(room, foodId, {
      id: foodId,
      x,
      y,
      size,
      value,
      isStarChip,
      color
    });
  }
}

// Spawns death bounty star chips & food authoritatively on server
function spawnSnakeDeathBounty(snake: any, room: ArenaRoom, isBoundaryDeath = false) {
  const isBot = !!snake.isBot;
  
  // 1. Drop star chips representing their bounty value (ONLY for real players, never bots)
  if (!isBot) {
    const totalChips = snake.carriedChips || 0;
    if (totalChips > 0) {
      const dropCount = Math.min(25, Math.max(3, Math.floor(totalChips / 5)));
      const valuePerDrop = Math.max(1, Math.floor(totalChips / dropCount));
      
      for (let i = 0; i < dropCount; i++) {
        const pt = snake.points[Math.floor((i / dropCount) * snake.points.length)] || snake.points[0];
        // Tight scattering on same spot as body trail segment (max 10px random variance)
        const spreadX = pt.x + (Math.random() - 0.5) * 10;
        const spreadY = pt.y + (Math.random() - 0.5) * 10;
        
        const foodId = `food-bounty-${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
        addFoodToRoom(room, foodId, {
          id: foodId,
          x: Math.max(50, Math.min(WORLD_SIZE - 50, spreadX)),
          y: Math.max(50, Math.min(WORLD_SIZE - 50, spreadY)),
          size: 9 + Math.random() * 4,
          value: valuePerDrop,
          isStarChip: true,
          color: '#eab308'
        });
      }
    }
  }
  
  // Rule: if bot hit boundary, they directly vanish and do not drop anything!
  // Rule: if real players die with boundary, they drop stars but NOT food!
  if (isBoundaryDeath) {
    return;
  }

  // 2. Drop regular food corresponding to length
  snake.points.forEach((pt: any, index: number) => {
    if (index % 2 === 0) { // drop at every alternate segment
      // Drop food tightly on the body segment points (max 8px random variance)
      const spreadX = pt.x + (Math.random() - 0.5) * 8;
      const spreadY = pt.y + (Math.random() - 0.5) * 8;
      
      const foodId = `food-regular-${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
      addFoodToRoom(room, foodId, {
        id: foodId,
        x: Math.max(50, Math.min(WORLD_SIZE - 50, spreadX)),
        y: Math.max(50, Math.min(WORLD_SIZE - 50, spreadY)),
        size: 4 + Math.random() * 3,
        value: 2,
        isStarChip: false,
        color: snake.color
      });
    }
  });
}

function getOrCreateRoom(arenaId: string): ArenaRoom {
  let room = arenaRooms.get(arenaId);
  if (!room) {
    room = {
      arenaId,
      foods: new Map<string, Food>(),
      addedFoods: new Map<string, Food>(),
      removedFoods: new Set<string>(),
      players: new Map<string, PlayerSession>(),
      bots: new Map<string, BotSession>(),
      powerUps: new Map<string, PowerUp>(),
      gameTimeElapsed: 0,
      bossSpawned: false,
      bossAlert: null,
      frameCount: 0
    };
    populateRoomFood(room);
    arenaRooms.set(arenaId, room);
    addLog(`Initialized gameserver authoritative room: ${arenaId}`);
  }
  return room;
}

// Find closest food on the server
function findClosestFoodServer(snake: any, foods: Food[], radius: number) {
  let closest: Food | null = null;
  let minDist = radius;
  const head = snake.points[0];
  foods.forEach((f) => {
    const dist = Math.hypot(f.x - head.x, f.y - head.y);
    if (dist < minDist) {
      minDist = dist;
      closest = f;
    }
  });
  return closest;
}

// Simple request rate limiter structure
const ipRequestLimit = new Map<string, { count: number; resetTime: number }>();
function rateLimiterMiddleware(req: any, res: any, next: any) {
  const ip = req.ip || 'unknown';
  const now = Date.now();
  const limitInfo = ipRequestLimit.get(ip);

  if (!limitInfo || now > limitInfo.resetTime) {
    ipRequestLimit.set(ip, { count: 1, resetTime: now + 60000 }); // 60s window
    return next();
  }

  limitInfo.count++;
  if (limitInfo.count > 120) { // Limit to 120 requests per minute
    return res.status(429).json({ error: 'Too many requests. Rate limit exceeded.' });
  }
  next();
}

async function startServer() {
  const app = express();
  app.use(express.json());
  
  const server = http.createServer(app);
  const io = new Server(server, {
    cors: { origin: '*', methods: ['GET', 'POST'] },
    pingInterval: 10000,
    pingTimeout: 5000,
  });

  // --- 1. USER AUTHENTICATION ENDPOINTS ---

  app.post('/api/auth/register', rateLimiterMiddleware, async (req, res) => {
    try {
      const { email, password, name, country } = req.body;
      if (!email || !password || !name) {
        return res.status(400).json({ error: 'Missing required profile credentials.' });
      }

      // Check if user already exists
      const userRef = db.doc('users/' + email.toLowerCase());
      const userDoc = await userRef.get();
      if (userDoc.exists) {
        return res.status(400).json({ error: 'Email already registered.' });
      }

      // Hash Password
      const salt = bcrypt.genSaltSync(10);
      const passwordHash = bcrypt.hashSync(password, salt);
      const userTag = `VENM-${Math.floor(1000 + Math.random() * 9000)}`;

      // Save User Credentials
      await userRef.set({
        email: email.toLowerCase(),
        passwordHash,
        userTag,
        createdAt: new Date().toISOString()
      });

      // Save Initial Player Stats
      const initialStats = {
        name,
        level: 1,
        xp: 0,
        bankedChips: 1000, // 1000 welcome chips
        lifetimeKills: 0,
        lifetimeDeaths: 0,
        lifetimeExtracts: 0,
        bestStreak: 0,
        biggestExtract: 0,
        totalChipsEarned: 1000,
        totalChipsLost: 0,
        unlockedSkins: ['skin-default', 'trail-none', 'death-default'],
        currentSkin: 'skin-default',
        currentTrail: 'trail-none',
        currentDeath: 'death-default',
        customSkinColors: ['#ffffff', '#22c55e', '#ec4899', '#f97316', '#eab308'],
        useCustomSkin: false,
        dailyStreak: 0,
        lastDailyClaim: null,
        championshipRank: 999,
        userTag,
        clanId: null,
        country: country || 'US'
      };

      await db.doc('players/' + userTag).set(initialStats);

      const token = jwt.sign({ userTag, name, email }, JWT_SECRET, { expiresIn: '7d' });
      addLog(`New account registered: ${name} (${userTag})`);
      res.json({ token, stats: initialStats });
    } catch (err: any) {
      console.error(err);
      res.status(500).json({ error: 'Authentication service failure.' });
    }
  });

  app.post('/api/auth/login', rateLimiterMiddleware, async (req, res) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) {
        return res.status(400).json({ error: 'Credentials required.' });
      }

      const userRef = db.doc('users/' + email.toLowerCase());
      const userDoc = await userRef.get();
      if (!userDoc.exists) {
        return res.status(400).json({ error: 'Invalid email or password.' });
      }

      const user = userDoc.data();
      if (!user) {
        return res.status(400).json({ error: 'Invalid email or password.' });
      }
      const valid = bcrypt.compareSync(password, user.passwordHash);
      if (!valid) {
        return res.status(400).json({ error: 'Invalid email or password.' });
      }

      // Fetch player profile
      const playerRef = db.doc('players/' + user.userTag);
      const playerDoc = await playerRef.get();
      const stats = playerDoc.exists ? playerDoc.data() : null;

      const token = jwt.sign({ userTag: user.userTag, name: stats?.name || 'Viper', email: user.email }, JWT_SECRET, { expiresIn: '7d' });
      addLog(`User logged in: ${stats?.name || 'Viper'} (${user.userTag})`);
      res.json({ token, stats });
    } catch (err) {
      res.status(500).json({ error: 'Internal login error.' });
    }
  });

  app.post('/api/auth/guest', rateLimiterMiddleware, async (req, res) => {
    try {
      const { name, country } = req.body;
      const guestTag = `GST-${Math.floor(1000 + Math.random() * 9000)}`;
      const guestName = name ? `${name.substring(0, 12)}` : 'GuestViper';

      const initialStats = {
        name: guestName,
        level: 1,
        xp: 0,
        bankedChips: 150, // Starter chips
        lifetimeKills: 0,
        lifetimeDeaths: 0,
        lifetimeExtracts: 0,
        bestStreak: 0,
        biggestExtract: 0,
        totalChipsEarned: 150,
        totalChipsLost: 0,
        unlockedSkins: ['skin-default', 'trail-none', 'death-default'],
        currentSkin: 'skin-default',
        currentTrail: 'trail-none',
        currentDeath: 'death-default',
        customSkinColors: ['#ffffff', '#22c55e', '#ec4899', '#f97316', '#eab308'],
        useCustomSkin: false,
        dailyStreak: 0,
        lastDailyClaim: null,
        championshipRank: 999,
        userTag: guestTag,
        clanId: null,
        country: country || 'US'
      };

      // Save temporary profile in Firestore
      await db.doc('players/' + guestTag).set(initialStats);

      const token = jwt.sign({ userTag: guestTag, name: guestName, isGuest: true }, JWT_SECRET, { expiresIn: '1d' });
      addLog(`Guest account provisioned: ${guestName} (${guestTag})`);
      res.json({ token, stats: initialStats });
    } catch (err) {
      res.status(500).json({ error: 'Guest authorization failed.' });
    }
  });

  app.post('/api/auth/link', rateLimiterMiddleware, async (req, res) => {
    try {
      const { email, password, name, userTag } = req.body;
      if (!email || !password || !userTag) {
        return res.status(400).json({ error: 'Linking parameters incomplete.' });
      }

      // Verify email uniqueness
      const userRef = db.doc('users/' + email.toLowerCase());
      const userDoc = await userRef.get();
      if (userDoc.exists) {
        return res.status(400).json({ error: 'This email is already linked to another account.' });
      }

      // Upgrade to secure email password
      const salt = bcrypt.genSaltSync(10);
      const passwordHash = bcrypt.hashSync(password, salt);

      await userRef.set({
        email: email.toLowerCase(),
        passwordHash,
        userTag,
        createdAt: new Date().toISOString()
      });

      // Update name if changed
      if (name) {
        await db.doc('players/' + userTag).set({ name }, { merge: true });
      }

      // Fetch latest profile
      const playerDoc = await db.doc('players/' + userTag).get();
      const stats = playerDoc.data();

      const token = jwt.sign({ userTag, name: stats?.name || name, email }, JWT_SECRET, { expiresIn: '7d' });
      addLog(`Linked Guest account securely to ${email} (${userTag})`);
      res.json({ token, stats });
    } catch (err) {
      res.status(500).json({ error: 'Linking transaction failed.' });
    }
  });

  // Basic diagnostic endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'active',
      uptime: process.uptime(),
      roomsCount: arenaRooms.size,
      totalPlayersConnected: io.engine.clientsCount
    });
  });

  // Arena live player stats endpoint
  app.get('/api/arena-stats', (req, res) => {
    const stats: Record<string, { players: number; maxPlayers: number }> = {};
    const knownTiers = ['tier-1', 'tier-2', 'tier-3', 'tier-4', 'tier-5', 'tier-6', 'tier-7'];
    knownTiers.forEach((tierId) => {
      const room = arenaRooms.get(tierId);
      const count = room ? room.players.size : 0;
      stats[tierId] = {
        players: count,
        maxPlayers: 500
      };
    });
    res.json(stats);
  });

  // --- 2. ADMIN & MODERATION TERMINAL ENDPOINTS ---

  function checkAdminAuth(req: any, res: any, next: any) {
    const authHeader = req.headers.authorization;
    if (!authHeader) return res.status(401).json({ error: 'Unauthorized overseer access.' });
    
    const token = authHeader.split(' ')[1];
    try {
      const decoded = jwt.verify(token, JWT_SECRET) as any;
      next();
    } catch (err) {
      return res.status(401).json({ error: 'Invalid overseer session token.' });
    }
  }

  app.get('/api/admin/status', checkAdminAuth, (req, res) => {
    const playersList: any[] = [];
    arenaRooms.forEach((room) => {
      room.players.forEach((p) => {
        playersList.push({
          id: p.id,
          name: p.name,
          userTag: p.userTag,
          level: p.level,
          carriedChips: p.carriedChips,
          arenaId: room.arenaId,
          isMuted: mutedSocketIds.has(p.id)
        });
      });
    });

    res.json({
      status: {
        roomsCount: arenaRooms.size,
        totalPlayersConnected: io.engine.clientsCount,
        uptime: process.uptime()
      },
      players: playersList,
      logs: systemLogs
    });
  });

  app.post('/api/admin/kick/:socketId', checkAdminAuth, (req, res) => {
    const socketId = req.params.socketId;
    const targetSocket = io.sockets.sockets.get(socketId);
    if (targetSocket) {
      targetSocket.emit('kick_notice', { reason: 'Overseer has terminated your session.' });
      targetSocket.disconnect(true);
      addLog(`Kicked active connection: Socket ${socketId}`);
      res.json({ success: true });
    } else {
      res.status(404).json({ error: 'Active connection session not found.' });
    }
  });

  app.post('/api/admin/ban/:userTag', checkAdminAuth, (req, res) => {
    const tag = req.params.userTag;
    bannedUserTags.add(tag);
    addLog(`Permanently banned user: ${tag}`);
    
    arenaRooms.forEach((room) => {
      room.players.forEach((p) => {
        if (p.userTag === tag) {
          const s = io.sockets.sockets.get(p.id);
          if (s) {
            s.emit('kick_notice', { reason: 'Your User Tag has been banned from the servers.' });
            s.disconnect(true);
          }
        }
      });
    });
    res.json({ success: true });
  });

  app.post('/api/admin/mute/:socketId', checkAdminAuth, (req, res) => {
    const socketId = req.params.socketId;
    if (mutedSocketIds.has(socketId)) {
      mutedSocketIds.delete(socketId);
      addLog(`Unmuted socket ID: ${socketId}`);
    } else {
      mutedSocketIds.add(socketId);
      addLog(`Muted socket ID: ${socketId}`);
    }
    res.json({ success: true });
  });

  app.post('/api/admin/broadcast', checkAdminAuth, (req, res) => {
    const { message } = req.body;
    if (message) {
      io.emit('broadcast_announcement', { message });
      addLog(`Admin Broadcast: ${message}`);
      res.json({ success: true });
    } else {
      res.status(400).json({ error: 'Message body missing.' });
    }
  });

  app.post('/api/admin/modify-chips', checkAdminAuth, async (req, res) => {
    try {
      const { userTag, amount } = req.body;
      if (!userTag || isNaN(amount)) {
        return res.status(400).json({ error: 'Parameters invalid.' });
      }

      const playerRef = db.doc('players/' + userTag);
      const playerDoc = await playerRef.get();
      if (playerDoc.exists) {
        const stats = playerDoc.data();
        const currentBalance = stats ? stats.bankedChips || 0 : 0;
        const nextBalance = Math.max(0, currentBalance + amount);
        await playerRef.set({ bankedChips: nextBalance }, { merge: true });
        addLog(`Overseer override: Adjusted balance of ${userTag} by ${amount} chips (New: ${nextBalance})`);
        res.json({ success: true });
      } else {
        res.status(404).json({ error: 'Player profile not found.' });
      }
    } catch (err) {
      res.status(500).json({ error: 'Failed to adjust chips.' });
    }
  });


  // --- 3. SOCKET.IO REALTIME SECURE MATCH CONTROLLER & ENGINE ---

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token || socket.handshake.query?.token;
    if (token) {
      try {
        const decoded = jwt.verify(token, JWT_SECRET) as any;
        if (bannedUserTags.has(decoded.userTag)) {
          return next(new Error('This user account has been permanently blacklisted.'));
        }
        (socket as any).user = decoded;
      } catch (err) {
        addLog(`WARN: Invalid token connected from Socket: ${socket.id}`);
      }
    }
    next();
  });

  io.on('connection', (socket: Socket) => {
    let currentArenaId: string | null = null;
    let playerId: string = socket.id;
    const userProfile = (socket as any).user;

    // 1. Join Arena & Matchmaking Lobby Assignment (Authoritative Secure Validation)
    socket.on('join_arena', async (data: { arenaId: string; playerStats: any }) => {
      const { arenaId, playerStats } = data;
      
      const activeUserTag = userProfile?.userTag || playerStats.userTag;
      if (!activeUserTag) {
        socket.emit('kick_notice', { reason: 'Unauthorized access. Valid profile required.' });
        socket.disconnect(true);
        return;
      }

      // Enforce Ban Check
      if (bannedUserTags.has(activeUserTag)) {
        socket.emit('kick_notice', { reason: 'Your account has been banned from active arenas.' });
        socket.disconnect(true);
        return;
      }

      currentArenaId = arenaId;
      socket.join(`arena_${arenaId}`);

      const room = getOrCreateRoom(arenaId);
      const arenaConfig = SERVER_ARENAS[arenaId] || { botsCount: 12, buyIn: 10, minExtract: 15, rewardMultiplier: 1.0 };

      // Secure Server-Side Chips/BuyIn Verification and Deduction
      try {
        const playerRef = db.doc('players/' + activeUserTag);
        const playerDoc = await playerRef.get();
        
        if (!playerDoc.exists) {
          socket.emit('kick_notice', { reason: 'Profile record not found in the database.' });
          socket.disconnect(true);
          return;
        }

        const stats = playerDoc.data();
        const bankedChips = stats ? stats.bankedChips || 0 : 0;

        if (bankedChips < arenaConfig.buyIn) {
          socket.emit('kick_notice', { reason: `Insufficient chips to join. Buy-in: ${arenaConfig.buyIn} chips.` });
          socket.disconnect(true);
          return;
        }

        // Authoritatively deduct the buyIn immediately upon joining
        const nextBanked = Math.max(0, bankedChips - arenaConfig.buyIn);
        const nextTotalLost = (stats?.totalChipsLost || 0) + arenaConfig.buyIn;

        await playerRef.set({
          bankedChips: nextBanked,
          totalChipsLost: nextTotalLost
        }, { merge: true });

        addLog(`Matchmaking Transaction: Deducted buy-in of ${arenaConfig.buyIn} chips from ${stats?.name || 'Viper'} (${activeUserTag}). Bank: ${nextBanked}`);

        // Spawn player snake securely on server inside circular arena bounds
        const spawnRadius = 3500;
        const spawnAngle = Math.random() * Math.PI * 2;
        const spawnDist = Math.sqrt(Math.random()) * spawnRadius;
        const startX = WORLD_SIZE / 2 + Math.cos(spawnAngle) * spawnDist;
        const startY = WORLD_SIZE / 2 + Math.sin(spawnAngle) * spawnDist;
        const startAngle = Math.random() * Math.PI * 2;

        const activeName = stats?.name || 'Anonymous Viper';

        room.players.set(playerId, {
          id: playerId,
          name: activeName,
          userTag: activeUserTag,
          level: stats?.level || 1,
          points: generateInitialBody(startX, startY, startAngle),
          angle: startAngle,
          targetAngle: startAngle,
          speed: 2.8,
          size: 8,
          carriedChips: arenaConfig.buyIn, // Initial carried bounty chips matching buy-in!
          score: INITIAL_BODY_LENGTH,
          isExtracting: false,
          isDead: false,
          color: playerStats.useCustomSkin && playerStats.customSkinColors?.length > 0 
            ? playerStats.customSkinColors[0] 
            : '#4f46e5',
          secondaryColor: playerStats.useCustomSkin && playerStats.customSkinColors?.length > 1 
            ? playerStats.customSkinColors[1] 
            : '#15803d',
          trailColor: playerStats.currentTrail || 'trail-none',
          useCustomSkin: playerStats.useCustomSkin || false,
          lastUpdated: Date.now(),
          extractionProgress: 0,
          kills: 0,
          wantsBoost: false,
          spawnProtectedTimer: 4000,
          shieldActive: false,
          magnetTimer: 0,
          doubleTimer: 0,
          freezeTimer: 0,
          isBot: false,
          isPlayer: true,
          chatMessage: undefined,
          chatTimer: undefined,
          frameCount: 0
        });

        // Initialize food and synchronize
        const currentFoods = Array.from(room.foods.values());
        const otherPlayers = Array.from(room.players.values()).filter(p => p.id !== playerId);

        socket.emit('arena_joined', {
          playerId,
          foods: currentFoods,
          players: otherPlayers
        });

        socket.to(`arena_${arenaId}`).emit('player_joined', room.players.get(playerId));
        addLog(`Matchmaking: ${activeName} (${activeUserTag}) authorized and assigned to room "${arenaId}"`);
      } catch (err) {
        console.error('Failed to authenticate join transaction:', err);
        socket.emit('kick_notice', { reason: 'Database transaction failed during buy-in authorization.' });
        socket.disconnect(true);
      }
    });

    // 2. Server-Authoritative Input Event (Receives client input vectors)
    socket.on('client_input', (data: { targetAngle: number; wantsBoost: boolean; isExtracting: boolean }) => {
      if (!currentArenaId) return;
      const room = arenaRooms.get(currentArenaId);
      if (!room) return;

      const player = room.players.get(playerId);
      if (player && !player.isDead) {
        if (typeof data.targetAngle === 'number' && !isNaN(data.targetAngle)) {
          player.targetAngle = data.targetAngle;
        }
        player.wantsBoost = !!data.wantsBoost;
        player.isExtracting = !!data.isExtracting;
        player.lastUpdated = Date.now();
      }
    });

    // 2B. Spawn dropped chips/food on server when players drop chips or die
    socket.on('spawn_chips', (data: { chips: any[] }) => {
      if (!currentArenaId) return;
      const room = arenaRooms.get(currentArenaId);
      if (!room) return;

      if (data.chips && Array.isArray(data.chips)) {
        data.chips.forEach((chip) => {
          const foodId = `star-drop-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
          const newFood: Food = {
            id: foodId,
            x: chip.x,
            y: chip.y,
            size: chip.size || 7,
            value: chip.value || 1,
            isStarChip: chip.isStarChip ?? true,
            color: chip.color || '#fbbf24'
          };
          addFoodToRoom(room, foodId, newFood);
        });
      }
    });

    // 2C. Client-Authoritative Food Eat Sync (Verifies and registers client food eating optimistically)
    socket.on('eat_food', (data: { foodId: string }) => {
      if (!currentArenaId) return;
      const room = arenaRooms.get(currentArenaId);
      if (!room) return;

      const player = room.players.get(playerId);
      if (!player || player.isDead) return;

      const food = room.foods.get(data.foodId);
      if (!food) return;

      // Distance validation with safety buffer (250px) to prevent teleport/speed exploits while accommodating network latency
      const playerHead = player.points[0];
      if (playerHead) {
        const dist = Math.hypot(food.x - playerHead.x, food.y - playerHead.y);
        if (dist < player.size + 250) {
          removeFoodFromRoom(room, data.foodId);
          populateRoomFood(room);

          // Apply double powerup multiplier on star chip value
          let chipsEarned = food.isStarChip ? food.value : 0;
          if (player.doubleTimer > 0 && food.isStarChip) {
            chipsEarned *= 2;
          }
          player.carriedChips += chipsEarned;

          // Grow body authoritative segments
          const growSegments = food.isStarChip ? 3 : 1;
          player.score += growSegments;
          for (let g = 0; g < growSegments; g++) {
            if (player.points.length < 120) {
              const tail = player.points[player.points.length - 1];
              player.points.push({ x: tail.x, y: tail.y });
            }
          }
          player.size = 8 + Math.sqrt(player.score) * 0.4;

          // Broadcast sync to ensure other players receive immediate delta updates
          if (food.isStarChip && chipsEarned > 0) {
            io.to(`arena_${currentArenaId}`).emit('food_eaten_sync', {
              playerId: player.id,
              foodId: food.id,
              chipsEarned
            });
          }
        }
      }
    });

    // 3. Team Beacons Replication
    socket.on('place_beacon', (data: { x: number; y: number; code: string; type: 'coop' | 'danger' }) => {
      if (!currentArenaId) return;
      socket.to(`arena_${currentArenaId}`).emit('beacon_placed', {
        id: `beacon-${Date.now()}-${playerId.substring(0, 4)}`,
        ...data,
        sender: playerId
      });
    });

    // 4. Real-time Protected Chat bubbles
    socket.on('send_chat', (data: { message: string }) => {
      if (mutedSocketIds.has(playerId)) {
        socket.emit('chat_received', { id: 'system', message: 'You have been muted by server overseers.' });
        return;
      }
      if (!currentArenaId || !data.message.trim()) return;
      const cleanMessage = data.message.substring(0, 80); // Size-limit input
      
      const room = arenaRooms.get(currentArenaId);
      if (room) {
        const player = room.players.get(playerId);
        if (player) {
          player.chatMessage = cleanMessage;
          player.chatTimer = 2500; // Display for 2.5 seconds on server
        }
      }

      io.to(`arena_${currentArenaId}`).emit('chat_received', {
        id: playerId,
        message: cleanMessage
      });
    });

    // 5. Cleanup
    socket.on('disconnect', () => {
      if (currentArenaId) {
        const room = arenaRooms.get(currentArenaId);
        if (room) {
          const player = room.players.get(playerId);
          if (player) {
            addLog(`Player offline: ${player.name} (${player.userTag}) left room "${currentArenaId}"`);
            
            // Save current stats to Firestore on disconnect to ensure durability
            if (!player.isDead) {
              const activeUserTag = player.userTag;
              db.doc('players/' + activeUserTag).set({
                lifetimeKills: serverTimestamp() // triggers a lightweight serverTimestamp merge, keeping it synced
              }, { merge: true }).catch(err => console.error(err));
            }

            room.players.delete(playerId);
          }
        }
        io.to(`arena_${currentArenaId}`).emit('player_left', { id: playerId });
      }
    });
  });

  // --- 4. GAME STATE TICK INTERVENTIONS (Authoritative Physics Loop at 60Hz) ---

  setInterval(async () => {
    for (const [arenaId, room] of arenaRooms.entries()) {
      room.gameTimeElapsed += 16.67;
      room.frameCount = (room.frameCount || 0) + 1;
      const arenaConfig = SERVER_ARENAS[arenaId] || { botsCount: 12, buyIn: 10, minExtract: 15, rewardMultiplier: 1.0 };

      // 1. Organic Spawning of Powerups (Max 4 per room) - DISABLED as requested
      if (false) {
        const types: ('shield' | 'magnet' | 'double')[] = ['shield', 'magnet', 'double'];
        const chosenType = types[Math.floor(Math.random() * types.length)];
        const colors = { shield: '#06b6d4', magnet: '#a855f7', double: '#fbbf24' };
        // Spawn actual powerup inside circular bounds
        const currentRadius = getMapRadius(room.gameTimeElapsed) - 200;
        const spawnAngle = Math.random() * Math.PI * 2;
        const spawnDist = Math.sqrt(Math.random()) * currentRadius;
        const powerupX = WORLD_SIZE / 2 + Math.cos(spawnAngle) * spawnDist;
        const powerupY = WORLD_SIZE / 2 + Math.sin(spawnAngle) * spawnDist;
        const id = `powerup-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
        
        room.powerUps.set(id, {
          id,
          x: powerupX,
          y: powerupY,
          type: chosenType as any,
          color: (colors as any)[chosenType],
          pulse: 0
        });
      }

      // Tick powerups pulse animations
      room.powerUps.forEach(p => p.pulse = (p.pulse + 0.05) % (Math.PI * 2));

      // 2. Boss Spawner Condition Check
      if (room.gameTimeElapsed > 40000 && !room.bossSpawned) {
        room.bossSpawned = true;
        room.bossAlert = "ALERT: Elite Hunter 'THE CORRUPTOR' has breached the shard! 💀👑";
        
        // Spawn actual boss bot
        const bossId = 'boss-corruptor';
        const bossX = WORLD_SIZE / 2 + (Math.random() < 0.5 ? -400 : 400);
        const bossY = WORLD_SIZE / 2 + (Math.random() < 0.5 ? -400 : 400);
        const bossAngle = Math.random() * Math.PI * 2;

        const bossBot: BotSession = {
          id: bossId,
          name: '💀 THE CORRUPTOR [BOSS]',
          points: generateInitialBody(bossX, bossY, bossAngle, 30), // Extremely long snake!
          angle: bossAngle,
          targetAngle: bossAngle,
          speed: 3.3,
          size: 20,
          color: '#f43f5e',
          secondaryColor: '#ec4899',
          isBot: true,
          isPlayer: false,
          botType: 'hunter',
          carriedChips: 200, // Juicy boss bounty!
          isExtracting: false,
          extractionProgress: 0,
          score: 30,
          isDead: false,
          spawnProtectedTimer: 0,
          chatMessage: "None shall extract alive! 💀🐍",
          chatTimer: 4000
        };
        room.bots.set(bossId, bossBot);
      }

      // 3. Process Player Mechanics (Movements, Boosts, Extractions, Timers)
      room.players.forEach((p) => {
        if (p.isDead) return;

        p.frameCount = (p.frameCount || 0) + 1;

        // Tick down player timers
        if (p.spawnProtectedTimer > 0) p.spawnProtectedTimer = Math.max(0, p.spawnProtectedTimer - 16.67);
        if (p.magnetTimer > 0) p.magnetTimer = Math.max(0, p.magnetTimer - 16.67);
        if (p.doubleTimer > 0) p.doubleTimer = Math.max(0, p.doubleTimer - 16.67);
        if (p.freezeTimer > 0) p.freezeTimer = Math.max(0, p.freezeTimer - 16.67);
        if (p.chatTimer && p.chatTimer > 0) p.chatTimer -= 16.67;

        // Steering lerp (Size-dependent turning radius matching client exactly)
        let angleDiff = p.targetAngle - p.angle;
        while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
        while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
        const baseTurnSpeed = 0.15;
        const turnFactor = Math.max(0.045, baseTurnSpeed - (p.score * 0.0006));
        p.angle += angleDiff * turnFactor;

        // Resolved authoritative speed (Doubled speed of snake and boost!)
        if (p.isExtracting) {
          p.speed = 3.2; // Graceful forward glide while extracting
        } else {
          p.speed = p.wantsBoost && p.points.length > 8 ? 11.6 : 6.4;
        }

        // Boost consumption - steady, continuous stream of food drops (every 20 frames)
        if (p.wantsBoost && !p.isExtracting && p.points.length > 8) {
          if (p.frameCount % 40 === 0) {
            const tail = p.points.pop();
            if (tail) {
              p.score = Math.max(8, p.score - 1);
              p.size = 8 + Math.sqrt(p.score) * 0.4;
              const foodId = `food-boost-${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
              addFoodToRoom(room, foodId, {
                id: foodId,
                x: tail.x,
                y: tail.y,
                size: 4 + Math.random() * 3,
                value: 1,
                isStarChip: false,
                color: p.color
              });
            }
          }
        }

        // Advance snake vector coordinates
        const head = p.points[0];
        const nextHeadX = head.x + Math.cos(p.angle) * p.speed;
        const nextHeadY = head.y + Math.sin(p.angle) * p.speed;

        // Butter-smooth, unbreakable Slither.io trailing physics!
        const currentSpacing = 5.2 + (p.size * 0.13);
        const newPoints = [{ x: nextHeadX, y: nextHeadY }];
        for (let i = 0; i < p.points.length - 1; i++) {
          const prev = newPoints[i]; // newly-calculated position of segment before this one
          const curr = p.points[i + 1]; // old position of this segment
          const dx = curr.x - prev.x;
          const dy = curr.y - prev.y;
          const dist = Math.hypot(dx, dy) || 0.001;

          // Position it exactly currentSpacing distance behind the preceding segment
          newPoints.push({
            x: prev.x + (dx / dist) * currentSpacing,
            y: prev.y + (dy / dist) * currentSpacing
          });
        }
        p.points = newPoints;

        // Circular boundary world wall collision check
        const distFromCenter = Math.hypot(nextHeadX - WORLD_SIZE / 2, nextHeadY - WORLD_SIZE / 2);
        const currentRadius = getMapRadius(room.gameTimeElapsed);
        if (distFromCenter > currentRadius) {
          p.isDead = true;
          addLog(`WALL COLLISION: Human ${p.name} died by colliding with circular world border.`);
          spawnSnakeDeathBounty(p, room, true); // true for isBoundaryDeath, meaning drop stars but no food
          io.to(`arena_${arenaId}`).emit('player_died', { victimId: p.id, killerId: 'wall', killerName: 'Boundary' });
          handlePlayerDeathFirestore(p, arenaConfig.buyIn);
          room.players.delete(p.id);
        }
      });

      // 4. Process Bot AI, Physics, and Boundary Collisions
      room.bots.forEach((b) => {
        if (b.isDead) return;

        // Decelerate bot timers
        if (b.spawnProtectedTimer > 0) b.spawnProtectedTimer = Math.max(0, b.spawnProtectedTimer - 16.67);
        if (b.chatTimer && b.chatTimer > 0) b.chatTimer -= 16.67;

        // AI Logic Steering Calculations
        let targetAngle = b.angle;
        b.speed = 4.5 + Math.random() * 1.0; // Safe, balanced base speed matching offline mode

        // Get nearest food/chips
        const nearestFood = findClosestFoodServer(b, Array.from(room.foods.values()), 350);

        if (b.botType === 'ally') {
          // Guard closest human player
          let closestPlayer: PlayerSession | null = null;
          let minPDist = 500;
          room.players.forEach(p => {
            const d = Math.hypot(p.points[0].x - b.points[0].x, p.points[0].y - b.points[0].y);
            if (d < minPDist) {
              minPDist = d;
              closestPlayer = p;
            }
          });

          if (closestPlayer) {
            const plHead = (closestPlayer as PlayerSession).points[0];
            if (minPDist > 150) {
              targetAngle = Math.atan2(plHead.y - b.points[0].y, plHead.x - b.points[0].x);
              b.speed = 5.0; // Balanced ally speed matching offline
            } else {
              targetAngle = (closestPlayer as PlayerSession).angle + Math.PI / 2;
            }
          } else if (nearestFood) {
            targetAngle = Math.atan2(nearestFood.y - b.points[0].y, nearestFood.x - b.points[0].x);
          }
        } else if (b.botType === 'coward') {
          // Flee closest human head
          let closestPlayerHead: { x: number; y: number } | null = null;
          let minPDist = 200;
          room.players.forEach(p => {
            const d = Math.hypot(p.points[0].x - b.points[0].x, p.points[0].y - b.points[0].y);
            if (d < minPDist) {
              minPDist = d;
              closestPlayerHead = p.points[0];
            }
          });

          if (closestPlayerHead) {
            targetAngle = Math.atan2(b.points[0].y - closestPlayerHead.y, b.points[0].x - closestPlayerHead.x);
            b.speed = 5.5; // Balanced coward speed
          } else if (nearestFood) {
            targetAngle = Math.atan2(nearestFood.y - b.points[0].y, nearestFood.x - b.points[0].x);
          }
        } else if (b.botType === 'hunter') {
          // Target closest human body segment to cut them off
          let closestPlayer: PlayerSession | null = null;
          let minPDist = 300;
          room.players.forEach(p => {
            const d = Math.hypot(p.points[0].x - b.points[0].x, p.points[0].y - b.points[0].y);
            if (d < minPDist) {
              minPDist = d;
              closestPlayer = p;
            }
          });

          if (closestPlayer) {
            const targetPt = (closestPlayer as PlayerSession).points[0];
            targetAngle = Math.atan2(targetPt.y - b.points[0].y, targetPt.x - b.points[0].x);
            b.speed = 5.8; // Balanced hunting speed boost
          } else if (nearestFood) {
            targetAngle = Math.atan2(nearestFood.y - b.points[0].y, nearestFood.x - b.points[0].x);
          }
        } else if (b.botType === 'extractor' && b.carriedChips > arenaConfig.minExtract) {
          // Move towards closest boundary wall to "mock extract"
          const distToLeft = b.points[0].x;
          const distToRight = WORLD_SIZE - b.points[0].x;
          const distToTop = b.points[0].y;
          const distToBottom = WORLD_SIZE - b.points[0].y;
          const minDist = Math.min(distToLeft, distToRight, distToTop, distToBottom);

          if (minDist < 80) {
            b.speed = 0;
            b.isExtracting = true;
            b.extractionProgress += 16.67;
            if (b.extractionProgress >= 3000) {
              b.isDead = true;
              addLog(`BOT EXTRACTED: AI Extractor ${b.name} extracted with ${b.carriedChips} chips.`);
              io.to(`arena_${arenaId}`).emit('player_left', { id: b.id });
              room.bots.delete(b.id);
              return;
            }
          } else {
            if (minDist === distToLeft) targetAngle = Math.PI;
            else if (minDist === distToRight) targetAngle = 0;
            else if (minDist === distToTop) targetAngle = -Math.PI / 2;
            else targetAngle = Math.PI / 2;
          }
        } else {
          // Scavenger / opportunist: pursue food
          if (nearestFood) {
            targetAngle = Math.atan2(nearestFood.y - b.points[0].y, nearestFood.x - b.points[0].x);
          } else if (Math.random() < 0.02) {
            targetAngle = b.angle + (Math.random() - 0.5) * 1.5;
          }
        }

        // Avoid circular boundaries dynamically
        const head = b.points[0];
        const distFromCenter = Math.hypot(head.x - WORLD_SIZE / 2, head.y - WORLD_SIZE / 2);
        const currentRadius = getMapRadius(room.gameTimeElapsed);
        if (distFromCenter > currentRadius - 250) {
          targetAngle = Math.atan2(WORLD_SIZE / 2 - head.y, WORLD_SIZE / 2 - head.x);
        }

        // --- Smart Body Collision Avoidance for Bots on Server ---
        let avoidAngleX = 0;
        let avoidAngleY = 0;
        let nearSegmentsCount = 0;

        // Check human players and other bots
        const activeSnakesInRoom: any[] = [];
        room.players.forEach(p => { if (!p.isDead) activeSnakesInRoom.push(p); });
        room.bots.forEach(bot => { if (!bot.isDead && bot.id !== b.id) activeSnakesInRoom.push(bot); });

        activeSnakesInRoom.forEach((other) => {
          other.points.forEach((seg, sIdx) => {
            if (sIdx % 4 !== 0) return; // optimization
            
            const dx = seg.x - head.x;
            const dy = seg.y - head.y;
            const dist = Math.hypot(dx, dy);

            if (dist < 180) { // Increased awareness range for fast movement
              const angleToSeg = Math.atan2(dy, dx);
              let angleDiffToSeg = angleToSeg - b.angle;
              while (angleDiffToSeg < -Math.PI) angleDiffToSeg += Math.PI * 2;
              while (angleDiffToSeg > Math.PI) angleDiffToSeg -= Math.PI * 2;

              if (Math.abs(angleDiffToSeg) < 1.3) {
                avoidAngleX -= dx / (dist * dist);
                avoidAngleY -= dy / (dist * dist);
                nearSegmentsCount++;
              }
            }
          });
        });

        if (nearSegmentsCount > 0) {
          targetAngle = Math.atan2(avoidAngleY, avoidAngleX);
          if (Math.random() < 0.12 && b.points.length > 15) {
            b.speed = 5.0; // Balanced escape boost
          } else {
            b.speed = 3.2; // Balanced escape speed
          }
        }

        // Smooth rotation steer lerp (agile for small, majestic turn arcs for large bots)
        let botDiff = targetAngle - b.angle;
        while (botDiff < -Math.PI) botDiff += Math.PI * 2;
        while (botDiff > Math.PI) botDiff -= Math.PI * 2;
        const baseBotTurnSpeed = Math.max(0.05, 0.15 - (b.score * 0.0006));
        // Triple turn rate responsiveness when actively avoiding obstacles to guarantee safety
        const botTurnSpeed = nearSegmentsCount > 0 ? baseBotTurnSpeed * 3.5 : baseBotTurnSpeed;
        b.angle += botDiff * botTurnSpeed;

        // Check freeze slow effect on enemies
        let currentBotSpeed = b.speed;
        let pFreezeActive = false;
        room.players.forEach(p => { if (p.freezeTimer > 0) pFreezeActive = true; });
        if (pFreezeActive && b.botType !== 'ally') {
          currentBotSpeed *= 0.45;
        }

        // Advance position vectors
        const nextHeadX = head.x + Math.cos(b.angle) * currentBotSpeed;
        const nextHeadY = head.y + Math.sin(b.angle) * currentBotSpeed;

        // Butter-smooth, unbreakable Slither.io trailing physics!
        const currentSpacing = 5.2 + (b.size * 0.13);
        const newPoints = [{ x: nextHeadX, y: nextHeadY }];
        for (let i = 0; i < b.points.length - 1; i++) {
          const prev = newPoints[i];
          const curr = b.points[i + 1];
          const dx = curr.x - prev.x;
          const dy = curr.y - prev.y;
          const dist = Math.hypot(dx, dy) || 0.001;

          newPoints.push({
            x: prev.x + (dx / dist) * currentSpacing,
            y: prev.y + (dy / dist) * currentSpacing
          });
        }
        b.points = newPoints;

        // Circular boundary death
        const deathDistFromCenter = Math.hypot(nextHeadX - WORLD_SIZE / 2, nextHeadY - WORLD_SIZE / 2);
        const deathCurrentRadius = getMapRadius(room.gameTimeElapsed);
        if (deathDistFromCenter > deathCurrentRadius) {
          b.isDead = true;
          addLog(`WALL COLLISION: Bot ${b.name} hit circular world border and died.`);
          spawnSnakeDeathBounty(b, room, true); // true for isBoundaryDeath, meaning bots directly vanish (no drops)
          io.to(`arena_${arenaId}`).emit('player_died', { victimId: b.id, killerId: 'wall', killerName: 'Boundary' });
          room.bots.delete(b.id);
        }
      });

      // 5. Authoritative Food Collection (Check proximity of all active snakes)
      room.foods.forEach((food, foodId) => {
        let eaten = false;

        // Proximity checks
        // First check human players
        for (const [pId, p] of room.players.entries()) {
          if (p.isDead) continue;
          
          const pHead = p.points[0];

          // Magnet Attraction Pull on Player
          if (p.magnetTimer > 0) {
            const dist = Math.hypot(food.x - pHead.x, food.y - pHead.y);
            if (dist < 160) {
              const pullSpeed = (160 - dist) * 0.15;
              const angle = Math.atan2(pHead.y - food.y, pHead.x - food.x);
              food.x += Math.cos(angle) * pullSpeed;
              food.y += Math.sin(angle) * pullSpeed;
            }
          }

          const distToHead = Math.hypot(food.x - pHead.x, food.y - pHead.y);
          if (distToHead < p.size + 4) {
            eaten = true;
            
            // Apply double powerup multiplier on star chip value
            let chipsEarned = food.isStarChip ? food.value : 0;
            if (food.isStarChip && p.doubleTimer > 0) {
              chipsEarned *= 2;
            }

            p.carriedChips += chipsEarned;
            
            // Grow snake (fatness thickness scales, body segment length is capped)
            const segmentsToGrow = food.isStarChip ? 3 : 1;
            p.score += segmentsToGrow;
            for (let i = 0; i < segmentsToGrow; i++) {
              if (p.points.length < 120) {
                const tail = p.points[p.points.length - 1] || pHead;
                p.points.push({ x: tail.x, y: tail.y });
              }
            }
            p.size = 8 + Math.sqrt(p.score) * 0.4;

            io.to(`arena_${arenaId}`).emit('food_eaten', { foodId, eaterId: pId });
            break;
          }
        }

        // If not eaten by players, check bots
        if (!eaten) {
          for (const [bId, b] of room.bots.entries()) {
            if (b.isDead) continue;
            
            const bHead = b.points[0];
            const distToHead = Math.hypot(food.x - bHead.x, food.y - bHead.y);
            if (distToHead < b.size + 4) {
              eaten = true;

              b.carriedChips += food.isStarChip ? food.value : 0;

              // Grow bot (fatness thickness scales, body segment length is capped)
              const segmentsToGrow = food.isStarChip ? 3 : 1;
              b.score += segmentsToGrow;
              for (let i = 0; i < segmentsToGrow; i++) {
                if (b.points.length < 120) {
                  const tail = b.points[b.points.length - 1] || bHead;
                  b.points.push({ x: tail.x, y: tail.y });
                }
              }
              const baseBotSize = (b as any).botType === 'boss' ? 16 : 7;
              b.size = baseBotSize + Math.sqrt(b.score) * 0.4;

              io.to(`arena_${arenaId}`).emit('food_eaten', { foodId, eaterId: bId });
              break;
            }
          }
        }

        // Delete from server state and respawn
        if (eaten) {
          removeFoodFromRoom(room, foodId);
          populateRoomFood(room);
        }
      });

      // 6. Authoritative PowerUp Collection (Players only)
      room.powerUps.forEach((pUp, pUpId) => {
        for (const [pId, p] of room.players.entries()) {
          if (p.isDead) continue;

          const pHead = p.points[0];
          const dist = Math.hypot(pUp.x - pHead.x, pUp.y - pHead.y);

          if (dist < p.size + 15) {
            // Apply secure powerup timer
            if (pUp.type === 'shield') {
              p.shieldActive = true;
            } else if (pUp.type === 'magnet') {
              p.magnetTimer = 10000;
            } else if (pUp.type === 'double') {
              p.doubleTimer = 12000;
            } else if (pUp.type === 'freeze') {
              p.freezeTimer = 8000;
            }

            // Emit collect notice
            io.to(`arena_${arenaId}`).emit('powerup_collected', {
              playerId: pId,
              powerUpId: pUpId,
              type: pUp.type,
              color: pUp.color,
              x: pUp.x,
              y: pUp.y
            });

            room.powerUps.delete(pUpId);
            break;
          }
        }
      });

      // 7. Authoritative Snake-to-Snake Collision Detection
      const allSnakes: any[] = [
        ...Array.from(room.players.values()),
        ...Array.from(room.bots.values())
      ];

      allSnakes.forEach((snakeA) => {
        if (snakeA.isDead || snakeA.points.length === 0) return;
        if (snakeA.spawnProtectedTimer > 0) return; // Ghosted / Spawn Protected

        const head = snakeA.points[0];

        allSnakes.forEach((snakeB) => {
          if (snakeA.id === snakeB.id) return; // Completely disable self-collisions to match offline mode!
          if (snakeB.isDead || snakeB.points.length === 0) return;
          if (snakeB.spawnProtectedTimer > 0) return;

          // Target points segments to collide with
          const targetPoints = snakeB.points;

          for (let i = 0; i < targetPoints.length; i++) {
            const pt = targetPoints[i];
            const dist = Math.hypot(head.x - pt.x, head.y - pt.y);
            const radiusA = snakeA.size || 16;
            const radiusB = snakeB.size || 16;

            if (dist < (radiusA + radiusB) * 0.75) {
              // Authoritative intersection death!
              snakeA.isDead = true;
              addLog(`COLLISION: Snake "${snakeA.name}" crashed into "${snakeB.name}"! Authorized death.`);
              
              spawnSnakeDeathBounty(snakeA, room);

              // Notify room
              io.to(`arena_${arenaId}`).emit('player_died', {
                victimId: snakeA.id,
                killerId: snakeB.id,
                killerName: snakeB.name
              });

              // Credit killer with a kill if human
              if (snakeB.isPlayer && snakeA.id !== snakeB.id) {
                snakeB.kills++;
                io.to(snakeB.id).emit('kill_confirmed', { victimName: snakeA.name });
              }

              // Firestore transactional save if human victim
              if (snakeA.isPlayer) {
                handlePlayerDeathFirestore(snakeA, arenaConfig.buyIn);
                room.players.delete(snakeA.id);
              } else {
                room.bots.delete(snakeA.id);
              }
              break;
            }
          }
        });
      });

      // 8. Secure Authoritative Extraction Ticks
      room.players.forEach((p) => {
        if (p.isDead) return;

        if (p.isExtracting) {
          p.extractionProgress += 16.67;
          
          if (p.extractionProgress >= 3000) {
            // Payout calculation
            p.isDead = true;
            const rawPayout = p.carriedChips;
            const finalP = Math.floor(rawPayout * 0.65); // 35% commission
            const xpReward = Math.floor((p.score * 5 + p.kills * 50) * arenaConfig.rewardMultiplier);

            addLog(`EXTRACTION APPROVED: Human ${p.name} (${p.userTag}) safely extracted ${rawPayout} chips (Retained: ${finalP} after commission, XP: ${xpReward})`);

            io.to(`arena_${arenaId}`).emit('player_extracted', {
              id: p.id,
              userTag: p.userTag,
              retainedChips: finalP,
              xpReward
            });

            // Handle transaction writing to database
            handlePlayerExtractionFirestore(p, finalP, xpReward);
            room.players.delete(p.id);
          }
        } else {
          p.extractionProgress = 0;
        }
      });

      // 9. Server-Authoritative Bot Spawner (Respawn bot inside circular bounds to keep arena full)
      const nonAllyBots = Array.from(room.bots.values()).filter(b => b.botType !== 'ally');
      if (nonAllyBots.length < arenaConfig.botsCount) {
        const respawnId = `bot-${Date.now()}-${Math.floor(Math.random() * 1000000)}`;
        const spawnRadius = 3500;
        const spawnAngle = Math.random() * Math.PI * 2;
        const spawnDist = Math.sqrt(Math.random()) * spawnRadius;
        const startX = WORLD_SIZE / 2 + Math.cos(spawnAngle) * spawnDist;
        const startY = WORLD_SIZE / 2 + Math.sin(spawnAngle) * spawnDist;
        const botAngle = Math.random() * Math.PI * 2;
        const botSkin = BOT_SKINS[Math.floor(Math.random() * BOT_SKINS.length)];
        const aiStyles: ('scavenger' | 'opportunist' | 'hunter' | 'extractor' | 'coward')[] = [
          'scavenger', 'opportunist', 'hunter', 'extractor', 'coward'
        ];
        const botType = aiStyles[Math.floor(Math.random() * aiStyles.length)];

        const newBot: BotSession = {
          id: respawnId,
          name: `${BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)]} [AI]`,
          points: generateInitialBody(startX, startY, botAngle),
          angle: botAngle,
          targetAngle: botAngle,
          speed: 2.2 + Math.random() * 0.8,
          size: 7 + Math.random() * 1.5,
          color: botSkin.color,
          secondaryColor: botSkin.secondaryColor,
          isBot: true,
          isPlayer: false,
          botType,
          carriedChips: 0,
          isExtracting: false,
          extractionProgress: 0,
          score: INITIAL_BODY_LENGTH,
          isDead: false,
          spawnProtectedTimer: 4000
        };
        room.bots.set(respawnId, newBot);
      }

      // 10. Frame Broadcast (Emits Room State at 30Hz - every second physics frame)
      // This reduces network payload by 50% compared to 60Hz, ensuring buttery smooth interpolation!
      const broadcastIntervalFrame = room.frameCount % 2 === 0;
      if (broadcastIntervalFrame) {
        const snakesPayload = [
          ...Array.from(room.players.values()).map(p => ({
            id: p.id,
            name: p.name,
            userTag: p.userTag,
            points: p.points,
            angle: p.angle,
            speed: p.speed,
            size: p.size,
            carriedChips: p.carriedChips,
            score: p.score,
            isDead: p.isDead,
            isExtracting: p.isExtracting,
            extractionProgress: p.extractionProgress,
            color: p.color,
            secondaryColor: p.secondaryColor,
            isBot: false,
            spawnProtectedTimer: p.spawnProtectedTimer,
            chatMessage: p.chatMessage,
            chatTimer: p.chatTimer ? Math.ceil(p.chatTimer / 1000) : undefined
          })),
          ...Array.from(room.bots.values()).map(b => ({
            id: b.id,
            name: b.name,
            userTag: 'AI_BOT',
            points: b.points,
            angle: b.angle,
            speed: b.speed,
            size: b.size,
            carriedChips: b.carriedChips,
            score: b.score,
            isDead: b.isDead,
            isExtracting: b.isExtracting,
            extractionProgress: b.extractionProgress,
            color: b.color,
            secondaryColor: b.secondaryColor,
            isBot: true,
            botType: b.botType,
            spawnProtectedTimer: b.spawnProtectedTimer,
            chatMessage: b.chatMessage,
            chatTimer: b.chatTimer ? Math.ceil(b.chatTimer / 1000) : undefined
          }))
        ];

        // Authoritative Real-Time Leaderboard Calculations (Top 10 snakes by score)
        const sortedLeaderboard = [...snakesPayload]
          .filter(s => !s.isDead)
          .sort((a, b) => b.score - a.score)
          .slice(0, 10)
          .map((s, index) => ({
            rank: index + 1,
            name: s.name,
            score: s.score,
            carriedChips: s.carriedChips,
            isPlayer: s.userTag !== 'AI_BOT'
          }));

        // Optimized AOI (Area of Interest) Broadcast: Emits customized, lightweight payloads to each player
        room.players.forEach((player, playerId) => {
          const socket = io.sockets.sockets.get(playerId);
          if (socket) {
            const playerHead = player.points[0];
            let nearbySnakes = snakesPayload;
            let nearbyAddedFoods = Array.from(room.addedFoods.values());
            
            if (playerHead) {
              // 1800px is more than enough for full viewport coverage. Faraway snakes are pruned.
              nearbySnakes = snakesPayload.filter((s) => {
                if (s.id === playerId) return true;
                const head = s.points[0];
                if (!head) return false;
                const dist = Math.hypot(head.x - playerHead.x, head.y - playerHead.y);
                return dist < 1800;
              });
              
              // Only send added foods within 2000px of player to save bandwidth
              nearbyAddedFoods = Array.from(room.addedFoods.values()).filter(f => {
                return Math.hypot(f.x - playerHead.x, f.y - playerHead.y) < 2000;
              });
            }

            socket.emit('room_state', {
              snakes: nearbySnakes,
              addedFoods: nearbyAddedFoods,
              removedFoods: Array.from(room.removedFoods),
              powerUps: Array.from(room.powerUps.values()),
              bossSpawned: room.bossSpawned,
              bossAlert: room.bossAlert,
              leaderboard: sortedLeaderboard,
              activeRealPlayersCount: room.players.size
            });
          }
        });

        // Clear incremental food buffers after broadcasting to all active players
        room.addedFoods.clear();
        room.removedFoods.clear();

        // Reset temporary alerts
        room.bossAlert = null;
      }
    }
  }, 16.67);

  // --- 5. FIRESTORE TRANS-SECURE HELPERS ---

  async function handlePlayerDeathFirestore(p: PlayerSession, buyIn: number) {
    try {
      const playerRef = db.doc('players/' + p.userTag);
      const playerDoc = await playerRef.get();
      if (playerDoc.exists) {
        const stats = playerDoc.data();
        const currentKills = stats?.lifetimeKills || 0;
        const currentDeaths = stats?.lifetimeDeaths || 0;

        await playerRef.set({
          lifetimeDeaths: currentDeaths + 1,
          lifetimeKills: currentKills + p.kills,
          bestStreak: 0 // Reset daily stream/streak on death
        }, { merge: true });

        addLog(`Database updated (DEATH): Player ${p.name} (${p.userTag}). Lifetime Deaths: ${currentDeaths + 1}, Session Kills: ${p.kills}`);
      }
    } catch (err) {
      console.error(`Failed to record death stats for ${p.userTag} in Firestore:`, err);
    }
  }

  async function handlePlayerExtractionFirestore(p: PlayerSession, retainedChips: number, xpReward: number) {
    try {
      const playerRef = db.doc('players/' + p.userTag);
      const playerDoc = await playerRef.get();
      if (playerDoc.exists) {
        const stats = playerDoc.data();
        const currentChips = stats?.bankedChips || 0;
        const currentExtracts = stats?.lifetimeExtracts || 0;
        const currentEarned = stats?.totalChipsEarned || 0;
        const currentKills = stats?.lifetimeKills || 0;
        const biggestExtract = stats?.biggestExtract || 0;
        
        let newXp = (stats?.xp || 0) + xpReward;
        let newLevel = stats?.level || 1;
        const xpNeeded = newLevel * 200;
        
        if (newXp >= xpNeeded) {
          newXp -= xpNeeded;
          newLevel += 1;
        }

        const nextBanked = currentChips + retainedChips;

        await playerRef.set({
          bankedChips: nextBanked,
          lifetimeExtracts: currentExtracts + 1,
          lifetimeKills: currentKills + p.kills,
          biggestExtract: Math.max(biggestExtract, retainedChips),
          totalChipsEarned: currentEarned + retainedChips,
          xp: newXp,
          level: newLevel
        }, { merge: true });

        addLog(`Database updated (EXTRACTION): Player ${p.name} (${p.userTag}). Banked chips: ${nextBanked}, XP: ${newXp}, Level: ${newLevel}`);
      }
    } catch (err) {
      console.error(`Failed to record extraction rewards for ${p.userTag} in Firestore:`, err);
    }
  }


  // Serve static assets in development & production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  server.listen(PORT, '0.0.0.0', () => {
    addLog(`Fullstack Multi-Lobby Server booted on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('[CRITICAL] Server crashed during startup:', error);
});
