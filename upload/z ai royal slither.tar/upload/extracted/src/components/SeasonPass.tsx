import React, { useState } from 'react';
import { Award, Star, Lock, Check, Sparkles, Trophy, Zap, Shield, Gift } from 'lucide-react';
import { PlayerStats } from '../types';

interface PassRewardTier {
  tier: number;
  xpRequired: number;
  freeReward: { title: string; category: string; icon: string };
  eliteReward: { title: string; category: string; skinName?: string; icon: string };
}

const COSMETIC_FREE_REWARDS = [
  { title: 'Neon Viper Badge', category: 'Badge', icon: '🏷️' },
  { title: 'Cyber Pulse Trail FX', category: 'Tail FX', icon: '⚡' },
  { title: 'Green Venom Frame', category: 'Avatar Border', icon: '🖼️' },
  { title: 'Serpent Whispers SFX', category: 'Kill Sound', icon: '🔊' },
  { title: 'Genesis Pioneer Title', category: 'Title', icon: '🎖️' },
  { title: 'Bio-Hazard Emote Spray', category: 'Spray', icon: '🎨' },
  { title: 'Emerald Tail Glow', category: 'Tail FX', icon: '✨' },
  { title: 'Cobra Strike Taunt', category: 'Emote', icon: '🐍' },
  { title: 'Cyber Samurai Border', category: 'Avatar Border', icon: '⚔️' },
  { title: 'Toxic Acid DNA Skin', category: 'DNA Skin', icon: '🧪' },
  { title: 'Quantum Grid Avatar', category: 'Profile Icon', icon: '🌐' },
  { title: 'Apex Vanguard Emblem', category: 'Badge', icon: '🛡️' },
  { title: 'Neon Matrix Audio FX', category: 'Kill Sound', icon: '🎵' },
  { title: 'Plasma Arc Tail Trail', category: 'Tail FX', icon: '⚡' },
  { title: 'Cyber Warlord Title', category: 'Title', icon: '👑' },
  { title: 'Solar Flare Emote', category: 'Emote', icon: '☀️' },
  { title: 'Titanium Viper Skin', category: 'DNA Skin', icon: '🦾' },
  { title: 'Cyber Void Frame', category: 'Avatar Border', icon: '🌌' },
  { title: 'Genesis Immortal Badge', category: 'Badge', icon: '🏆' },
  { title: 'Genesis Master DNA Skin', category: 'DNA Skin', icon: '🐉' }
];

const COSMETIC_ELITE_REWARDS = [
  { title: 'Cyber Serpent God Skin', category: 'DNA Skin', skinName: 'Cyber Serpent God', icon: '👑' },
  { title: 'Hyper Plasma Arc FX', category: 'Tail FX', icon: '⚡' },
  { title: 'Cyber Siren Roar SFX', category: 'Kill Sound', icon: '🔊' },
  { title: 'Royal Throne Taunt', category: 'Emote', icon: '🛋️' },
  { title: '1 Crore Immortal Badge', category: 'Badge', icon: '🎖️' },
  { title: 'Modular Venom DNA Skin', category: 'DNA Skin', skinName: 'Modular Venom DNA', icon: '🐍' },
  { title: 'Holo-Shield Tail Aura', category: 'Tail FX', icon: '🛡️' },
  { title: 'Golden Viper Frame', category: 'Avatar Border', icon: '🖼️' },
  { title: 'Galactic Overlord Title', category: 'Title', icon: '🌌' },
  { title: 'Dark Matter DNA Skin', category: 'DNA Skin', skinName: 'Dark Matter DNA', icon: '🌑' },
  { title: 'Celestial Fire Trail', category: 'Tail FX', icon: '🔥' },
  { title: 'Apex Predator Emblem', category: 'Badge', icon: '🦅' },
  { title: 'Cyber Phantom Skin', category: 'DNA Skin', skinName: 'Cyber Phantom', icon: '👻' },
  { title: 'Supernova Explosion SFX', category: 'Kill Sound', icon: '💥' },
  { title: 'Emperor\'s Crown Frame', category: 'Avatar Border', icon: '👑' },
  { title: 'Diamond Viper DNA Skin', category: 'DNA Skin', skinName: 'Diamond Viper', icon: '💎' },
  { title: 'Hyper-Drive Trail FX', category: 'Tail FX', icon: '⚡' },
  { title: 'Genesis Sovereign Title', category: 'Title', icon: '📜' },
  { title: 'Infinite Horizon Frame', category: 'Avatar Border', icon: '🎆' },
  { title: 'Serpent God Ascended', category: 'DNA Skin', skinName: 'Serpent God Ascended', icon: '🌟' }
];

const SEASON_TIERS: PassRewardTier[] = Array.from({ length: 20 }, (_, i) => {
  const tierNum = i + 1;
  return {
    tier: tierNum,
    xpRequired: tierNum * 1000,
    freeReward: COSMETIC_FREE_REWARDS[i],
    eliteReward: COSMETIC_ELITE_REWARDS[i]
  };
});

interface SeasonPassProps {
  playerStats: PlayerStats;
  onUpdatePlayerStats: (updated: Partial<PlayerStats>) => void;
  onToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export default function SeasonPass({ playerStats, onUpdatePlayerStats, onToast }: SeasonPassProps) {
  const [hasElitePass, setHasElitePass] = useState<boolean>(playerStats.level > 15);
  const [claimedFreeTiers, setClaimedFreeTiers] = useState<Set<number>>(new Set([1, 2, 3]));
  const [claimedEliteTiers, setClaimedEliteTiers] = useState<Set<number>>(new Set([1, 2]));

  const currentLevel = playerStats.level || 1;
  const currentXP = (currentLevel * 1000) - 400; // Simulated XP
  const nextLevelXP = currentLevel * 1000;

  const handleClaimFreeReward = (tier: PassRewardTier) => {
    if (claimedFreeTiers.has(tier.tier)) return;
    if (currentLevel < tier.tier) {
      onToast(`Reach Season Level ${tier.tier} to unlock this reward!`, 'error');
      return;
    }

    claimedFreeTiers.add(tier.tier);
    setClaimedFreeTiers(new Set(claimedFreeTiers));
    onToast(`Unlocked Free Cosmetic [${tier.freeReward.category}] for Tier ${tier.tier}: ${tier.freeReward.title}! 🎨`, 'success');
  };

  const handleClaimEliteReward = (tier: PassRewardTier) => {
    if (!hasElitePass) {
      onToast('Unlock Elite Cyber Pass to claim premium rewards!', 'error');
      return;
    }
    if (claimedEliteTiers.has(tier.tier)) return;
    if (currentLevel < tier.tier) {
      onToast(`Reach Season Level ${tier.tier} to unlock this reward!`, 'error');
      return;
    }

    claimedEliteTiers.add(tier.tier);
    setClaimedEliteTiers(new Set(claimedEliteTiers));
    onToast(`Unlocked ELITE Cosmetic [${tier.eliteReward.category}] for Tier ${tier.tier}: ${tier.eliteReward.title}! 👑`, 'success');
  };

  const handleBuyElitePass = () => {
    if (playerStats.bankedChips < 100000) {
      onToast('1,00,000 Banked Chips required for Elite Cyber Pass!', 'error');
      return;
    }

    onUpdatePlayerStats({ bankedChips: playerStats.bankedChips - 100000 });
    setHasElitePass(true);
    onToast('ELITE CYBER PASS UNLOCKED! Enjoy 3x Rewards & Exclusive Skins! 👑', 'success');
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-6 relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute -top-12 -right-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Season Banner */}
      <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-indigo-950 p-6 rounded-2xl border border-purple-500/30 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl relative overflow-hidden">
        <div className="space-y-2">
          <div className="flex items-center gap-2">
            <span className="bg-purple-500/20 text-purple-300 border border-purple-500/40 text-xs font-mono font-bold px-2 py-0.5 rounded uppercase">
              Season 01: Venom Genesis
            </span>
            <span className="text-xs text-amber-400 font-mono font-bold">Ends in 48 Days</span>
          </div>
          <h2 className="text-2xl font-bold font-sans tracking-tight text-white flex items-center gap-2">
            <Award className="w-7 h-7 text-yellow-400" />
            Cyber Pass & Season Progression
          </h2>
          <p className="text-xs text-slate-300 max-w-xl">
            Earn Season XP from arena extractions and daily missions to unlock 20 tiers of exclusive DNA skins, tail trails, kill sounds, avatar borders, and badges!
          </p>
        </div>

        {/* Elite Pass Upgrade Card */}
        <div className="bg-slate-950/90 p-4 rounded-xl border border-amber-500/40 space-y-2 shrink-0 min-w-[240px]">
          <div className="flex justify-between items-center text-xs font-sans">
            <span className="text-slate-300 font-bold flex items-center gap-1">
              <Sparkles className="w-4 h-4 text-amber-400" /> Pass Status
            </span>
            <span className={`font-mono font-bold text-xs ${hasElitePass ? 'text-amber-400' : 'text-slate-500'}`}>
              {hasElitePass ? '👑 ELITE PASS ACTIVE' : 'FREE PASS'}
            </span>
          </div>

          {!hasElitePass && (
            <button
              onClick={handleBuyElitePass}
              className="w-full py-2 bg-gradient-to-r from-amber-500 to-yellow-400 hover:from-amber-400 hover:to-yellow-300 text-black font-sans text-xs font-bold rounded-lg transition-all shadow-md flex items-center justify-center gap-1"
            >
              Unlock Elite Pass (1,00,000 c)
            </button>
          )}
        </div>
      </div>

      {/* Season XP Progress Bar */}
      <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
        <div className="flex justify-between items-center text-xs font-sans">
          <span className="text-white font-bold flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-indigo-400" /> Season Level {currentLevel}
          </span>
          <span className="text-slate-400 font-mono">
            {currentXP.toLocaleString()} / {nextLevelXP.toLocaleString()} XP
          </span>
        </div>
        <div className="w-full h-3 bg-slate-900 rounded-full border border-slate-800 overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-full"
            style={{ width: `${Math.min(100, (currentXP / nextLevelXP) * 100)}%` }}
          />
        </div>
      </div>

      {/* Tiers Reward Track */}
      <div className="space-y-3">
        <h3 className="text-sm font-bold text-white font-sans flex items-center gap-2">
          <Trophy className="w-4 h-4 text-yellow-400" /> Reward Tier Track (1 to 20)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 max-h-[500px] overflow-y-auto pr-1">
          {SEASON_TIERS.map((tier) => {
            const isUnlocked = currentLevel >= tier.tier;
            const isFreeClaimed = claimedFreeTiers.has(tier.tier);
            const isEliteClaimed = claimedEliteTiers.has(tier.tier);

            return (
              <div
                key={tier.tier}
                className={`p-4 rounded-2xl border flex flex-col justify-between space-y-3 transition-all ${
                  isUnlocked
                    ? 'bg-slate-950 border-slate-700 shadow-md'
                    : 'bg-slate-950/60 border-slate-900 opacity-75'
                }`}
              >
                {/* Header */}
                <div className="flex justify-between items-center border-b border-slate-900 pb-2">
                  <span className="text-xs font-mono font-bold text-amber-400">
                    TIER {tier.tier}
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {tier.xpRequired.toLocaleString()} XP
                  </span>
                </div>

                {/* Free Reward */}
                <div className="p-2.5 bg-slate-900/80 rounded-xl border border-slate-800 space-y-1">
                  <div className="flex justify-between text-[10px] font-mono text-slate-400">
                    <span>FREE TRACK</span>
                    {isFreeClaimed && <span className="text-emerald-400 font-bold">CLAIMED</span>}
                  </div>
                  <div className="text-xs font-bold text-white font-sans flex items-center gap-1.5">
                    <span>{tier.freeReward.icon}</span>
                    <span className="truncate">{tier.freeReward.title}</span>
                  </div>
                  <button
                    onClick={() => handleClaimFreeReward(tier)}
                    disabled={!isUnlocked || isFreeClaimed}
                    className={`w-full py-1 mt-1 rounded text-[10px] font-sans font-bold ${
                      isFreeClaimed
                        ? 'bg-slate-800 text-slate-500 cursor-default'
                        : isUnlocked
                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                        : 'bg-slate-900 text-slate-600'
                    }`}
                  >
                    {isFreeClaimed ? 'Claimed' : isUnlocked ? 'Claim Free' : `Reach Lvl ${tier.tier}`}
                  </button>
                </div>

                {/* Elite Reward */}
                <div className={`p-2.5 rounded-xl border space-y-1 ${
                  hasElitePass ? 'bg-amber-950/20 border-amber-500/30' : 'bg-slate-900/40 border-slate-800'
                }`}>
                  <div className="flex justify-between text-[10px] font-mono text-amber-400 font-bold">
                    <span>ELITE TRACK</span>
                    {isEliteClaimed && <span className="text-emerald-400">CLAIMED</span>}
                  </div>
                  <div className="text-xs font-bold text-amber-300 font-sans flex items-center gap-1.5">
                    <span>{tier.eliteReward.icon}</span>
                    <span className="truncate">{tier.eliteReward.title}</span>
                  </div>
                  <button
                    onClick={() => handleClaimEliteReward(tier)}
                    disabled={!isUnlocked || isEliteClaimed || !hasElitePass}
                    className={`w-full py-1 mt-1 rounded text-[10px] font-sans font-bold ${
                      isEliteClaimed
                        ? 'bg-slate-800 text-slate-500 cursor-default'
                        : isUnlocked && hasElitePass
                        ? 'bg-amber-500 hover:bg-amber-400 text-black'
                        : 'bg-slate-900 text-slate-600'
                    }`}
                  >
                    {isEliteClaimed ? 'Claimed' : !hasElitePass ? 'Requires Elite Pass' : isUnlocked ? 'Claim Elite' : `Reach Lvl ${tier.tier}`}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
