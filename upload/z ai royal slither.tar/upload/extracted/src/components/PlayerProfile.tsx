import React, { useState, useEffect, FormEvent } from 'react';
import { 
  User, Shield, Trophy, Target, Award, Skull, RefreshCw, Landmark, Coins,
  Compass, Eye, Edit2, Check, Lock, AlertTriangle, Globe, MessageSquare, 
  History, Users, UserPlus, Trash2, Calendar, Clock, Sparkles, Upload, Image, LogOut,
  Swords, X
} from 'lucide-react';
import { PlayerStats, Friend } from '../types';
import { ALL_COSMETICS, ARENA_TIERS } from '../data';
import { getFriendSimulatedChips } from './SocialPanel';

const FACTION_COUNTRIES = [
  { code: 'US', emoji: '🇺🇸', name: 'United States' },
  { code: 'GB', emoji: '🇬🇧', name: 'United Kingdom' },
  { code: 'DE', emoji: '🇩🇪', name: 'Germany' },
  { code: 'CA', emoji: '🇨🇦', name: 'Canada' },
  { code: 'JP', emoji: '🇯🇵', name: 'Japan' },
  { code: 'KR', emoji: '🇰🇷', name: 'South Korea' },
  { code: 'IN', emoji: '🇮🇳', name: 'India' },
  { code: 'AU', emoji: '🇦🇺', name: 'Australia' },
  { code: 'FR', emoji: '🇫🇷', name: 'France' },
  { code: 'BR', emoji: '🇧🇷', name: 'Brazil' },
  { code: 'SG', emoji: '🇸🇬', name: 'Singapore' },
  { code: 'NL', emoji: '🇳🇱', name: 'Netherlands' },
];

const PRESET_AVATARS = [
  { id: 'av-viper', label: 'Venomous Viper', emoji: '🐍' },
  { id: 'av-skull', label: 'Syndicate Skull', emoji: '🏴‍☠️' },
  { id: 'av-invader', label: 'Pixel Invader', emoji: '👾' },
  { id: 'av-sentinel', label: 'Cyber Sentinel', emoji: '🤖' },
  { id: 'av-king', label: 'Midas King', emoji: '👑' },
  { id: 'av-storm', label: 'Storm Surge', emoji: '⚡' },
  { id: 'av-fury', label: 'Crimson Fury', emoji: '🔥' },
  { id: 'av-nebula', label: 'Cosmic Nebula', emoji: '🌌' },
];

interface IdentityLogEntry {
  id: string;
  previousName: string;
  newName: string;
  previousCountry: string;
  newCountry: string;
  timestamp: string;
  status: 'VERIFIED' | 'APPROVED' | 'FIRST_HANDSHAKE';
}

interface MatchHistoryEntry {
  id: string;
  arenaName: string;
  isOnline: boolean;
  status: 'EXTRACTED' | 'COLLIDED';
  chipsEarned: number;
  chipsLost: number;
  kills: number;
  snakeLength: number;
  timestamp: string;
  durationSec: number;
}

interface PlayerProfileProps {
  playerStats: PlayerStats;
  onUpdateStats: (stats: Partial<PlayerStats>) => void;
  onToast: (msg: string, type: 'success' | 'info' | 'error') => void;
  onLogout?: () => void;
  onSelectArena?: (arena: any, isOnline: boolean) => void;
  onSpectateFriend?: (name: string, color: string) => void;
}

export default function PlayerProfile({ 
  playerStats, 
  onUpdateStats, 
  onToast, 
  onLogout,
  onSelectArena,
  onSpectateFriend
}: PlayerProfileProps) {
  const [activeTab, setActiveTab] = useState<'stats' | 'history' | 'friends' | 'identityLog'>('stats');
  
  // Co-Op Lobby Invite Modal States
  const [activeInviteFriend, setActiveInviteFriend] = useState<Friend | null>(null);
  const [inviteSelectedArenaId, setInviteSelectedArenaId] = useState<string>('tier-1');
  const [inviteStatusMessage, setInviteStatusMessage] = useState<{
    type: 'success' | 'warning' | 'error' | 'counter';
    text: string;
    counterArenaId?: string;
  } | null>(null);
  
  // Profile editing states
  const [isEditing, setIsEditing] = useState(false);
  const [newName, setNewName] = useState(playerStats.name);
  const [selectedCountry, setSelectedCountry] = useState(playerStats.country || 'US');
  const [selectedAvatar, setSelectedAvatar] = useState(playerStats.avatar || '');
  const [instagram, setInstagram] = useState(playerStats.instagram || '');
  const [youtube, setYoutube] = useState(playerStats.youtube || '');
  const [twitch, setTwitch] = useState(playerStats.twitch || '');
  
  // Game clip/content post inputs
  const [newPostTitle, setNewPostTitle] = useState('');
  const [newPostUrl, setNewPostUrl] = useState('');

  // Drag and drop / Custom upload states
  const [isDragging, setIsDragging] = useState(false);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processAvatarFile(files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
      processAvatarFile(files[0]);
    }
  };

  const processAvatarFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      onToast('Please select a valid image file.', 'error');
      return;
    }
    if (file.size > 1.5 * 1024 * 1024) {
      onToast('Image size exceeds 1.5MB. Please choose a smaller file.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setSelectedAvatar(event.target.result as string);
        onToast('Custom avatar selected! Save your handshake to lock it in.', 'success');
      }
    };
    reader.readAsDataURL(file);
  };

  // Friends & Match history state
  const [friends, setFriends] = useState<Friend[]>([]);
  const [matches, setMatches] = useState<MatchHistoryEntry[]>([]);
  const [identityLogs, setIdentityLogs] = useState<IdentityLogEntry[]>([]);
  const [newFriendName, setNewFriendName] = useState('');

  // Load from local storage
  useEffect(() => {
    const savedFriends = localStorage.getItem('venom_friends');
    if (savedFriends) {
      setFriends(JSON.parse(savedFriends));
    } else {
      const initial: Friend[] = [
        { id: 'f-1', name: 'ApexViper', userTag: 'APEX-1029', status: 'online', level: 42, skinColor: '#10b981', giftSentToday: false, giftReceivedToday: true },
        { id: 'f-2', name: 'ShadowSlinker', userTag: 'SLNK-9281', status: 'in-match', level: 18, skinColor: '#a855f7', giftSentToday: false, giftReceivedToday: false },
        { id: 'f-3', name: 'CoinGobbler', userTag: 'COIN-5432', status: 'offline', level: 29, skinColor: '#eab308', giftSentToday: true, giftReceivedToday: false },
        { id: 'f-4', name: 'VenomKing', userTag: 'VNOM-0001', status: 'idle', level: 55, skinColor: '#ef4444', giftSentToday: false, giftReceivedToday: false },
      ];
      setFriends(initial);
      localStorage.setItem('venom_friends', JSON.stringify(initial));
    }

    const savedMatches = localStorage.getItem('venom_match_history');
    if (savedMatches) {
      setMatches(JSON.parse(savedMatches));
    } else {
      // Mock historical data to make page feel robust right away if no matches were played yet
      const sampleMatches: MatchHistoryEntry[] = [
        {
          id: 'match-mock1',
          arenaName: 'Slum Alley',
          isOnline: false,
          status: 'EXTRACTED',
          chipsEarned: 180,
          chipsLost: 0,
          kills: 3,
          snakeLength: 22,
          timestamp: new Date(Date.now() - 4 * 3600000).toISOString(),
          durationSec: 85
        },
        {
          id: 'match-mock2',
          arenaName: 'Neon Grid',
          isOnline: true,
          status: 'COLLIDED',
          chipsEarned: 0,
          chipsLost: 50,
          kills: 1,
          snakeLength: 14,
          timestamp: new Date(Date.now() - 24 * 3600000).toISOString(),
          durationSec: 42
        },
        {
          id: 'match-mock3',
          arenaName: 'Viper Syndicate',
          isOnline: true,
          status: 'EXTRACTED',
          chipsEarned: 640,
          chipsLost: 0,
          kills: 6,
          snakeLength: 35,
          timestamp: new Date(Date.now() - 48 * 3600000).toISOString(),
          durationSec: 164
        }
      ];
      setMatches(sampleMatches);
      localStorage.setItem('venom_match_history', JSON.stringify(sampleMatches));
    }

    const savedIdentityLogs = localStorage.getItem('venom_identity_history_log');
    if (savedIdentityLogs) {
      setIdentityLogs(JSON.parse(savedIdentityLogs));
    } else {
      const initialLogs: IdentityLogEntry[] = [
        {
          id: 'log-1',
          previousName: 'Unregistered Agent',
          newName: playerStats.name,
          previousCountry: 'None',
          newCountry: playerStats.country || 'US',
          timestamp: new Date(Date.now() - 5 * 86400000).toISOString(),
          status: 'FIRST_HANDSHAKE'
        }
      ];
      setIdentityLogs(initialLogs);
      localStorage.setItem('venom_identity_history_log', JSON.stringify(initialLogs));
    }
  }, [playerStats.name, playerStats.country]);

  // Level XP Progress calculations
  const xpNeeded = playerStats.level * 200;
  const xpPercent = Math.min(100, Math.floor((playerStats.xp / xpNeeded) * 100));

  // Edit identity triggers
  const handleStartEditing = () => {
    setNewName(playerStats.name);
    setSelectedCountry(playerStats.country || 'US');
    setSelectedAvatar(playerStats.avatar || '');
    setInstagram(playerStats.instagram || '');
    setYoutube(playerStats.youtube || '');
    setTwitch(playerStats.twitch || '');
    setIsEditing(true);
  };

  const handleSaveProfile = () => {
    const trimmed = newName.trim();
    if (!trimmed) {
      onToast('Nickname cannot be empty!', 'error');
      return;
    }
    if (trimmed.length > 15) {
      onToast('Nickname must be 15 characters or less.', 'error');
      return;
    }

    const nameChanged = trimmed !== playerStats.name;
    const countryChanged = selectedCountry !== (playerStats.country || 'US');
    const avatarChanged = selectedAvatar !== (playerStats.avatar || '');

    // Save identity change history to prevent data tampering
    if (nameChanged || countryChanged) {
      const logId = 'log-' + Math.random().toString(36).substr(2, 9);
      const newLogEntry: IdentityLogEntry = {
        id: logId,
        previousName: playerStats.name,
        newName: trimmed,
        previousCountry: playerStats.country || 'US',
        newCountry: selectedCountry,
        timestamp: new Date().toISOString(),
        status: 'VERIFIED'
      };

      const updatedLogs = [newLogEntry, ...identityLogs];
      setIdentityLogs(updatedLogs);
      localStorage.setItem('venom_identity_history_log', JSON.stringify(updatedLogs));
    }

    // Update global state
    onUpdateStats({
      name: trimmed,
      country: selectedCountry,
      avatar: selectedAvatar,
      instagram: instagram.trim(),
      youtube: youtube.trim(),
      twitch: twitch.trim()
    });

    setIsEditing(false);
    onToast(`Handshake secure! Profile & Social links saved successfully! 🔒`, 'success');
  };

  // Safe KD Calculation
  const deathsCount = playerStats.lifetimeDeaths || 1; 
  const kdRatio = ((playerStats.lifetimeKills || 0) / deathsCount).toFixed(2);

  // Success Extraction rate
  const totalRuns = (playerStats.lifetimeExtracts || 0) + (playerStats.lifetimeDeaths || 0);
  const extractRate = totalRuns > 0 
    ? `${Math.floor(((playerStats.lifetimeExtracts || 0) / totalRuns) * 100)}%`
    : '0%';

  // Friend management handlers
  const handleAddFriend = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = newFriendName.trim();
    if (!trimmed) return;

    if (friends.some(f => f.name.toLowerCase() === trimmed.toLowerCase())) {
      onToast(`${trimmed} is already in your allied squad list!`, 'error');
      return;
    }

    const newFriend: Friend = {
      id: 'f-' + Math.random().toString(36).substr(2, 9),
      name: trimmed,
      userTag: 'VIPR-' + Math.floor(1000 + Math.random() * 9000),
      status: Math.random() > 0.5 ? 'online' : 'offline',
      level: Math.floor(5 + Math.random() * 45),
      skinColor: '#38bdf8',
      giftSentToday: false,
      giftReceivedToday: false
    };

    const updated = [...friends, newFriend];
    setFriends(updated);
    localStorage.setItem('venom_friends', JSON.stringify(updated));
    setNewFriendName('');
    onToast(`${trimmed} has been synced into your ally list! 🔗`, 'success');
  };

  const handleRemoveFriend = (id: string, name: string) => {
    const updated = friends.filter(f => f.id !== id);
    setFriends(updated);
    localStorage.setItem('venom_friends', JSON.stringify(updated));
    onToast(`Alliance with ${name} dismantled.`, 'info');
  };

  const handleSendGift = (id: string, name: string) => {
    const updated = friends.map(f => {
      if (f.id === id) {
        return { ...f, giftSentToday: true };
      }
      return f;
    });
    setFriends(updated);
    localStorage.setItem('venom_friends', JSON.stringify(updated));
    onToast(`Deposited 25 tactical bonus Chips to ${name}! 🎁`, 'success');
  };

  // Cosmetic Active Skins
  const activeSkin = ALL_COSMETICS.find((c) => c.id === playerStats.currentSkin) || ALL_COSMETICS[0];
  const activeBanner = ALL_COSMETICS.find(c => c.id === playerStats.currentBanner && c.type === 'banner');
  const activeFlag = FACTION_COUNTRIES.find(c => c.code === (playerStats.country || 'US'));

  return (
    <div className="w-full max-w-6xl mx-auto p-4 sm:p-6 bg-slate-950/60 border border-slate-900 rounded-2xl shadow-xl relative overflow-hidden backdrop-blur-md">
      {/* Glow highlight */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-48 h-48 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* TOP HEADER SECTION */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-slate-900 pb-6 mb-6">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center border border-indigo-400/30 relative shadow-md overflow-hidden shrink-0">
            {playerStats.avatar ? (
              playerStats.avatar.startsWith('data:') || playerStats.avatar.startsWith('http') ? (
                <img src={playerStats.avatar} alt={playerStats.name} className="w-full h-full object-cover" referrerpolicy="no-referrer" />
              ) : (
                <span className="text-3xl select-none">{playerStats.avatar}</span>
              )
            ) : (
              <span className="text-3xl select-none" title="EQuipped DNA Skin">
                {activeSkin.emoji || '🐍'}
              </span>
            )}
            <div className="absolute -bottom-1 -right-1 bg-slate-950 border border-slate-800 px-1.5 py-0.5 rounded text-[10px] font-mono font-bold text-indigo-400 shadow">
              Lvl {playerStats.level}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-bold text-white font-sans tracking-tight flex items-center gap-2">
                <span className="text-xl" title="Region flag">
                  {activeFlag?.emoji || '🇺🇸'}
                </span>
                <span>{playerStats.name}</span>
                <span className="text-[10px] font-mono font-bold bg-slate-950 border border-slate-850 text-indigo-400 px-1.5 py-0.5 rounded uppercase">
                  {playerStats.country || 'US'}
                </span>
              </h2>
              <button
                onClick={handleStartEditing}
                className="text-slate-400 hover:text-white p-1 transition cursor-pointer"
                title="Edit Identity"
              >
                <Edit2 className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-slate-400 font-sans mt-1">
              Ledger Tag: <span className="font-mono text-slate-300 font-bold">#{playerStats.userTag || 'STRK-8291'}</span> • Global Standing: <span className="text-amber-400 font-bold font-mono">#{playerStats.championshipRank}</span>
            </p>

            {/* Social Channel Links Badges */}
            <div className="flex flex-wrap items-center gap-2 mt-2">
              {playerStats.instagram && (
                <a
                  href={`https://instagram.com/${playerStats.instagram.replace('@', '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1 bg-pink-500/10 hover:bg-pink-500/20 text-pink-400 border border-pink-500/30 rounded-lg text-[11px] font-sans font-bold flex items-center gap-1.5 transition-all"
                >
                  📸 {playerStats.instagram}
                </a>
              )}
              {playerStats.youtube && (
                <a
                  href={playerStats.youtube.startsWith('http') ? playerStats.youtube : `https://youtube.com/${playerStats.youtube}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded-lg text-[11px] font-sans font-bold flex items-center gap-1.5 transition-all"
                >
                  🎥 YouTube
                </a>
              )}
              {playerStats.twitch && (
                <a
                  href={`https://twitch.tv/${playerStats.twitch}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1 bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-500/30 rounded-lg text-[11px] font-sans font-bold flex items-center gap-1.5 transition-all"
                >
                  📱 Twitch
                </a>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full md:w-auto">
          {/* Level Progression Indicator */}
          <div className="w-full md:w-72 bg-slate-900/60 p-3 rounded-xl border border-slate-850 backdrop-blur-sm flex-1">
            <div className="flex justify-between items-center text-xs text-slate-400 font-sans mb-1.5">
              <span className="flex items-center gap-1"><Sparkles className="w-3.5 h-3.5 text-indigo-400 animate-pulse" /> Level Progress</span>
              <span className="font-mono text-white font-bold">{playerStats.xp} / {xpNeeded} XP</span>
            </div>
            <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800 p-0.5">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
                style={{ width: `${xpPercent}%` }}
              />
            </div>
          </div>

          {/* Logout Action */}
          {onLogout && (
            <button
              onClick={onLogout}
              className="px-4 py-3 bg-red-950/20 hover:bg-red-950/40 border border-red-500/20 text-red-400 hover:text-red-350 rounded-xl text-xs font-bold transition duration-200 cursor-pointer flex items-center justify-center gap-1.5 shadow h-[52px]"
              title="Logout Session"
            >
              <LogOut className="w-4 h-4" />
              <span className="whitespace-nowrap">Sign Out</span>
            </button>
          )}
        </div>
      </div>

      {/* MULTI-TAB NAVIGATION */}
      <div className="flex flex-wrap gap-2 mb-6 border-b border-slate-900 pb-3">
        <button
          onClick={() => { setActiveTab('stats'); setIsEditing(false); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'stats' 
              ? 'bg-indigo-600/10 border border-indigo-500/30 text-indigo-400 shadow-lg' 
              : 'bg-transparent border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <Target className="w-3.5 h-3.5" />
          Records & Statistics
        </button>

        <button
          onClick={() => { setActiveTab('history'); setIsEditing(false); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'history' 
              ? 'bg-indigo-600/10 border border-indigo-500/30 text-indigo-400 shadow-lg' 
              : 'bg-transparent border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <History className="w-3.5 h-3.5" />
          Match History Ledger
        </button>

        <button
          onClick={() => { setActiveTab('friends'); setIsEditing(false); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'friends' 
              ? 'bg-indigo-600/10 border border-indigo-500/30 text-indigo-400 shadow-lg' 
              : 'bg-transparent border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <Users className="w-3.5 h-3.5" />
          Friends & Spectate ({friends.length})
        </button>

        <button
          onClick={() => { setActiveTab('identityLog'); setIsEditing(false); }}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition flex items-center gap-2 cursor-pointer ${
            activeTab === 'identityLog' 
              ? 'bg-indigo-600/10 border border-indigo-500/30 text-indigo-400 shadow-lg' 
              : 'bg-transparent border border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          Identity Anti-Tamper Logs
        </button>
      </div>

      {/* CORE INTERACTIVE WORKSPACE */}

      {/* TAB 1: RECORDS & STATISTICS */}
      {activeTab === 'stats' && (
        <div className="space-y-6">
          {/* Identity Editing Mode embedded in stats tab when editing button is clicked */}
          {isEditing ? (
            <div className="border border-indigo-500/30 bg-slate-950/80 rounded-2xl p-5 sm:p-6 mb-6">
              <div className="flex items-center gap-3 border-b border-slate-800 pb-4 mb-4">
                <div className="p-2.5 bg-indigo-500/10 border border-indigo-500/20 rounded-xl text-indigo-400">
                  <Lock className="w-5 h-5 animate-pulse" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-white font-sans">Handshake Registration Protocol</h3>
                  <p className="text-xs text-slate-400">Lock down your tournament handle and regional alignment. All changes are logged.</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {/* Nickname */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider font-sans">Challenger Handle</label>
                  <input
                    type="text"
                    value={newName}
                    onChange={(e) => setNewName(e.target.value)}
                    maxLength={15}
                    className="bg-slate-900 border border-slate-800 text-white font-sans text-sm px-3.5 py-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all w-full"
                    placeholder="Enter nickname"
                  />
                  <span className="text-[10px] text-slate-500">Max 15 characters. System validates non-duplicate handle signatures.</span>
                </div>

                {/* Country */}
                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider font-sans">Faction Region (Flag)</label>
                  <select
                    value={selectedCountry}
                    onChange={(e) => setSelectedCountry(e.target.value)}
                    className="bg-slate-900 border border-slate-800 text-white font-sans text-sm px-3.5 py-2 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500 transition-all w-full cursor-pointer"
                  >
                    {FACTION_COUNTRIES.map((c) => (
                      <option key={c.code} value={c.code}>
                        {c.emoji} {c.name} ({c.code})
                      </option>
                    ))}
                  </select>
                  <span className="text-[10px] text-slate-500">Associates your extraction chips to regional champion rankings.</span>
                </div>

                {/* Profile Image Customizer */}
                <div className="md:col-span-2 flex flex-col gap-3 border-t border-slate-900/60 pt-5">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider font-sans">Profile Avatar / Identity Emblem</label>
                  
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-start">
                    {/* Left: Preview & File Upload Drag & Drop */}
                    <div className="md:col-span-5 flex flex-col gap-3">
                      <div 
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                        className={`border-2 border-dashed rounded-2xl p-5 flex flex-col items-center justify-center text-center cursor-pointer transition-all duration-200 relative group h-44 ${
                          isDragging 
                            ? 'border-indigo-500 bg-indigo-500/5' 
                            : 'border-slate-800 bg-slate-900/40 hover:border-indigo-500/40 hover:bg-slate-900/60'
                        }`}
                        onClick={() => document.getElementById('avatar-file-input')?.click()}
                      >
                        <input 
                          id="avatar-file-input"
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={handleFileChange}
                        />

                        {selectedAvatar && (selectedAvatar.startsWith('data:') || selectedAvatar.startsWith('http')) ? (
                          <div className="absolute inset-0 p-1.5 flex flex-col items-center justify-center bg-slate-950/80 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity z-10">
                            <Upload className="w-6 h-6 text-indigo-400 mb-1" />
                            <span className="text-[10px] text-white font-sans font-bold">CHANGE IMAGE</span>
                            <span className="text-[9px] text-slate-400 mt-0.5">Drag & Drop or Click</span>
                          </div>
                        ) : null}

                        {selectedAvatar ? (
                          selectedAvatar.startsWith('data:') || selectedAvatar.startsWith('http') ? (
                            <div className="w-24 h-24 rounded-2xl border border-indigo-500/20 overflow-hidden relative shadow-lg">
                              <img src={selectedAvatar} alt="Avatar Preview" className="w-full h-full object-cover" referrerpolicy="no-referrer" />
                            </div>
                          ) : (
                            <div className="flex flex-col items-center justify-center">
                              <div className="w-16 h-16 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-4xl mb-2 shadow-inner">
                                {selectedAvatar}
                              </div>
                              <span className="text-xs font-bold text-white font-sans">Preset Selected</span>
                              <span className="text-[10px] text-slate-500 mt-1 font-sans">Click here to upload custom image instead</span>
                            </div>
                          )
                        ) : (
                          <div className="flex flex-col items-center justify-center">
                            <div className="w-12 h-12 rounded-xl bg-slate-950 flex items-center justify-center border border-slate-800 text-slate-400 group-hover:text-indigo-400 transition-colors mb-2.5">
                              <Image className="w-5.5 h-5.5" />
                            </div>
                            <span className="text-xs font-bold text-white font-sans">Upload Custom Photo</span>
                            <span className="text-[10px] text-slate-500 mt-1">Drag & Drop or click to browse</span>
                            <span className="text-[9px] text-slate-500 mt-0.5">PNG, JPG, WebP up to 1.5MB</span>
                          </div>
                        )}
                      </div>

                      {selectedAvatar && (
                        <button
                          type="button"
                          onClick={() => setSelectedAvatar('')}
                          className="py-1.5 px-3 bg-slate-900 hover:bg-red-950/40 hover:text-red-400 hover:border-red-500/20 border border-slate-800 text-slate-400 rounded-xl text-[10px] font-sans font-bold transition-all cursor-pointer flex items-center justify-center gap-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" /> Reset to Skin Default
                        </button>
                      )}
                    </div>

                    {/* Right: Preset Avatars */}
                    <div className="md:col-span-7 flex flex-col gap-2.5">
                      <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-sans">Choose Preset Emblem</span>
                      <div className="grid grid-cols-4 gap-2">
                        {PRESET_AVATARS.map((p) => {
                          const isSelected = selectedAvatar === p.emoji;
                          return (
                            <button
                              key={p.id}
                              type="button"
                              onClick={() => setSelectedAvatar(p.emoji)}
                              className={`p-3 rounded-xl border transition-all duration-200 cursor-pointer flex flex-col items-center justify-center gap-1.5 group hover:scale-105 h-20 ${
                                isSelected 
                                  ? 'border-indigo-500 bg-indigo-500/10 shadow-lg' 
                                  : 'border-slate-900 bg-slate-950/40 hover:border-slate-800'
                              }`}
                              title={p.label}
                            >
                              <span className="text-2xl select-none group-hover:scale-110 transition-transform">{p.emoji}</span>
                              <span className="text-[8.5px] font-sans font-semibold text-slate-400 group-hover:text-slate-200 truncate w-full text-center">{p.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Social Channels Section */}
                <div className="md:col-span-2 flex flex-col gap-3 border-t border-slate-900/60 pt-5">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-wider font-sans flex items-center gap-2">
                    <Globe className="w-4 h-4 text-purple-400" /> Creator Social Channels (Showcased on your Public Profile)
                  </label>
                  <p className="text-[11px] text-slate-400 font-sans">
                    Link your Instagram handle, YouTube channel, and Twitch profile so other vipers and allies can follow you and watch your game clips!
                  </p>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-bold text-pink-400 font-sans uppercase">📸 Instagram Handle</label>
                      <input
                        type="text"
                        value={instagram}
                        onChange={(e) => setInstagram(e.target.value)}
                        placeholder="@username (e.g. @hari_snake_god)"
                        className="bg-slate-900 border border-slate-800 text-white font-sans text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-pink-500"
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-bold text-red-400 font-sans uppercase">🎥 YouTube Channel / Handle</label>
                      <input
                        type="text"
                        value={youtube}
                        onChange={(e) => setYoutube(e.target.value)}
                        placeholder="@channel or URL"
                        className="bg-slate-900 border border-slate-800 text-white font-sans text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-red-500"
                      />
                    </div>

                    <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-bold text-purple-400 font-sans uppercase">📱 Twitch Stream Handle</label>
                      <input
                        type="text"
                        value={twitch}
                        onChange={(e) => setTwitch(e.target.value)}
                        placeholder="twitch_username"
                        className="bg-slate-900 border border-slate-800 text-white font-sans text-xs px-3 py-2 rounded-xl focus:outline-none focus:border-purple-500"
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-5 p-3.5 bg-indigo-950/20 border border-indigo-500/10 rounded-xl flex items-start gap-3">
                <AlertTriangle className="w-4.5 h-4.5 text-indigo-400 shrink-0 mt-0.5" />
                <div className="text-xs font-sans leading-relaxed text-slate-300">
                  <strong className="text-indigo-300 block mb-0.5">CYBER HANDSHAKE WARNING:</strong>
                  Changing your registered alias or territory updates global tournament indices. Immutable record logs are appended to the ledger below.
                </div>
              </div>

              <div className="mt-5 flex justify-end gap-2.5 border-t border-slate-900 pt-4">
                <button
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 rounded-xl text-xs font-bold transition cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveProfile}
                  className="px-4.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition shadow-lg shadow-indigo-600/20 flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" /> Save Handshake
                </button>
              </div>
            </div>
          ) : null}

          {/* Statistics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
            {/* Banked chips */}
            <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between hover:border-slate-800 transition shadow">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-sans">Banked Wallet</span>
                <Landmark className="w-4 h-4 text-emerald-400" />
              </div>
              <div>
                <span className="text-xl font-bold font-mono text-emerald-400 tracking-tight block">
                  {playerStats.bankedChips.toLocaleString()}
                </span>
                <span className="text-[9px] font-mono uppercase text-slate-500 tracking-wider">Deposited Chips</span>
              </div>
            </div>

            {/* Total Kills */}
            <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between hover:border-slate-800 transition shadow">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-sans">Tournament Kills</span>
                <Skull className="w-4 h-4 text-rose-400" />
              </div>
              <div>
                <span className="text-xl font-bold font-mono text-white tracking-tight block">
                  {playerStats.lifetimeKills}
                </span>
                <span className="text-[9px] font-mono uppercase text-slate-500 tracking-wider">Total Terminations</span>
              </div>
            </div>

            {/* K/D Ratio */}
            <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between hover:border-slate-800 transition shadow">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-sans">K/D Ratio</span>
                <Target className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <span className="text-xl font-bold font-mono text-amber-400 tracking-tight block">
                  {kdRatio}
                </span>
                <span className="text-[9px] font-mono uppercase text-slate-500 tracking-wider">Kill / Death Index</span>
              </div>
            </div>

            {/* Extraction Success Rate */}
            <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between hover:border-slate-800 transition shadow">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-sans">Extraction Rate</span>
                <Compass className="w-4 h-4 text-cyan-400" />
              </div>
              <div>
                <span className="text-xl font-bold font-mono text-cyan-400 tracking-tight block">
                  {extractRate}
                </span>
                <span className="text-[9px] font-mono uppercase text-slate-500 tracking-wider">Successful Handshakes</span>
              </div>
            </div>

            {/* Best Streak */}
            <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between hover:border-slate-800 transition shadow">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-sans">Survival Streak</span>
                <Trophy className="w-4 h-4 text-yellow-500" />
              </div>
              <div>
                <span className="text-xl font-bold font-mono text-yellow-500 tracking-tight block">
                  {playerStats.bestStreak}
                </span>
                <span className="text-[9px] font-mono uppercase text-slate-500 tracking-wider">Consecutive Extractions</span>
              </div>
            </div>

            {/* Max single extraction */}
            <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between hover:border-slate-800 transition shadow">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-sans">Record Extraction</span>
                <Award className="w-4 h-4 text-indigo-400" />
              </div>
              <div>
                <span className="text-xl font-bold font-mono text-indigo-400 tracking-tight block">
                  {playerStats.biggestExtract.toLocaleString()}
                </span>
                <span className="text-[9px] font-mono uppercase text-slate-500 tracking-wider">Max Retained in One Run</span>
              </div>
            </div>

            {/* Total earned chips */}
            <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between hover:border-slate-800 transition shadow">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-sans">Lifetime Retained</span>
                <Landmark className="w-4 h-4 text-teal-400" />
              </div>
              <div>
                <span className="text-xl font-bold font-mono text-teal-400 tracking-tight block">
                  {playerStats.totalChipsEarned.toLocaleString()}
                </span>
                <span className="text-[9px] font-mono uppercase text-slate-500 tracking-wider">Cumulative Chip Profit</span>
              </div>
            </div>

            {/* Total lost chips */}
            <div className="bg-slate-950/40 border border-slate-900 rounded-xl p-4 flex flex-col justify-between hover:border-slate-800 transition shadow">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-sans">Total Forfeited</span>
                <RefreshCw className="w-4 h-4 text-red-400" />
              </div>
              <div>
                <span className="text-xl font-bold font-mono text-red-400 tracking-tight block">
                  {playerStats.totalChipsLost.toLocaleString()}
                </span>
                <span className="text-[9px] font-mono uppercase text-slate-500 tracking-wider">Forfeited in Crash Events</span>
              </div>
            </div>
          </div>

          {/* ANNUAL TOURNAMENT MATCH CAP & GUARDRAIL METRICS CARD */}
          <div className="bg-slate-950 border border-amber-500/30 rounded-2xl p-5 shadow-xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-900 pb-3">
              <div className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-amber-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-sans">
                  Annual Tournament Guardrails & Limit Allowances
                </h3>
              </div>
              <span className="text-[11px] font-mono font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20">
                1-YEAR UTC TOURNAMENT CYCLE ACTIVE
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* 1. MATCH CAP (10,000 GAMES / YEAR) */}
              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-bold uppercase font-sans flex items-center gap-1">
                    <Swords className="w-3.5 h-3.5 text-indigo-400" /> Matches Allowed
                  </span>
                  <span className="font-mono font-bold text-indigo-300">
                    {(playerStats.matchesPlayedThisYear || 2300).toLocaleString()} / 10,000
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-950 rounded-full border border-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full"
                    style={{ width: `${Math.min(100, (((playerStats.matchesPlayedThisYear || 2300) / 10000) * 100))}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>Completed: {(playerStats.matchesPlayedThisYear || 2300).toLocaleString()}</span>
                  <span className="text-emerald-400 font-bold">Remaining: {(10000 - (playerStats.matchesPlayedThisYear || 2300)).toLocaleString()} matches</span>
                </div>
              </div>

              {/* 2. ANNUAL CHIPS PURCHASE CAP (25 LAKH CHIPS MAX / YEAR) */}
              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-bold uppercase font-sans flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5 text-emerald-400" /> Annual Buy Cap (25L)
                  </span>
                  <span className="font-mono font-bold text-emerald-300">
                    {(playerStats.yearlyPurchasedChips || 0).toLocaleString()} / 25,00,000 c
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-950 rounded-full border border-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full"
                    style={{ width: `${Math.min(100, (((playerStats.yearlyPurchasedChips || 0) / 2500000) * 100))}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>Bought: {(playerStats.yearlyPurchasedChips || 0).toLocaleString()} c</span>
                  <span className="text-emerald-400 font-bold">Cap Remaining: {(2500000 - (playerStats.yearlyPurchasedChips || 0)).toLocaleString()} c</span>
                </div>
              </div>

              {/* 3. DAILY AD CAP (12 ADS / DAY) */}
              <div className="bg-slate-900/80 p-4 rounded-xl border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400 font-bold uppercase font-sans flex items-center gap-1">
                    <Trophy className="w-3.5 h-3.5 text-amber-400" /> Rewarded Ads Today
                  </span>
                  <span className="font-mono font-bold text-amber-300">
                    {playerStats.adsWatchedToday || 0} / 12 Ads
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-950 rounded-full border border-slate-800 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full"
                    style={{ width: `${Math.min(100, (((playerStats.adsWatchedToday || 0) / 12) * 100))}%` }}
                  />
                </div>
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>Watched: {playerStats.adsWatchedToday || 0}</span>
                  <span className="text-amber-400 font-bold">Resets at 00:00 UTC</span>
                </div>
              </div>
            </div>
          </div>

          {/* Tactical Challenger Information Banner */}
          <div className="p-4 rounded-xl border border-slate-900 bg-slate-900/10 flex items-center gap-4">
            <Shield className="w-8 h-8 text-indigo-500 shrink-0" />
            <div className="text-xs leading-relaxed text-slate-400">
              <span className="font-bold text-slate-200 uppercase block mb-0.5">CHALLENGER STANDING RATING</span>
              All tournament statistics are linked directly to your global challenger index handle. Altering your registry flag updates leaderboard feeds dynamically. Data verification handshakes run periodically to check metrics validity.
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: MATCH HISTORY LEDGER */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between border-b border-slate-900 pb-3">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <History className="w-4 h-4 text-indigo-400" /> Match Run Records Ledger
            </h3>
            <span className="text-xs text-slate-500 font-mono">Showing last 25 operations</span>
          </div>

          {matches.length === 0 ? (
            <div className="text-center py-12 border border-dashed border-slate-900 rounded-2xl">
              <History className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <p className="text-sm text-slate-400">No matches found in the active ledger standing.</p>
              <p className="text-xs text-slate-600 mt-1">Jump into any arena to log your first run data!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-900 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
                    <th className="py-3 px-4">Arena Sector</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4 text-right">Chips Outcome</th>
                    <th className="py-3 px-4 text-center">Kills</th>
                    <th className="py-3 px-4 text-center">Tail Score</th>
                    <th className="py-3 px-4">Time Elapsed</th>
                    <th className="py-3 px-4">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-900/60 text-xs">
                  {matches.map((match) => (
                    <tr key={match.id} className="hover:bg-slate-900/20 transition">
                      <td className="py-3.5 px-4 font-bold text-slate-300">
                        <div className="flex items-center gap-1.5">
                          <Compass className="w-3.5 h-3.5 text-indigo-400" />
                          <span>{match.arenaName}</span>
                          <span className={`text-[8px] font-mono px-1 rounded ${
                            match.isOnline 
                              ? 'bg-indigo-500/10 border border-indigo-500/20 text-indigo-300' 
                              : 'bg-slate-800 text-slate-400'
                          }`}>
                            {match.isOnline ? 'ONLINE' : 'PRACTICE'}
                          </span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                          match.status === 'EXTRACTED'
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400'
                            : 'bg-rose-500/10 border-rose-500/30 text-rose-400'
                        }`}>
                          {match.status}
                        </span>
                      </td>
                      <td className={`py-3.5 px-4 text-right font-mono font-bold ${
                        match.status === 'EXTRACTED' ? 'text-emerald-400' : 'text-rose-400'
                      }`}>
                        {match.status === 'EXTRACTED' 
                          ? `+${match.chipsEarned.toLocaleString()} c` 
                          : `-${match.chipsLost.toLocaleString()} c`
                        }
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono font-semibold text-slate-300">
                        {match.kills}
                      </td>
                      <td className="py-3.5 px-4 text-center font-mono font-medium text-indigo-300">
                        {match.snakeLength || 10}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-slate-400">
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-500" />
                          <span>{match.durationSec}s</span>
                        </div>
                      </td>
                      <td className="py-3.5 px-4 font-mono text-slate-500 text-[11px]">
                        {new Date(match.timestamp).toLocaleDateString()} {new Date(match.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: ALLIED SQUAD (FRIENDS) */}
      {activeTab === 'friends' && (
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-400" /> Friends & Live Spectate Portal
            </h3>
            <p className="text-xs text-slate-400 mt-1">
              Add allies to build your roster. Send daily gifts, invite them to high-stakes co-op matches, or spectate their live runs in real-time when they are in-match!
            </p>
          </div>

          {/* Add Friend Form */}
          <form onSubmit={handleAddFriend} className="flex gap-2.5 max-w-md">
            <div className="relative flex-1">
              <UserPlus className="absolute left-3.5 top-2.5 w-4.5 h-4.5 text-slate-500" />
              <input
                type="text"
                placeholder="Enter challenger alias..."
                value={newFriendName}
                onChange={(e) => setNewFriendName(e.target.value)}
                maxLength={15}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 transition-all font-sans"
              />
            </div>
            <button
              type="submit"
              className="px-4.5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            >
              <UserPlus className="w-4 h-4" /> Sync Ally
            </button>
          </form>

          {/* Friends List */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {friends.map((friend) => (
              <div 
                key={friend.id} 
                className="bg-slate-950/40 border border-slate-900 rounded-2xl p-4 flex items-center justify-between hover:border-slate-800 transition shadow"
              >
                <div className="flex items-center gap-3">
                  {/* Status Indicator */}
                  <div className="relative">
                    <div className="w-11 h-11 rounded-xl bg-slate-900 flex items-center justify-center border border-slate-800">
                      <span className="text-xl">🐍</span>
                    </div>
                    <span className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-slate-950 ${
                      friend.status === 'online' 
                        ? 'bg-emerald-500' 
                        : friend.status === 'idle'
                          ? 'bg-amber-500 animate-pulse'
                          : friend.status === 'in-match'
                            ? 'bg-fuchsia-500 animate-pulse'
                            : 'bg-slate-600'
                    }`} 
                    title={friend.status === 'online' ? 'Online' : friend.status === 'idle' ? 'Idle' : friend.status === 'in-match' ? 'In Match' : 'Offline'}
                    />
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                      <span>{friend.name}</span>
                      <span className="text-[9px] font-mono text-slate-500 font-normal">#{friend.userTag}</span>
                    </h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      Level {friend.level} • <span className={`text-[10px] uppercase font-mono font-bold ${
                        friend.status === 'online'
                          ? 'text-emerald-400'
                          : friend.status === 'idle'
                            ? 'text-amber-400'
                            : friend.status === 'in-match'
                              ? 'text-fuchsia-400'
                              : 'text-slate-500'
                      }`}>{friend.status}</span>
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 flex-wrap">
                  {/* Spectate Button */}
                  {friend.status === 'in-match' && onSpectateFriend && (
                    <button
                      onClick={() => onSpectateFriend(friend.name, friend.skinColor)}
                      className="px-2.5 py-1.5 bg-fuchsia-600/20 text-fuchsia-300 hover:bg-fuchsia-600 hover:text-white border border-fuchsia-500/30 rounded-xl transition cursor-pointer text-xs font-bold flex items-center gap-1.5 animate-pulse"
                      title="Spectate Match"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Spectate</span>
                    </button>
                  )}

                  {/* Invite Button */}
                  {(friend.status === 'online' || friend.status === 'idle') && onSelectArena && (
                    <button
                      onClick={() => {
                        setActiveInviteFriend(friend);
                        setInviteSelectedArenaId('tier-1');
                        setInviteStatusMessage(null);
                      }}
                      className="px-2.5 py-1.5 bg-violet-600/20 text-violet-300 hover:bg-violet-600 hover:text-white border border-violet-500/30 rounded-xl transition cursor-pointer text-xs font-bold flex items-center gap-1.5"
                      title="Invite to Match"
                    >
                      <Swords className="w-3.5 h-3.5" />
                      <span>Invite</span>
                    </button>
                  )}

                  <button
                    onClick={() => handleSendGift(friend.id, friend.name)}
                    disabled={friend.giftSentToday || friend.status === 'offline'}
                    className={`px-2.5 py-1.5 rounded-xl border transition cursor-pointer text-xs font-bold flex items-center gap-1 ${
                      friend.giftSentToday
                        ? 'bg-slate-900 border-slate-850 text-slate-500 cursor-not-allowed'
                        : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500/20'
                    }`}
                    title="Send Gift"
                  >
                    <Landmark className="w-4 h-4" />
                    <span>{friend.giftSentToday ? 'Gifted' : 'Gift'}</span>
                  </button>

                  <button
                    onClick={() => handleRemoveFriend(friend.id, friend.name)}
                    className="p-2 text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-xl border border-transparent hover:border-rose-500/20 transition cursor-pointer"
                    title="Dismantle Alliance"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: IDENTITY TAMPERING LOGS */}
      {activeTab === 'identityLog' && (
        <div className="space-y-4">
          <div className="p-4 rounded-xl border border-indigo-500/20 bg-indigo-500/5 flex items-start gap-3.5 mb-2">
            <Lock className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <div className="text-xs font-sans leading-relaxed text-slate-300">
              <strong className="text-white uppercase block mb-1">CHALLENGER REGISTRY LEDGER</strong>
              To maintain the integrity of global tournaments, all modifications to nickname tags or regional affiliations are permanently logged to this client audit ledger. Tampering or spoofing database records will immediately reset active tournament streak counts.
            </div>
          </div>

          <div className="border border-slate-900 rounded-2xl overflow-hidden bg-slate-950/20">
            {identityLogs.length === 0 ? (
              <p className="text-center py-8 text-slate-500 text-xs font-mono">No handshakes registered yet.</p>
            ) : (
              <div className="divide-y divide-slate-900">
                {identityLogs.map((log) => (
                  <div key={log.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs font-mono">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-500">TAG REGISTERED:</span>
                        <span className="text-slate-300 font-bold">{log.previousName}</span>
                        <span className="text-slate-500">➜</span>
                        <span className="text-indigo-400 font-bold">{log.newName}</span>
                      </div>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400">
                        <span>REGION ALIGNMENT:</span>
                        <span className="text-slate-500 uppercase">{log.previousCountry}</span>
                        <span className="text-slate-500">➜</span>
                        <span className="text-emerald-400 uppercase font-bold">{log.newCountry}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 justify-between sm:justify-end">
                      <div className="text-right">
                        <span className="text-[10px] text-slate-500 block">HANDSHAKE TIMESTAMP</span>
                        <span className="text-slate-400 text-[11px]">{new Date(log.timestamp).toLocaleDateString()} {new Date(log.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <span className="px-2 py-1 rounded text-[9px] font-bold tracking-widest bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 uppercase">
                        {log.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* CO-OP LOBBY INVITE MODAL */}
      {activeInviteFriend && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-2xl overflow-hidden">
            <div
              className="absolute -top-10 -right-10 w-32 h-32 rounded-full blur-3xl opacity-20 pointer-events-none"
              style={{ backgroundColor: activeInviteFriend.skinColor }}
            />

            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <Swords className="w-5 h-5 text-violet-400 animate-pulse" />
                <div>
                  <h3 className="font-bold text-white text-sm font-sans">Co-Op Lobby Invite</h3>
                  <p className="text-[10px] text-slate-400 font-sans mt-0.5">Assemble a squad with your allies</p>
                </div>
              </div>
              <button
                onClick={() => setActiveInviteFriend(null)}
                className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Friend and User Balance Cards */}
            <div className="grid grid-cols-2 gap-3 my-4">
              <div className="bg-slate-950/60 border border-slate-800/60 p-3 rounded-xl flex flex-col gap-1 text-center">
                <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider font-sans">Your Balance</span>
                <span className="text-sm font-bold font-mono text-indigo-400">
                  {playerStats.bankedChips.toLocaleString()} <span className="text-xs font-sans text-slate-500">c</span>
                </span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800/60 p-3 rounded-xl flex flex-col gap-1 text-center">
                <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider font-sans">{activeInviteFriend.name}</span>
                <span className="text-sm font-bold font-mono text-emerald-400">
                  {getFriendSimulatedChips(activeInviteFriend).toLocaleString()} <span className="text-xs font-sans text-slate-500">c</span>
                </span>
              </div>
            </div>

            {/* Arena Selector dropdown or scrolling cards */}
            <div className="flex flex-col gap-2 my-4">
              <label className="text-[10px] text-slate-400 font-bold uppercase font-sans tracking-wide">
                Select Arena Stakes
              </label>
              <div className="flex flex-col gap-1.5 max-h-[180px] overflow-y-auto pr-1">
                {ARENA_TIERS.map((tier) => {
                  const isSelected = tier.id === inviteSelectedArenaId;
                  const friendAffords = getFriendSimulatedChips(activeInviteFriend) >= tier.buyIn;
                  const youAfford = playerStats.bankedChips >= tier.buyIn;

                  return (
                    <button
                      key={tier.id}
                      onClick={() => {
                        setInviteSelectedArenaId(tier.id);
                        setInviteStatusMessage(null); // Clear previous status on arena switch
                      }}
                      className={`flex items-center justify-between p-2.5 rounded-xl border text-left transition cursor-pointer ${
                        isSelected
                          ? 'bg-slate-850 border-indigo-500 shadow-md'
                          : 'bg-slate-950/40 border-slate-800/60 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: tier.accentColor }}
                        />
                        <div>
                          <span className="text-xs font-bold text-white block">{tier.name}</span>
                          <span className="text-[9px] text-slate-400 font-sans mt-0.5 leading-none">
                            Buy-In: {tier.buyIn.toLocaleString()} c
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-1">
                        {!youAfford ? (
                          <span className="text-[8px] bg-rose-950/80 text-rose-400 border border-rose-900/40 px-1.5 py-0.5 rounded font-bold font-sans">
                            You can't afford
                          </span>
                        ) : !friendAffords ? (
                          <span className="text-[8px] bg-amber-950/80 text-amber-300 border border-amber-900/40 px-1.5 py-0.5 rounded font-bold font-sans">
                            They can't afford
                          </span>
                        ) : (
                          <span className="text-[8px] bg-emerald-950/80 text-emerald-300 border border-emerald-900/40 px-1.5 py-0.5 rounded font-bold font-sans">
                            Eligible 🤝
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Friend's response / counter-proposal speech bubble */}
            {inviteStatusMessage && (
              <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl flex flex-col gap-2 my-4">
                <div className="flex items-center gap-2">
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold"
                    style={{ backgroundColor: `${activeInviteFriend.skinColor}33`, color: activeInviteFriend.skinColor }}
                  >
                    💬
                  </div>
                  <span className="text-[10px] font-bold text-slate-300">{activeInviteFriend.name} responds:</span>
                </div>
                <p className="text-xs italic text-slate-300 leading-relaxed pl-7">
                  "{inviteStatusMessage.text}"
                </p>

                {inviteStatusMessage.type === 'counter' && inviteStatusMessage.counterArenaId && (
                  <button
                    onClick={() => {
                      if (inviteStatusMessage.counterArenaId) {
                        setInviteSelectedArenaId(inviteStatusMessage.counterArenaId);
                        setInviteStatusMessage(null);
                        onToast(`Switched buy-in to match counter-proposal!`, 'info');
                      }
                    }}
                    className="mt-1 ml-7 self-start px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-lg text-[10px] font-bold font-sans transition cursor-pointer"
                  >
                    🤝 Accept Proposal & Invite
                  </button>
                )}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center gap-2 border-t border-slate-800/60 pt-4 mt-4">
              <button
                onClick={() => setActiveInviteFriend(null)}
                className="flex-1 py-2 border border-slate-800 hover:border-slate-700 bg-slate-950/40 text-slate-400 hover:text-white rounded-xl text-xs font-bold font-sans transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const selectedTier = ARENA_TIERS.find((t) => t.id === inviteSelectedArenaId) || ARENA_TIERS[0];
                  const friendChips = getFriendSimulatedChips(activeInviteFriend);
                  const playerChips = playerStats.bankedChips;

                  if (playerChips < selectedTier.buyIn) {
                    onToast(`You do not have enough chips for ${selectedTier.name}!`, 'error');
                    return;
                  }

                  if (friendChips < selectedTier.buyIn) {
                    // Friend has insufficient chips! Simulate counter proposal.
                    // Find a tier that the friend CAN afford and is closest but less than friendChips
                    const affordableTiers = ARENA_TIERS.filter(t => friendChips >= t.buyIn && playerChips >= t.buyIn);
                    
                    if (affordableTiers.length > 0) {
                      const counterTier = affordableTiers[affordableTiers.length - 1]; // highest affordable
                      setInviteStatusMessage({
                        type: 'counter',
                        text: `Sorry! I don't have enough chips for ${selectedTier.name} (need ${selectedTier.buyIn.toLocaleString()} c, only have ${friendChips.toLocaleString()} c). Let's join the "${counterTier.name}" (Buy-In: ${counterTier.buyIn.toLocaleString()} c) instead! Re-invite me?`,
                        counterArenaId: counterTier.id
                      });
                      onToast(`Co-op invitation rejected: Insufficient chips. Counter-proposal received!`, 'info');
                    } else {
                      setInviteStatusMessage({
                        type: 'error',
                        text: `Ah, I'm super low on chips right now (${friendChips.toLocaleString()} c) and can't afford any of the available buy-ins. Send me a chip gift or invite me when I earn some more! 🐍`,
                      });
                      onToast(`Co-op invitation rejected: Insufficient chips.`, 'error');
                    }
                    return;
                  }

                  // Friend accepted! Save active match invite with specific arena ID
                  localStorage.setItem('venom_active_match_invite', JSON.stringify({
                    name: activeInviteFriend.name,
                    skinColor: activeInviteFriend.skinColor,
                    arenaId: selectedTier.id,
                  }));

                  onToast(`Co-op invite accepted by ${activeInviteFriend.name}! Staking buy-in... 🤝⚔️`, 'success');
                  setActiveInviteFriend(null);
                  if (onSelectArena) {
                    setTimeout(() => {
                      onSelectArena(selectedTier, true);
                    }, 800);
                  }
                }}
                className="flex-1 py-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 border border-violet-500/30 text-white rounded-xl text-xs font-bold font-sans transition cursor-pointer"
              >
                Send Co-Op Invite
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
