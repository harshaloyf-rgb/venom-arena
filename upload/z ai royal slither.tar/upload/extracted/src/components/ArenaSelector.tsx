import { useState, useEffect } from 'react';
import { Target, Shield, Compass, Landmark, Swords, Users, Trophy, ChevronRight, Play, ChevronLeft } from 'lucide-react';
import { ArenaTier, PlayerStats } from '../types';
import { ARENA_TIERS, PRACTICE_TIERS } from '../data';

interface ArenaSelectorProps {
  playerStats: PlayerStats;
  onSelectArena: (arena: ArenaTier, isOnline: boolean) => void;
  onToast: (msg: string, type: 'success' | 'info' | 'error') => void;
  initialOnline?: boolean;
  onBack?: () => void;
}

export default function ArenaSelector({ playerStats, onSelectArena, onToast, initialOnline, onBack }: ArenaSelectorProps) {
  const [isOnline, setIsOnline] = useState(initialOnline !== undefined ? initialOnline : true);
  const [selectedTierId, setSelectedTierId] = useState<string>(initialOnline === false ? 'practice-easy' : 'tier-1');
  const [arenaStats, setArenaStats] = useState<Record<string, { players: number; maxPlayers: number }>>({});

  useEffect(() => {
    if (!isOnline) return;

    const fetchStats = async () => {
      try {
        const res = await fetch('/api/arena-stats');
        if (res.ok) {
          const data = await res.json();
          setArenaStats(data);
        }
      } catch (err) {
        console.error('Error fetching arena stats:', err);
      }
    };

    fetchStats();
    const interval = setInterval(fetchStats, 5000);
    return () => clearInterval(interval);
  }, [isOnline]);

  // Load active invite if any
  const [activeInvite, setActiveInvite] = useState<{
    name: string;
    skinColor: string;
    arenaId: string;
  } | null>(() => {
    const saved = localStorage.getItem('venom_active_match_invite');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (err) {
        return null;
      }
    }
    return null;
  });

  const tiersList = isOnline ? ARENA_TIERS : PRACTICE_TIERS;
  const selectedTier = tiersList.find((t) => t.id === selectedTierId) || tiersList[0];
  const canAfford = playerStats.bankedChips >= selectedTier.buyIn;
  const canPlay = !isOnline || canAfford;

  const handleEnterArena = () => {
    if (isOnline && !canAfford) {
      onToast(`Insufficient chips to enter this arena! Claim daily rewards or play lower stakes to rebuild.`, 'error');
      return;
    }
    onSelectArena(selectedTier, isOnline);
  };

  return (
    <div id="arena-selector" className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      {/* List of Arena Tiers - Left side */}
      <div className="lg:col-span-7 flex flex-col gap-3">
        <div className="flex items-center justify-between px-2">
          <div className="flex items-center gap-3">
            {onBack && (
              <button
                onClick={onBack}
                className="p-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-white hover:bg-slate-900 transition-all cursor-pointer flex items-center justify-center shrink-0"
                title="Back to Mode Selection"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
            )}
            <div>
              <h3 className="text-sm font-bold font-sans uppercase tracking-wider text-slate-400">
                {isOnline ? 'Online PvP Shards' : 'Practice Arenas'}
              </h3>
              <p className="text-xs text-slate-500 font-sans mt-0.5">Choose your buy-in risk level</p>
            </div>
          </div>

          {/* Mode Selector */}
          <div className="flex bg-slate-950 p-0.5 rounded-lg border border-slate-800/80">
            <button
              onClick={() => {
                setIsOnline(true);
                setSelectedTierId('tier-1');
              }}
              className={`px-3 py-1 rounded-md text-xs font-sans font-medium flex items-center gap-1 transition-all ${
                isOnline
                  ? 'bg-indigo-600/25 text-indigo-300 border border-indigo-500/20'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              <Users className="w-3.5 h-3.5" /> Online Arena
            </button>
            <button
              onClick={() => {
                setIsOnline(false);
                setSelectedTierId('practice-easy');
              }}
              className={`px-3 py-1 rounded-md text-xs font-sans font-medium flex items-center gap-1 transition-all ${
                !isOnline
                  ? 'bg-amber-600/25 text-amber-300 border border-amber-500/20'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >
              <Swords className="w-3.5 h-3.5" /> Offline Mode
            </button>
          </div>
        </div>

        {/* Tiers Scroll */}
        <div className="flex flex-col gap-2.5 max-h-[460px] overflow-y-auto pr-1">
          {tiersList.map((tier) => {
            const active = tier.id === selectedTierId;
            const unaffordable = isOnline && playerStats.bankedChips < tier.buyIn;

            return (
              <button
                key={tier.id}
                onClick={() => setSelectedTierId(tier.id)}
                className={`relative flex items-center justify-between p-4 rounded-xl border transition-all text-left group ${
                  active
                    ? 'bg-slate-800/50 border-indigo-500 shadow-md shadow-indigo-950/20'
                    : 'bg-slate-900 border-slate-800/80 hover:border-slate-700/80'
                }`}
              >
                <div className="flex items-center gap-4">
                  {/* Glowing light marker */}
                  <div
                    className="w-3.5 h-3.5 rounded-full border border-white/20 shadow-lg"
                    style={{
                      backgroundColor: tier.accentColor,
                      boxShadow: active ? `0 0 12px ${tier.accentColor}` : 'none',
                    }}
                  />

                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-bold font-sans text-white group-hover:text-indigo-300 transition-colors">
                        {tier.name}
                      </span>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold uppercase tracking-wider font-sans border border-transparent ${tier.color}`}>
                        {tier.difficulty}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 font-sans mt-1 line-clamp-1">
                      {tier.description}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {isOnline && (
                    <div className="text-right mr-3 select-none">
                      <span className="text-[10px] text-slate-500 block uppercase font-mono tracking-wider">Online</span>
                      <span className="text-xs font-bold font-mono text-indigo-400 flex items-center justify-end gap-1">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse inline-block" />
                        {arenaStats[tier.id] ? `${arenaStats[tier.id].players} / ${arenaStats[tier.id].maxPlayers}` : '0 / 500'}
                      </span>
                    </div>
                  )}
                  <div className="text-right">
                    <span className="text-[10px] text-slate-500 block uppercase font-mono tracking-wider">Buy-In</span>
                    <span className={`text-sm font-bold font-mono ${unaffordable ? 'text-red-400' : 'text-emerald-400'}`}>
                      {tier.buyIn === 0 ? 'FREE' : `${tier.buyIn.toLocaleString()} c`}
                    </span>
                  </div>
                  <ChevronRight className={`w-4 h-4 text-slate-500 transition-transform ${active ? 'translate-x-1 text-indigo-400' : ''}`} />
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Arena Detail card & Launch Button - Right side */}
      <div className="lg:col-span-5 flex flex-col justify-between bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        {/* Glow */}
        <div
          className="absolute -top-12 -right-12 w-48 h-48 rounded-full blur-3xl opacity-10 pointer-events-none transition-all duration-300"
          style={{ backgroundColor: selectedTier.accentColor }}
        />

        <div>
          <span className={`text-[10px] px-2 py-1 rounded-full font-bold uppercase tracking-wider font-sans border border-transparent ${selectedTier.color}`}>
            {selectedTier.difficulty} Match
          </span>

          <h2 className="text-2xl font-bold font-sans tracking-tight text-white mt-4 flex items-center gap-2">
            {selectedTier.name}
          </h2>

          <p className="text-sm text-slate-300 font-sans mt-2.5 leading-relaxed">
            {selectedTier.description}
          </p>

          {/* Co-Op Active Invite Matching Banner */}
          {activeInvite && activeInvite.arenaId === selectedTier.id && (
            <div className="mt-4 p-3 rounded-xl bg-indigo-950/45 border border-indigo-500/30 text-xs text-indigo-200 flex flex-col gap-2 animate-pulse">
              <div className="flex items-center gap-2">
                <Swords className="w-4 h-4 text-indigo-400" />
                <span className="font-bold">CO-OP MATCHMAKING READY!</span>
              </div>
              <p className="text-[11px] text-indigo-300 leading-relaxed">
                Your ally <strong>{activeInvite.name}</strong> will join the active Arena Shard with you once you buy-in to this arena! 🤝
              </p>
            </div>
          )}

          {/* Co-Op Pending Invite Non-Matching Warning Banner */}
          {activeInvite && activeInvite.arenaId !== selectedTier.id && (
            <div className="mt-4 p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300 flex flex-col gap-1.5">
              <div className="flex items-center gap-2 text-amber-400">
                <Users className="w-4 h-4" />
                <span className="font-bold font-sans uppercase">Co-Op Lobby Pending</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                You invited <strong>{activeInvite.name}</strong> to play in the <strong>{ARENA_TIERS.find(t => t.id === activeInvite.arenaId)?.name || 'another Arena'}</strong>. Select that arena to activate co-op, or buy-in here to play Solo.
              </p>
              <button
                onClick={() => {
                  setSelectedTierId(activeInvite.arenaId);
                  onToast(`Switched to the invited Arena: ${ARENA_TIERS.find(t => t.id === activeInvite.arenaId)?.name}`, 'success');
                }}
                className="mt-1 self-start px-2.5 py-1.5 bg-indigo-600/20 hover:bg-indigo-600 border border-indigo-500/30 text-indigo-300 hover:text-white rounded-lg text-[10px] font-bold font-sans transition cursor-pointer"
              >
                Switch to Invited Arena ⚔️
              </button>
            </div>
          )}

          {/* Details list */}
          <div className="flex flex-col gap-3 mt-6 bg-slate-950/60 p-4 rounded-xl border border-slate-800/60">
            {/* Buy in */}
            <div className="flex items-center justify-between text-xs font-sans text-slate-400">
              <span className="flex items-center gap-1.5"><Landmark className="w-3.5 h-3.5 text-slate-500" /> Stake Buy-In</span>
              <span className="font-mono text-white font-semibold">
                {selectedTier.buyIn === 0 ? 'FREE' : `${selectedTier.buyIn.toLocaleString()} CHIPS`}
              </span>
            </div>

            {/* Minimum Extract threshold */}
            <div className="flex items-center justify-between text-xs font-sans text-slate-400">
              <span className="flex items-center gap-1.5"><Trophy className="w-3.5 h-3.5 text-slate-500" /> Target Value</span>
              <span className="font-mono text-emerald-400 font-semibold">
                {selectedTier.minExtract === 0 ? 'NONE (EXIT ANYTIME)' : `${selectedTier.minExtract.toLocaleString()} CHIPS`}
              </span>
            </div>

            {/* Simulated Active Competitors */}
            <div className="flex items-center justify-between text-xs font-sans text-slate-400">
              <span className="flex items-center gap-1.5"><Users className="w-3.5 h-3.5 text-slate-500" /> Active Challengers</span>
              <span className="font-mono text-cyan-400 font-semibold">{selectedTier.botsCount} Snakes</span>
            </div>

            {/* Live Online Players count */}
            {isOnline && (
              <div className="flex items-center justify-between text-xs font-sans text-slate-400 border-t border-slate-900/50 pt-2.5 mt-0.5">
                <span className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  Live Online Players
                </span>
                <span className="font-mono text-indigo-400 font-semibold">
                  {arenaStats[selectedTier.id] ? `${arenaStats[selectedTier.id].players} / ${arenaStats[selectedTier.id].maxPlayers}` : '0 / 500'}
                </span>
              </div>
            )}

            {/* Reward Multiplier */}
            <div className="flex items-center justify-between text-xs font-sans text-slate-400">
              <span className="flex items-center gap-1.5"><Compass className="w-3.5 h-3.5 text-slate-500" /> XP Multiplier</span>
              <span className="font-mono text-indigo-400 font-semibold">x{selectedTier.rewardMultiplier} Multi</span>
            </div>
          </div>

          {/* Mode Warning details */}
          <div className="mt-4 p-3 rounded-lg bg-indigo-950/20 border border-indigo-900/30 text-[11px] text-indigo-300 font-sans flex items-start gap-2 leading-relaxed">
            <Shield className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              {isOnline ? (
                <span>
                  <strong>ONLINE MULTIPLAYER SIM:</strong> High-tension lobby. Collect dropping star chips from opponents and escape safely. Successful extraction banks <strong>65% of carried chips</strong> after <strong>35% system commission</strong>.
                </span>
              ) : (
                <span>
                  <strong>OFFLINE PRACTICE MODE:</strong> Risk-free training ground. Test your skills against bots without wagering, losing, or earning any of your banked chips!
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Enter Trigger */}
        <div className="mt-6 pt-4 border-t border-slate-800/60">
          <button
            onClick={handleEnterArena}
            className={`w-full py-3 rounded-xl font-sans font-bold text-sm flex items-center justify-center gap-2 transition duration-200 cursor-pointer ${
              canPlay
                ? isOnline
                  ? 'bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-400 hover:to-indigo-500 text-white shadow-lg shadow-indigo-950/30 border border-indigo-500'
                  : 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-white shadow-lg shadow-amber-950/30 border border-amber-500'
                : 'bg-slate-950 border border-slate-800 text-slate-600 cursor-not-allowed'
            }`}
          >
            <Play className="w-4 h-4 fill-current" />
            {isOnline
              ? canPlay
                ? `BUY IN ARENA (-${selectedTier.buyIn.toLocaleString()} c)`
                : 'STAKE AMOUNT EXCEEDS BANK'
              : `START PRACTICE MODE (FREE)`}
          </button>
        </div>
      </div>
    </div>
  );
}
