import { useState, useEffect } from 'react';
import { Gift, Calendar, CheckCircle, Flame, Video, Sparkles } from 'lucide-react';
import { PlayerStats } from '../types';

interface DailyRewardsProps {
  playerStats: PlayerStats;
  onUpdateStats: (stats: Partial<PlayerStats>) => void;
  onToast: (msg: string, type: 'success' | 'info' | 'error') => void;
}

const DAILY_REWARD_VALUES = [10, 20, 50, 100, 250, 500, 1000];

export default function DailyRewards({ playerStats, onUpdateStats, onToast }: DailyRewardsProps) {
  const [canClaim, setCanClaim] = useState(false);
  const [timeLeft, setTimeLeft] = useState('');
  const [adLoading, setAdLoading] = useState(false);

  useEffect(() => {
    checkClaimStatus();
    const interval = setInterval(checkClaimStatus, 1000);
    return () => clearInterval(interval);
  }, [playerStats.lastDailyClaim]);

  const checkClaimStatus = () => {
    if (!playerStats.lastDailyClaim) {
      setCanClaim(true);
      return;
    }

    const lastClaimTime = new Date(playerStats.lastDailyClaim).getTime();
    const now = new Date().getTime();
    const cooldown = 24 * 60 * 60 * 1000; // 24 hours
    const diff = cooldown - (now - lastClaimTime);

    if (diff <= 0) {
      setCanClaim(true);
      setTimeLeft('');
    } else {
      setCanClaim(false);
      const hours = Math.floor(diff / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);
      setTimeLeft(
        `${hours.toString().padStart(2, '0')}:${minutes
          .toString()
          .padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
      );
    }
  };

  const handleClaim = (multiplier = 1) => {
    const currentDay = playerStats.dailyStreak % 7;
    const baseReward = DAILY_REWARD_VALUES[currentDay];
    const finalReward = baseReward * multiplier;

    const newStreak = playerStats.dailyStreak + 1;
    const now = new Date().toISOString();

    onUpdateStats({
      bankedChips: playerStats.bankedChips + finalReward,
      totalChipsEarned: playerStats.totalChipsEarned + finalReward,
      dailyStreak: newStreak,
      lastDailyClaim: now,
    });

    onToast(
      `Claimed Daily Reward: +${finalReward} CHIPS! ${multiplier > 1 ? '(2x Ad Bonus!)' : ''}`,
      'success'
    );
  };

  const watchAdDouble = () => {
    setAdLoading(true);
    onToast('Launching ad-stream sponsor link... Please hold', 'info');
    setTimeout(() => {
      setAdLoading(false);
      handleClaim(2);
    }, 2500);
  };

  const currentDayIndex = playerStats.dailyStreak % 7;

  return (
    <div id="daily-rewards-panel" className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
      {/* Background neon accent */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-6">
        <div>
          <h2 className="text-xl font-bold font-sans tracking-tight text-white flex items-center gap-2">
            <Gift className="w-5 h-5 text-emerald-400 animate-bounce" /> Daily Log Rewards
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-1">
            Build your claim streak to secure massive payouts for arena entries!
          </p>
        </div>

        <div className="flex items-center gap-4 bg-slate-950 px-4 py-2 rounded-xl border border-slate-800/60">
          <div className="flex items-center gap-1.5">
            <Flame className="w-5 h-5 text-amber-500 fill-amber-500" />
            <span className="text-sm font-semibold font-sans text-white">{playerStats.dailyStreak} Days</span>
          </div>
          <span className="text-xs text-slate-500 font-sans">Current Streak</span>
        </div>
      </div>

      {/* Days grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-3 mb-6">
        {DAILY_REWARD_VALUES.map((val, idx) => {
          const isClaimed = idx < currentDayIndex;
          const isToday = idx === currentDayIndex && canClaim;
          const isUpcoming = idx > currentDayIndex || (idx === currentDayIndex && !canClaim);

          return (
            <div
              key={idx}
              className={`relative flex flex-col items-center justify-between p-4 rounded-xl border transition-all duration-300 ${
                isClaimed
                  ? 'bg-slate-950 border-emerald-500/20 text-slate-500'
                  : isToday
                  ? 'bg-emerald-950/20 border-emerald-400 text-white shadow-lg shadow-emerald-950/40 ring-1 ring-emerald-500/30'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400'
              }`}
            >
              <span className="text-[10px] font-mono tracking-wider uppercase opacity-60">Day {idx + 1}</span>
              <Calendar
                className={`w-8 h-8 my-3 transition-colors ${
                  isClaimed ? 'text-emerald-500/40' : isToday ? 'text-emerald-400 animate-pulse' : 'text-slate-600'
                }`}
              />
              <span className="text-sm font-bold font-mono tracking-tight text-white">
                {val} <span className="text-[10px] text-emerald-400">c</span>
              </span>

              {isClaimed && (
                <div className="absolute top-1 right-1 bg-emerald-500 rounded-full p-0.5 text-black">
                  <CheckCircle className="w-3 h-3 fill-emerald-500 stroke-black text-black" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Claim Actions */}
      <div className="bg-slate-950/40 rounded-xl border border-slate-800 p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          {canClaim ? (
            <p className="text-sm text-emerald-400 font-sans flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 animate-spin text-emerald-400" />
              Day {currentDayIndex + 1} reward is available! Claim now to boost your chips balance.
            </p>
          ) : (
            <p className="text-sm text-slate-400 font-sans">
              Next Daily Claim available in: <span className="font-mono font-semibold text-emerald-400">{timeLeft || 'calculating...'}</span>
            </p>
          )}
        </div>

        <div className="flex gap-3 w-full sm:w-auto">
          {canClaim ? (
            <>
              <button
                id="btn-claim-daily-standard"
                onClick={() => handleClaim(1)}
                className="flex-1 sm:flex-none px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-sans font-medium rounded-xl border border-slate-700 text-xs transition duration-200"
              >
                Standard Claim
              </button>
              <button
                id="btn-claim-daily-ad"
                disabled={adLoading}
                onClick={watchAdDouble}
                className="flex-1 sm:flex-none px-5 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-sans font-bold rounded-xl text-xs flex items-center justify-center gap-1.5 transition duration-200 shadow-md shadow-emerald-950/40 cursor-pointer disabled:opacity-50"
              >
                <Video className="w-4 h-4" />
                {adLoading ? 'Buffering Sponsor...' : 'Watch Ad (Double Claim)'}
              </button>
            </>
          ) : (
            <button
              disabled
              className="w-full sm:w-auto px-6 py-2.5 bg-slate-900 border border-slate-800 text-slate-500 font-sans font-medium rounded-xl text-xs cursor-not-allowed"
            >
              Already Claimed Today
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
