import React, { useState } from 'react';
import { Film, ThumbsUp, Flame, ExternalLink, Plus, Search, Trophy, Play, Check, Shield } from 'lucide-react';
import { PlayerStats } from '../types';

export interface GameClip {
  id: string;
  title: string;
  creatorName: string;
  creatorTag: string;
  country: string;
  flag: string;
  videoUrl: string;
  platform: 'YouTube' | 'Twitch' | 'Rumble';
  extractedChips: number;
  upvotes: number;
  dateStr: string;
  tags: string[];
}

const SAMPLE_CLIPS: GameClip[] = [
  {
    id: 'clip-1',
    title: '1,00,00,000 CHIPS EXTRACTION CLUTCH IN TIER-05 ARENA! 🔥',
    creatorName: 'Hari',
    creatorTag: '#IND-001',
    country: 'IN',
    flag: '🇮🇳',
    videoUrl: 'https://youtube.com/watch?v=demo_hari_crore',
    platform: 'YouTube',
    extractedChips: 10000000,
    upvotes: 4210,
    dateStr: '23 Jan 2027',
    tags: ['Crore Milestone', 'Tier-05', 'High Stakes']
  },
  {
    id: 'clip-2',
    title: 'SOLO 1V3 VIPER TRAP ON EXTRACTION ZONE BOUNDARY 🐍',
    creatorName: 'Apex_Viper',
    creatorTag: '#USA-882',
    country: 'US',
    flag: '🇺🇸',
    videoUrl: 'https://twitch.tv/videos/demo_apex_clutch',
    platform: 'Twitch',
    extractedChips: 2500000,
    upvotes: 1890,
    dateStr: '25 Jan 2027',
    tags: ['1v3 Clutch', 'Platinum Tier']
  },
  {
    id: 'clip-3',
    title: 'NINJA SNAKE DNA SKIN SHOWCASE & SPEED EXTRACTION ⚡',
    creatorName: 'Shadow_Ninja',
    creatorTag: '#JPN-309',
    country: 'JP',
    flag: '🇯🇵',
    videoUrl: 'https://youtube.com/watch?v=demo_ninja_speed',
    platform: 'YouTube',
    extractedChips: 5000000,
    upvotes: 1240,
    dateStr: '22 Jan 2027',
    tags: ['Skin Showcase', 'Speed Run']
  }
];

interface ClipShowcaseProps {
  playerStats: PlayerStats;
  onToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onInspectPlayer?: (player: any) => void;
}

export default function ClipShowcase({ playerStats, onToast, onInspectPlayer }: ClipShowcaseProps) {
  const [clips, setClips] = useState<GameClip[]>(SAMPLE_CLIPS);
  const [upvotedClipIds, setUpvotedClipIds] = useState<Set<string>>(new Set());
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [filterTag, setFilterTag] = useState<string>('all');

  // Form states for uploading clip
  const [newTitle, setNewTitle] = useState('');
  const [newUrl, setNewUrl] = useState('');
  const [newPlatform, setNewPlatform] = useState<'YouTube' | 'Twitch'>('YouTube');
  const [newChips, setNewChips] = useState<number>(500000);
  const [newTag, setNewTag] = useState('Clutch Extraction');

  const handleUpvote = (id: string) => {
    const updatedClips = clips.map((clip) => {
      if (clip.id === id) {
        const isUpvoted = upvotedClipIds.has(id);
        const newUpvotes = isUpvoted ? clip.upvotes - 1 : clip.upvotes + 1;

        if (isUpvoted) {
          upvotedClipIds.delete(id);
        } else {
          upvotedClipIds.add(id);
          onToast(`Upvoted "${clip.title}"! 🔥`, 'success');
        }

        return { ...clip, upvotes: newUpvotes };
      }
      return clip;
    });

    setClips(updatedClips);
    setUpvotedClipIds(new Set(upvotedClipIds));
  };

  const handleUploadClip = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newUrl.trim()) {
      onToast('Clip Title and Video URL are required!', 'error');
      return;
    }

    const created: GameClip = {
      id: `clip-${Date.now()}`,
      title: newTitle.trim(),
      creatorName: playerStats.name,
      creatorTag: playerStats.userTag || '#IND-001',
      country: playerStats.country || 'IN',
      flag: '🇮🇳',
      videoUrl: newUrl.trim(),
      platform: newPlatform,
      extractedChips: newChips,
      upvotes: 1,
      dateStr: 'Today',
      tags: [newTag]
    };

    setClips([created, ...clips]);
    setShowUploadModal(false);
    setNewTitle('');
    setNewUrl('');
    onToast('Game Clip published to Esports Highlights feed! 🎬', 'success');
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-6 relative overflow-hidden">
      {/* Glow backgrounds */}
      <div className="absolute -top-12 -right-12 w-64 h-64 bg-red-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h2 className="text-2xl font-bold font-sans tracking-tight text-white flex items-center gap-2">
            <Film className="w-7 h-7 text-red-400" />
            Esports Clip Showcase & Highlights
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-1">
            Watch community clutch extractions, vote on top plays of the week, and share your own YouTube & Twitch clips!
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="px-4 py-2.5 bg-red-600 hover:bg-red-500 text-white font-sans text-xs font-bold rounded-xl transition-all shadow-lg flex items-center gap-1.5 shrink-0"
        >
          <Plus className="w-4 h-4" /> Share Game Clip
        </button>
      </div>

      {/* Clip Feed Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {clips.map((clip) => {
          const isUpvoted = upvotedClipIds.has(clip.id);

          return (
            <div
              key={clip.id}
              className="bg-slate-950 border border-slate-800 hover:border-slate-700 rounded-2xl overflow-hidden shadow-xl flex flex-col justify-between transition-all"
            >
              {/* Thumbnail / Video Banner */}
              <div className="relative bg-slate-900 aspect-video flex items-center justify-center overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent z-10" />
                
                {/* Simulated Play Overlay */}
                <div className="w-12 h-12 rounded-full bg-red-600/90 text-white flex items-center justify-center pl-1 z-20 group-hover:scale-110 transition-transform shadow-lg cursor-pointer">
                  <Play className="w-5 h-5 fill-white" />
                </div>

                {/* Extracted Chips Badge */}
                <div className="absolute top-3 left-3 z-20 bg-emerald-500/90 text-black text-[10px] font-mono font-bold px-2 py-0.5 rounded-full shadow">
                  💰 {clip.extractedChips.toLocaleString()} c Extracted
                </div>

                {/* Platform Badge */}
                <div className="absolute top-3 right-3 z-20 bg-slate-900/90 text-white text-[10px] font-mono font-bold px-2 py-0.5 rounded-full border border-slate-700">
                  {clip.platform}
                </div>

                {/* Creator info on thumbnail */}
                <div className="absolute bottom-3 left-3 z-20 flex items-center gap-2">
                  <span className="text-xl">{clip.flag}</span>
                  <div>
                    <span className="text-xs font-bold text-white font-sans block">{clip.creatorName}</span>
                    <span className="text-[10px] text-slate-400 font-mono">{clip.creatorTag}</span>
                  </div>
                </div>
              </div>

              {/* Clip Details */}
              <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-xs font-bold text-white font-sans line-clamp-2 leading-relaxed">
                    {clip.title}
                  </h3>

                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {clip.tags.map((t, i) => (
                      <span key={i} className="text-[9px] bg-slate-900 text-slate-300 font-mono px-2 py-0.5 rounded border border-slate-800">
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Upvotes & External Watch Link */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-900 text-xs font-sans">
                  <button
                    onClick={() => handleUpvote(clip.id)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold font-mono transition-all ${
                      isUpvoted
                        ? 'bg-red-500/20 text-red-400 border border-red-500/40'
                        : 'bg-slate-900 hover:bg-slate-800 text-slate-300'
                    }`}
                  >
                    <Flame className={`w-3.5 h-3.5 ${isUpvoted ? 'text-red-400 fill-red-400' : 'text-slate-400'}`} />
                    <span>{clip.upvotes}</span>
                  </button>

                  <a
                    href={clip.videoUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="flex items-center gap-1 px-3 py-1.5 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 rounded-xl text-xs font-bold transition-all"
                  >
                    Watch <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* UPLOAD CLIP MODAL */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-lg w-full shadow-2xl space-y-4">
            <h3 className="text-base font-bold text-white font-sans flex items-center gap-2 border-b border-slate-800 pb-3">
              <Film className="w-5 h-5 text-red-400" /> Share Game Clip to Community Feed
            </h3>

            <form onSubmit={handleUploadClip} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Clip Title</label>
                <input
                  type="text"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. INSANE 1V2 EXTRACTION CLUTCH!"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-red-500"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Platform</label>
                  <select
                    value={newPlatform}
                    onChange={(e) => setNewPlatform(e.target.value as any)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none"
                  >
                    <option value="YouTube">YouTube</option>
                    <option value="Twitch">Twitch</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">Extracted Chips (c)</label>
                  <input
                    type="number"
                    value={newChips}
                    onChange={(e) => setNewChips(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white font-mono focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">Video URL</label>
                <input
                  type="url"
                  value={newUrl}
                  onChange={(e) => setNewUrl(e.target.value)}
                  placeholder="https://youtube.com/watch?v=..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-2.5 text-xs text-white font-mono focus:outline-none"
                  required
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold rounded-xl"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-red-600 hover:bg-red-500 text-white text-xs font-bold rounded-xl shadow-lg"
                >
                  Publish Clip
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
