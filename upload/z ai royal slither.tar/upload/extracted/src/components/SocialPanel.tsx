import { useState, useEffect, useRef, FormEvent } from 'react';
import { 
  Users, UserPlus, Shield, MessageSquare, Gift, Search, X, Check, 
  Crown, LogOut, Coins, Plus, Send, Info, Award, CircleDot, Zap, Swords, Eye, Globe
} from 'lucide-react';
import { PlayerStats, Friend, Rival, Clan, ClanMember, ClanMessage } from '../types';
import { ARENA_TIERS } from '../data';
import { 
  subscribeToActiveSessions, subscribeToClans, createOrUpdateClan, 
  subscribeToClanMessages, sendClanMessage 
} from '../utils/firebaseSync';

export const getFriendSimulatedChips = (friend: Friend): number => {
  if (friend.name === 'ApexViper') return 1200;
  if (friend.name === 'ShadowSlinker') return 150;
  if (friend.name === 'CoinGobbler') return 40;
  if (friend.name === 'VenomKing') return 250000;
  return friend.level * 45;
};

interface SocialPanelProps {
  playerStats: PlayerStats;
  onUpdateStats: (stats: Partial<PlayerStats>) => void;
  onToast: (msg: string, type: 'success' | 'info' | 'error') => void;
  onSpectateFriend?: (name: string, color: string) => void;
  onJoinArena?: (arenaTierId: string) => void;
}

// Initial mockup data for friends
const INITIAL_FRIENDS: Friend[] = [
  { id: 'f-1', name: 'ApexViper', userTag: 'APEX-1029', status: 'online', currentArenaId: 'tier-1', currentArenaName: 'Training Pit', level: 42, skinColor: '#10b981', giftSentToday: false, giftReceivedToday: true },
  { id: 'f-2', name: 'ShadowSlinker', userTag: 'SLNK-9281', status: 'in-match', currentArenaId: 'tier-2', currentArenaName: 'High Stakes Lounge', level: 18, skinColor: '#a855f7', giftSentToday: false, giftReceivedToday: false },
  { id: 'f-3', name: 'CoinGobbler', userTag: 'COIN-5432', status: 'offline', level: 29, skinColor: '#eab308', giftSentToday: true, giftReceivedToday: false },
  { id: 'f-4', name: 'VenomKing', userTag: 'VNOM-0001', status: 'idle', level: 55, skinColor: '#ef4444', giftSentToday: false, giftReceivedToday: false },
];

// Initial mockup data for rivals
const INITIAL_RIVALS: Rival[] = [
  {
    id: 'r-1',
    name: 'VenomKing',
    userTag: 'VNOM-0001',
    status: 'in-match',
    currentArenaId: 'tier-3',
    currentArenaName: 'Venom Pit (5,000 Buy-In)',
    level: 55,
    skinColor: '#ef4444',
    timesKilledByYou: 2,
    timesKilledYou: 5,
    lastEncounterDate: 'Today, 2:15 PM'
  },
  {
    id: 'r-2',
    name: 'ShadowSlinker',
    userTag: 'SLNK-9281',
    status: 'online',
    currentArenaId: 'tier-2',
    currentArenaName: 'High Stakes Lounge (1,000 Buy-In)',
    level: 38,
    skinColor: '#a855f7',
    timesKilledByYou: 4,
    timesKilledYou: 1,
    lastEncounterDate: 'Yesterday, 8:40 PM'
  },
  {
    id: 'r-3',
    name: 'ApexViper',
    userTag: 'APEX-1029',
    status: 'in-match',
    currentArenaId: 'tier-4',
    currentArenaName: 'Extreme Arena (25,000 Buy-In)',
    level: 42,
    skinColor: '#10b981',
    timesKilledByYou: 1,
    timesKilledYou: 3,
    lastEncounterDate: '2 days ago'
  }
];

// Global community players database for searching and connecting with anyone globally
const GLOBAL_COMMUNITY_PLAYERS = [
  { name: 'CobraMaster_IN', userTag: 'IND-8821', country: 'IN', flag: '🇮🇳', level: 48, chips: 4500000, skinColor: '#10b981', status: 'online' },
  { name: 'Viper_Syndicate', userTag: 'IND-1049', country: 'IN', flag: '🇮🇳', level: 52, chips: 12500000, skinColor: '#eab308', status: 'in-match' },
  { name: 'Mamba_Strike', userTag: 'USA-4012', country: 'US', flag: '🇺🇸', level: 39, chips: 2100000, skinColor: '#ef4444', status: 'online' },
  { name: 'Tokyo_Slinker', userTag: 'JPN-9012', country: 'JP', flag: '🇯🇵', level: 44, chips: 3800000, skinColor: '#a855f7', status: 'idle' },
  { name: 'Seoul_Apex', userTag: 'KOR-2290', country: 'KR', flag: '🇰🇷', level: 50, chips: 8900000, skinColor: '#3b82f6', status: 'online' },
  { name: 'London_Viper', userTag: 'GBR-5012', country: 'GB', flag: '🇬🇧', level: 35, chips: 1800000, skinColor: '#f43f5e', status: 'in-match' },
  { name: 'Dragon_Cobra', userTag: 'IND-2201', country: 'IN', flag: '🇮🇳', level: 41, chips: 2900000, skinColor: '#06b6d4', status: 'online' },
  { name: 'Phoenix_Venom', userTag: 'BRA-7712', country: 'BR', flag: '🇧🇷', level: 33, chips: 950000, skinColor: '#84cc16', status: 'offline' },
  { name: 'Berlin_Predator', userTag: 'DEU-3321', country: 'DE', flag: '🇩🇪', level: 46, chips: 5400000, skinColor: '#ec4899', status: 'online' },
  { name: 'Sydney_Strike', userTag: 'AUS-6612', country: 'AU', flag: '🇦🇺', level: 37, chips: 1400000, skinColor: '#6366f1', status: 'idle' },
  { name: 'Zenith_Slither', userTag: 'CAN-8840', country: 'CA', flag: '🇨🇦', level: 28, chips: 620000, skinColor: '#14b8a6', status: 'online' },
  { name: 'Paris_Serpent', userTag: 'FRA-1190', country: 'FR', flag: '🇫🇷', level: 38, chips: 1950000, skinColor: '#8b5cf6', status: 'offline' },
];

// Available public clans to join
const PUBLIC_CLANS: Clan[] = [
  {
    id: 'c-1',
    name: 'Apex Predators',
    tag: 'APEX',
    emblem: '🦅',
    level: 8,
    xp: 4200,
    bankedChips: 15000,
    description: 'Elite hunters only. Extract with 100+ chips or get kicked.',
    maxMembers: 30,
    members: [
      { id: 'm-1', name: 'VenomKing', userTag: 'VNOM-0001', rank: 'Leader', level: 55, totalContributedChips: 5000, isOnline: true },
      { id: 'm-2', name: 'ApexViper', userTag: 'APEX-1029', rank: 'Co-Leader', level: 42, totalContributedChips: 3500, isOnline: true },
      { id: 'm-3', name: 'StrikeFast', userTag: 'FAST-8822', rank: 'Viper', level: 22, totalContributedChips: 1200, isOnline: false }
    ]
  },
  {
    id: 'c-2',
    name: 'Slinky Syndicate',
    tag: 'SLYK',
    emblem: '🐍',
    level: 5,
    xp: 1200,
    bankedChips: 4500,
    description: 'Casual chip collectors. Let\'s grow together!',
    maxMembers: 20,
    members: [
      { id: 'm-4', name: 'CozyCobra', userTag: 'COZY-7311', rank: 'Leader', level: 31, totalContributedChips: 2000, isOnline: true },
      { id: 'm-5', name: 'ShadowSlinker', userTag: 'SLNK-9281', rank: 'Viper', level: 18, totalContributedChips: 800, isOnline: true },
      { id: 'm-6', name: 'GoldHoarder', userTag: 'GOLD-4455', rank: 'Viper', level: 15, totalContributedChips: 500, isOnline: false }
    ]
  }
];

const PRESET_EMBLEMS = ['🐍', '🦅', '🎯', '💀', '💎', '🔥', '👑', '⚡', '🏆', '☣️'];

const BOT_REPLIES = [
  "Nice run in the High-Stakes Arena today! 🏆",
  "That was an insane cut-off! Easy food. 💥",
  "Don't forget to deposit chips, we need that Level 10 Clan Buff! 💎",
  "Who is up for some Venom Arena lobbies? 🐍",
  "Just extracted with 250 chips, feeling like a god! 😎",
  "Slinky style, baby! 😂",
  "Be careful of VenomKing, he was hunting everyone in Tier 3!"
];

export default function SocialPanel({ playerStats, onUpdateStats, onToast, onSpectateFriend, onJoinArena }: SocialPanelProps) {
  const [friends, setFriends] = useState<Friend[]>(() => {
    const saved = localStorage.getItem('venom_friends');
    return saved ? JSON.parse(saved) : INITIAL_FRIENDS;
  });

  const [rivals, setRivals] = useState<Rival[]>(() => {
    const saved = localStorage.getItem('venom_rivals');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return playerStats.rivals && playerStats.rivals.length > 0 ? playerStats.rivals : INITIAL_RIVALS;
  });

  const [clans, setClans] = useState<Clan[]>(() => {
    const saved = localStorage.getItem('venom_clans');
    return saved ? JSON.parse(saved) : PUBLIC_CLANS;
  });

  const [activeSubTab, setActiveSubTab] = useState<'friends' | 'clan'>('friends');
  
  // Friends & Rivals states
  const [friendSearch, setFriendSearch] = useState('');
  const [friendTabMode, setFriendTabMode] = useState<'my_friends' | 'my_rivals' | 'global_search'>('my_friends');
  const [selectedCountryFilter, setSelectedCountryFilter] = useState<string>('ALL');
  
  // Clan states
  const [clanSearch, setClanSearch] = useState('');
  const [showCreateClan, setShowCreateClan] = useState(false);
  const [newClanName, setNewClanName] = useState('');
  const [newClanTag, setNewClanTag] = useState('');
  const [newClanEmblem, setNewClanEmblem] = useState('🐍');
  const [newClanDesc, setNewClanDesc] = useState('');
  const [depositAmount, setDepositAmount] = useState('');
  
  // Clan chat state
  const [chatMessage, setChatMessage] = useState('');
  const [clanMessages, setClanMessages] = useState<ClanMessage[]>([]);

  // 1. Listen to real-time active player sessions
  useEffect(() => {
    const unsub = subscribeToActiveSessions((sessions) => {
      setFriends((prevFriends) => {
        return prevFriends.map((friend) => {
          const liveSession = sessions[friend.userTag];
          if (liveSession) {
            return {
              ...friend,
              status: liveSession.status as 'online' | 'offline' | 'in-match',
              level: liveSession.level || friend.level,
              skinColor: liveSession.skinColor || friend.skinColor,
            };
          }
          return friend;
        });
      });
    });
    return () => unsub();
  }, []);

  // 2. Listen to real-time syndicates (clans) list
  useEffect(() => {
    const unsub = subscribeToClans((firestoreClans) => {
      if (firestoreClans.length === 0) {
        // Seed default public clans in Firestore if empty
        PUBLIC_CLANS.forEach(async (c) => {
          try {
            await createOrUpdateClan(c);
          } catch (e) {
            console.warn(`[Firebase] Skipped/Failed seeding default clan ${c.name}:`, e);
          }
        });
        setClans(PUBLIC_CLANS);
      } else {
        setClans(firestoreClans);
      }
    });
    return () => unsub();
  }, []);

  // 3. Listen to real-time syndicate chat messages
  useEffect(() => {
    if (!playerStats.clanId) return;
    const unsub = subscribeToClanMessages(playerStats.clanId, (msgs) => {
      setClanMessages(msgs);
    });
    return () => unsub();
  }, [playerStats.clanId]);

  // Invite Arena Modal States
  const [activeInviteFriend, setActiveInviteFriend] = useState<Friend | null>(null);
  const [inviteSelectedArenaId, setInviteSelectedArenaId] = useState<string>('tier-1');
  const [inviteStatusMessage, setInviteStatusMessage] = useState<{
    type: 'success' | 'warning' | 'error' | 'counter';
    text: string;
    counterArenaId?: string;
  } | null>(null);

  const chatEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll chat
  useEffect(() => {
    if (chatEndRef.current) {
      chatEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [clanMessages]);

  // Save state helpers
  const saveFriends = (updated: Friend[]) => {
    setFriends(updated);
    localStorage.setItem('venom_friends', JSON.stringify(updated));
  };

  const saveRivals = (updated: Rival[]) => {
    setRivals(updated);
    localStorage.setItem('venom_rivals', JSON.stringify(updated));
    onUpdateStats({ rivals: updated });
  };

  const handleHuntRival = (rival: Rival) => {
    const targetArenaId = rival.currentArenaId || 'tier-1';
    const targetArenaName = rival.currentArenaName || 'Training Pit';
    if (onJoinArena) {
      onJoinArena(targetArenaId);
      onToast(`⚔️ HUNT INITIATED: Entering ${targetArenaName} to take down ${rival.name}!`, 'success');
    } else {
      onToast(`⚔️ Rival ${rival.name} is currently playing in ${targetArenaName}! Select that arena from the lobby!`, 'info');
    }
  };

  const handleRemoveRival = (rivalId: string, rivalName: string) => {
    const updated = rivals.filter((r) => r.id !== rivalId);
    saveRivals(updated);
    onToast(`Removed ${rivalName} from your Rival List.`, 'info');
  };

  const handleConvertRivalToFriend = (rival: Rival) => {
    const newFriend: Friend = {
      id: `f-${Date.now()}`,
      name: rival.name,
      userTag: rival.userTag,
      status: rival.status,
      currentArenaId: rival.currentArenaId,
      currentArenaName: rival.currentArenaName,
      level: rival.level,
      skinColor: rival.skinColor,
      giftSentToday: false,
      giftReceivedToday: false
    };

    if (!friends.some((f) => f.userTag === rival.userTag)) {
      saveFriends([...friends, newFriend]);
    }

    saveRivals(rivals.filter((r) => r.id !== rival.id));
    onToast(`🤝 Peace declared! Converted ${rival.name} from Rival to Friend!`, 'success');
  };

  const saveClans = (updated: Clan[]) => {
    setClans(updated);
    localStorage.setItem('venom_clans', JSON.stringify(updated));
  };

  // 1. FRIENDS ACTIONS
  const handleAddFriend = () => {
    const search = friendSearch.trim();
    if (!search) {
      onToast('Please enter a friend name or player tag.', 'error');
      return;
    }

    // Format check: either NAME or NAME-NUMBER
    const parts = search.split('-');
    const name = parts[0];
    const tagNum = parts[1] || Math.floor(1000 + Math.random() * 9000).toString();
    const finalTag = `${name.substring(0, 4).toUpperCase()}-${tagNum}`;

    // Avoid duplicates
    if (friends.some(f => f.name.toLowerCase() === name.toLowerCase())) {
      onToast(`"${name}" is already your friend!`, 'error');
      return;
    }

    const newFriend: Friend = {
      id: `f-${Date.now()}`,
      name: name,
      userTag: finalTag,
      status: Math.random() > 0.4 ? 'online' : 'offline',
      level: Math.floor(5 + Math.random() * 45),
      skinColor: ['#10b981', '#a855f7', '#eab308', '#ef4444', '#3b82f6', '#f43f5e'][Math.floor(Math.random() * 6)],
      giftSentToday: false,
      giftReceivedToday: Math.random() > 0.7 // Randomly let them receive gifts
    };

    const updated = [...friends, newFriend];
    saveFriends(updated);
    setFriendSearch('');
    onToast(`Friend request accepted! Added ${name} (${finalTag})`, 'success');
  };

  const handleAddGlobalPlayerAsFriend = (gp: { name: string; userTag: string; level: number; skinColor: string; status: string }) => {
    if (friends.some(f => f.name.toLowerCase() === gp.name.toLowerCase() || f.userTag === gp.userTag)) {
      onToast(`"${gp.name}" is already in your Friends list!`, 'info');
      return;
    }

    const newFriend: Friend = {
      id: `f-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: gp.name,
      userTag: gp.userTag,
      status: gp.status as 'online' | 'offline' | 'in-match' | 'idle',
      level: gp.level,
      skinColor: gp.skinColor,
      giftSentToday: false,
      giftReceivedToday: false
    };

    const updated = [...friends, newFriend];
    saveFriends(updated);
    onToast(`Connected! Added ${gp.name} (${gp.userTag}) to your Friends! 🤝`, 'success');
  };

  const handleSendGift = (friendId: string) => {
    const updated = friends.map(friend => {
      if (friend.id === friendId) {
        if (friend.giftSentToday) return friend;
        onToast(`Sent 25 Daily Chips Gift to ${friend.name}! 🎁`, 'success');
        return { ...friend, giftSentToday: true };
      }
      return friend;
    });
    saveFriends(updated);
  };

  const handleClaimGift = (friendId: string) => {
    const updated = friends.map(friend => {
      if (friend.id === friendId) {
        if (!friend.giftReceivedToday) return friend;
        
        // Credited 25 chips
        onUpdateStats({
          bankedChips: playerStats.bankedChips + 25,
          totalChipsEarned: playerStats.totalChipsEarned + 25
        });
        onToast(`Claimed 25 chips gift from ${friend.name}! 🪙`, 'success');
        
        return { ...friend, giftReceivedToday: false };
      }
      return friend;
    });
    saveFriends(updated);
  };

  const handleRemoveFriend = (friendId: string, friendName: string) => {
    const updated = friends.filter(f => f.id !== friendId);
    saveFriends(updated);
    onToast(`Removed ${friendName} from friends list.`, 'info');
  };

  const handleInviteFriendToMatch = (friend: Friend) => {
    if (friend.status === 'offline') {
      onToast(`${friend.name} is offline. You can only invite active friends to play!`, 'error');
      return;
    }
    
    // Open dynamic co-op invite modal
    setActiveInviteFriend(friend);
    setInviteSelectedArenaId('tier-1');
    setInviteStatusMessage(null);
  };

  // 2. CLAN ACTIONS
  const handleCreateClan = async (e: FormEvent) => {
    e.preventDefault();
    const name = newClanName.trim();
    const tag = newClanTag.trim().toUpperCase();
    const desc = newClanDesc.trim();

    if (!name || name.length < 4) {
      onToast('Clan name must be at least 4 characters.', 'error');
      return;
    }
    if (!tag || tag.length < 3 || tag.length > 4) {
      onToast('Clan tag must be exactly 3 or 4 uppercase letters.', 'error');
      return;
    }
    if (playerStats.bankedChips < 500) {
      onToast('You need at least 500 banked chips to charter a new Syndicate!', 'error');
      return;
    }

    const newClanId = `c-${Date.now()}`;
    const selfMember: ClanMember = {
      id: 'player-member',
      name: playerStats.name,
      userTag: playerStats.userTag || `PLR-${Math.floor(1000 + Math.random() * 9000)}`,
      rank: 'Leader',
      level: playerStats.level,
      totalContributedChips: 0,
      isOnline: true
    };

    const createdClan: Clan = {
      id: newClanId,
      name,
      tag,
      emblem: newClanEmblem,
      level: 1,
      xp: 0,
      bankedChips: 0,
      description: desc || 'The ultimate predator syndicate.',
      members: [selfMember],
      maxMembers: 20
    };

    // Deduct registration chips (500) and update local profile
    onUpdateStats({
      bankedChips: playerStats.bankedChips - 500,
      clanId: newClanId,
      clanRank: 'Leader'
    });

    await createOrUpdateClan(createdClan);
    setShowCreateClan(false);
    onToast(`Successfully registered the "${name} [${tag}]" Syndicate! -500 chips`, 'success');
  };

  const handleJoinClan = async (clanId: string) => {
    if (playerStats.clanId) {
      onToast('You are already a member of a Syndicate! Leave your current clan first.', 'error');
      return;
    }

    const targetClan = clans.find(c => c.id === clanId);
    if (!targetClan) return;

    if (targetClan.members.length >= targetClan.maxMembers) {
      onToast('This Syndicate is currently full!', 'error');
      return;
    }

    const selfMember: ClanMember = {
      id: 'player-member',
      name: playerStats.name,
      userTag: playerStats.userTag || `PLR-${Math.floor(1000 + Math.random() * 9000)}`,
      rank: 'Viper',
      level: playerStats.level,
      totalContributedChips: 0,
      isOnline: true
    };

    const updatedClan = {
      ...targetClan,
      members: [...targetClan.members, selfMember]
    };

    await createOrUpdateClan(updatedClan);
    onUpdateStats({
      clanId: clanId,
      clanRank: 'Viper'
    });
    onToast(`Joined Syndicate: ${targetClan.name} [${targetClan.tag}]`, 'success');
  };

  const handleLeaveClan = async () => {
    if (!playerStats.clanId) return;

    const clanId = playerStats.clanId;
    const targetClan = clans.find(c => c.id === clanId);
    if (!targetClan) return;

    // Remove self from clan members
    const nextMembers = targetClan.members.filter(m => m.userTag !== playerStats.userTag && m.id !== 'player-member');
    
    if (nextMembers.length === 0) {
      // If clan is empty, we could keep or clean up. Let's just write an empty/removable record
      const updatedClan = {
        ...targetClan,
        members: []
      };
      await createOrUpdateClan(updatedClan);
    } else {
      // If there are other members left, nominate next leader if leaving leader
      const isLeader = playerStats.clanRank === 'Leader';
      const updatedMembers = nextMembers.map((m, idx) => {
        if (isLeader && idx === 0) {
          return { ...m, rank: 'Leader' as const };
        }
        return m;
      });

      const updatedClan = {
        ...targetClan,
        members: updatedMembers
      };
      await createOrUpdateClan(updatedClan);
    }

    onUpdateStats({
      clanId: null,
      clanRank: undefined
    });
    onToast(`You have left the Syndicate.`, 'info');
  };

  const handleDepositChips = async () => {
    const amount = parseInt(depositAmount);
    if (isNaN(amount) || amount <= 0) {
      onToast('Please enter a valid chip deposit amount.', 'error');
      return;
    }

    if (playerStats.bankedChips < amount) {
      onToast('Insufficient chip balance to deposit.', 'error');
      return;
    }

    const clanId = playerStats.clanId;
    if (!clanId) return;

    const targetClan = clans.find(c => c.id === clanId);
    if (!targetClan) return;

    // 10 deposited chips = 1 Clan XP points
    const earnedXp = Math.floor(amount * 0.1);

    const nextBank = targetClan.bankedChips + amount;
    let nextXp = targetClan.xp + earnedXp;
    let nextLevel = targetClan.level;
    const xpRequired = targetClan.level * 1000;

    if (nextXp >= xpRequired) {
      nextXp -= xpRequired;
      nextLevel += 1;
      setTimeout(() => {
        onToast(`🏆 SYNDICATE LEVEL UP! ${targetClan.name} is now LEVEL ${nextLevel}!`, 'success');
      }, 500);
    }

    // Update player contribution in members list
    const nextMembers = targetClan.members.map(m => {
      if (m.userTag === playerStats.userTag || m.id === 'player-member') {
        return {
          ...m,
          totalContributedChips: (m.totalContributedChips || 0) + amount,
          level: playerStats.level // keep level synced
        };
      }
      return m;
    });

    const updatedClan: Clan = {
      ...targetClan,
      bankedChips: nextBank,
      xp: nextXp,
      level: nextLevel,
      members: nextMembers
    };

    await createOrUpdateClan(updatedClan);
    onUpdateStats({
      bankedChips: playerStats.bankedChips - amount
    });
    setDepositAmount('');
    onToast(`Deposited ${amount} chips to Syndicate Bank! Earned +${earnedXp} Clan XP.`, 'success');
  };

  const handleSendChatMessage = async (e: FormEvent) => {
    e.preventDefault();
    const msgText = chatMessage.trim();
    if (!msgText) return;

    if (!playerStats.clanId) {
      onToast('You must join a Syndicate to send messages.', 'error');
      return;
    }

    await sendClanMessage(playerStats.clanId, {
      sender: playerStats.name,
      senderRank: playerStats.clanRank || 'Viper',
      message: msgText
    });

    setChatMessage('');
  };

  // Filter clans based on search
  const filteredClans = clans.filter(c => 
    c.name.toLowerCase().includes(clanSearch.toLowerCase()) || 
    c.tag.toLowerCase().includes(clanSearch.toLowerCase())
  );

  // Active joined clan
  const joinedClan = playerStats.clanId ? clans.find(c => c.id === playerStats.clanId) : null;

  return (
    <div id="social-panel-container" className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl relative overflow-hidden flex flex-col min-h-[500px]">
      {/* Background neon glows */}
      <div className="absolute top-0 left-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-32 h-32 bg-violet-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Main Tab Bar */}
      <div className="flex border-b border-slate-800 bg-slate-950/40 p-1 gap-1">
        <button
          onClick={() => setActiveSubTab('friends')}
          className={`flex-1 py-3 text-xs font-sans font-bold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeSubTab === 'friends'
              ? 'bg-indigo-600/20 border border-indigo-500/30 text-indigo-300 shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
          }`}
        >
          <Users className="w-4 h-4 text-indigo-400" /> Friends & Global Search ({friends.length})
        </button>
        <button
          onClick={() => setActiveSubTab('clan')}
          className={`flex-1 py-3 text-xs font-sans font-bold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer ${
            activeSubTab === 'clan'
              ? 'bg-violet-600/15 border border-violet-500/20 text-violet-300'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/40'
          }`}
        >
          <Shield className="w-4 h-4" /> Competitive Syndicate {joinedClan ? `[${joinedClan.tag}]` : ''}
        </button>
      </div>

      <div className="p-6 flex-1 flex flex-col">
        {/* --- FRIENDS SUB TAB --- */}
        {activeSubTab === 'friends' && (
          <div className="flex-1 flex flex-col gap-5">
            {/* Sub-navigation bar inside Friends */}
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 gap-2">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setFriendTabMode('my_friends')}
                  className={`px-3 py-1.5 text-xs font-sans font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                    friendTabMode === 'my_friends'
                      ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  <Users className="w-3.5 h-3.5" /> My Friends ({friends.length})
                </button>
                <button
                  onClick={() => setFriendTabMode('my_rivals')}
                  className={`px-3 py-1.5 text-xs font-sans font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                    friendTabMode === 'my_rivals'
                      ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/30'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  <Swords className="w-3.5 h-3.5 text-rose-400" /> My Rivals ({rivals.length})
                </button>
                <button
                  onClick={() => setFriendTabMode('global_search')}
                  className={`px-3 py-1.5 text-xs font-sans font-bold rounded-lg transition-all flex items-center gap-1.5 cursor-pointer ${
                    friendTabMode === 'global_search'
                      ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-600/30'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  <Globe className="w-3.5 h-3.5 text-cyan-400" /> Search Global Players
                </button>
              </div>
            </div>

            {/* MY FRIENDS VIEW */}
            {friendTabMode === 'my_friends' && (
              <div className="flex-1 flex flex-col gap-4">
                {/* Direct Invite bar */}
                <div className="flex items-center gap-2">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input
                      type="text"
                      value={friendSearch}
                      onChange={(e) => setFriendSearch(e.target.value)}
                      placeholder="Enter Player Tag or Name (e.g. Cobra-4231)..."
                      className="w-full bg-slate-950 border border-slate-800/80 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 font-sans"
                    />
                  </div>
                  <button
                    onClick={handleAddFriend}
                    className="bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-sans font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-1 shrink-0"
                  >
                    <UserPlus className="w-3.5 h-3.5" /> Add Friend
                  </button>
                </div>

                {/* Friends list grid */}
                {friends.length === 0 ? (
                  <div className="flex-1 flex flex-col items-center justify-center py-12 text-center">
                    <Users className="w-10 h-10 text-slate-700 mb-2" />
                    <span className="text-sm font-sans font-bold text-slate-400">Your Friends List is Empty</span>
                    <p className="text-xs text-slate-500 max-w-xs mt-1 leading-relaxed">
                      Use "Search Global Players" above or enter rival tags to connect, gift daily free chips, and play!
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {friends.map((friend) => (
                      <div 
                        key={friend.id}
                        className="bg-slate-950/40 border border-slate-800/80 hover:border-slate-750 p-4 rounded-xl flex flex-col justify-between transition-all group"
                      >
                        {/* Header: avatar & name & level */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex items-center gap-2.5">
                            {/* Custom snake color avatar preview */}
                            <div 
                              className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 border border-slate-800/80 shadow relative overflow-hidden"
                              style={{ background: `radial-gradient(circle, ${friend.skinColor}33 10%, #020617 80%)` }}
                            >
                              <div className="w-4 h-4 rounded-full border border-slate-950 shadow-inner" style={{ backgroundColor: friend.skinColor }} />
                              {/* Online badge */}
                              <div className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border border-slate-950 ${
                                friend.status === 'online' 
                                  ? 'bg-emerald-500' 
                                  : friend.status === 'idle'
                                    ? 'bg-amber-500 animate-pulse'
                                    : friend.status === 'in-match' 
                                      ? 'bg-fuchsia-500 animate-pulse' 
                                      : 'bg-slate-600'
                              }`} />
                            </div>

                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className="text-xs font-bold text-white font-sans">{friend.name}</span>
                                <span className="text-[9px] bg-slate-900 border border-slate-800 text-slate-400 px-1 py-0.5 rounded uppercase font-semibold tracking-wider">Lvl {friend.level}</span>
                              </div>
                              <span className="text-[10px] text-slate-500 font-mono block mt-0.5">{friend.userTag}</span>
                            </div>
                          </div>

                          {/* Status label */}
                          <span className={`text-[9px] font-sans font-bold uppercase tracking-wide px-2 py-0.5 rounded-full border ${
                            friend.status === 'online' 
                              ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' 
                              : friend.status === 'idle'
                                ? 'text-amber-400 bg-amber-500/10 border-amber-500/20 animate-pulse'
                                : friend.status === 'in-match' 
                                  ? 'text-fuchsia-400 bg-fuchsia-500/10 border-fuchsia-500/20 animate-pulse'
                                  : 'text-slate-500 bg-slate-950 border-slate-800'
                          }`}>
                            {friend.status === 'online' ? 'Lobby' : friend.status === 'idle' ? 'Idle' : friend.status === 'in-match' ? 'In-Arena' : 'Offline'}
                          </span>
                        </div>

                        {/* Footer Actions: Daily gifting */}
                        <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between gap-2">
                          {/* Received gift claim */}
                          {friend.giftReceivedToday ? (
                            <button
                              onClick={() => handleClaimGift(friend.id)}
                              className="px-2.5 py-1 bg-amber-500 hover:bg-amber-400 text-black text-[10px] font-sans font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1 animate-bounce"
                            >
                              <Gift className="w-3 h-3" /> Claim +25c
                            </button>
                          ) : (
                            <span className="text-[10px] text-slate-500 font-sans">No pending gift</span>
                          )}

                          <div className="flex items-center gap-1.5">
                            {/* Spectate or Invite to Match */}
                            {friend.status === 'in-match' ? (
                              onSpectateFriend && (
                                <button
                                  onClick={() => onSpectateFriend(friend.name, friend.skinColor)}
                                  className="px-2.5 py-1 text-[10px] font-sans font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1 bg-fuchsia-600/20 text-fuchsia-300 border border-fuchsia-500/30 hover:bg-fuchsia-600 hover:text-white animate-pulse"
                                >
                                  <Eye className="w-3 h-3" /> Spectate
                                </button>
                              )
                            ) : (
                              <button
                                onClick={() => handleInviteFriendToMatch(friend)}
                                disabled={friend.status === 'offline'}
                                className={`px-2.5 py-1 text-[10px] font-sans font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                                  friend.status === 'offline'
                                    ? 'bg-slate-900 text-slate-600 border border-slate-950 cursor-not-allowed opacity-40'
                                    : 'bg-violet-600/20 text-violet-300 border border-violet-500/30 hover:bg-violet-600 hover:text-white'
                                }`}
                              >
                                <Swords className="w-3 h-3" /> Invite
                              </button>
                            )}

                            {/* Send gift */}
                            <button
                              onClick={() => handleSendGift(friend.id)}
                              disabled={friend.giftSentToday || friend.status === 'offline'}
                              className={`px-2.5 py-1 text-[10px] font-sans font-bold rounded-lg transition-all cursor-pointer flex items-center gap-1 ${
                                friend.giftSentToday 
                                  ? 'bg-slate-900 text-slate-500 border border-slate-800 cursor-not-allowed' 
                                  : 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30 hover:bg-indigo-500 hover:text-white'
                              }`}
                            >
                              <Send className="w-3 h-3" /> {friend.giftSentToday ? 'Sent Today' : 'Send Gift'}
                            </button>

                            {/* Delete friend icon */}
                            <button
                              onClick={() => handleRemoveFriend(friend.id, friend.name)}
                              className="p-1 hover:bg-rose-500/10 text-slate-500 hover:text-rose-400 rounded-lg transition cursor-pointer"
                              title="Remove Friend"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* MY RIVALS VIEW */}
            {friendTabMode === 'my_rivals' && (
              <div className="flex-1 flex flex-col gap-4">
                {/* Rivals Header Banner */}
                <div className="bg-gradient-to-r from-rose-950/40 via-slate-900 to-slate-950 border border-rose-900/30 p-4 rounded-xl flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 shrink-0">
                      <Swords className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white font-sans flex items-center gap-2">
                        RIVALRY & REVENGE TRACKER
                        <span className="text-[10px] bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded-full border border-rose-500/30 font-mono">
                          {rivals.length} Active Rivals
                        </span>
                      </h3>
                      <p className="text-xs text-slate-400 font-sans mt-0.5">
                        Players who eliminated you or collided with you in arena matches. Track their online status and join their exact arena to seek revenge!
                      </p>
                    </div>
                  </div>
                </div>

                {/* Rivals List Grid */}
                {rivals.length === 0 ? (
                  <div className="flex-1 flex flex-col items-center justify-center py-12 text-center">
                    <Swords className="w-10 h-10 text-slate-700 mb-2" />
                    <span className="text-sm font-sans font-bold text-slate-400">No Rivals in Your List</span>
                    <p className="text-xs text-slate-500 max-w-xs mt-1 leading-relaxed">
                      When you get eliminated or collide with players in matches, click <strong className="text-rose-400">"ADD RIVAL"</strong> on the game-over screen to track them here!
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {rivals.map((rival) => {
                      const youLead = rival.timesKilledByYou > rival.timesKilledYou;
                      const rivalLeads = rival.timesKilledYou > rival.timesKilledByYou;

                      return (
                        <div 
                          key={rival.id}
                          className="bg-slate-950/60 border border-rose-900/30 hover:border-rose-700/50 p-4 rounded-xl flex flex-col justify-between transition-all group relative overflow-hidden shadow-lg"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex items-center gap-3">
                              {/* Skin Avatar */}
                              <div 
                                className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border border-slate-800 shadow relative"
                                style={{ background: `radial-gradient(circle, ${rival.skinColor}44 10%, #020617 80%)` }}
                              >
                                <div className="w-5 h-5 rounded-full border border-slate-950 shadow-inner" style={{ backgroundColor: rival.skinColor }} />
                                <div className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-slate-950 ${
                                  rival.status === 'in-match' 
                                    ? 'bg-rose-500 animate-pulse' 
                                    : rival.status === 'online'
                                      ? 'bg-emerald-500'
                                      : 'bg-slate-600'
                                }`} />
                              </div>

                              <div>
                                <div className="flex items-center gap-2">
                                  <span className="text-sm font-bold text-white font-sans">{rival.name}</span>
                                  <span className="text-[9px] bg-slate-900 border border-slate-800 text-slate-400 px-1.5 py-0.5 rounded font-mono">
                                    Lvl {rival.level}
                                  </span>
                                </div>
                                <span className="text-[10px] text-slate-500 font-mono block mt-0.5">{rival.userTag}</span>
                              </div>
                            </div>

                            {/* Status Badge */}
                            <span className={`text-[9px] font-sans font-bold uppercase tracking-wide px-2.5 py-1 rounded-full border ${
                              rival.status === 'in-match'
                                ? 'text-rose-400 bg-rose-500/10 border-rose-500/30 animate-pulse'
                                : rival.status === 'online'
                                  ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
                                  : 'text-slate-500 bg-slate-900 border-slate-800'
                            }`}>
                              {rival.status === 'in-match' ? '⚔️ Playing Arena' : rival.status === 'online' ? '🟢 Online' : '⚪ Offline'}
                            </span>
                          </div>

                          {/* Head-to-Head Stats Banner */}
                          <div className="bg-slate-900/80 p-2.5 rounded-lg border border-slate-800/60 my-3 flex items-center justify-between text-xs">
                            <span className="text-[10px] text-slate-400 font-mono uppercase tracking-wider">Head-To-Head Record:</span>
                            <div className="flex items-center gap-2 font-mono font-bold text-xs">
                              <span className={youLead ? 'text-emerald-400 font-extrabold' : 'text-slate-300'}>You: {rival.timesKilledByYou}</span>
                              <span className="text-slate-600">-</span>
                              <span className={rivalLeads ? 'text-rose-400 font-extrabold' : 'text-slate-300'}>Rival: {rival.timesKilledYou}</span>
                            </div>
                          </div>

                          {/* Current Playing Table / Arena info */}
                          <div className="text-[11px] text-slate-400 font-sans flex items-center justify-between mb-3 bg-slate-900/40 px-2.5 py-1.5 rounded-lg border border-slate-800/40">
                            <span className="text-slate-500 text-[10px]">CURRENT ARENA TABLE:</span>
                            <span className="font-semibold text-amber-300 font-mono text-[11px]">
                              {rival.currentArenaName || 'High Stakes Lounge (1,000 Buy-In)'}
                            </span>
                          </div>

                          {/* Action Buttons */}
                          <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between gap-2">
                            <button
                              onClick={() => handleHuntRival(rival)}
                              className="flex-1 py-2 bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-sans font-bold text-xs rounded-xl transition cursor-pointer shadow-lg shadow-rose-950/30 flex items-center justify-center gap-1.5"
                            >
                              <Swords className="w-3.5 h-3.5" /> HUNT / JOIN ARENA
                            </button>

                            <button
                              onClick={() => handleConvertRivalToFriend(rival)}
                              className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-sans font-bold text-xs rounded-xl transition cursor-pointer flex items-center gap-1"
                              title="Convert to Friend"
                            >
                              <UserPlus className="w-3.5 h-3.5 text-emerald-400" />
                            </button>

                            <button
                              onClick={() => handleRemoveRival(rival.id, rival.name)}
                              className="p-2 hover:bg-rose-500/10 text-slate-500 hover:text-rose-400 rounded-xl transition cursor-pointer"
                              title="Remove Rival"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            )}

            {/* GLOBAL PLAYERS SEARCH VIEW */}
            {friendTabMode === 'global_search' && (
              <div className="flex-1 flex flex-col gap-4">
                {/* Search input & Country Filter */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  <div className="flex-1 relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input
                      type="text"
                      value={friendSearch}
                      onChange={(e) => setFriendSearch(e.target.value)}
                      placeholder="Search players globally by Name or Tag (e.g. Cobra, #IND-8821)..."
                      className="w-full bg-slate-950 border border-slate-800/80 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-500 font-sans"
                    />
                  </div>
                  <select
                    value={selectedCountryFilter}
                    onChange={(e) => setSelectedCountryFilter(e.target.value)}
                    className="bg-slate-950 border border-slate-800 text-xs text-slate-300 font-sans rounded-xl px-3 py-2 focus:outline-none focus:border-cyan-500 cursor-pointer"
                  >
                    <option value="ALL">🌐 All Countries</option>
                    <option value="IN">🇮🇳 India</option>
                    <option value="US">🇺🇸 USA</option>
                    <option value="JP">🇯🇵 Japan</option>
                    <option value="KR">🇰🇷 South Korea</option>
                    <option value="GB">🇬🇧 UK</option>
                    <option value="DE">🇩🇪 Germany</option>
                    <option value="BR">🇧🇷 Brazil</option>
                    <option value="AU">🇦🇺 Australia</option>
                    <option value="CA">🇨🇦 Canada</option>
                    <option value="FR">🇫🇷 France</option>
                  </select>
                </div>

                {/* Filtered list */}
                {(() => {
                  const filtered = GLOBAL_COMMUNITY_PLAYERS.filter((gp) => {
                    const matchCountry = selectedCountryFilter === 'ALL' || gp.country === selectedCountryFilter;
                    const q = friendSearch.trim().toLowerCase();
                    const matchQuery = !q || gp.name.toLowerCase().includes(q) || gp.userTag.toLowerCase().includes(q);
                    return matchCountry && matchQuery;
                  });

                  return (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {filtered.map((gp) => {
                        const isAlreadyFriend = friends.some(
                          (f) => f.name.toLowerCase() === gp.name.toLowerCase() || f.userTag === gp.userTag
                        );
                        return (
                          <div key={gp.userTag} className="bg-slate-950/60 border border-slate-800/80 hover:border-slate-700 p-3.5 rounded-xl flex items-center justify-between gap-3">
                            <div className="flex items-center gap-2.5 min-w-0">
                              <div 
                                className="w-9 h-9 rounded-full flex items-center justify-center shrink-0 border border-slate-800/80 shadow relative overflow-hidden"
                                style={{ background: `radial-gradient(circle, ${gp.skinColor}33 10%, #020617 80%)` }}
                              >
                                <div className="w-4 h-4 rounded-full border border-slate-950" style={{ backgroundColor: gp.skinColor }} />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-1.5 truncate">
                                  <span className="text-xs font-bold text-white font-sans truncate">{gp.name}</span>
                                  <span className="text-xs">{gp.flag}</span>
                                </div>
                                <div className="flex items-center gap-2 text-[10px] text-slate-400 font-mono mt-0.5">
                                  <span>{gp.userTag}</span>
                                  <span>•</span>
                                  <span className="text-amber-400 font-semibold">🪙 {(gp.chips / 1000).toFixed(0)}k</span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-1 shrink-0">
                              {isAlreadyFriend ? (
                                <span className="px-2.5 py-1 text-[10px] font-sans font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg flex items-center gap-1">
                                  <Check className="w-3 h-3" /> Connected
                                </span>
                              ) : (
                                <button
                                  onClick={() => handleAddGlobalPlayerAsFriend(gp)}
                                  className="px-2.5 py-1 text-[10px] font-sans font-bold text-cyan-300 bg-cyan-600/20 border border-cyan-500/30 hover:bg-cyan-600 hover:text-white rounded-lg transition-all cursor-pointer flex items-center gap-1"
                                >
                                  <UserPlus className="w-3 h-3" /> Connect
                                </button>
                              )}
                            </div>
                          </div>
                        );
                      })}

                      {/* If searching for custom tag not in default presets */}
                      {friendSearch.trim().length > 2 && !filtered.some((gp) => gp.name.toLowerCase() === friendSearch.trim().toLowerCase()) && (
                        <div className="col-span-1 sm:col-span-2 bg-cyan-950/20 border border-cyan-500/30 p-3.5 rounded-xl flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2">
                            <Globe className="w-4 h-4 text-cyan-400 shrink-0" />
                            <div>
                              <div className="text-xs font-bold text-white font-sans">Custom Player Tag: "{friendSearch.trim()}"</div>
                              <div className="text-[10px] text-cyan-300/80 font-sans">Found on Global Server. Connect & send invite request.</div>
                            </div>
                          </div>
                          <button
                            onClick={handleAddFriend}
                            className="px-3 py-1.5 bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-sans font-bold rounded-lg transition cursor-pointer flex items-center gap-1 shrink-0"
                          >
                            <UserPlus className="w-3.5 h-3.5" /> Connect
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        )}

        {/* --- CLAN / SYNDICATE SUB TAB --- */}
        {activeSubTab === 'clan' && (
          <div className="flex-1 flex flex-col gap-5">
            {/* NO CLAN SCREEN */}
            {!joinedClan ? (
              <div className="flex-1 flex flex-col">
                {/* Headers */}
                <div className="text-center max-w-lg mx-auto mb-6">
                  <h3 className="text-base font-bold text-white font-sans flex items-center justify-center gap-1.5">
                    <Shield className="w-5 h-5 text-violet-400" /> Choose Your Combat Syndicate
                  </h3>
                  <p className="text-xs text-slate-400 font-sans mt-1.5 leading-relaxed">
                    Syndicates are competitive teams of Venom Arena players. Work cooperatively, pool chip assets to unlock level-based buffs, compete on Clan Leaderboards, and chat in private feeds!
                  </p>
                </div>

                {/* Switch to Create or Join view */}
                {!showCreateClan ? (
                  <div className="flex-1 flex flex-col gap-4">
                    {/* Search filter / trigger create button */}
                    <div className="flex items-center justify-between gap-4 flex-wrap sm:flex-nowrap">
                      <div className="relative flex-1 min-w-[200px]">
                        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                        <input
                          type="text"
                          value={clanSearch}
                          onChange={(e) => setClanSearch(e.target.value)}
                          placeholder="Search public Syndicates..."
                          className="w-full bg-slate-950 border border-slate-800/80 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                        />
                      </div>
                      <button
                        onClick={() => setShowCreateClan(true)}
                        className="bg-violet-600 hover:bg-violet-500 text-white font-sans font-bold text-xs px-4 py-2 rounded-xl transition cursor-pointer flex items-center gap-1 shrink-0"
                      >
                        <Plus className="w-3.5 h-3.5" /> Register Syndicate (500c)
                      </button>
                    </div>

                    {/* Clan listing */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {filteredClans.map((clan) => (
                        <div 
                          key={clan.id}
                          className="bg-slate-950/40 border border-slate-800/80 hover:border-slate-750 p-5 rounded-2xl flex flex-col justify-between"
                        >
                          <div>
                            {/* Emblem name tag */}
                            <div className="flex items-center justify-between gap-2 mb-3">
                              <div className="flex items-center gap-2">
                                <span className="text-2xl">{clan.emblem}</span>
                                <div>
                                  <h4 className="text-sm font-bold text-white font-sans">{clan.name}</h4>
                                  <span className="text-[10px] text-slate-500 font-mono">[{clan.tag}]</span>
                                </div>
                              </div>
                              <span className="text-xs font-semibold bg-violet-500/10 border border-violet-500/20 text-violet-300 px-2 py-0.5 rounded-full font-sans">
                                Level {clan.level}
                              </span>
                            </div>

                            <p className="text-xs text-slate-400 font-sans leading-relaxed mb-4">{clan.description}</p>
                          </div>

                          {/* Clan metrics & join button */}
                          <div className="pt-3 border-t border-slate-800/50 flex items-center justify-between">
                            <div className="flex items-center gap-4">
                              <div>
                                <span className="text-[9px] text-slate-500 uppercase block font-semibold">Members</span>
                                <span className="text-xs font-mono font-bold text-slate-300">{clan.members.length}/{clan.maxMembers}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-slate-500 uppercase block font-semibold">Clan Bank</span>
                                <span className="text-xs font-mono font-bold text-emerald-400">{clan.bankedChips.toLocaleString()} c</span>
                              </div>
                            </div>

                            <button
                              onClick={() => handleJoinClan(clan.id)}
                              className="px-4 py-1.5 bg-violet-600 hover:bg-violet-500 text-white font-sans font-bold text-xs rounded-lg transition cursor-pointer"
                            >
                              Join Syndicate
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  /* CREATE CLAN VIEW */
                  <form onSubmit={handleCreateClan} className="bg-slate-950/40 border border-slate-800/80 p-6 rounded-2xl max-w-xl mx-auto w-full flex flex-col gap-4">
                    <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                      <span className="text-sm font-bold text-white font-sans">Syndicate Charter Registration</span>
                      <button 
                        type="button" 
                        onClick={() => setShowCreateClan(false)}
                        className="p-1 hover:bg-slate-900 rounded-lg text-slate-400"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {/* Name input */}
                      <div className="flex flex-col gap-1">
                        <label className="text-[10px] font-sans font-bold text-slate-400 uppercase">Syndicate Name</label>
                        <input
                          type="text"
                          required
                          value={newClanName}
                          onChange={(e) => setNewClanName(e.target.value)}
                          placeholder="e.g. Poison Fangs"
                          className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-violet-500"
                        />
                      </div>

                      {/* Tag input */}
                      <div className="flex flex-col gap-1">
                        <label className="text-[10px] font-sans font-bold text-slate-400 uppercase">Clan Tag (3-4 Chars)</label>
                        <input
                          type="text"
                          required
                          value={newClanTag}
                          onChange={(e) => setNewClanTag(e.target.value)}
                          placeholder="e.g. FANG"
                          className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white uppercase focus:outline-none focus:border-violet-500"
                        />
                      </div>
                    </div>

                    {/* Emblem Selector */}
                    <div className="flex flex-col gap-1.5">
                      <label className="text-[10px] font-sans font-bold text-slate-400 uppercase">Select Emblem Symbol</label>
                      <div className="flex flex-wrap gap-1.5">
                        {PRESET_EMBLEMS.map(em => (
                          <button
                            key={em}
                            type="button"
                            onClick={() => setNewClanEmblem(em)}
                            className={`w-9 h-9 text-lg rounded-lg border flex items-center justify-center transition cursor-pointer ${
                              newClanEmblem === em 
                                ? 'bg-violet-600/20 border-violet-500 text-white' 
                                : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                            }`}
                          >
                            {em}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Description */}
                    <div className="flex flex-col gap-1">
                      <label className="text-[10px] font-sans font-bold text-slate-400 uppercase">Description / Manifesto</label>
                      <textarea
                        value={newClanDesc}
                        onChange={(e) => setNewClanDesc(e.target.value)}
                        placeholder="Write your squad's focus, rules or motto..."
                        className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-violet-500 h-20 resize-none font-sans"
                      />
                    </div>

                    <div className="mt-2 flex items-center justify-between flex-wrap gap-4 pt-4 border-t border-slate-800">
                      <div className="flex items-center gap-1.5 bg-slate-950 px-3 py-1 rounded-lg border border-slate-800">
                        <Coins className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-[10px] text-slate-400 font-sans">Cost: <strong className="text-white">500 c</strong></span>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => setShowCreateClan(false)}
                          className="px-4 py-2 bg-slate-900 border border-slate-800 hover:bg-slate-850 text-slate-300 font-sans font-bold text-xs rounded-xl transition cursor-pointer"
                        >
                          Cancel
                        </button>
                        <button
                          type="submit"
                          className="px-4 py-2 bg-violet-600 hover:bg-violet-500 text-white font-sans font-bold text-xs rounded-xl transition cursor-pointer flex items-center gap-1 shadow-md shadow-violet-950"
                        >
                          <Check className="w-3.5 h-3.5" /> Establish Charter
                        </button>
                      </div>
                    </div>
                  </form>
                )}
              </div>
            ) : (
              /* ACTIVE JOINED CLAN SCREEN */
              <div className="flex-1 flex flex-col lg:flex-row gap-6">
                
                {/* Left Side: Clan Dashboard & Members */}
                <div className="flex-1 flex flex-col gap-5">
                  {/* Clan Header Summary Card */}
                  <div className="bg-slate-950 border border-slate-800 p-5 rounded-2xl relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-violet-600/5 rounded-full blur-3xl pointer-events-none" />
                    
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <span className="text-4xl">{joinedClan.emblem}</span>
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="text-base font-bold text-white font-sans">{joinedClan.name}</h3>
                            <span className="text-[10px] bg-violet-500/10 border border-violet-500/20 text-violet-300 px-2 py-0.5 rounded uppercase font-mono font-bold tracking-wider">
                              [{joinedClan.tag}]
                            </span>
                          </div>
                          <p className="text-xs text-slate-400 font-sans mt-1 leading-relaxed">{joinedClan.description}</p>
                        </div>
                      </div>

                      <button
                        onClick={handleLeaveClan}
                        className="py-1.5 px-3 bg-rose-500/10 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/20 text-[10px] font-sans font-bold rounded-lg transition cursor-pointer self-start flex items-center gap-1"
                      >
                        <LogOut className="w-3 h-3" /> Leave Syndicate
                      </button>
                    </div>

                    {/* Progress to next level */}
                    <div className="mt-5 pt-4 border-t border-slate-800/60">
                      <div className="flex items-center justify-between text-xs font-sans font-bold mb-1.5">
                        <span className="text-violet-300 flex items-center gap-1">
                          <Award className="w-3.5 h-3.5" /> Syndicate level {joinedClan.level}
                        </span>
                        <span className="text-slate-400 font-mono text-[11px]">{joinedClan.xp.toLocaleString()} / {(joinedClan.level * 1000).toLocaleString()} XP</span>
                      </div>
                      <div className="w-full h-2 bg-slate-900 rounded-full border border-slate-800/80 overflow-hidden">
                        <div 
                          className="h-full bg-gradient-to-r from-violet-600 to-indigo-500 shadow-inner rounded-full transition-all duration-300"
                          style={{ width: `${Math.min(100, (joinedClan.xp / (joinedClan.level * 1000)) * 100)}%` }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Clan Bank / Fund Deposit Box */}
                  <div className="bg-slate-950/40 border border-slate-800/80 p-4 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div>
                      <h4 className="text-xs font-bold text-white font-sans flex items-center gap-1">
                        <Coins className="w-4 h-4 text-emerald-400" /> Co-Op Syndicate Vault
                      </h4>
                      <p className="text-[10px] text-slate-400 font-sans mt-0.5">
                        Deposit excess banked chips to grow the vault balance. Deposits earn 10% value in Clan XP! Current Vault: <strong className="text-emerald-400 font-mono">{joinedClan.bankedChips.toLocaleString()} c</strong>
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <input
                        type="number"
                        min="1"
                        value={depositAmount}
                        onChange={(e) => setDepositAmount(e.target.value)}
                        placeholder="Amt (e.g. 100)"
                        className="bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white font-mono w-28 focus:outline-none"
                      />
                      <button
                        onClick={handleDepositChips}
                        className="bg-emerald-500 hover:bg-emerald-400 text-black font-sans font-bold text-xs px-4 py-1.5 rounded-lg transition cursor-pointer shadow-md shadow-emerald-950/40 flex items-center gap-1"
                      >
                        <Coins className="w-3.5 h-3.5" /> Deposit
                      </button>
                    </div>
                  </div>

                  {/* Members List Table */}
                  <div className="bg-slate-950/30 border border-slate-800/60 rounded-xl overflow-hidden">
                    <div className="bg-slate-950/80 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
                      <span className="text-xs font-bold text-white font-sans">Active Members ({joinedClan.members.length}/{joinedClan.maxMembers})</span>
                      <span className="text-[10px] text-slate-400 font-sans">Leader: 👑 {joinedClan.members.find(m => m.rank === 'Leader')?.name || 'None'}</span>
                    </div>

                    <div className="divide-y divide-slate-800/40">
                      {joinedClan.members.map((member) => (
                        <div key={member.id} className="px-4 py-3 flex items-center justify-between hover:bg-slate-900/10">
                          <div className="flex items-center gap-2.5">
                            <div className="relative">
                              <div className="w-7 h-7 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-xs">
                                🐍
                              </div>
                              <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-slate-950 ${
                                member.isOnline ? 'bg-emerald-500' : 'bg-slate-600'
                              }`} />
                            </div>

                            <div>
                              <div className="flex items-center gap-1.5">
                                <span className={`text-xs font-semibold font-sans ${member.id === 'player-member' ? 'text-indigo-300' : 'text-slate-200'}`}>
                                  {member.name} {member.id === 'player-member' ? '(You)' : ''}
                                </span>
                                <span className="text-[9px] text-slate-500 font-mono">{member.userTag}</span>
                              </div>
                              <span className="text-[9px] text-slate-400 font-sans block mt-0.5">Level {member.level}</span>
                            </div>
                          </div>

                          {/* Member Rank & Contribution */}
                          <div className="flex items-center gap-4 text-right">
                            <div>
                              <span className="text-[9px] text-slate-500 uppercase block font-semibold">Total Deposits</span>
                              <span className="text-xs font-mono font-bold text-slate-300">{member.totalContributedChips.toLocaleString()} c</span>
                            </div>

                            <div className="min-w-[70px]">
                              {member.rank === 'Leader' ? (
                                <span className="text-[9px] bg-amber-500/10 border border-amber-500/20 text-amber-400 px-2 py-0.5 rounded font-sans font-bold flex items-center justify-center gap-0.5">
                                  <Crown className="w-2.5 h-2.5" /> Leader
                                </span>
                              ) : member.rank === 'Co-Leader' ? (
                                <span className="text-[9px] bg-violet-500/10 border border-violet-500/20 text-violet-300 px-2 py-0.5 rounded font-sans font-bold flex items-center justify-center">
                                  Co-Leader
                                </span>
                              ) : (
                                <span className="text-[9px] bg-slate-800 border border-slate-700 text-slate-400 px-2 py-0.5 rounded font-sans font-medium flex items-center justify-center">
                                  Viper
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right Side: Interactive Syndicate Chat */}
                <div className="w-full lg:w-[320px] bg-slate-950 border border-slate-800 rounded-2xl flex flex-col h-[480px]">
                  {/* Chat header */}
                  <div className="px-4 py-3 bg-slate-950/80 border-b border-slate-800 flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-violet-400" />
                    <div>
                      <span className="text-xs font-bold text-white font-sans block">Syndicate HQ Feed</span>
                      <span className="text-[9px] text-slate-400 font-sans">Active conversation channel</span>
                    </div>
                  </div>

                  {/* Message feed */}
                  <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 scrollbar-thin">
                    {clanMessages.map((msg) => (
                      <div key={msg.id} className="flex flex-col gap-0.5">
                        <div className="flex items-center justify-between gap-1.5">
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] font-bold text-slate-200 font-sans">{msg.sender}</span>
                            <span className={`text-[8px] px-1 rounded uppercase font-bold tracking-wider ${
                              msg.senderRank === 'Leader' ? 'bg-amber-500/10 text-amber-400' : 'bg-slate-800 text-slate-400'
                            }`}>
                              {msg.senderRank}
                            </span>
                          </div>
                          <span className="text-[8px] text-slate-500 font-sans font-medium">{msg.timestamp}</span>
                        </div>
                        <div className="bg-slate-900 border border-slate-800/40 p-2.5 rounded-xl text-xs text-slate-300 font-sans leading-relaxed">
                          {msg.message}
                        </div>
                      </div>
                    ))}
                    <div ref={chatEndRef} />
                  </div>

                  {/* Input form */}
                  <form onSubmit={handleSendChatMessage} className="p-3 border-t border-slate-800 bg-slate-950/60 flex items-center gap-1.5">
                    <input
                      type="text"
                      value={chatMessage}
                      onChange={(e) => setChatMessage(e.target.value)}
                      placeholder="Type message to Syndicate..."
                      className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder:text-slate-500 focus:outline-none"
                    />
                    <button
                      type="submit"
                      className="p-1.5 bg-violet-600 hover:bg-violet-500 active:bg-violet-700 text-white rounded-lg transition cursor-pointer"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </form>
                </div>

              </div>
            )}
          </div>
        )}
      </div>

      {/* Dynamic Co-Op Invite & Counter-proposal Arena Modal */}
      {activeInviteFriend && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl flex flex-col gap-4 relative overflow-hidden animate-fade-in">
            {/* Background Accent Glow */}
            <div
              className="absolute -top-10 -right-10 w-32 h-32 rounded-full blur-3xl opacity-20 pointer-events-none"
              style={{ backgroundColor: activeInviteFriend.skinColor }}
            />

            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <Swords className="w-5 h-5 text-violet-400 animate-pulse" />
                <div>
                  <h3 className="font-bold text-white text-sm font-sans">Co-Op Lobby Invite</h3>
                  <p className="text-[10px] text-slate-400 font-sans mt-0.5">Assemble a squad with your allies</p>
                </div>
              </div>
              <button
                onClick={() => setActiveInviteFriend(null)}
                className="p-1 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Friend and User Balance Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-950/60 border border-slate-800/60 p-3 rounded-xl flex flex-col gap-1 text-center">
                <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider font-sans">Your Balance</span>
                <span className="text-sm font-bold font-mono text-indigo-400">
                  {playerStats.bankedChips.toLocaleString()} <span className="text-xs font-sans text-slate-500">c</span>
                </span>
              </div>
              <div className="bg-slate-950/60 border border-slate-800/60 p-3 rounded-xl flex flex-col gap-1 text-center">
                <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider font-sans">{activeInviteFriend.name}</span>
                <span className="text-sm font-bold font-mono text-emerald-400">
                  {getFriendSimulatedChips(activeInviteFriend).toLocaleString()} <span className="text-xs font-sans text-slate-500">c</span>
                </span>
              </div>
            </div>

            {/* Arena Selector dropdown or scrolling cards */}
            <div className="flex flex-col gap-2">
              <label className="text-[10px] text-slate-400 font-bold uppercase font-sans tracking-wide">
                Select Arena Stakes
              </label>
              <div className="flex flex-col gap-1.5 max-h-[180px] overflow-y-auto pr-1">
                {ARENA_TIERS.map((tier) => {
                  const isSelected = tier.id === inviteSelectedArenaId;
                  const friendAffords = getFriendSimulatedChips(activeInviteFriend) >= tier.buyIn;
                  const youAfford = playerStats.bankedChips >= tier.buyIn;

                  return (
                    <button
                      key={tier.id}
                      onClick={() => {
                        setInviteSelectedArenaId(tier.id);
                        setInviteStatusMessage(null); // Clear previous status on arena switch
                      }}
                      className={`flex items-center justify-between p-2.5 rounded-xl border text-left transition cursor-pointer ${
                        isSelected
                          ? 'bg-slate-800 border-indigo-500 shadow-md'
                          : 'bg-slate-950/40 border-slate-800/60 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: tier.accentColor }}
                        />
                        <div>
                          <span className="text-xs font-bold text-white block">{tier.name}</span>
                          <span className="text-[9px] text-slate-400 font-sans mt-0.5 leading-none">
                            Buy-In: {tier.buyIn.toLocaleString()} c
                          </span>
                        </div>
                      </div>

                      <div className="flex flex-col items-end gap-1">
                        {!youAfford ? (
                          <span className="text-[8px] bg-rose-950/80 text-rose-400 border border-rose-900/40 px-1.5 py-0.5 rounded font-bold font-sans">
                            You can't afford
                          </span>
                        ) : !friendAffords ? (
                          <span className="text-[8px] bg-amber-950/80 text-amber-300 border border-amber-900/40 px-1.5 py-0.5 rounded font-bold font-sans">
                            They can't afford
                          </span>
                        ) : (
                          <span className="text-[8px] bg-emerald-950/80 text-emerald-300 border border-emerald-900/40 px-1.5 py-0.5 rounded font-bold font-sans">
                            Eligible 🤝
                          </span>
                        )}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Friend's response / counter-proposal speech bubble */}
            {inviteStatusMessage && (
              <div className="bg-slate-950/80 border border-slate-800 p-3 rounded-xl flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <div
                    className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold"
                    style={{ backgroundColor: `${activeInviteFriend.skinColor}33`, color: activeInviteFriend.skinColor }}
                  >
                    💬
                  </div>
                  <span className="text-[10px] font-bold text-slate-300">{activeInviteFriend.name} responds:</span>
                </div>
                <p className="text-xs italic text-slate-300 leading-relaxed pl-7">
                  "{inviteStatusMessage.text}"
                </p>

                {inviteStatusMessage.type === 'counter' && inviteStatusMessage.counterArenaId && (
                  <button
                    onClick={() => {
                      if (inviteStatusMessage.counterArenaId) {
                        setInviteSelectedArenaId(inviteStatusMessage.counterArenaId);
                        setInviteStatusMessage(null);
                        onToast(`Switched buy-in to match counter-proposal!`, 'info');
                      }
                    }}
                    className="mt-1 ml-7 self-start px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white rounded-lg text-[10px] font-bold font-sans transition cursor-pointer"
                  >
                    🤝 Accept Proposal & Invite
                  </button>
                )}
              </div>
            )}

            {/* Modal Actions */}
            <div className="flex items-center gap-2 border-t border-slate-800/60 pt-4 mt-2">
              <button
                onClick={() => setActiveInviteFriend(null)}
                className="flex-1 py-2 border border-slate-800 hover:border-slate-700 bg-slate-950/40 text-slate-400 hover:text-white rounded-xl text-xs font-bold font-sans transition cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  const selectedTier = ARENA_TIERS.find((t) => t.id === inviteSelectedArenaId) || ARENA_TIERS[0];
                  const friendChips = getFriendSimulatedChips(activeInviteFriend);
                  const playerChips = playerStats.bankedChips;

                  if (playerChips < selectedTier.buyIn) {
                    onToast(`You do not have enough chips for ${selectedTier.name}!`, 'error');
                    return;
                  }

                  if (friendChips < selectedTier.buyIn) {
                    // Friend has insufficient chips! Simulate counter proposal.
                    // Find a tier that the friend CAN afford and is closest but less than friendChips
                    const affordableTiers = ARENA_TIERS.filter(t => friendChips >= t.buyIn && playerChips >= t.buyIn);
                    
                    if (affordableTiers.length > 0) {
                      const counterTier = affordableTiers[affordableTiers.length - 1]; // highest affordable
                      setInviteStatusMessage({
                        type: 'counter',
                        text: `Sorry! I don't have enough chips for ${selectedTier.name} (need ${selectedTier.buyIn.toLocaleString()} c, only have ${friendChips.toLocaleString()} c). Let's join the "${counterTier.name}" (Buy-In: ${counterTier.buyIn.toLocaleString()} c) instead! Re-invite me?`,
                        counterArenaId: counterTier.id
                      });
                      onToast(`Co-op invitation rejected: Insufficient chips. Counter-proposal received!`, 'info');
                    } else {
                      setInviteStatusMessage({
                        type: 'error',
                        text: `Ah, I'm super low on chips right now (${friendChips.toLocaleString()} c) and can't afford any of the available buy-ins. Send me a chip gift or invite me when I earn some more! 🐍`,
                      });
                      onToast(`Co-op invitation rejected: Insufficient chips.`, 'error');
                    }
                    return;
                  }

                  // Friend accepted! Save active match invite with specific arena ID
                  localStorage.setItem('venom_active_match_invite', JSON.stringify({
                    name: activeInviteFriend.name,
                    skinColor: activeInviteFriend.skinColor,
                    arenaId: selectedTier.id,
                  }));

                  onToast(`Co-op invite sent for ${selectedTier.name}! Active with ${activeInviteFriend.name}! 🤝⚔️`, 'success');
                  setActiveInviteFriend(null);
                }}
                className="flex-1 py-2 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 border border-violet-500/30 text-white rounded-xl text-xs font-bold font-sans transition cursor-pointer"
              >
                Send Co-Op Invite
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
