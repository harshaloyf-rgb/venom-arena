import React, { useState, useEffect } from 'react';
import { Trophy, Crown, Swords, Zap, Award, Timer, Sparkles, Flame, Users, Check, Shield, Gift, ChevronRight, Globe, MapPin, Flag, Star, Play, Lock } from 'lucide-react';
import { PlayerStats } from '../types';

export type ChampionshipScope = 'GLOBAL' | 'REGIONAL' | 'COUNTRY';
export type RankCategory = 'ALL' | 'RANK_1' | 'RANK_2_10' | 'RANK_11_50' | 'RANK_51_100';

export interface ChampionshipRankTier {
  category: RankCategory;
  title: string;
  badge: string;
  chipsReward: number;
  crownTitle: string;
  itemReward: string;
  color: string;
  hallOfFameInduction: boolean;
}

export interface ChampionshipContender {
  rank: number;
  name: string;
  userTag: string;
  gamesPlayed: number;
  maxGames: number;
  walletChips: number;
  clanTag?: string;
  skinColor: string;
  country: string;
  flag: string;
  region: string;
  projectedPrize: string;
}

const CHAMPIONSHIP_PRIZE_TIERS: ChampionshipRankTier[] = [
  {
    category: 'RANK_1',
    title: '👑 RANK 1: GRAND CHAMPION',
    badge: '🥇 1st Place (World / Region / Country)',
    chipsReward: 5000000,
    crownTitle: '👑 2026 WORLD VENOM CHAMPION',
    itemReward: 'Mythic Golden Dragon Skin & World Crown',
    color: 'from-amber-500/20 via-yellow-500/10 to-amber-950/40 border-amber-500/60 text-amber-300',
    hallOfFameInduction: true
  },
  {
    category: 'RANK_2_10',
    title: '🥈 RANKS 2–10: TOP 10 LEGENDS',
    badge: '🥈 Top 10 Legends',
    chipsReward: 2500000,
    crownTitle: '🥈 VENOM ARENA OVERLORD',
    itemReward: 'Platinum Armor Skin & Crown Effect',
    color: 'from-slate-400/20 via-slate-500/10 to-slate-950/40 border-slate-400/60 text-slate-200',
    hallOfFameInduction: true
  },
  {
    category: 'RANK_11_50',
    title: '🥉 RANKS 11–50: ELITE MASTERS',
    badge: '🥉 Ranks 11–50 Masters',
    chipsReward: 1000000,
    crownTitle: '🥉 ARENA ELITE MASTER',
    itemReward: 'Diamond Trail Effect & Master Crest',
    color: 'from-purple-500/20 via-indigo-500/10 to-purple-950/40 border-purple-400/60 text-purple-300',
    hallOfFameInduction: true
  },
  {
    category: 'RANK_51_100',
    title: '🛡️ RANKS 51–100: CHAMPIONSHIP CONTENDERS',
    badge: '🛡️ Ranks 51–100 Contenders',
    chipsReward: 250000,
    crownTitle: '🛡️ CHAMPIONSHIP CONTENDER',
    itemReward: '2,500 Season Pass XP & Contender Badge',
    color: 'from-indigo-500/20 via-blue-500/10 to-blue-950/40 border-blue-400/60 text-indigo-300',
    hallOfFameInduction: true
  }
];

const INITIAL_CONTENDERS: ChampionshipContender[] = [
  { rank: 1, name: 'Hari', userTag: '#IND-001', gamesPlayed: 4820, maxGames: 10000, walletChips: 10000000, clanTag: 'APEX', skinColor: '#f59e0b', country: 'India', flag: '🇮🇳', region: 'APAC', projectedPrize: '5,00,000 Chips + 👑 2026 WORLD CHAMPION' },
  { rank: 2, name: 'ApexViper_IND', userTag: '#IND-002', gamesPlayed: 6210, maxGames: 10000, walletChips: 9400000, clanTag: 'APEX', skinColor: '#ef4444', country: 'India', flag: '🇮🇳', region: 'APAC', projectedPrize: '2,500,000 Chips + 🥈 ARENA OVERLORD' },
  { rank: 3, name: 'VenomKing_US', userTag: '#USA-882', gamesPlayed: 5890, maxGames: 10000, walletChips: 8800000, clanTag: 'APEX', skinColor: '#a855f7', country: 'United States', flag: '🇺🇸', region: 'NA', projectedPrize: '2,500,000 Chips + 🥈 ARENA OVERLORD' },
  { rank: 4, name: 'K-Snake_Master', userTag: '#KOR-114', gamesPlayed: 4120, maxGames: 10000, walletChips: 8200000, clanTag: 'NINJA', skinColor: '#10b981', country: 'South Korea', flag: '🇰🇷', region: 'APAC', projectedPrize: '2,500,000 Chips + 🥈 ARENA OVERLORD' },
  { rank: 5, name: 'ShadowSlinker_JP', userTag: '#JPN-309', gamesPlayed: 3940, maxGames: 10000, walletChips: 7600000, clanTag: 'NINJA', skinColor: '#06b6d4', country: 'Japan', flag: '🇯🇵', region: 'APAC', projectedPrize: '2,500,000 Chips + 🥈 ARENA OVERLORD' },
  { rank: 6, name: 'KaiserSlayer_DE', userTag: '#GER-901', gamesPlayed: 5100, maxGames: 10000, walletChips: 6900000, clanTag: 'WAR', skinColor: '#ec4899', country: 'Germany', flag: '🇩🇪', region: 'EU', projectedPrize: '2,500,000 Chips + 🥈 ARENA OVERLORD' },
  { rank: 7, name: 'SambaVenom_BR', userTag: '#BRA-502', gamesPlayed: 4890, maxGames: 10000, walletChips: 6400000, clanTag: 'BRZ', skinColor: '#f97316', country: 'Brazil', flag: '🇧🇷', region: 'LATAM', projectedPrize: '2,500,000 Chips + 🥈 ARENA OVERLORD' },
  { rank: 8, name: 'BritStriker_UK', userTag: '#UK-402', gamesPlayed: 3820, maxGames: 10000, walletChips: 5800000, clanTag: 'ROYAL', skinColor: '#3b82f6', country: 'United Kingdom', flag: '🇬🇧', region: 'EU', projectedPrize: '2,500,000 Chips + 🥈 ARENA OVERLORD' },
  { rank: 9, name: 'CobraMaster_IN', userTag: '#IND-8821', gamesPlayed: 2950, maxGames: 10000, walletChips: 5200000, clanTag: 'PHNX', skinColor: '#10b981', country: 'India', flag: '🇮🇳', region: 'APAC', projectedPrize: '2,500,000 Chips + 🥈 ARENA OVERLORD' },
  { rank: 10, name: 'Dragon_Slayer_US', userTag: '#USA-104', gamesPlayed: 4100, maxGames: 10000, walletChips: 4900000, clanTag: 'APEX', skinColor: '#eab308', country: 'United States', flag: '🇺🇸', region: 'NA', projectedPrize: '2,500,000 Chips + 🥈 ARENA OVERLORD' },
  { rank: 11, name: 'Delhi_King', userTag: '#IND-003', gamesPlayed: 2100, maxGames: 10000, walletChips: 4500000, clanTag: 'PHNX', skinColor: '#8b5cf6', country: 'India', flag: '🇮🇳', region: 'APAC', projectedPrize: '1,000,000 Chips + 🥉 ELITE MASTER' },
  { rank: 12, name: 'Cyber_Wolf_US', userTag: '#USA-102', gamesPlayed: 3200, maxGames: 10000, walletChips: 4100000, clanTag: 'CYBER', skinColor: '#06b6d4', country: 'United States', flag: '🇺🇸', region: 'NA', projectedPrize: '1,000,000 Chips + 🥉 ELITE MASTER' },
  { rank: 15, name: 'Ronin_Slayer_JP', userTag: '#JPN-881', gamesPlayed: 1800, maxGames: 10000, walletChips: 3800000, clanTag: 'NINJA', skinColor: '#10b981', country: 'Japan', flag: '🇯🇵', region: 'APAC', projectedPrize: '1,000,000 Chips + 🥉 ELITE MASTER' },
  { rank: 52, name: 'Challenger_Viper', userTag: '#IND-902', gamesPlayed: 850, maxGames: 10000, walletChips: 1200000, clanTag: 'VPR', skinColor: '#6366f1', country: 'India', flag: '🇮🇳', region: 'APAC', projectedPrize: '250,000 Chips + 🛡️ CONTENDER' }
];

const COUNTRIES = [
  { code: 'ALL', name: 'All Countries', flag: '🌐' },
  { code: 'India', name: 'India', flag: '🇮🇳' },
  { code: 'United States', name: 'United States', flag: '🇺🇸' },
  { code: 'Japan', name: 'Japan', flag: '🇯🇵' },
  { code: 'South Korea', name: 'South Korea', flag: '🇰🇷' },
  { code: 'Germany', name: 'Germany', flag: '🇩🇪' },
  { code: 'Brazil', name: 'Brazil', flag: '🇧🇷' },
  { code: 'United Kingdom', name: 'United Kingdom', flag: '🇬🇧' }
];

const REGIONS = [
  { code: 'ALL', name: 'All Regions', flag: '🌐' },
  { code: 'APAC', name: 'Asia-Pacific (APAC)', flag: '🌏' },
  { code: 'NA', name: 'North America (NA)', flag: '🌎' },
  { code: 'EU', name: 'Europe (EU)', flag: '🌍' },
  { code: 'LATAM', name: 'Latin America (LATAM)', flag: '💃' }
];

interface ChampionshipsProps {
  playerStats: PlayerStats;
  onUpdateStats: (updated: Partial<PlayerStats>) => void;
  onToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onSelectArena?: (arena: any, isOnline: boolean) => void;
}

export default function Championships({ playerStats, onUpdateStats, onToast, onSelectArena }: ChampionshipsProps) {
  // Championship Registration & User Stats stored in LocalStorage
  const [isRegistered, setIsRegistered] = useState<boolean>(() => {
    return JSON.parse(localStorage.getItem('venom_championship_registered') || 'true');
  });

  const [gamesPlayedCount, setGamesPlayedCount] = useState<number>(() => {
    return Number(localStorage.getItem('venom_championship_games_played') || '34');
  });

  const MAX_GAMES_ALLOWED = 10000;

  // Filters State
  const [activeScope, setActiveScope] = useState<ChampionshipScope>('GLOBAL');
  const [selectedRegion, setSelectedRegion] = useState<string>('ALL');
  const [selectedCountry, setSelectedCountry] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<RankCategory>('ALL');

  // Countdown to Jan 1 midnight year-end finale (Dec 31, 2026)
  const [secondsUntilJan1, setSecondsUntilJan1] = useState<number>(13651200); // ~158 days

  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsUntilJan1((prev) => Math.max(0, prev - 1));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatCountdown = (seconds: number) => {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${d}d ${h.toString().padStart(2, '0')}h ${m.toString().padStart(2, '0')}m ${s.toString().padStart(2, '0')}s`;
  };

  const handleRegisterChampionship = () => {
    if (isRegistered) return;
    setIsRegistered(true);
    localStorage.setItem('venom_championship_registered', JSON.stringify(true));
    onToast(`🏆 REGISTERED FOR 2026 ANNUAL VENOM WORLD CHAMPIONSHIP! You have 10,000 matches limit. Good luck!`, 'success');
  };

  // Filter contenders based on Scope, Region, Country, and Rank Category
  const getFilteredContenders = () => {
    let list = [...INITIAL_CONTENDERS];

    // Inject player into leaderboard if registered
    const playerInList = list.some((c) => c.userTag === playerStats.userTag);
    if (!playerInList && isRegistered) {
      list.push({
        rank: 142,
        name: playerStats.name,
        userTag: playerStats.userTag,
        gamesPlayed: gamesPlayedCount,
        maxGames: MAX_GAMES_ALLOWED,
        walletChips: playerStats.bankedChips,
        clanTag: playerStats.clanTag,
        skinColor: '#f59e0b',
        country: 'India',
        flag: '🇮🇳',
        region: 'APAC',
        projectedPrize: 'Hall of Fame Qualifying Contender'
      });
    }

    // Sort by wallet chips descending (Max chips at year-end wins!)
    list.sort((a, b) => b.walletChips - a.walletChips);

    // Re-index ranks
    list = list.map((item, index) => ({
      ...item,
      rank: index + 1
    }));

    // Scope / Region / Country filters
    if (activeScope === 'REGIONAL' && selectedRegion !== 'ALL') {
      list = list.filter((item) => item.region === selectedRegion);
    } else if (activeScope === 'COUNTRY' && selectedCountry !== 'ALL') {
      list = list.filter((item) => item.country === selectedCountry);
    }

    // Rank Category Filter
    if (selectedCategory === 'RANK_1') {
      list = list.filter((item) => item.rank === 1);
    } else if (selectedCategory === 'RANK_2_10') {
      list = list.filter((item) => item.rank >= 2 && item.rank <= 10);
    } else if (selectedCategory === 'RANK_11_50') {
      list = list.filter((item) => item.rank >= 11 && item.rank <= 50);
    } else if (selectedCategory === 'RANK_51_100') {
      list = list.filter((item) => item.rank >= 51 && item.rank <= 100);
    }

    return list;
  };

  const filteredContenders = getFilteredContenders();

  return (
    <div className="w-full flex flex-col gap-6 animate-fade-in font-sans">
      {/* HEADER HERO BANNER */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-amber-950/90 via-yellow-950/50 to-slate-950 border border-amber-500/50 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-5">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-600 border-2 border-amber-300 flex items-center justify-center text-3xl shadow-xl shadow-amber-950/60 shrink-0">
              👑
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-[10px] font-mono uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold">
                  OFFICIAL 1-YEAR TOURNAMENT
                </span>
                <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-0.5 rounded-full border border-emerald-500/20 font-bold flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> JAN 1 HALL OF FAME PAYOUT
                </span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white font-sans tracking-tight">
                2026 ANNUAL VENOM WORLD CHAMPIONSHIP
              </h1>
              <p className="text-xs text-slate-300 font-sans mt-1 max-w-2xl leading-relaxed">
                Join anytime during the year! Play up to <strong>10,000 Games</strong>. When the year ends, players with the <strong>Maximum Wallet Chips</strong> across Global, Regional, and Country leaderboards will be awarded massive chip prizes and permanently inducted into the <strong>Hall of Fame on January 1st!</strong>
              </p>
            </div>
          </div>

          {/* COUNTDOWN TO JAN 1 FINALE */}
          <div className="flex flex-col items-end gap-2 bg-slate-950/90 p-4 rounded-2xl border border-amber-500/40 shrink-0 shadow-lg">
            <span className="text-[10px] text-amber-400 font-mono font-bold uppercase tracking-wider flex items-center gap-1">
              <Timer className="w-3.5 h-3.5 text-amber-400" /> YEAR-END FINALE & JAN 1 PAYOUT IN:
            </span>
            <span className="text-lg font-black text-white font-mono tracking-tight">
              {formatCountdown(secondsUntilJan1)}
            </span>
            <span className="text-[10px] text-slate-400 font-mono">
              Payout Date: Midnight UTC, 01 January 2027
            </span>
          </div>
        </div>
      </div>

      {/* PLAYER CHAMPIONSHIP STATUS DOSSIER CARD */}
      <div className="bg-slate-950 border border-amber-500/30 rounded-2xl p-6 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
        <div className="flex-1 flex flex-col sm:flex-row items-center gap-6 w-full">
          {/* Matches Limit Gauge */}
          <div className="w-full sm:w-auto bg-slate-900/80 p-4 rounded-xl border border-slate-800 flex flex-col gap-2 shrink-0">
            <div className="flex items-center justify-between text-xs font-mono font-bold">
              <span className="text-slate-400 flex items-center gap-1.5">
                <Swords className="w-4 h-4 text-amber-400" /> Matches Limit Progress:
              </span>
              <span className="text-amber-300 font-extrabold">{gamesPlayedCount.toLocaleString()} / {MAX_GAMES_ALLOWED.toLocaleString()} Played</span>
            </div>
            
            <div className="w-full sm:w-64 h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800 p-0.5">
              <div 
                className="h-full bg-gradient-to-r from-amber-500 to-yellow-400 rounded-full transition-all"
                style={{ width: `${Math.min(100, (gamesPlayedCount / MAX_GAMES_ALLOWED) * 100)}%` }}
              />
            </div>
            
            <span className="text-[10px] text-slate-500 font-mono">
              {MAX_GAMES_ALLOWED - gamesPlayedCount} Championship matches remaining this year
            </span>
          </div>

          {/* Current Wallet Chips competing */}
          <div className="flex items-center gap-4 bg-slate-900/80 p-4 rounded-xl border border-slate-800 w-full sm:w-auto">
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shrink-0">
              💰
            </div>
            <div>
              <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider block">COMPETING WALLET CHIPS</span>
              <span className="text-xl font-black text-amber-400 font-mono">{playerStats.bankedChips.toLocaleString()} Chips</span>
              <span className="text-[10px] text-emerald-400 font-sans block mt-0.5">Max chips at year-end decides rank!</span>
            </div>
          </div>
        </div>

        {/* Action Button: Register or Play Match */}
        <div className="flex flex-col items-stretch sm:items-end gap-2 w-full md:w-auto shrink-0">
          {!isRegistered ? (
            <button
              onClick={handleRegisterChampionship}
              className="px-6 py-3 bg-gradient-to-r from-amber-500 to-yellow-500 hover:brightness-110 text-slate-950 font-sans font-black text-sm rounded-xl transition cursor-pointer shadow-xl shadow-amber-950/40 flex items-center justify-center gap-2 uppercase tracking-wider"
            >
              <Trophy className="w-5 h-5" /> JOIN 2026 CHAMPIONSHIP NOW
            </button>
          ) : (
            <button
              onClick={() => {
                if (onSelectArena) {
                  onSelectArena(null, true);
                  onToast('Entering Championship High-Stakes Arena match...', 'info');
                }
              }}
              className="px-6 py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-slate-950 font-sans font-black text-sm rounded-xl transition cursor-pointer shadow-xl shadow-emerald-950/40 flex items-center justify-center gap-2 uppercase tracking-wider"
            >
              <Play className="w-5 h-5 fill-slate-950" /> PLAY CHAMPIONSHIP MATCH
            </button>
          )}

          <span className="text-[10px] text-slate-500 font-mono text-center sm:text-right">
            {isRegistered ? '✅ Registered & Active in 2026 Championship' : 'Free Entry | Join Anytime'}
          </span>
        </div>
      </div>

      {/* PRIZE RANK TIERS DISTRIBUTION (RANK 1, 2-10, 11-50, 51-100) */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-bold text-amber-400 uppercase tracking-wider font-sans flex items-center gap-2">
            <Gift className="w-4 h-4 text-amber-400" /> Jan 1st Payout & Hall of Fame Induction Tiers
          </h2>
          <span className="text-xs text-slate-400 font-mono">Awarded automatically on 01 January</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {CHAMPIONSHIP_PRIZE_TIERS.map((tier) => (
            <div
              key={tier.category}
              className={`p-4 rounded-2xl bg-gradient-to-b ${tier.color} backdrop-blur-md border shadow-lg flex flex-col justify-between gap-3`}
            >
              <div>
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider block opacity-80 mb-1">
                  {tier.badge}
                </span>
                <h3 className="text-sm font-extrabold font-sans text-white leading-tight">
                  {tier.title}
                </h3>
                <span className="text-base font-black font-mono text-amber-300 block mt-2">
                  +{tier.chipsReward.toLocaleString()} CHIPS
                </span>
              </div>

              <div className="space-y-1.5 pt-2 border-t border-slate-800/60 text-xs font-sans">
                <div className="text-[11px] font-bold font-mono text-slate-200">
                  Crown Title: <span className="text-amber-300">{tier.crownTitle}</span>
                </div>
                <div className="text-[10px] text-slate-300 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-amber-400" /> {tier.itemReward}
                </div>
                <div className="text-[9px] text-emerald-400 font-mono font-bold flex items-center gap-1 pt-1">
                  <Award className="w-3 h-3" /> Permanent Hall of Fame Inscription
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SCOPE & RANK FILTERS TOOLBAR */}
      <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        {/* Scope Tabs */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => { setActiveScope('GLOBAL'); setSelectedRegion('ALL'); setSelectedCountry('ALL'); }}
            className={`px-4 py-2 rounded-xl text-xs font-sans font-bold transition flex items-center gap-2 cursor-pointer ${
              activeScope === 'GLOBAL'
                ? 'bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-950/50'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Globe className="w-4 h-4" /> GLOBAL WORLD CHAMPIONSHIP
          </button>

          <button
            onClick={() => { setActiveScope('REGIONAL'); setSelectedCountry('ALL'); }}
            className={`px-4 py-2 rounded-xl text-xs font-sans font-bold transition flex items-center gap-2 cursor-pointer ${
              activeScope === 'REGIONAL'
                ? 'bg-indigo-600 text-white font-black shadow-lg shadow-indigo-950/50'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <MapPin className="w-4 h-4 text-indigo-400" /> REGIONAL MASTERS
          </button>

          <button
            onClick={() => { setActiveScope('COUNTRY'); setSelectedRegion('ALL'); }}
            className={`px-4 py-2 rounded-xl text-xs font-sans font-bold transition flex items-center gap-2 cursor-pointer ${
              activeScope === 'COUNTRY'
                ? 'bg-emerald-600 text-white font-black shadow-lg shadow-emerald-950/50'
                : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
            }`}
          >
            <Flag className="w-4 h-4 text-emerald-400" /> NATIONAL COUNTRY CIRCUIT
          </button>
        </div>

        {/* Region / Country Dropdowns */}
        {activeScope === 'REGIONAL' && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-mono">Region:</span>
            <select
              value={selectedRegion}
              onChange={(e) => setSelectedRegion(e.target.value)}
              className="bg-slate-900 text-white text-xs font-sans font-bold px-3 py-1.5 rounded-xl border border-slate-800 focus:outline-none focus:border-indigo-500 cursor-pointer"
            >
              {REGIONS.map((r) => (
                <option key={r.code} value={r.code}>{r.flag} {r.name}</option>
              ))}
            </select>
          </div>
        )}

        {activeScope === 'COUNTRY' && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-mono">Country:</span>
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="bg-slate-900 text-white text-xs font-sans font-bold px-3 py-1.5 rounded-xl border border-slate-800 focus:outline-none focus:border-emerald-500 cursor-pointer"
            >
              {COUNTRIES.map((c) => (
                <option key={c.code} value={c.code}>{c.flag} {c.name}</option>
              ))}
            </select>
          </div>
        )}

        {/* Rank Category Filter Pills */}
        <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-slate-800">
          {[
            { cat: 'ALL', label: 'All Ranks' },
            { cat: 'RANK_1', label: '👑 Rank 1' },
            { cat: 'RANK_2_10', label: '🥈 Ranks 2–10' },
            { cat: 'RANK_11_50', label: '🥉 Ranks 11–50' },
            { cat: 'RANK_51_100', label: '🛡️ Ranks 51–100' }
          ].map((item) => (
            <button
              key={item.cat}
              onClick={() => setSelectedCategory(item.cat as RankCategory)}
              className={`px-3 py-1 rounded-lg text-xs font-sans font-bold transition-all cursor-pointer ${
                selectedCategory === item.cat
                  ? 'bg-amber-500 text-black shadow'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </div>

      {/* LIVE CHAMPIONSHIP LEADERBOARD TABLE */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
        <div className="p-4 bg-slate-900/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Crown className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold text-white font-sans uppercase tracking-wider">
              2026 Championship Standings ({activeScope})
            </h3>
          </div>
          <span className="text-xs font-mono text-amber-400 font-bold bg-amber-500/10 px-3 py-1 rounded-full border border-amber-500/30">
            Jan 1 Hall of Fame Payout Eligible
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-[10px] uppercase font-bold text-slate-400 bg-slate-900/90">
                <th className="py-3 px-4">Rank</th>
                <th className="py-3 px-4">Contender Name</th>
                <th className="py-3 px-4">User Tag</th>
                <th className="py-3 px-4 text-center">Games Played</th>
                <th className="py-3 px-4 text-right">Wallet Chips (Rank Criteria)</th>
                <th className="py-3 px-4">Projected Jan 1 Payout</th>
                <th className="py-3 px-4 text-center">Hall of Fame</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-900 text-xs font-sans">
              {filteredContenders.map((c) => {
                const isRank1 = c.rank === 1;
                const isTop10 = c.rank <= 10;
                const isUser = c.userTag === playerStats.userTag;

                return (
                  <tr
                    key={c.userTag}
                    className={`hover:bg-slate-900/60 transition-colors ${
                      isUser
                        ? 'bg-amber-500/15 border-l-4 border-l-amber-500 font-bold'
                        : isRank1
                          ? 'bg-amber-500/10'
                          : isTop10
                            ? 'bg-slate-900/40'
                            : ''
                    }`}
                  >
                    <td className="py-3 px-4 font-mono font-bold">
                      {c.rank === 1 ? (
                        <span className="flex items-center gap-1 text-amber-400 font-black">
                          👑 #1
                        </span>
                      ) : c.rank <= 10 ? (
                        <span className="text-slate-200 font-bold">🥈 #{c.rank}</span>
                      ) : (
                        <span className="text-slate-500">#{c.rank}</span>
                      )}
                    </td>

                    <td className="py-3 px-4 font-bold text-white flex items-center gap-2">
                      <div
                        className="w-7 h-7 rounded-lg flex items-center justify-center font-bold text-[10px] shadow shrink-0"
                        style={{ backgroundColor: c.skinColor, color: '#000' }}
                      >
                        {c.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span>{c.name}</span>
                          {c.clanTag && (
                            <span className="text-[9px] bg-indigo-500/20 text-indigo-300 px-1.5 py-0.2 rounded font-mono border border-indigo-500/30">
                              [{c.clanTag}]
                            </span>
                          )}
                          {isUser && (
                            <span className="text-[9px] bg-amber-500 text-slate-950 px-1.5 py-0.2 rounded font-mono font-black">
                              YOU
                            </span>
                          )}
                        </div>
                        <span className="text-[9px] text-slate-500 font-mono block">
                          {c.flag} {c.country} ({c.region})
                        </span>
                      </div>
                    </td>

                    <td className="py-3 px-4 font-mono text-slate-400">
                      {c.userTag}
                    </td>

                    <td className="py-3 px-4 text-center font-mono text-slate-300">
                      {c.gamesPlayed.toLocaleString()} / {c.maxGames.toLocaleString()}
                    </td>

                    <td className="py-3 px-4 text-right font-mono font-black text-amber-400 text-sm">
                      {c.walletChips.toLocaleString()} c
                    </td>

                    <td className="py-3 px-4 font-mono text-xs text-slate-300">
                      {c.projectedPrize}
                    </td>

                    <td className="py-3 px-4 text-center">
                      <span className="text-[10px] font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded-full flex items-center justify-center gap-1">
                        <Award className="w-3 h-3" /> INDUCTED JAN 1
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
