import { useState } from 'react';
import { Landmark, Sparkles, Video, CreditCard, Gift, ShieldAlert, Lock, AlertTriangle } from 'lucide-react';
import { PlayerStats } from '../types';

interface ChipStoreProps {
  playerStats: PlayerStats;
  onUpdateStats: (stats: Partial<PlayerStats>) => void;
  onToast: (msg: string, type: 'success' | 'info' | 'error') => void;
}

const CHIP_PACKS = [
  { id: 'pack-10', name: 'Starter Pack', chips: 1000, priceINR: 10, priceUSD: '$0.12', bonus: 'Base Rate', desc: '1,000 Chips at 100 Chips/₹1.' },
  { id: 'pack-50', name: 'Scout Bundle', chips: 5100, priceINR: 50, priceUSD: '$0.60', bonus: '+2% Bonus', desc: '5,100 Chips with early stakes bonus.' },
  { id: 'pack-100', name: 'Contender Sack', chips: 10500, priceINR: 100, priceUSD: '$1.20', bonus: '+5% Bonus', desc: '10,500 Chips for medium arena buy-ins.' },
  { id: 'pack-250', name: 'Gladiator Chest', chips: 27500, priceINR: 250, priceUSD: '$3.00', bonus: '+10% Bonus', desc: '27,500 Chips for serious competitors.' },
  { id: 'pack-500', name: 'High Roller Vault', chips: 57500, priceINR: 500, priceUSD: '$6.00', bonus: '+15% Bonus', desc: '57,500 Chips for VIP Syndicate arenas.' },
  { id: 'pack-1000', name: 'Championship Crate', chips: 120000, priceINR: 1000, priceUSD: '$12.00', bonus: '+20% Bonus', desc: '1,20,000 Chips for Apex Vault entry.' },
  { id: 'pack-2500', name: 'Syndicate Treasury', chips: 325000, priceINR: 2500, priceUSD: '$30.00', bonus: '+30% Bonus', desc: '3,25,000 Chips for grand tournament runs.' },
  { id: 'pack-5000', name: 'National Titan Coffer', chips: 700000, priceINR: 5000, priceUSD: '$60.00', bonus: '+40% Bonus', desc: '7,00,000 Chips for country leaderboard pushes.' },
  { id: 'pack-10000', name: 'World Champion Trove', chips: 1500000, priceINR: 10000, priceUSD: '$120.00', bonus: '+50% Bonus', desc: '15,00,000 Chips for global elite domination.' },
  { id: 'pack-15000', name: 'MAX ANNUAL CAP PACK', chips: 2500000, priceINR: 15000, priceUSD: '$175.00', bonus: '+66.67% BONUS (INSTANT LOCK)', desc: '25,00,000 Chips! Reaches ₹15,000 annual spending cap and locks store for 365 days.' }
];

const MAX_YEARLY_BUY_CHIPS = 2500000; // 25 Lakh Chips Max Buy Cap per Year
const MAX_DAILY_ADS = 12;

export default function ChipStore({ playerStats, onUpdateStats, onToast }: ChipStoreProps) {
  const [promoCode, setPromoCode] = useState('');
  const [adLoading, setAdLoading] = useState(false);
  const [purchasingPack, setPurchasingPack] = useState<string | null>(null);

  const currentPurchasedChips = playerStats.yearlyPurchasedChips || 0;
  const isStoreLocked = currentPurchasedChips >= MAX_YEARLY_BUY_CHIPS;

  const todayStr = new Date().toISOString().slice(0, 10);
  const adsWatchedToday = playerStats.lastAdResetDate === todayStr ? (playerStats.adsWatchedToday || 0) : 0;

  const handleWatchAdForChips = () => {
    if (adsWatchedToday >= MAX_DAILY_ADS) {
      onToast(`Daily Ad Limit Reached (${MAX_DAILY_ADS}/${MAX_DAILY_ADS})! Resets at 00:00 UTC.`, 'error');
      return;
    }

    setAdLoading(true);
    onToast('Launching high-definition sponsor video... Keep active.', 'info');
    setTimeout(() => {
      setAdLoading(false);
      const newAdsCount = adsWatchedToday + 1;
      onUpdateStats({
        bankedChips: playerStats.bankedChips + 100,
        totalChipsEarned: playerStats.totalChipsEarned + 100,
        adsWatchedToday: newAdsCount,
        lastAdResetDate: todayStr,
      });
      onToast(`Sponsor Ad Completed: +100 FREE CHIPS deposited! (${newAdsCount}/${MAX_DAILY_ADS} ads today)`, 'success');
    }, 2000);
  };

  const handleBuyPack = (pack: typeof CHIP_PACKS[0]) => {
    if (isStoreLocked) {
      onToast('Store is LOCKED for 365 days because annual buy cap of 25 Lakh Chips (2,500,000 chips) was reached!', 'error');
      return;
    }

    if (currentPurchasedChips + pack.chips > MAX_YEARLY_BUY_CHIPS) {
      onToast(`This package (+${pack.chips.toLocaleString()} chips) exceeds your remaining yearly buy allowance of ${(MAX_YEARLY_BUY_CHIPS - currentPurchasedChips).toLocaleString()} chips!`, 'error');
      return;
    }

    setPurchasingPack(pack.id);
    onToast(`Initializing secure App Store/Play Store sandboxed billing for ₹${pack.priceINR} (${pack.priceUSD})...`, 'info');
    
    setTimeout(() => {
      setPurchasingPack(null);
      const newPurchasedChips = currentPurchasedChips + pack.chips;
      
      onUpdateStats({
        bankedChips: playerStats.bankedChips + pack.chips,
        totalChipsEarned: playerStats.totalChipsEarned + pack.chips,
        yearlyPurchasedChips: newPurchasedChips,
      });

      if (newPurchasedChips >= MAX_YEARLY_BUY_CHIPS) {
        onToast(`🎉 Purchase Successful! +${pack.chips.toLocaleString()} CHIPS added! Annual buy cap of 25 Lakh Chips (2,500,000) reached — Store locked for 365 days to maintain tournament skill parity!`, 'success');
      } else {
        onToast(`Purchase Successful! +${pack.chips.toLocaleString()} CHIPS credited. (Bought this year: ${newPurchasedChips.toLocaleString()} / 25,00,000 max)`, 'success');
      }
    }, 1800);
  };

  const handleRedeemCode = () => {
    const code = promoCode.trim().toUpperCase();
    if (!code) {
      onToast('Please enter a promotional code.', 'error');
      return;
    }

    if (code === 'VENOM') {
      onUpdateStats({
        bankedChips: playerStats.bankedChips + 500,
        totalChipsEarned: playerStats.totalChipsEarned + 500,
      });
      onToast('Promo Code redeemed successfully: +500 CHIPS credited!', 'success');
      setPromoCode('');
    } else if (code === 'CHAMPION') {
      onUpdateStats({
        bankedChips: playerStats.bankedChips + 1000,
        totalChipsEarned: playerStats.totalChipsEarned + 1000,
      });
      onToast('Promo Code redeemed successfully: +1000 CHIPS credited!', 'success');
      setPromoCode('');
    } else {
      onToast('Invalid or expired promotional code. Try code "VENOM" or "CHAMPION"!', 'error');
    }
  };

  return (
    <div id="chip-store-panel" className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
      {/* Background glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-6 border-b border-slate-800/80">
        <div>
          <h2 className="text-xl font-bold font-sans tracking-tight text-white flex items-center gap-2">
            <Landmark className="w-5 h-5 text-emerald-400" /> Integrated Store Matrix (Base Rate: 100 Chips = ₹1)
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-1">
            Rebuild your bank cushion with fair-play packages bounded by strict annual buy limits (25 Lakh Chips max / year).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="bg-slate-950 px-3.5 py-1.5 rounded-xl border border-slate-800">
            <span className="text-[10px] text-slate-500 font-sans block uppercase font-semibold">Your Wallet</span>
            <span className="text-sm font-bold font-mono text-emerald-400">
              {playerStats.bankedChips.toLocaleString()} c
            </span>
          </div>

          <div className="bg-slate-950 px-3.5 py-1.5 rounded-xl border border-amber-500/30">
            <span className="text-[10px] text-amber-500 font-sans block uppercase font-semibold">Yearly Buy Cap</span>
            <span className="text-sm font-bold font-mono text-amber-400">
              {currentPurchasedChips.toLocaleString()} / 25,00,000 c
            </span>
          </div>
        </div>
      </div>

      {/* STORE LOCKED ALERT IF CAP REACHED */}
      {isStoreLocked && (
        <div className="mb-6 p-4 bg-red-950/40 border border-red-500/40 rounded-xl text-red-300 text-xs font-sans flex items-center gap-3">
          <Lock className="w-6 h-6 text-red-400 shrink-0" />
          <div>
            <strong className="text-white font-bold block text-sm">ANTI-MONOPOLY STORE LOCK ACTIVE (365 DAYS)</strong>
            You have reached the absolute maximum yearly buy cap of 25 Lakh Chips (2,500,000 chips). Store purchases are disabled to ensure tournament skill remains 100% fair across all 197 countries. Free ad rewards (1,200 chips/day) and arena wagers remain fully active!
          </div>
        </div>
      )}

      {/* Grid of IAP Chip packs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3.5 mb-6">
        {CHIP_PACKS.map((pack) => {
          const packDisabled = isStoreLocked || (currentPurchasedChips + pack.chips > MAX_YEARLY_BUY_CHIPS);
          const isMaxPack = pack.chips === 2500000;

          return (
            <div
              key={pack.id}
              className={`bg-slate-950/90 border rounded-xl p-4 flex flex-col justify-between relative overflow-hidden group transition-all duration-200 ${
                isMaxPack 
                  ? 'border-amber-500/50 bg-gradient-to-b from-amber-950/20 to-slate-950 shadow-lg shadow-amber-950/20' 
                  : 'border-slate-800/80 hover:border-slate-700'
              }`}
            >
              {/* Header / Badge */}
              <div>
                <div className="flex items-start justify-between gap-1 mb-1">
                  <span className="text-xs font-bold text-white font-sans">{pack.name}</span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded-full font-bold uppercase tracking-wider shrink-0 ${
                    isMaxPack 
                      ? 'bg-amber-500 text-black animate-pulse' 
                      : 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-300'
                  }`}>
                    {pack.bonus}
                  </span>
                </div>
                <p className="text-[10px] text-slate-400 font-sans leading-tight min-h-[28px]">{pack.desc}</p>
              </div>

              {/* Chips Amount */}
              <div className="my-3">
                <div className="text-xl font-extrabold font-mono text-emerald-400">{pack.chips.toLocaleString()}</div>
                <div className="text-[10px] text-slate-500 font-sans">chips</div>
              </div>

              {/* Pricing & Trigger Button */}
              <div className="mt-auto pt-2 border-t border-slate-800/50">
                <div className="flex items-center justify-between text-[11px] font-sans text-slate-300 font-bold mb-2">
                  <span>₹{pack.priceINR.toLocaleString()}</span>
                  <span className="text-slate-500 font-normal">({pack.priceUSD})</span>
                </div>

                <button
                  onClick={() => handleBuyPack(pack)}
                  disabled={packDisabled || purchasingPack !== null}
                  className={`w-full py-2 text-xs font-sans font-bold rounded-lg transition-all flex items-center justify-center gap-1.5 cursor-pointer disabled:opacity-50 ${
                    isMaxPack
                      ? 'bg-amber-500 hover:bg-amber-400 text-black shadow-md shadow-amber-950/40'
                      : 'bg-slate-900 group-hover:bg-indigo-600 hover:!bg-indigo-500 text-white border border-slate-800 group-hover:border-indigo-500'
                  }`}
                >
                  {isStoreLocked ? (
                    <>
                      <Lock className="w-3.5 h-3.5" /> Locked
                    </>
                  ) : purchasingPack === pack.id ? (
                    'Connecting...'
                  ) : (
                    <>
                      <CreditCard className="w-3.5 h-3.5" /> Buy Pack
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Free chips & Promo codes row */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Ad Video Sponsorship (12 Ads Max / Day) */}
        <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white font-sans flex items-center gap-1.5">
                <Video className="w-4 h-4 text-emerald-400 animate-pulse" /> Daily Reward Ads (12 Max / Day)
              </h3>
              <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-950/50 px-2 py-0.5 rounded border border-emerald-500/20">
                {adsWatchedToday} / {MAX_DAILY_ADS}
              </span>
            </div>
            <p className="text-xs text-slate-400 font-sans mt-1 leading-relaxed">
              Each completed ad awards 100 chips directly to your wallet (Max 1,200 free chips per day). Resets strictly at 00:00 UTC daily.
            </p>
          </div>

          <button
            onClick={handleWatchAdForChips}
            disabled={adLoading || adsWatchedToday >= MAX_DAILY_ADS}
            className="w-full mt-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-sans font-bold rounded-lg flex items-center justify-center gap-1.5 transition cursor-pointer disabled:opacity-50 shadow-md shadow-emerald-950/40"
          >
            <Video className="w-3.5 h-3.5" />
            {adLoading 
              ? 'Buffering Sponsor Offer...' 
              : adsWatchedToday >= MAX_DAILY_ADS
              ? `Daily Limit Reached (${MAX_DAILY_ADS}/${MAX_DAILY_ADS})`
              : `Watch Sponsor Ad (+100 Chips)`}
          </button>
        </div>

        {/* Promo Coupons */}
        <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-4 flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-bold text-white font-sans flex items-center gap-1.5">
              <Gift className="w-4 h-4 text-indigo-400" /> Promotional Codes
            </h3>
            <p className="text-xs text-slate-400 font-sans mt-1 leading-relaxed">
              Type special campaign coupon codes below to receive immediate bonus chips for the championship.
            </p>
          </div>

          <div className="flex items-center gap-2 mt-4">
            <input
              type="text"
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value)}
              placeholder="Enter Code (e.g. VENOM)"
              className="flex-1 bg-slate-950 border border-slate-800/80 rounded-lg px-3 py-1.5 text-xs text-white font-mono uppercase focus:outline-none focus:border-indigo-500"
            />
            <button
              onClick={handleRedeemCode}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-xs px-4 py-1.5 rounded-lg transition cursor-pointer"
            >
              Redeem
            </button>
          </div>
        </div>
      </div>

      {/* Compliance / Store Notice */}
      <div className="mt-4 p-3 bg-indigo-950/20 border border-indigo-900/30 rounded-lg text-[10px] text-indigo-300 font-sans leading-relaxed flex items-start gap-2">
        <ShieldAlert className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
        <span>
          <strong>STORE POLICY COMPLIANCE ASSURANCE:</strong> This is a store-safe edition. Spending is capped at ₹15,000/year to block monopoly loops. Free potential daily rewards allow non-paying competitors to fully win the World Cup purely through skill and win-rate!
        </span>
      </div>
    </div>
  );
}
