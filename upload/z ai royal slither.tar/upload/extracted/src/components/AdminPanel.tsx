import React, { useState, useEffect } from 'react';
import { Shield, Users, Database, Play, AlertTriangle, UserX, VolumeX, Trash2, Coins, Server, FileText } from 'lucide-react';
import { PlayerStats } from '../types';

interface AdminPanelProps {
  playerStats: PlayerStats;
  onUpdateStats: (stats: Partial<PlayerStats>) => void;
  onToast: (msg: string, type: 'success' | 'info' | 'error') => void;
}

interface ServerStatus {
  roomsCount: number;
  totalPlayersConnected: number;
  uptime: number;
}

interface LivePlayer {
  id: string;
  name: string;
  userTag: string;
  level: number;
  carriedChips: number;
  arenaId: string;
  isMuted: boolean;
}

export default function AdminPanel({ playerStats, onUpdateStats, onToast }: AdminPanelProps) {
  const [isAdmin, setIsAdmin] = useState(false);
  const [accessCode, setAccessCode] = useState('');
  const [serverStatus, setServerStatus] = useState<ServerStatus | null>(null);
  const [players, setPlayers] = useState<LivePlayer[]>([]);
  const [logs, setLogs] = useState<string[]>([]);
  const [broadcastMsg, setBroadcastMsg] = useState('');
  const [economyTargetTag, setEconomyTargetTag] = useState('');
  const [economyAmount, setEconomyAmount] = useState('');

  // Fetch status and logs
  useEffect(() => {
    if (!isAdmin) return;

    const fetchServerData = async () => {
      try {
        const statusRes = await fetch('/api/admin/status', {
          headers: { 'Authorization': `Bearer ${localStorage.getItem('venom_jwt')}` }
        });
        if (statusRes.ok) {
          const data = await statusRes.json();
          setServerStatus(data.status);
          setPlayers(data.players || []);
          setLogs(data.logs || []);
        }
      } catch (err) {
        console.error('Failed to fetch admin stats:', err);
      }
    };

    fetchServerData();
    const interval = setInterval(fetchServerData, 3000);
    return () => clearInterval(interval);
  }, [isAdmin]);

  const handleAuthorize = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const cleanCode = accessCode.trim().toLowerCase();
    
    // Accept any common admin code or non-empty input
    if (
      cleanCode === 'admin' ||
      cleanCode === 'admin123' ||
      cleanCode === 'venom' ||
      cleanCode === 'venom_dev' ||
      cleanCode === '1234' ||
      cleanCode === '0000' ||
      cleanCode === 'pass' ||
      cleanCode === 'password' ||
      cleanCode.length > 0
    ) {
      setIsAdmin(true);
      onToast('Developer Admin credentials authorized!', 'success');
    } else {
      onToast('Please click Quick Unlock below or enter "admin".', 'error');
    }
  };

  const handleKick = async (playerId: string) => {
    try {
      const res = await fetch(`/api/admin/kick/${playerId}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('venom_jwt')}` }
      });
      if (res.ok) {
        onToast(`Player ${playerId} kicked from active lobby.`, 'success');
        setPlayers(prev => prev.filter(p => p.id !== playerId));
      }
    } catch (err) {
      onToast('Failed to kick player.', 'error');
    }
  };

  const handleBan = async (userTag: string) => {
    try {
      const res = await fetch(`/api/admin/ban/${userTag}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('venom_jwt')}` }
      });
      if (res.ok) {
        onToast(`Banned player ${userTag} permanently.`, 'success');
      }
    } catch (err) {
      onToast('Failed to ban player.', 'error');
    }
  };

  const handleMute = async (playerId: string) => {
    try {
      const res = await fetch(`/api/admin/mute/${playerId}`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${localStorage.getItem('venom_jwt')}` }
      });
      if (res.ok) {
        onToast(`Toggled mute state for player ${playerId}.`, 'success');
        setPlayers(prev => prev.map(p => p.id === playerId ? { ...p, isMuted: !p.isMuted } : p));
      }
    } catch (err) {
      onToast('Failed to mute player.', 'error');
    }
  };

  const handleBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastMsg.trim()) return;
    try {
      const res = await fetch('/api/admin/broadcast', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('venom_jwt')}`
        },
        body: JSON.stringify({ message: broadcastMsg })
      });
      if (res.ok) {
        onToast('Global admin broadcast sent!', 'success');
        setBroadcastMsg('');
      }
    } catch (err) {
      onToast('Failed to send broadcast.', 'error');
    }
  };

  const handleModifyChips = async (e: React.FormEvent) => {
    e.preventDefault();
    const tag = economyTargetTag.trim();
    const amount = parseInt(economyAmount);
    if (!tag || isNaN(amount)) {
      onToast('Please fill in both fields correctly.', 'error');
      return;
    }
    try {
      const res = await fetch('/api/admin/modify-chips', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('venom_jwt')}`
        },
        body: JSON.stringify({ userTag: tag, amount })
      });
      if (res.ok) {
        onToast(`Modified balance of ${tag} by ${amount} chips!`, 'success');
        if (tag === playerStats.userTag) {
          onUpdateStats({ bankedChips: playerStats.bankedChips + amount });
        }
        setEconomyTargetTag('');
        setEconomyAmount('');
      }
    } catch (err) {
      onToast('Failed to adjust player chips.', 'error');
    }
  };

  if (!isAdmin) {
    return (
      <div id="admin-auth-gate" className="bg-slate-900 border border-slate-800 rounded-2xl p-8 max-w-md mx-auto my-12 text-center shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 via-amber-500 to-indigo-500" />
        <Shield className="w-16 h-16 text-amber-500 mx-auto mb-4 animate-bounce" />
        <h3 className="text-xl font-bold font-sans text-white mb-2">Central Operations Gate</h3>
        <p className="text-slate-400 text-xs mb-6 leading-relaxed">
          Access is restricted to authorized Syndicate Technical Overseers. Enter your operations code below.
        </p>
        <form onSubmit={handleAuthorize} className="flex flex-col gap-3">
          <input
            type="text"
            placeholder="Overseer Access Code (or leave blank for quick unlock)"
            value={accessCode}
            onChange={(e) => setAccessCode(e.target.value)}
            className="bg-slate-950 border border-slate-800 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-amber-500 font-mono text-center"
          />
          <button
            type="submit"
            className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl py-2.5 text-xs uppercase tracking-wider transition-colors font-sans"
          >
            Authorize Terminal
          </button>
        </form>

        <div className="mt-4 pt-4 border-t border-slate-800/80 flex flex-col gap-2">
          <button
            type="button"
            onClick={() => {
              setIsAdmin(true);
              onToast('Developer Admin Console Unlocked!', 'success');
            }}
            className="bg-red-600/20 hover:bg-red-600/30 text-red-300 border border-red-500/40 rounded-xl py-2.5 text-xs font-bold font-sans transition-all flex items-center justify-center gap-2"
          >
            <Shield className="w-4 h-4 text-red-400" /> ⚡ Quick Unlock Admin Console (1-Click)
          </button>
          <span className="text-[10px] text-slate-500 font-mono">
            Default code: <strong className="text-slate-300">admin</strong> (or click Quick Unlock)
          </span>
        </div>
      </div>
    );
  }

  return (
    <div id="admin-operations-panel" className="grid grid-cols-1 lg:grid-cols-3 gap-6 max-w-7xl mx-auto p-4">
      {/* Column 1: Server health and logs */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 flex flex-col gap-5 shadow-xl">
        <div className="flex items-center gap-2 border-b border-slate-800/80 pb-3">
          <Server className="w-5 h-5 text-indigo-400" />
          <h4 className="text-sm font-semibold font-sans text-white">System Diagnostics</h4>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-slate-950 border border-slate-800/40 rounded-xl p-3 text-center">
            <span className="text-[10px] text-slate-500 font-mono uppercase">Connected Sockets</span>
            <div className="text-xl font-extrabold text-indigo-400 font-mono mt-1">
              {serverStatus?.totalPlayersConnected ?? 0}
            </div>
          </div>
          <div className="bg-slate-950 border border-slate-800/40 rounded-xl p-3 text-center">
            <span className="text-[10px] text-slate-500 font-mono uppercase">Active Rooms</span>
            <div className="text-xl font-extrabold text-emerald-400 font-mono mt-1">
              {serverStatus?.roomsCount ?? 0}
            </div>
          </div>
        </div>

        {/* Live Broadcast */}
        <form onSubmit={handleBroadcast} className="flex flex-col gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800/40">
          <label className="text-[11px] text-slate-400 font-semibold font-sans">Global Intercom Broadcast</label>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Announce to all active matches..."
              value={broadcastMsg}
              onChange={(e) => setBroadcastMsg(e.target.value)}
              className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-indigo-500"
            />
            <button type="submit" className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg px-3 py-1.5 text-xs transition-colors">
              Send
            </button>
          </div>
        </form>

        {/* Logs terminal */}
        <div className="flex-1 flex flex-col gap-2 min-h-[180px]">
          <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-bold">
            <FileText className="w-3.5 h-3.5" />
            <span>SYSLOG MONITOR</span>
          </div>
          <div className="flex-1 bg-slate-950 rounded-xl border border-slate-800/60 p-3 font-mono text-[10px] text-slate-400 overflow-y-auto max-h-[220px] flex flex-col gap-1">
            {logs.length === 0 ? (
              <span className="text-slate-600">No recent transactions...</span>
            ) : (
              logs.map((log, idx) => (
                <div key={idx} className="border-b border-slate-900/40 pb-1">
                  {log}
                </div>
              ))
            )}
          </div>
        </div>
      </div>

      {/* Column 2: Live Players and active matches */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-xl lg:col-span-2 flex flex-col gap-4">
        <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-400" />
            <h4 className="text-sm font-semibold font-sans text-white">Live Operations Roster</h4>
          </div>
          <span className="bg-indigo-500/10 text-indigo-400 font-mono text-[10px] px-2 py-0.5 rounded-full font-bold border border-indigo-500/20">
            {players.length} Active
          </span>
        </div>

        <div className="flex-1 overflow-y-auto max-h-[350px] flex flex-col gap-2 pr-1">
          {players.length === 0 ? (
            <div className="text-center py-12 bg-slate-950/20 border border-slate-800/40 rounded-xl text-slate-500 text-xs">
              No active human players currently linked to server memory.
            </div>
          ) : (
            players.map((p) => (
              <div key={p.id} className="bg-slate-950 border border-slate-800/50 hover:border-slate-700/60 transition-all rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="text-xs font-bold text-white">{p.name}</span>
                      <span className="text-[9px] font-mono text-slate-500 bg-slate-900 border border-slate-800/60 px-1 py-0.5 rounded">
                        {p.userTag}
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-500 mt-0.5">
                      Socket ID: <span className="font-mono text-indigo-400/80">{p.id.substring(0, 8)}...</span> • Lvl {p.level} • Room: <span className="text-amber-500 font-mono font-bold">{p.arenaId}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 self-end sm:self-auto">
                  <div className="bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-lg px-2.5 py-1 text-[10px] font-mono font-bold mr-2">
                    {p.carriedChips} Chips
                  </div>
                  <button
                    onClick={() => handleMute(p.id)}
                    title="Toggle Mute Player"
                    className={`p-1.5 rounded-lg border transition-all ${p.isMuted ? 'bg-amber-500/10 text-amber-400 border-amber-500/30 hover:bg-amber-500/20' : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:bg-slate-800'}`}
                  >
                    <VolumeX className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleKick(p.id)}
                    title="Kick Connection"
                    className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-red-400 hover:text-white hover:bg-red-900/30 hover:border-red-500/30 transition-all"
                  >
                    <UserX className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => handleBan(p.userTag)}
                    title="Ban UserTag Permanently"
                    className="p-1.5 rounded-lg bg-red-500/10 text-red-500 border border-red-500/20 hover:bg-red-600 hover:text-slate-950 transition-all"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Economy Operations Panel */}
        <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-4 mt-2">
          <div className="flex items-center gap-1.5 text-xs font-bold text-amber-500 uppercase mb-3">
            <Coins className="w-4 h-4" />
            <span>Economy Ledger Overrides</span>
          </div>
          <form onSubmit={handleModifyChips} className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <input
              type="text"
              placeholder="Player Tag (e.g. STRK-8291)"
              value={economyTargetTag}
              onChange={(e) => setEconomyTargetTag(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
            />
            <input
              type="number"
              placeholder="Amount (+/- e.g. 5000)"
              value={economyAmount}
              onChange={(e) => setEconomyAmount(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500 font-mono"
            />
            <button
              type="submit"
              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-lg px-4 py-1.5 text-xs transition-colors"
            >
              Adjust Chips Balance
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
