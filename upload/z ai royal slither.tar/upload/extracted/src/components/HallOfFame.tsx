import { useState, useEffect } from 'react';
import { Crown, Trophy, Sparkles, Radio, Shield, Globe, Award, Star, Check, X, Filter, Search } from 'lucide-react';
import { PlayerStats, LiveCommentaryMessage } from '../types';

interface HallOfFameProps {
  playerStats: PlayerStats;
  onInspectPlayer?: (player: { name: string; country: string; userTag: string; bankedChips: number; level: number; avatar?: string; instagram?: string; youtube?: string; twitch?: string }) => void;
  onToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export interface MilestoneTier {
  id: string;
  name: string;
  chipsRequired: number;
  chipDisplay: string;
  badge: string;
  color: string;
  firstAchiever: {
    playerName: string;
    userTag: string;
    country: string;
    flag: string;
    dateStr: string;
    avatar?: string;
  };
  totalAchieversCount: number;
}

const MILESTONE_TIERS: MilestoneTier[] = [
  {
    id: 't-1lakh',
    name: '1 LAKH CHIPS MILESTONE',
    chipsRequired: 100000,
    chipDisplay: '1,00,000 Chips (1 Lakh)',
    badge: '🥉 Bronze Elite',
    color: 'from-amber-700/20 to-orange-950/40 border-amber-600/40 text-amber-300',
    firstAchiever: {
      playerName: 'Rookie_Striker',
      userTag: '#IND-104',
      country: 'IN',
      flag: '🇮🇳',
      dateStr: '02 Jan 2026, 09:15 AM UTC',
      avatar: '🐍'
    },
    totalAchieversCount: 14209
  },
  {
    id: 't-5lakh',
    name: '5 LAKH CHIPS MILESTONE',
    chipsRequired: 500000,
    chipDisplay: '5,00,000 Chips (5 Lakhs)',
    badge: '🥈 Silver Commander',
    color: 'from-slate-400/20 to-slate-900/40 border-slate-400/40 text-slate-200',
    firstAchiever: {
      playerName: 'Viper_Zero',
      userTag: '#USA-402',
      country: 'US',
      flag: '🇺🇸',
      dateStr: '07 Jan 2026, 02:40 PM UTC',
      avatar: '👑'
    },
    totalAchieversCount: 4810
  },
  {
    id: 't-10lakh',
    name: '10 LAKH CHIPS (1 MILLION) MILESTONE',
    chipsRequired: 1000000,
    chipDisplay: '10,00,000 Chips (10 Lakhs / 1M)',
    badge: '🥇 Gold Apex Vanguard',
    color: 'from-yellow-500/20 to-amber-950/40 border-yellow-500/50 text-yellow-300',
    firstAchiever: {
      playerName: 'K-Snake_Master',
      userTag: '#KOR-114',
      country: 'KR',
      flag: '🇰🇷',
      dateStr: '11 Jan 2026, 06:30 AM SGT',
      avatar: '💎'
    },
    totalAchieversCount: 1290
  },
  {
    id: 't-25lakh',
    name: '25 LAKH CHIPS MILESTONE',
    chipsRequired: 2500000,
    chipDisplay: '25,00,000 Chips (25 Lakhs)',
    badge: '💎 Platinum Sovereign',
    color: 'from-cyan-500/20 to-blue-950/40 border-cyan-400/50 text-cyan-300',
    firstAchiever: {
      playerName: 'Apex_Viper',
      userTag: '#USA-882',
      country: 'US',
      flag: '🇺🇸',
      dateStr: '16 Jan 2026, 11:10 PM UTC',
      avatar: '⚡'
    },
    totalAchieversCount: 312
  },
  {
    id: 't-50lakh',
    name: '50 LAKH CHIPS MILESTONE',
    chipsRequired: 5000000,
    chipDisplay: '50,00,000 Chips (50 Lakhs)',
    badge: '🔮 Diamond Warlord',
    color: 'from-purple-500/20 to-indigo-950/40 border-purple-400/50 text-purple-300',
    firstAchiever: {
      playerName: 'Shadow_Ninja',
      userTag: '#JPN-309',
      country: 'JP',
      flag: '🇯🇵',
      dateStr: '19 Jan 2026, 08:22 PM JST',
      avatar: '🥋'
    },
    totalAchieversCount: 64
  },
  {
    id: 't-1crore',
    name: '1 CRORE CHIPS (10,000,000) LEGENDARY MILESTONE',
    chipsRequired: 10000000,
    chipDisplay: '1,00,00,000 Chips (1 Crore / 10M)',
    badge: '👑 OMEGA IMMORTAL GOD',
    color: 'from-amber-500/30 via-yellow-500/20 to-orange-950/60 border-2 border-amber-400 text-amber-300',
    firstAchiever: {
      playerName: 'Hari',
      userTag: '#IND-001',
      country: 'IN',
      flag: '🇮🇳',
      dateStr: '23 Jan 2026, 05:00 PM WST',
      avatar: '🇮🇳'
    },
    totalAchieversCount: 3
  }
];

const COUNTRY_OPTIONS = [
  { code: 'GLOBAL', name: 'Global (All Countries)', flag: '🌍' },
  { code: 'IN', name: 'India', flag: '🇮🇳' },
  { code: 'US', name: 'United States', flag: '🇺🇸' },
  { code: 'JP', name: 'Japan', flag: '🇯🇵' },
  { code: 'KR', name: 'South Korea', flag: '🇰🇷' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪' },
  { code: 'BR', name: 'Brazil', flag: '🇧🇷' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'FR', name: 'France', flag: '🇫🇷' },
  { code: 'AU', name: 'Australia', flag: '🇦🇺' }
];

const INITIAL_COMMENTARY: LiveCommentaryMessage[] = [
  {
    id: 'c1',
    timestamp: '13:41:02 UTC',
    text: '🎙️ ESPORTS DESK: Hari from India (#IND-001) locked in a massive extraction in Tier-05 High Stakes Arena!',
    type: 'extraction',
    playerName: 'Hari',
    country: 'IN',
    flag: '🇮🇳'
  },
  {
    id: 'c2',
    timestamp: '13:40:48 UTC',
    text: '💥 ARENA BLAST: Apex_Viper eliminated Scavenger_Bot and harvested 12 Star Chips on boundary!',
    type: 'elimination',
    playerName: 'Apex_Viper',
    country: 'US',
    flag: '🇺🇸'
  },
  {
    id: 'c3',
    timestamp: '13:39:15 UTC',
    text: '👑 MILESTONE NOTICE: User K-Snake_Master reached 2,500,000 banked chips & secured Platinum Sovereign Tier!',
    type: 'milestone',
    playerName: 'K-Snake_Master',
    country: 'KR',
    flag: '🇰🇷'
  }
];

// Helper to generate Top 100 for a specific tier
function generateTierTop100(tier: MilestoneTier, selectedCountry: string, selectedYear: number) {
  const list = [];
  const flags = ['🇮🇳', '🇺🇸', '🇯🇵', '🇰🇷', '🇩🇪', '🇧🇷', '🇬🇧', '🇫🇷', '🇦🇺'];

  if (tier.id === 't-1crore') {
    if (selectedCountry === 'GLOBAL' || selectedCountry === 'IN') {
      list.push({ rank: 1, name: 'Hari', userTag: '#IND-001', country: 'IN', flag: '🇮🇳', chips: 10000000, level: 50, dateStr: `23 Jan ${selectedYear}, 05:00 PM IST` });
    }
    if (selectedCountry === 'GLOBAL' || selectedCountry === 'US') {
      list.push({ rank: list.length + 1, name: 'Apex_Viper', userTag: '#USA-882', country: 'US', flag: '🇺🇸', chips: 10000000, level: 49, dateStr: `25 Jan ${selectedYear}, 11:10 PM EST` });
    }
    if (selectedCountry === 'GLOBAL' || selectedCountry === 'KR') {
      list.push({ rank: list.length + 1, name: 'K-Snake_Master', userTag: '#KOR-114', country: 'KR', flag: '🇰🇷', chips: 10000000, level: 49, dateStr: `28 Jan ${selectedYear}, 08:30 AM KST` });
    }
  } else {
    list.push({
      rank: 1,
      name: tier.firstAchiever.playerName,
      userTag: tier.firstAchiever.userTag,
      country: tier.firstAchiever.country,
      flag: tier.firstAchiever.flag,
      chips: tier.chipsRequired,
      level: 48,
      dateStr: tier.firstAchiever.dateStr
    });
  }

  const countryObj = COUNTRY_OPTIONS.find(c => c.code === selectedCountry);

  for (let r = list.length + 1; r <= 100; r++) {
    const flag = selectedCountry === 'GLOBAL' ? flags[r % flags.length] : (countryObj?.flag || '🇮🇳');
    const code = selectedCountry === 'GLOBAL' ? (COUNTRY_OPTIONS[(r % (COUNTRY_OPTIONS.length - 1)) + 1]?.code || 'IN') : selectedCountry;

    list.push({
      rank: r,
      name: `${selectedCountry === 'GLOBAL' ? 'Global' : countryObj?.name}_Achiever_${r}`,
      userTag: `#${code}-${100 + r}`,
      country: code,
      flag: flag,
      chips: Math.max(tier.chipsRequired, tier.chipsRequired + Math.floor((100 - r) * 15000)),
      level: Math.max(10, 50 - Math.floor(r / 2.5)),
      dateStr: `${(r % 28) + 1} Jan ${selectedYear}, 12:00 UTC`
    });
  }

  return list;
}

// Helper for general national top 100
function generateCountryTop100(countryCode: string) {
  const countryObj = COUNTRY_OPTIONS.find(c => c.code === countryCode) || COUNTRY_OPTIONS[1];
  const list = [];

  if (countryCode === 'IN' || countryCode === 'GLOBAL') {
    list.push({ rank: 1, name: 'Hari', userTag: '#IND-001', country: 'IN', chips: 10000000, level: 50, avatar: '🇮🇳' });
    list.push({ rank: 2, name: 'Arjun_Viper', userTag: '#IND-002', country: 'IN', chips: 8400000, level: 48, avatar: '🐍' });
    list.push({ rank: 3, name: 'Delhi_King', userTag: '#IND-003', country: 'IN', chips: 6200000, level: 45, avatar: '🦁' });
  } else if (countryCode === 'US') {
    list.push({ rank: 1, name: 'Apex_Viper', userTag: '#USA-882', country: 'US', chips: 9400000, level: 49, avatar: '🇺🇸' });
    list.push({ rank: 2, name: 'Cyber_Wolf', userTag: '#USA-102', country: 'US', chips: 7800000, level: 46, avatar: '🏍️' });
  } else if (countryCode === 'KR') {
    list.push({ rank: 1, name: 'K-Snake_Master', userTag: '#KOR-114', country: 'KR', chips: 8900000, level: 49, avatar: '🇰🇷' });
  }

  const startRank = list.length + 1;
  let currentChips = list.length > 0 ? list[list.length - 1].chips - 150000 : 5000000;

  for (let r = startRank; r <= 100; r++) {
    currentChips = Math.max(100000, Math.floor(currentChips - (Math.random() * 40000 + 10000)));
    list.push({
      rank: r,
      name: `${countryObj.name}_Challenger_${r}`,
      userTag: `#${countryCode}-${100 + r}`,
      country: countryCode,
      chips: currentChips,
      level: Math.max(10, 50 - Math.floor(r / 2.5)),
      avatar: countryObj.flag
    });
  }

  return list;
}

export default function HallOfFame({ playerStats, onInspectPlayer, onToast }: HallOfFameProps) {
  const [activeTab, setActiveTab] = useState<'firsts' | 'archives' | 'commentary'>('firsts');
  const [selectedCountry, setSelectedCountry] = useState<string>('IN');
  const [selectedYear, setSelectedYear] = useState<number>(2026);
  const [milestoneYear, setMilestoneYear] = useState<number>(2026);
  const [commentaryFeed, setCommentaryFeed] = useState<LiveCommentaryMessage[]>(INITIAL_COMMENTARY);
  const [filterType, setFilterType] = useState<string>('all');
  const [top100List, setTop100List] = useState<any[]>([]);

  // Tier Leaderboard Modal State
  const [inspectedTier, setInspectedTier] = useState<MilestoneTier | null>(null);
  const [tierCountry, setTierCountry] = useState<string>('GLOBAL');
  const [tierYear, setTierYear] = useState<number>(2026);

  // Update Top 100 whenever country or year changes
  useEffect(() => {
    setTop100List(generateCountryTop100(selectedCountry));
  }, [selectedCountry, selectedYear]);

  // Live commentary ticker simulation
  useEffect(() => {
    const interval = setInterval(() => {
      const names = ['Hari', 'Apex_Viper', 'Shadow_Ninja', 'Elysium_God', 'Ronin_JP', 'Brazil_King'];
      const countries = COUNTRY_OPTIONS.filter(c => c.code !== 'GLOBAL');

      const chosenCountry = countries[Math.floor(Math.random() * countries.length)];
      const chosenPlayer = names[Math.floor(Math.random() * names.length)];
      const randomChips = (Math.floor(Math.random() * 80) + 10) * 10000;
      const types: LiveCommentaryMessage['type'][] = ['extraction', 'elimination', 'milestone', 'high_stakes'];
      const chosenType = types[Math.floor(Math.random() * types.length)];

      let text = '';
      if (chosenType === 'extraction') {
        text = `🎙️ LIVE EXTRACTION: ${chosenPlayer} from ${chosenCountry.name} ${chosenCountry.flag} successfully extracted ${randomChips.toLocaleString()} chips in Tier-05 Arena!`;
      } else if (chosenType === 'elimination') {
        text = `💥 ARENA ELIMINATION: ${chosenPlayer} ${chosenCountry.flag} trapped a rival viper and claimed ${Math.floor(randomChips / 2).toLocaleString()} star chips!`;
      } else if (chosenType === 'milestone') {
        text = `👑 MILESTONE UPDATE: ${chosenPlayer} ${chosenCountry.flag} reached a new milestone tier with ${randomChips.toLocaleString()} chips!`;
      } else {
        text = `🔥 HIGH STAKES ACTION: Room #04 is boiling as ${chosenPlayer} ${chosenCountry.flag} enters extraction zone holding ${randomChips.toLocaleString()} chips!`;
      }

      const newMsg: LiveCommentaryMessage = {
        id: `c-${Date.now()}`,
        timestamp: new Date().toLocaleTimeString('en-US', { hour12: false }),
        text,
        type: chosenType,
        playerName: chosenPlayer,
        country: chosenCountry.code,
        flag: chosenCountry.flag
      };

      setCommentaryFeed((prev) => [newMsg, ...prev.slice(0, 19)]);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const filteredCommentary = commentaryFeed.filter((c) => {
    if (filterType === 'all') return true;
    return c.type === filterType;
  });

  return (
    <div id="hall-of-fame-panel" className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden space-y-6">
      {/* Glow backgrounds */}
      <div className="absolute -top-12 -right-12 w-64 h-64 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-12 -left-12 w-64 h-64 bg-yellow-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h2 className="text-2xl font-bold font-sans tracking-tight text-white flex items-center gap-2">
            <Crown className="w-7 h-7 text-yellow-400 drop-shadow-md animate-pulse" />
            Project Venom Hall of Fame & Esports Shrine
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-1 max-w-2xl">
            Immortalizing milestone achievers (1 Lakh to 1 Crore), annual World Cup champions, and live 1–100 national & global tier rankings!
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 shrink-0">
          <button
            onClick={() => setActiveTab('firsts')}
            className={`px-4 py-2 rounded-lg text-xs font-sans font-bold flex items-center gap-2 transition-all ${
              activeTab === 'firsts'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-lg'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-4 h-4 text-amber-400" /> Milestone Tiers (1L - 1Cr)
          </button>
          <button
            onClick={() => setActiveTab('archives')}
            className={`px-4 py-2 rounded-lg text-xs font-sans font-bold flex items-center gap-2 transition-all ${
              activeTab === 'archives'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-lg'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Trophy className="w-4 h-4 text-yellow-400" /> Tournament Archives (Ranks 1-100)
          </button>
          <button
            onClick={() => setActiveTab('commentary')}
            className={`px-4 py-2 rounded-lg text-xs font-sans font-bold flex items-center gap-2 transition-all ${
              activeTab === 'commentary'
                ? 'bg-red-500/20 text-red-300 border border-red-500/40 shadow-lg'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className="w-4 h-4 text-red-400 animate-pulse" /> Live Esports Ticker
          </button>
        </div>
      </div>

      {/* TICKER MARQUEE BANNER */}
      <div className="bg-slate-950 border border-amber-500/30 rounded-xl p-3 flex items-center gap-3 overflow-hidden shadow-inner">
        <div className="flex items-center gap-2 px-2 py-1 bg-red-600 text-white font-mono text-[10px] font-bold uppercase rounded shrink-0 animate-pulse">
          <Radio className="w-3 h-3" /> LIVE BROADCAST
        </div>
        <div className="overflow-hidden whitespace-nowrap text-xs font-mono text-amber-300 font-semibold flex-1">
          <div className="inline-block animate-marquee">
            {commentaryFeed[0]?.text || '🎙️ ESPORTS COMMENTARY ACTIVE: Welcome to Project Venom World Arena Championship!'}
          </div>
        </div>
      </div>

      {/* TAB 1: ALL MILESTONE TIERS (1 LAKH TO 1 CRORE) */}
      {activeTab === 'firsts' && (
        <div className="space-y-6">
          <div className="p-4 bg-amber-950/30 border border-amber-500/40 rounded-xl text-xs text-amber-200 font-sans flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-start gap-3">
              <Award className="w-6 h-6 text-yellow-400 shrink-0 mt-0.5" />
              <div>
                <strong className="block text-white text-sm">PERMANENT MILESTONE IMMORTALITY</strong>
                Whenever a player reaches a milestone target (from 1 Lakh to 1 Crore Chips), their record is permanently inscribed in the Hall of Fame for that tournament year! Live ranks update every 30 mins.
              </div>
            </div>

            {/* Year Selector for Milestone Tiers */}
            <div className="flex items-center gap-2 shrink-0 bg-slate-950 p-2 rounded-xl border border-slate-800">
              <span className="text-xs font-bold text-amber-300 font-sans flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 text-yellow-400" /> Milestone Year:
              </span>
              <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
                {[2026, 2025, 2024, 2023, 2022].map((yr) => (
                  <button
                    key={yr}
                    onClick={() => setMilestoneYear(yr)}
                    className={`px-2.5 py-1 rounded text-xs font-mono font-bold transition-all ${
                      milestoneYear === yr
                        ? 'bg-amber-500 text-black shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {yr} {yr === 2026 ? '(Current)' : ''}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {MILESTONE_TIERS.map((tier) => {
              const isCurrentPlayerEligible = playerStats.bankedChips >= tier.chipsRequired;

              return (
                <div
                  key={tier.id}
                  className={`p-5 rounded-2xl bg-gradient-to-b ${tier.color} backdrop-blur-md shadow-xl flex flex-col justify-between space-y-4 relative overflow-hidden transition-all hover:scale-[1.02]`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-mono font-bold uppercase tracking-widest block opacity-80">
                        {tier.badge}
                      </span>
                      <h3 className="text-base font-bold font-sans text-white mt-0.5">
                        {tier.name}
                      </h3>
                      <p className="text-xs font-mono font-bold text-emerald-400 mt-1">
                        {tier.chipDisplay}
                      </p>
                    </div>

                    {isCurrentPlayerEligible && (
                      <span className="bg-emerald-500 text-black text-[9px] font-mono font-bold px-2 py-0.5 rounded-full uppercase flex items-center gap-1">
                        <Check className="w-3 h-3" /> Achieved!
                      </span>
                    )}
                  </div>

                  {/* First Achiever Card */}
                  <div className="bg-slate-950/80 p-3.5 rounded-xl border border-slate-800 space-y-1.5">
                    <div className="text-[10px] font-mono text-slate-400 uppercase flex items-center justify-between font-bold">
                      <span className="flex items-center gap-1"><Star className="w-3 h-3 text-yellow-400" /> FIRST ACHIEVER ({milestoneYear})</span>
                      <span className="text-[9px] text-amber-400 font-mono">Season {milestoneYear}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-xl">{tier.firstAchiever.flag}</span>
                        <div>
                          <div className="text-xs font-bold text-white font-sans">
                            {tier.firstAchiever.playerName}{' '}
                            <span className="text-[10px] text-slate-400 font-mono">
                              {tier.firstAchiever.userTag}
                            </span>
                          </div>
                          <div className="text-[10px] text-slate-400 font-sans">
                            {tier.firstAchiever.dateStr.replace('2027', milestoneYear.toString())}
                          </div>
                        </div>
                      </div>

                      {onInspectPlayer && (
                        <button
                          onClick={() =>
                            onInspectPlayer({
                              name: tier.firstAchiever.playerName,
                              country: tier.firstAchiever.country,
                              userTag: tier.firstAchiever.userTag,
                              bankedChips: tier.chipsRequired,
                              level: 45,
                              avatar: tier.firstAchiever.flag
                            })
                          }
                          className="px-2 py-1 bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-black rounded-lg text-[10px] font-bold font-sans transition-colors"
                        >
                          Inspect
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Tier Action Button: View Ranks 1 to 100 */}
                  <button
                    onClick={() => {
                      setInspectedTier(tier);
                      setTierCountry('GLOBAL');
                      setTierYear(milestoneYear);
                    }}
                    className="w-full py-2.5 bg-slate-950/90 hover:bg-slate-950 text-amber-300 hover:text-yellow-200 border border-amber-500/40 rounded-xl text-xs font-sans font-bold flex items-center justify-center gap-2 transition-all shadow-lg"
                  >
                    <Trophy className="w-4 h-4 text-yellow-400" /> View Ranks #1 to #100 for {milestoneYear}
                  </button>

                  <div className="flex justify-between items-center text-[11px] font-sans text-slate-400 pt-2 border-t border-slate-800/60">
                    <span>Total Qualifiers This Year:</span>
                    <span className="font-mono font-bold text-white">
                      {tier.totalAchieversCount.toLocaleString()} Players
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: TOURNAMENT ARCHIVES & LIVE TOP 1-100 COUNTRY LEADERBOARDS */}
      {activeTab === 'archives' && (
        <div className="space-y-6">
          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
            {/* Year Selector */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white font-sans flex items-center gap-1.5">
                <Trophy className="w-4 h-4 text-yellow-400" /> Season Year:
              </span>
              <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
                {[2026, 2025, 2024, 2023, 2022].map((yr) => (
                  <button
                    key={yr}
                    onClick={() => setSelectedYear(yr)}
                    className={`px-3 py-1 rounded-md text-xs font-mono font-bold transition-all ${
                      selectedYear === yr
                        ? 'bg-amber-500 text-black shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {yr} {yr === 2026 ? '(Current Live)' : '(Archive)'}
                  </button>
                ))}
              </div>
            </div>

            {/* Country Selector */}
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white font-sans flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-indigo-400" /> Country Leaderboard:
              </span>
              <select
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-sans font-bold focus:outline-none focus:border-amber-500 cursor-pointer"
              >
                {COUNTRY_OPTIONS.filter(c => c.code !== 'GLOBAL').map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.flag} {c.name} ({c.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* National Top 100 Ranks Table */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="p-4 bg-slate-900/60 border-b border-slate-800 flex justify-between items-center">
              <div className="flex items-center gap-2">
                <span className="text-2xl">
                  {COUNTRY_OPTIONS.find((c) => c.code === selectedCountry)?.flag || '🌐'}
                </span>
                <h3 className="text-base font-bold text-white font-sans">
                  {selectedYear} {COUNTRY_OPTIONS.find((c) => c.code === selectedCountry)?.name} Top 100 Ranking
                </h3>
              </div>
              <span className="text-xs font-mono text-emerald-400 font-bold bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                #1 Country Champion Wins National Gold Medal
              </span>
            </div>

            <div className="max-h-[500px] overflow-y-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-[10px] uppercase font-bold text-slate-400 bg-slate-950 sticky top-0 z-10">
                    <th className="py-3 px-4">Rank</th>
                    <th className="py-3 px-4">Challenger</th>
                    <th className="py-3 px-4">User Tag</th>
                    <th className="py-3 px-4 text-right">Banked Chips</th>
                    <th className="py-3 px-4 text-center">Level</th>
                    <th className="py-3 px-4 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-900 text-xs font-sans">
                  {top100List.map((p) => {
                    const isTop1 = p.rank === 1;
                    const isTop3 = p.rank <= 3;

                    return (
                      <tr
                        key={p.rank}
                        className={`hover:bg-slate-900/60 transition-colors ${
                          isTop1 ? 'bg-amber-500/10' : isTop3 ? 'bg-slate-900/40' : ''
                        }`}
                      >
                        <td className="py-3 px-4 font-mono font-bold">
                          {p.rank === 1 ? (
                            <span className="flex items-center gap-1 text-yellow-400 font-black">
                              <Crown className="w-4 h-4 fill-yellow-400" /> #1
                            </span>
                          ) : p.rank === 2 ? (
                            <span className="text-slate-300 font-bold">🥈 #2</span>
                          ) : p.rank === 3 ? (
                            <span className="text-amber-600 font-bold">🥉 #3</span>
                          ) : (
                            <span className="text-slate-500">#{p.rank}</span>
                          )}
                        </td>

                        <td className="py-3 px-4 font-bold text-white flex items-center gap-2">
                          <span className="text-lg">{p.avatar}</span>
                          <span>{p.name}</span>
                          {isTop1 && (
                            <span className="text-[9px] bg-amber-500 text-black font-mono font-bold px-1.5 py-0.5 rounded">
                              NATIONAL CHAMP
                            </span>
                          )}
                        </td>

                        <td className="py-3 px-4 font-mono text-slate-400 text-xs">
                          {p.userTag}
                        </td>

                        <td className="py-3 px-4 text-right font-mono font-bold text-emerald-400">
                          {p.chips.toLocaleString()} c
                        </td>

                        <td className="py-3 px-4 text-center font-mono text-slate-300">
                          Lvl {p.level}
                        </td>

                        <td className="py-3 px-4 text-center">
                          {onInspectPlayer && (
                            <button
                              onClick={() =>
                                onInspectPlayer({
                                  name: p.name,
                                  country: selectedCountry,
                                  userTag: p.userTag,
                                  bankedChips: p.chips,
                                  level: p.level,
                                  avatar: p.avatar
                                })
                              }
                              className="px-2.5 py-1 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 rounded-lg text-[10px] font-bold transition-all cursor-pointer"
                            >
                              Inspect
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: LIVE ESPORTS TICKER STREAM */}
      {activeTab === 'commentary' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4 bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white font-sans flex items-center gap-2">
                <Radio className="w-4 h-4 text-red-400 animate-pulse" /> Channel Filter:
              </span>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1 text-xs text-white font-sans font-bold focus:outline-none"
              >
                <option value="all">🌐 All Arena Events</option>
                <option value="extraction">💰 High Stakes Extractions</option>
                <option value="elimination">💥 Viper Eliminations</option>
                <option value="milestone">👑 Milestone Breakers</option>
              </select>
            </div>
          </div>

          <div className="bg-slate-950 border border-slate-800/80 rounded-xl divide-y divide-slate-900 max-h-96 overflow-y-auto">
            {filteredCommentary.map((c) => (
              <div key={c.id} className="p-3.5 hover:bg-slate-900/50 transition-colors flex items-start gap-3 text-xs font-sans">
                <span className="font-mono text-[10px] text-slate-500 shrink-0 mt-0.5">{c.timestamp}</span>
                <div className="flex-1 text-slate-200">
                  {c.text}
                </div>
                {c.playerName && onInspectPlayer && (
                  <button
                    onClick={() => onInspectPlayer({ name: c.playerName!, country: c.country || 'IN', userTag: `#${c.country || 'IND'}-001`, bankedChips: 1500000, level: 35, avatar: c.flag })}
                    className="shrink-0 text-[10px] text-amber-400 hover:text-amber-300 font-bold underline cursor-pointer"
                  >
                    Inspect
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TIER-WISE TOP 1-100 ACHIEVERS MODAL */}
      {inspectedTier && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/40 rounded-2xl p-6 max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl relative space-y-4 overflow-hidden">
            <button
              onClick={() => setInspectedTier(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1.5 rounded-lg bg-slate-950 border border-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Title Banner */}
            <div className="flex items-center gap-3 border-b border-slate-800 pb-3">
              <div className="w-12 h-12 rounded-xl bg-slate-950 border border-amber-500/40 flex items-center justify-center text-2xl shadow-inner shrink-0">
                🏆
              </div>
              <div>
                <h3 className="text-lg font-bold text-white font-sans flex items-center gap-2">
                  <span>{inspectedTier.name}</span>
                  <span className="text-xs bg-amber-500 text-black font-mono font-bold px-2 py-0.5 rounded-full">
                    Ranks 1–100
                  </span>
                </h3>
                <p className="text-xs text-emerald-400 font-mono font-bold mt-0.5">
                  Target Threshold: {inspectedTier.chipDisplay}
                </p>
              </div>
            </div>

            {/* Filter controls inside modal */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
              {/* Country / Global filter */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-300 font-sans flex items-center gap-1">
                  <Globe className="w-3.5 h-3.5 text-indigo-400" /> Filter Scope:
                </span>
                <select
                  value={tierCountry}
                  onChange={(e) => setTierCountry(e.target.value)}
                  className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white font-sans font-bold focus:outline-none focus:border-amber-500 cursor-pointer"
                >
                  {COUNTRY_OPTIONS.map((c) => (
                    <option key={c.code} value={c.code}>
                      {c.flag} {c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Year filter */}
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-300 font-sans flex items-center gap-1">
                  <Trophy className="w-3.5 h-3.5 text-yellow-400" /> Year:
                </span>
                <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
                  {[2026, 2025, 2024, 2023, 2022].map((yr) => (
                    <button
                      key={yr}
                      onClick={() => setTierYear(yr)}
                      className={`px-2.5 py-0.5 rounded text-xs font-mono font-bold transition-all ${
                        tierYear === yr
                          ? 'bg-amber-500 text-black shadow'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {yr}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Tier Top 100 Achievers Table */}
            <div className="flex-1 overflow-y-auto bg-slate-950 rounded-xl border border-slate-800">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800 text-[10px] uppercase font-bold text-slate-400 bg-slate-900 sticky top-0 z-10">
                    <th className="py-2.5 px-3">Tier Rank</th>
                    <th className="py-2.5 px-3">Immortal Achiever</th>
                    <th className="py-2.5 px-3">User Tag</th>
                    <th className="py-2.5 px-3">Achieved On</th>
                    <th className="py-2.5 px-3 text-right">Qualifying Chips</th>
                    <th className="py-2.5 px-3 text-center">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-900 text-xs font-sans">
                  {generateTierTop100(inspectedTier, tierCountry, tierYear).map((p) => (
                    <tr key={p.rank} className="hover:bg-slate-900/60 transition-colors">
                      <td className="py-2.5 px-3 font-mono font-bold text-amber-400">
                        {p.rank === 1 ? (
                          <span className="text-yellow-400 font-bold flex items-center gap-1">👑 #1 First</span>
                        ) : p.rank <= 3 ? (
                          <span className="text-slate-200 font-bold">🥈 #{p.rank}</span>
                        ) : (
                          <span className="text-slate-500">#{p.rank}</span>
                        )}
                      </td>

                      <td className="py-2.5 px-3 font-bold text-white flex items-center gap-1.5">
                        <span className="text-base">{p.flag}</span>
                        <span>{p.name}</span>
                      </td>

                      <td className="py-2.5 px-3 font-mono text-slate-400 text-xs">
                        {p.userTag}
                      </td>

                      <td className="py-2.5 px-3 text-slate-400 text-[11px]">
                        {p.dateStr}
                      </td>

                      <td className="py-2.5 px-3 text-right font-mono font-bold text-emerald-400">
                        {p.chips.toLocaleString()} c
                      </td>

                      <td className="py-2.5 px-3 text-center">
                        {onInspectPlayer && (
                          <button
                            onClick={() => {
                              onInspectPlayer({
                                name: p.name,
                                country: p.country,
                                userTag: p.userTag,
                                bankedChips: p.chips,
                                level: p.level,
                                avatar: p.flag
                              });
                            }}
                            className="px-2 py-0.5 bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 rounded text-[10px] font-bold transition-all cursor-pointer"
                          >
                            Inspect
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
