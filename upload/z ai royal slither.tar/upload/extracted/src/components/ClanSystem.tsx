import React, { useState } from 'react';
import { Shield, Users, Trophy, Coins, Plus, Check, Search, Lock, Award, Crown, Zap, Send, MessageSquare, ArrowUpRight } from 'lucide-react';
import { PlayerStats } from '../types';

interface ClanMember {
  id: string;
  name: string;
  userTag: string;
  role: 'Leader' | 'Officer' | 'Member';
  bankedChips: number;
  level: number;
  country: string;
  flag: string;
  joinedDate: string;
}

interface ClanData {
  id: string;
  name: string;
  tag: string;
  motto: string;
  level: number;
  logoEmoji: string;
  treasuryChips: number;
  totalMembers: number;
  maxMembers: number;
  leaderName: string;
  leaderTag: string;
  minLevelReq: number;
  isPrivate: boolean;
  clanRank: number;
  members: ClanMember[];
  announcements: { id: string; author: string; text: string; time: string }[];
}

const SAMPLE_CLANS: ClanData[] = [
  {
    id: 'clan-1',
    name: 'Viper Apex Syndicate',
    tag: 'APEX',
    motto: 'Dominate the boundary, extract all chips.',
    level: 12,
    logoEmoji: '🐍',
    treasuryChips: 14500000,
    totalMembers: 28,
    maxMembers: 30,
    leaderName: 'Hari',
    leaderTag: '#IND-001',
    minLevelReq: 1,
    isPrivate: false,
    clanRank: 1,
    members: [
      { id: 'm1', name: 'Hari', userTag: '#IND-001', role: 'Leader', bankedChips: 10000000, level: 50, country: 'IN', flag: '🇮🇳', joinedDate: '01 Jan 2027' },
      { id: 'm2', name: 'Apex_Viper', userTag: '#USA-882', role: 'Officer', bankedChips: 9400000, level: 49, country: 'US', flag: '🇺🇸', joinedDate: '03 Jan 2027' },
      { id: 'm3', name: 'K-Snake_Master', userTag: '#KOR-114', role: 'Officer', bankedChips: 8900000, level: 49, country: 'KR', flag: '🇰🇷', joinedDate: '05 Jan 2027' },
      { id: 'm4', name: 'Rookie_Striker', userTag: '#IND-104', role: 'Member', bankedChips: 1200000, level: 32, country: 'IN', flag: '🇮🇳', joinedDate: '12 Jan 2027' }
    ],
    announcements: [
      { id: 'a1', author: 'Hari (Leader)', text: '🔥 Self-Sponsored Clan Arena War starts Saturday! Treasury pool funds 1,00,000c prize pool.', time: '2 hours ago' },
      { id: 'a2', author: 'Apex_Viper (Officer)', text: 'Treasury Bank replenished by members for custom clan tournaments!', time: '1 day ago' }
    ]
  },
  {
    id: 'clan-2',
    name: 'Cyber Ninja Shadow Squad',
    tag: 'NINJA',
    motto: 'Silent extraction, maximum venom.',
    level: 9,
    logoEmoji: '🥷',
    treasuryChips: 8200000,
    totalMembers: 22,
    maxMembers: 25,
    leaderName: 'Shadow_Ninja',
    leaderTag: '#JPN-309',
    minLevelReq: 15,
    isPrivate: false,
    clanRank: 2,
    members: [
      { id: 'm21', name: 'Shadow_Ninja', userTag: '#JPN-309', role: 'Leader', bankedChips: 5000000, level: 48, country: 'JP', flag: '🇯🇵', joinedDate: '02 Jan 2027' }
    ],
    announcements: [
      { id: 'a21', author: 'Shadow_Ninja', text: 'Recruiting active players for High Stakes Tier 5 extractions!', time: '3 days ago' }
    ]
  },
  {
    id: 'clan-3',
    name: 'Phoenix Elite Extraction Corps',
    tag: 'PHNX',
    motto: 'From the ashes, we reclaim the arena.',
    level: 6,
    logoEmoji: '🔥',
    treasuryChips: 3400000,
    totalMembers: 18,
    maxMembers: 20,
    leaderName: 'Viper_Zero',
    leaderTag: '#USA-402',
    minLevelReq: 10,
    isPrivate: false,
    clanRank: 3,
    members: [],
    announcements: []
  }
];

interface ClanSystemProps {
  playerStats: PlayerStats;
  onUpdatePlayerStats: (updated: Partial<PlayerStats>) => void;
  onToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
  onInspectPlayer?: (player: any) => void;
}

export default function ClanSystem({ playerStats, onUpdatePlayerStats, onToast, onInspectPlayer }: ClanSystemProps) {
  const [activeTab, setActiveTab] = useState<'myclan' | 'browse' | 'create'>('myclan');
  const [clansList, setClansList] = useState<ClanData[]>(SAMPLE_CLANS);
  const [userClanId, setUserClanId] = useState<string | null>(playerStats.clanTag ? 'clan-1' : null);
  const [searchQuery, setSearchQuery] = useState('');
  const [depositAmount, setDepositAmount] = useState<number>(10000);
  const [announcementInput, setAnnouncementInput] = useState('');

  // Form states for creating a new clan
  const [newClanName, setNewClanName] = useState('');
  const [newClanTag, setNewClanTag] = useState('');
  const [newClanMotto, setNewClanMotto] = useState('');
  const [newClanLogo, setNewClanLogo] = useState('🐍');
  const [newClanMinLevel, setNewClanMinLevel] = useState(5);

  const userClan = clansList.find((c) => c.id === userClanId);

  // Handle joining a clan
  const handleJoinClan = (clan: ClanData) => {
    if (userClanId) {
      onToast('You are already in a clan! Leave your current clan first.', 'error');
      return;
    }
    if (playerStats.level < clan.minLevelReq) {
      onToast(`Level ${clan.minLevelReq} required to join ${clan.name}!`, 'error');
      return;
    }

    const updatedClans = clansList.map((c) => {
      if (c.id === clan.id) {
        return {
          ...c,
          totalMembers: c.totalMembers + 1,
          members: [
            ...c.members,
            {
              id: `m-${Date.now()}`,
              name: playerStats.name,
              userTag: playerStats.userTag || '#IND-999',
              role: 'Member' as const,
              bankedChips: playerStats.bankedChips,
              level: playerStats.level,
              country: playerStats.country || 'IN',
              flag: '🇮🇳',
              joinedDate: 'Today'
            }
          ]
        };
      }
      return c;
    });

    setClansList(updatedClans);
    setUserClanId(clan.id);
    onUpdatePlayerStats({ clanTag: clan.tag });
    onToast(`Welcome to ${clan.name} [${clan.tag}]! 🛡️`, 'success');
    setActiveTab('myclan');
  };

  // Handle creating a clan
  const handleCreateClan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClanName.trim() || !newClanTag.trim()) {
      onToast('Clan Name and 3-4 character Tag are required!', 'error');
      return;
    }
    if (playerStats.bankedChips < 50000) {
      onToast('50,000 Banked Chips required to form a new Syndicate Clan!', 'error');
      return;
    }

    const createdClan: ClanData = {
      id: `clan-${Date.now()}`,
      name: newClanName.trim(),
      tag: newClanTag.trim().toUpperCase().slice(0, 5),
      motto: newClanMotto.trim() || 'Unconquerable venom warriors.',
      level: 1,
      logoEmoji: newClanLogo,
      treasuryChips: 50000,
      totalMembers: 1,
      maxMembers: 20,
      leaderName: playerStats.name,
      leaderTag: playerStats.userTag || '#IND-001',
      minLevelReq: newClanMinLevel,
      isPrivate: false,
      clanRank: clansList.length + 1,
      members: [
        {
          id: `m-${Date.now()}`,
          name: playerStats.name,
          userTag: playerStats.userTag || '#IND-001',
          role: 'Leader',
          bankedChips: playerStats.bankedChips - 50000,
          level: playerStats.level,
          country: playerStats.country || 'IN',
          flag: '🇮🇳',
          joinedDate: 'Today'
        }
      ],
      announcements: [
        { id: `a-${Date.now()}`, author: `${playerStats.name} (Leader)`, text: 'Syndicate formed! Welcome all founders.', time: 'Just now' }
      ]
    };

    // Deduct entry fee
    onUpdatePlayerStats({
      bankedChips: playerStats.bankedChips - 50000,
      clanTag: createdClan.tag
    });

    setClansList([createdClan, ...clansList]);
    setUserClanId(createdClan.id);
    onToast(`Syndicate ${createdClan.name} [${createdClan.tag}] formed successfully! 👑`, 'success');
    setActiveTab('myclan');
  };

  // Deposit chips into treasury
  const handleDepositTreasury = () => {
    if (!userClan) return;
    if (depositAmount <= 0) return;
    if (playerStats.bankedChips < depositAmount) {
      onToast('Insufficient Banked Chips to deposit!', 'error');
      return;
    }

    onUpdatePlayerStats({ bankedChips: playerStats.bankedChips - depositAmount });

    setClansList(clansList.map((c) => {
      if (c.id === userClan.id) {
        return { ...c, treasuryChips: c.treasuryChips + depositAmount };
      }
      return c;
    }));

    onToast(`Deposited ${depositAmount.toLocaleString()} chips into ${userClan.name} Treasury! 🏦`, 'success');
  };

  // Post announcement
  const handlePostAnnouncement = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userClan || !announcementInput.trim()) return;

    setClansList(clansList.map((c) => {
      if (c.id === userClan.id) {
        return {
          ...c,
          announcements: [
            { id: `a-${Date.now()}`, author: `${playerStats.name} (Leader)`, text: announcementInput.trim(), time: 'Just now' },
            ...c.announcements
          ]
        };
      }
      return c;
    }));

    setAnnouncementInput('');
    onToast('Clan broadcast published to member feed! 📢', 'info');
  };

  const filteredClans = clansList.filter((c) =>
    c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.tag.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-6 relative overflow-hidden">
      {/* Background accents */}
      <div className="absolute -top-12 -right-12 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <h2 className="text-2xl font-bold font-sans tracking-tight text-white flex items-center gap-2">
            <Shield className="w-7 h-7 text-indigo-400" />
            Viper Clan & Syndicate Guild HQ
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-1">
            Form or join a player syndicate, pool chips into the Clan Treasury, level up for extraction perks, and dominate Clan Wars!
          </p>
        </div>

        {/* Navigation Tabs */}
        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 shrink-0">
          <button
            onClick={() => setActiveTab('myclan')}
            className={`px-4 py-2 rounded-lg text-xs font-sans font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'myclan'
                ? 'bg-indigo-600 text-white shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Shield className="w-4 h-4" /> My Clan
          </button>
          <button
            onClick={() => setActiveTab('browse')}
            className={`px-4 py-2 rounded-lg text-xs font-sans font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'browse'
                ? 'bg-indigo-600 text-white shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Search className="w-4 h-4" /> Browse Clans
          </button>
          <button
            onClick={() => setActiveTab('create')}
            className={`px-4 py-2 rounded-lg text-xs font-sans font-bold flex items-center gap-1.5 transition-all ${
              activeTab === 'create'
                ? 'bg-indigo-600 text-white shadow-lg'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Plus className="w-4 h-4" /> Form Syndicate
          </button>
        </div>
      </div>

      {/* TAB 1: MY CLAN DASHBOARD */}
      {activeTab === 'myclan' && (
        <div>
          {userClan ? (
            <div className="space-y-6">
              {/* Clan Header Banner */}
              <div className="bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 p-6 rounded-2xl border border-indigo-500/30 flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden shadow-xl">
                <div className="flex items-center gap-4">
                  <div className="w-20 h-20 rounded-2xl bg-slate-950 border-2 border-indigo-500/50 flex items-center justify-center text-4xl shadow-inner shrink-0">
                    {userClan.logoEmoji}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-xl font-bold text-white font-sans">{userClan.name}</h3>
                      <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-xs font-mono font-bold px-2 py-0.5 rounded">
                        [{userClan.tag}]
                      </span>
                      <span className="bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-mono font-bold px-2 py-0.5 rounded flex items-center gap-1">
                        <Trophy className="w-3 h-3 text-amber-400" /> Clan Rank #{userClan.clanRank}
                      </span>
                    </div>
                    <p className="text-xs text-slate-300 italic font-sans mt-1">"{userClan.motto}"</p>
                    <div className="flex items-center gap-4 text-xs font-sans text-slate-400 mt-2">
                      <span>Leader: <strong className="text-amber-400 font-mono">{userClan.leaderName} ({userClan.leaderTag})</strong></span>
                      <span>•</span>
                      <span>Members: <strong className="text-white">{userClan.totalMembers}/{userClan.maxMembers}</strong></span>
                      <span>•</span>
                      <span>Clan Level: <strong className="text-indigo-400 font-mono font-bold">Lvl {userClan.level}</strong></span>
                    </div>
                  </div>
                </div>

                {/* Treasury Stats & Deposit Card */}
                <div className="bg-slate-950/80 p-4 rounded-xl border border-slate-800 space-y-3 min-w-[260px]">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-slate-400 font-bold uppercase font-sans flex items-center gap-1">
                      <Coins className="w-3.5 h-3.5 text-amber-400" /> Clan Treasury Bank
                    </span>
                    <span className="font-mono font-bold text-emerald-400 text-sm">
                      {userClan.treasuryChips.toLocaleString()} c
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      value={depositAmount}
                      onChange={(e) => setDepositAmount(Number(e.target.value))}
                      className="bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-xs text-white font-mono w-28 focus:outline-none focus:border-indigo-500"
                      step={5000}
                    />
                    <button
                      onClick={handleDepositTreasury}
                      className="flex-1 py-1 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-sans text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1"
                    >
                      <Coins className="w-3.5 h-3.5" /> Deposit
                    </button>
                  </div>
                </div>
              </div>

              {/* Clan Perks Bar */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center gap-3">
                  <div className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl">
                    <Zap className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white font-sans">Self-Sponsored Arenas</div>
                    <div className="text-[11px] text-slate-400 font-mono">Host custom clan tournaments funded by Treasury</div>
                  </div>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center gap-3">
                  <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white font-sans">Clan Tag Emblem</div>
                    <div className="text-[11px] text-slate-400 font-mono">Displays [{userClan.tag}] badge in match leaderboards</div>
                  </div>
                </div>

                <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center gap-3">
                  <div className="p-2.5 bg-purple-500/10 text-purple-400 rounded-xl">
                    <Crown className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white font-sans">Syndicate Wars Access</div>
                    <div className="text-[11px] text-slate-400 font-mono">Qualified for weekly Clan vs Clan prize matches</div>
                  </div>
                </div>
              </div>

              {/* Members List & Announcements */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Members Roster */}
                <div className="lg:col-span-2 bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4">
                  <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                    <h4 className="text-sm font-bold text-white font-sans flex items-center gap-2">
                      <Users className="w-4 h-4 text-indigo-400" /> Member Roster ({userClan.members.length})
                    </h4>
                    <span className="text-xs text-slate-400 font-mono">Max Capacity: {userClan.maxMembers}</span>
                  </div>

                  <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                    {userClan.members.map((m) => (
                      <div key={m.id} className="p-3 bg-slate-900/60 hover:bg-slate-900 rounded-xl border border-slate-800/80 flex items-center justify-between transition-colors">
                        <div className="flex items-center gap-3">
                          <span className="text-lg">{m.flag}</span>
                          <div>
                            <div className="text-xs font-bold text-white font-sans flex items-center gap-2">
                              <span>{m.name}</span>
                              <span className="text-[10px] text-slate-400 font-mono">{m.userTag}</span>
                              {m.role === 'Leader' && (
                                <span className="bg-amber-500 text-black text-[9px] font-mono font-bold px-1.5 py-0.2 rounded">
                                  LEADER
                                </span>
                              )}
                              {m.role === 'Officer' && (
                                <span className="bg-indigo-500 text-white text-[9px] font-mono font-bold px-1.5 py-0.2 rounded">
                                  OFFICER
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-400 font-sans">Joined: {m.joinedDate} • Level {m.level}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-3">
                          <span className="text-xs font-mono font-bold text-emerald-400">{m.bankedChips.toLocaleString()} c</span>
                          {onInspectPlayer && (
                            <button
                              onClick={() => onInspectPlayer({ name: m.name, country: m.country, userTag: m.userTag, bankedChips: m.bankedChips, level: m.level, avatar: m.flag })}
                              className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded text-[10px] font-bold"
                            >
                              Inspect
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Broadcast Announcements */}
                <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-4">
                  <h4 className="text-sm font-bold text-white font-sans flex items-center gap-2">
                    <MessageSquare className="w-4 h-4 text-purple-400" /> Syndicate Broadcast Feed
                  </h4>

                  <form onSubmit={handlePostAnnouncement} className="space-y-2">
                    <textarea
                      value={announcementInput}
                      onChange={(e) => setAnnouncementInput(e.target.value)}
                      placeholder="Publish broadcast announcement to all members..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500 resize-none h-20"
                    />
                    <button
                      type="submit"
                      className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-sans text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1.5"
                    >
                      <Send className="w-3.5 h-3.5" /> Post Announcement
                    </button>
                  </form>

                  <div className="space-y-2 max-h-56 overflow-y-auto">
                    {userClan.announcements.map((a) => (
                      <div key={a.id} className="p-3 bg-slate-900/80 rounded-xl border border-slate-800 text-xs font-sans space-y-1">
                        <div className="flex justify-between items-center text-[10px] text-amber-400 font-bold">
                          <span>{a.author}</span>
                          <span className="text-slate-500 font-mono">{a.time}</span>
                        </div>
                        <p className="text-slate-200">{a.text}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 bg-slate-950 rounded-2xl border border-slate-800 space-y-4">
              <Shield className="w-12 h-12 text-slate-600 mx-auto" />
              <h3 className="text-lg font-bold text-white font-sans">You are not in a Viper Clan</h3>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                Join an existing clan from the directory to participate in Clan Wars and earn extraction perks, or form your own syndicate!
              </p>
              <div className="flex justify-center gap-3 pt-2">
                <button
                  onClick={() => setActiveTab('browse')}
                  className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-sans text-xs font-bold rounded-xl"
                >
                  Browse Clans
                </button>
                <button
                  onClick={() => setActiveTab('create')}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-sans text-xs font-bold rounded-xl"
                >
                  Form Syndicate
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: BROWSE CLANS */}
      {activeTab === 'browse' && (
        <div className="space-y-4">
          <div className="flex items-center gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
            <Search className="w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search clans by name or tag..."
              className="bg-transparent text-xs text-white placeholder-slate-500 focus:outline-none flex-1"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredClans.map((clan) => (
              <div key={clan.id} className="p-5 bg-slate-950 border border-slate-800 rounded-2xl space-y-3 hover:border-slate-700 transition-all">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-3xl">{clan.logoEmoji}</span>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="text-base font-bold text-white font-sans">{clan.name}</h4>
                        <span className="bg-indigo-500/20 text-indigo-300 text-[10px] font-mono font-bold px-1.5 py-0.5 rounded">
                          [{clan.tag}]
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 italic font-sans">{clan.motto}</p>
                    </div>
                  </div>
                  <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">
                    Rank #{clan.clanRank}
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-slate-900/60 p-2.5 rounded-xl text-[11px] font-sans text-slate-300">
                  <div>
                    <span className="text-slate-500 block">Level:</span>
                    <strong className="text-white font-mono">Lvl {clan.level}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Members:</span>
                    <strong className="text-white font-mono">{clan.totalMembers}/{clan.maxMembers}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Treasury:</span>
                    <strong className="text-emerald-400 font-mono">{clan.treasuryChips.toLocaleString()} c</strong>
                  </div>
                </div>

                <button
                  onClick={() => handleJoinClan(clan)}
                  disabled={userClanId === clan.id}
                  className={`w-full py-2 rounded-xl text-xs font-sans font-bold transition-all ${
                    userClanId === clan.id
                      ? 'bg-slate-900 text-slate-500 border border-slate-800 cursor-default'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                  }`}
                >
                  {userClanId === clan.id ? 'Already a Member' : `Join Syndicate (Req Lvl ${clan.minLevelReq})`}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: FORM NEW SYNDICATE */}
      {activeTab === 'create' && (
        <form onSubmit={handleCreateClan} className="max-w-2xl mx-auto bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
          <h3 className="text-base font-bold text-white font-sans flex items-center gap-2 border-b border-slate-800 pb-3">
            <Plus className="w-5 h-5 text-indigo-400" /> Form a New Viper Syndicate Clan
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Syndicate Name</label>
              <input
                type="text"
                value={newClanName}
                onChange={(e) => setNewClanName(e.target.value)}
                placeholder="e.g. Omega Extractions"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Clan Tag (3-4 Chars)</label>
              <input
                type="text"
                value={newClanTag}
                onChange={(e) => setNewClanTag(e.target.value.toUpperCase())}
                placeholder="e.g. OMG"
                maxLength={4}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white font-mono focus:outline-none focus:border-indigo-500"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">Syndicate Motto</label>
            <input
              type="text"
              value={newClanMotto}
              onChange={(e) => setNewClanMotto(e.target.value)}
              placeholder="e.g. Extraction above all else."
              className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Emblem Logo</label>
              <select
                value={newClanLogo}
                onChange={(e) => setNewClanLogo(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white focus:outline-none"
              >
                <option value="🐍">🐍 Viper Snake</option>
                <option value="👑">👑 Royal Crown</option>
                <option value="🥷">🥷 Cyber Ninja</option>
                <option value="🔥">🔥 Phoenix Fire</option>
                <option value="⚡">⚡ Lightning Bolt</option>
                <option value="💎">💎 Diamond Shield</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Minimum Level Req.</label>
              <input
                type="number"
                value={newClanMinLevel}
                onChange={(e) => setNewClanMinLevel(Number(e.target.value))}
                min={1}
                max={50}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white font-mono focus:outline-none"
              />
            </div>
          </div>

          <div className="bg-amber-950/20 border border-amber-500/30 p-3 rounded-xl text-xs text-amber-300 font-sans flex items-center justify-between">
            <span>Formation Fee: <strong>50,000 Banked Chips</strong></span>
            <span className="font-mono font-bold text-emerald-400">Balance: {playerStats.bankedChips.toLocaleString()} c</span>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-sans text-xs font-bold rounded-xl transition-colors shadow-lg"
          >
            Form Syndicate & Initialize Treasury
          </button>
        </form>
      )}
    </div>
  );
}
