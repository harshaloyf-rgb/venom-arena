import { useEffect, useRef, useState } from 'react';
import { Compass, Landmark, Swords, Skull, Shield, Zap, Sparkles, Navigation, MessageSquare, X, Volume2, VolumeX, Magnet, Flame, Globe, Users, Trophy, UserPlus } from 'lucide-react';
import { ArenaTier, PlayerStats, Snake, Food, Particle, SnakePoint, Friend, Rival } from '../types';
import { ALL_COSMETICS } from '../data';
import { gameAudio } from '../utils/audio';
import { io } from 'socket.io-client';
import { logMatchOutcome } from '../utils/firebaseSync';

interface GameCanvasProps {
  playerStats: PlayerStats;
  selectedArena: ArenaTier;
  isOnline: boolean;
  onUpdateStats: (stats: Partial<PlayerStats>) => void;
  onExitGame: () => void;
  onPlayAgain?: () => void;
  onToast: (msg: string, type: 'success' | 'info' | 'error') => void;
  spectateTarget?: { name: string; color: string; } | null;
}

interface PowerUp {
  id: string;
  x: number;
  y: number;
  type: 'shield' | 'magnet' | 'double' | 'freeze';
  color: string;
  pulse: number;
}

// World Boundaries
const WORLD_SIZE = 8000;
const INITIAL_BODY_LENGTH = 15;

function getMapRadius(elapsedTimeMs: number): number {
  const baseRadius = 3800; // Large 3800 radius within 8000x8000 world coordinates
  const cycleTime = (elapsedTimeMs % 10000) / 10000;
  const sinVal = Math.sin(cycleTime * Math.PI * 2);
  return baseRadius + sinVal * 40; // Breathes by +/- 40 pixels
}
const BOT_NAMES = [
  'ViperX', 'NagaSlayer', 'Kobracommander', 'Copperhead', 'Basilisk', 
  'MambaGrid', 'PythonPro', 'Sidewinder', 'Anacondax', 'TaipanFury',
  'GoldBiter', 'NeonVenom', 'ApexStryker', 'Slinky', 'StarStealer',
  'Hold_To_Extract', 'GreedyGargoyle', 'RiskTaker', 'DiamondHands', 'FleeMaster'
];

export default function GameCanvas({
  playerStats,
  selectedArena,
  isOnline,
  onUpdateStats,
  onExitGame,
  onPlayAgain,
  onToast,
  spectateTarget,
}: GameCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Game Engine Refs (to avoid re-render cycles)
  const playerSnakeRef = useRef<Snake | null>(null);
  const snakesRef = useRef<Snake[]>([]);
  const foodsRef = useRef<Food[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const keysPressedRef = useRef<{ [key: string]: boolean }>({});
  const mousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const controlModeRef = useRef<'mouse' | 'keyboard'>('mouse');
  const socketRef = useRef<any>(null);

  // UI States
  const [carriedChips, setCarriedChips] = useState<number>(isOnline ? selectedArena.buyIn : 0);
  const [realKillsCount, setRealKillsCount] = useState<number>(0);
  const [snakeLength, setSnakeLength] = useState<number>(INITIAL_BODY_LENGTH);
  const [activeLeaderboard, setActiveLeaderboard] = useState<{ name: string; carried: number; isPlayer: boolean; isBot: boolean }[]>([]);
  const [isHoldingExtract, setIsHoldingExtract] = useState(false);
  const [extractProgress, setExtractProgress] = useState(0); // 0 to 100
  const [isGameOver, setIsGameOver] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [killsCount, setKillsCount] = useState(0);
  const [finalChipsBanked, setFinalChipsBanked] = useState(0);
  const [combatBanner, setCombatBanner] = useState<{ text: string; sub: string; color: string; id: number } | null>(null);
  const [activeRealPlayers, setActiveRealPlayers] = useState<number>(1);

  const lastKillTimeRef = useRef<number>(0);
  const killComboRef = useRef<number>(0);

  // Keep refs updated to prevent stale closures in requestAnimationFrame gameLoop
  const playerStatsRef = useRef(playerStats);
  const selectedArenaRef = useRef(selectedArena);
  const isOnlineRef = useRef(isOnline);
  const isGameOverRef = useRef(isGameOver);
  const playerServerPointsRef = useRef<SnakePoint[]>([]);
  const isSuccessRef = useRef(isSuccess);
  const isHoldingExtractRef = useRef(isHoldingExtract);
  const lastWarningToastTimeRef = useRef(0);
  const extractionStartAngleRef = useRef<number | null>(null);
  const extractionStartMousePosRef = useRef<{ x: number; y: number } | null>(null);
  const lastLeaderboardUpdateTimeRef = useRef<number>(0);
  const lastExtractProgressRef = useRef<number>(-1);
  const lastCarriedChipsRef = useRef<number>(-1);
  const lastSnakeLengthRef = useRef<number>(-1);

  // Power Ups & Boss Refs
  const powerUpsRef = useRef<PowerUp[]>([]);
  const shieldActiveRef = useRef(false);
  const magnetTimerRef = useRef(0);
  const doubleTimerRef = useRef(0);
  const freezeTimerRef = useRef(0);
  const gameTimeElapsedRef = useRef(0);
  const bossSpawnedRef = useRef(false);
  const allyCommandRef = useRef<'protect' | 'farm' | 'hunt'>('protect');
  const screenShakeRef = useRef<number>(0);
  const lastSentInputRef = useRef<{ targetAngle: number; wantsBoost: boolean; isExtracting: boolean; time: number }>({
    targetAngle: 0,
    wantsBoost: false,
    isExtracting: false,
    time: 0
  });
  const gameStartTimeRef = useRef<number>(Date.now());
  const animFrameRef = useRef<number | null>(null);
  const isMountedRef = useRef<boolean>(true);

  const triggerShake = (amount: number) => {
    screenShakeRef.current = Math.max(screenShakeRef.current, amount);
  };

  // React states to bind to UI
  const [shieldActive, setShieldActive] = useState(false);
  const [magnetTimeLeft, setMagnetTimeLeft] = useState(0);
  const [doubleTimeLeft, setDoubleTimeLeft] = useState(0);
  const [freezeTimeLeft, setFreezeTimeLeft] = useState(0);
  const [allyCommand, setAllyCommand] = useState<'protect' | 'farm' | 'hunt'>('protect');
  const [hasAlly, setHasAlly] = useState(false);
  const [bossAlert, setBossAlert] = useState<string | null>(null);
  const [isMuted, setIsMuted] = useState(() => gameAudio.isMuted);

  useEffect(() => {
    playerStatsRef.current = playerStats;
  }, [playerStats]);

  useEffect(() => {
    selectedArenaRef.current = selectedArena;
  }, [selectedArena]);

  useEffect(() => {
    isOnlineRef.current = isOnline;
  }, [isOnline]);

  useEffect(() => {
    isGameOverRef.current = isGameOver;
  }, [isGameOver]);

  useEffect(() => {
    isSuccessRef.current = isSuccess;
  }, [isSuccess]);

  useEffect(() => {
    isHoldingExtractRef.current = isHoldingExtract;
  }, [isHoldingExtract]);

  // Live Squad & Co-Op States
  const [activeFriends] = useState<Friend[]>(() => {
    const saved = localStorage.getItem('venom_friends');
    return saved ? JSON.parse(saved) : [
      { id: 'f-1', name: 'ApexViper', userTag: 'APEX-1029', status: 'online', level: 42, skinColor: '#10b981', giftSentToday: false, giftReceivedToday: true },
      { id: 'f-2', name: 'ShadowSlinker', userTag: 'SLNK-9281', status: 'in-match', level: 18, skinColor: '#a855f7', giftSentToday: false, giftReceivedToday: false },
      { id: 'f-3', name: 'CoinGobbler', userTag: 'COIN-5432', status: 'offline', level: 29, skinColor: '#eab308', giftSentToday: true, giftReceivedToday: false },
      { id: 'f-4', name: 'VenomKing', userTag: 'VNOM-0001', status: 'online', level: 55, skinColor: '#ef4444', giftSentToday: false, giftReceivedToday: false },
    ];
  });
  const [showInviteDrawer, setShowInviteDrawer] = useState(false);
  const [pendingInvites, setPendingInvites] = useState<{ [friendId: string]: boolean }>({});
  
  // Mobile UI declutter: default collapsed on screen width < 768px
  const [showMinimap, setShowMinimap] = useState(() => window.innerWidth >= 768);
  const [showLeaderboard, setShowLeaderboard] = useState(() => window.innerWidth >= 768);
  const [showEmotes, setShowEmotes] = useState(() => window.innerWidth >= 768);

  // Audio/Visual Cosmetic Colors
  const cosmeticSkin = ALL_COSMETICS.find((c) => c.id === playerStats.currentSkin) || ALL_COSMETICS[0];
  const cosmeticTrail = ALL_COSMETICS.find((c) => c.id === playerStats.currentTrail) || ALL_COSMETICS[5];
  const cosmeticDeath = ALL_COSMETICS.find((c) => c.id === playerStats.currentDeath) || ALL_COSMETICS[8];

  // Ad Reward and Rank States
  const [isWatchingAd, setIsWatchingAd] = useState(false);
  const [adCountdown, setAdCountdown] = useState(3);
  const [hasWatchedAd, setHasWatchedAd] = useState(false);

  // Killer & Rivalry Action States
  const [killerInfo, setKillerInfo] = useState<{ name: string; userTag: string; color: string; isBot?: boolean } | null>(null);
  const [isAddedRival, setIsAddedRival] = useState(false);
  const [isAddedFriend, setIsAddedFriend] = useState(false);

  const handleAddRival = () => {
    if (!killerInfo || isAddedRival) return;
    const newRival: Rival = {
      id: `rival-${Date.now()}`,
      name: killerInfo.name,
      userTag: killerInfo.userTag,
      status: 'online',
      currentArenaId: selectedArena.id,
      currentArenaName: selectedArena.name,
      level: Math.floor(15 + Math.random() * 35),
      skinColor: killerInfo.color || '#ef4444',
      timesKilledByYou: 0,
      timesKilledYou: 1,
      lastEncounterDate: 'Just now'
    };

    const currentRivals: Rival[] = playerStats.rivals || [];
    if (!currentRivals.some((r) => r.userTag === killerInfo.userTag)) {
      const updatedRivals = [newRival, ...currentRivals];
      onUpdateStats({ rivals: updatedRivals });
      const savedLocal = JSON.parse(localStorage.getItem('venom_rivals') || '[]');
      localStorage.setItem('venom_rivals', JSON.stringify([newRival, ...savedLocal.filter((r: any) => r.userTag !== killerInfo.userTag)]));
    }

    setIsAddedRival(true);
    onToast(`⚔️ ${killerInfo.name} added to your Rival List! Hunt them in future lobbies!`, 'success');
  };

  const handleAddFriend = () => {
    if (!killerInfo || isAddedFriend) return;
    const newFriend: Friend = {
      id: `friend-${Date.now()}`,
      name: killerInfo.name,
      userTag: killerInfo.userTag,
      status: 'online',
      currentArenaId: selectedArena.id,
      currentArenaName: selectedArena.name,
      level: Math.floor(15 + Math.random() * 35),
      skinColor: killerInfo.color || '#10b981',
      giftSentToday: false,
      giftReceivedToday: false
    };

    const savedFriends: Friend[] = JSON.parse(localStorage.getItem('venom_friends') || '[]');
    if (!savedFriends.some((f) => f.userTag === killerInfo.userTag)) {
      const updatedFriends = [newFriend, ...savedFriends];
      localStorage.setItem('venom_friends', JSON.stringify(updatedFriends));
    }

    setIsAddedFriend(true);
    onToast(`🤝 Added ${killerInfo.name} (${killerInfo.userTag}) to your Friends list!`, 'success');
  };

  const getPlayerRank = () => {
    const player = playerSnakeRef.current;
    if (!player) return 1;

    // Deduplicate snakes by ID to prevent duplicate player or bot entries from corrupting rank
    const snakeMap = new Map<string, Snake>();
    snakeMap.set(player.id, player);
    snakesRef.current.forEach((s) => {
      if (!s.isDead) {
        if (s.isPlayer || s.id === 'player' || (socketRef.current && s.id === socketRef.current.id)) {
          snakeMap.set(player.id, player);
        } else {
          snakeMap.set(s.id, s);
        }
      }
    });

    const allSnakes = Array.from(snakeMap.values());
    allSnakes.sort((a, b) => b.score - a.score);

    const rankIndex = allSnakes.findIndex((s) => s.id === player.id || s.isPlayer);
    return rankIndex !== -1 ? rankIndex + 1 : 1;
  };

  const handleWatchAd = () => {
    if (hasWatchedAd) return;
    setIsWatchingAd(true);
    setAdCountdown(3);
    
    const interval = setInterval(() => {
      setAdCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsWatchingAd(false);
          setHasWatchedAd(true);
          
          // Credit 50 chips to player's account
          onUpdateStats({
            bankedChips: playerStatsRef.current.bankedChips + 50,
            totalChipsEarned: playerStatsRef.current.totalChipsEarned + 50
          });
          
          onToast("📺 +50 chips successfully credited to your bank account! 💎", "success");
          try {
            gameAudio.playStar();
          } catch (e) {}
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  // Game initialization
  useEffect(() => {
    isMountedRef.current = true;
    initGame();

    // Event listeners
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    window.addEventListener('mousemove', handleMouseMove);

    // Dynamic resize
    const handleResize = () => {
      if (!canvasRef.current || !containerRef.current) return;
      canvasRef.current.width = containerRef.current.clientWidth;
      canvasRef.current.height = containerRef.current.clientHeight;
    };
    window.addEventListener('resize', handleResize);
    handleResize();

    // Start Animation Loop
    animFrameRef.current = requestAnimationFrame(gameLoop);

    return () => {
      isMountedRef.current = false;
      if (animFrameRef.current !== null) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  // Multiplayer socket.io engine integration
  useEffect(() => {
    if (!isOnline) return;

    // Connect to the shared-port fullstack Express server with JWT auth
    const token = localStorage.getItem('venom_jwt');
    const socket = io({
      auth: { token }
    });
    socketRef.current = socket;

    socket.emit('join_arena', {
      arenaId: selectedArena.id,
      playerStats: playerStatsRef.current
    });

    socket.on('arena_joined', (data: { playerId: string; foods: Food[]; players: any[] }) => {
      onToast(`Connected to real-time multiplayer shard!`, 'success');

      if (data.foods && data.foods.length > 0) {
        foodsRef.current = data.foods;
      }

      // Format incoming players as standard client snakes (excluding local player)
      const remotePlayers = data.players.filter((p) => p.id !== data.playerId && p.id !== socket.id);
      
      if (playerSnakeRef.current) {
        playerSnakeRef.current.id = data.playerId;
      }

      const incomingSnakes: Snake[] = remotePlayers.map((p) => {
        const startX = p.points && p.points.length > 0 ? p.points[0].x : Math.random() * (WORLD_SIZE - 200) + 100;
        const startY = p.points && p.points.length > 0 ? p.points[0].y : Math.random() * (WORLD_SIZE - 200) + 100;
        const angle = p.angle || 0;
        return {
          id: p.id,
          name: p.name,
          points: p.points && p.points.length > 0 ? p.points : generateInitialBody(startX, startY, angle),
          angle,
          targetAngle: angle,
          speed: p.speed,
          size: p.size,
          color: p.color,
          secondaryColor: p.secondaryColor,
          isBot: false,
          carriedChips: p.carriedChips,
          isExtracting: p.isExtracting,
          extractionProgress: 0,
          score: p.score,
          isDead: p.isDead,
        };
      });

      // Inject into snakes pool: strictly keep local player and online incoming snakes (completely purging offline bots)
      if (playerSnakeRef.current) {
        playerSnakeRef.current.isPlayer = true;
      }

      snakesRef.current = [
        playerSnakeRef.current!,
        ...incomingSnakes
      ];
    });

    // --- Server-Authoritative State Synchronization ---
    socket.on('room_state', (data: {
      snakes: any[];
      foods?: Food[];
      addedFoods?: Food[];
      removedFoods?: string[];
      powerUps: PowerUp[];
      bossSpawned: boolean;
      bossAlert: string | null;
      leaderboard: any[];
      activeRealPlayersCount?: number;
    }) => {
      // Synchronize foods
      if (data.foods) {
        foodsRef.current = data.foods;
      } else {
        if (!foodsRef.current) foodsRef.current = [];
        
        // Remove eaten foods
        if (data.removedFoods && data.removedFoods.length > 0) {
          const removedSet = new Set(data.removedFoods);
          foodsRef.current = foodsRef.current.filter((f) => !removedSet.has(f.id));
        }

        // Add newly spawned foods
        if (data.addedFoods && data.addedFoods.length > 0) {
          const existingIds = new Set(foodsRef.current.map((f) => f.id));
          data.addedFoods.forEach((f) => {
            if (!existingIds.has(f.id)) {
              foodsRef.current.push(f);
            }
          });
        }
      }

      // Synchronize powerups
      powerUpsRef.current = data.powerUps;

      // Synchronize boss status
      if (data.bossSpawned) {
        bossSpawnedRef.current = true;
      }
      if (data.bossAlert) {
        onToast(`⚠️ ${data.bossAlert}`, 'info');
      }

      // Extract local player reference & socket ID for reconciliation & leaderboard UI
      const localPlayer = playerSnakeRef.current;
      const myId = socket.id;

      // Throttle UI React state updates (Leaderboard & Player Counts) to max 2Hz (500ms) to eliminate flickering
      const now = Date.now();
      if (now - lastLeaderboardUpdateTimeRef.current > 500) {
        lastLeaderboardUpdateTimeRef.current = now;
        if (data.activeRealPlayersCount !== undefined) {
          setActiveRealPlayers((prev) => (prev !== data.activeRealPlayersCount ? data.activeRealPlayersCount : prev));
        }

        if (data.leaderboard) {
          setActiveLeaderboard(
            data.leaderboard.map((entry: any) => ({
              name: entry.name,
              carried: entry.carriedChips !== undefined ? entry.carriedChips : (entry.carried || 0),
              isPlayer: entry.id === myId || entry.id === localPlayer?.id || entry.id === 'player',
              isBot: !!entry.isBot
            }))
          );
        }
      }

      // Reconcile and synchronize snakes cleanly without duplication
      const updatedSnakes: Snake[] = [];

      data.snakes.forEach((serverSnake: any) => {
        const isSelf = serverSnake.id === myId || (localPlayer && serverSnake.id === localPlayer.id);

        if (isSelf && localPlayer) {
          // Reconcile local player properties from server
          localPlayer.carriedChips = Math.max(localPlayer.carriedChips, serverSnake.carriedChips);
          if (lastCarriedChipsRef.current !== localPlayer.carriedChips) {
            lastCarriedChipsRef.current = localPlayer.carriedChips;
            setCarriedChips(localPlayer.carriedChips);
          }
          
          localPlayer.score = serverSnake.score;
          localPlayer.size = serverSnake.size;
          
          if (lastSnakeLengthRef.current !== localPlayer.points.length) {
            lastSnakeLengthRef.current = localPlayer.points.length;
            setSnakeLength(localPlayer.points.length);
          }

          localPlayer.isExtracting = serverSnake.isExtracting;
          localPlayer.extractionProgress = serverSnake.extractionProgress;
          localPlayer.isPlayer = true;

          playerServerPointsRef.current = serverSnake.points.map((pt: any) => ({ ...pt }));

          if (!updatedSnakes.includes(localPlayer)) {
            updatedSnakes.push(localPlayer);
          }
        } else {
          if (localPlayer && (serverSnake.id === localPlayer.id || serverSnake.id === myId)) {
            return; // Skip duplicate self
          }

          let localSnake = snakesRef.current.find(s => s.id === serverSnake.id);
          
          if (localSnake) {
            localSnake.targetPoints = serverSnake.points.map((pt: any) => ({ ...pt }));
            localSnake.angle = serverSnake.angle;
            localSnake.speed = serverSnake.speed;
            localSnake.size = serverSnake.size;
            localSnake.carriedChips = serverSnake.carriedChips;
            localSnake.score = serverSnake.score;
            localSnake.isExtracting = serverSnake.isExtracting;
            localSnake.isDead = serverSnake.isDead;
            localSnake.chatMessage = serverSnake.chatMessage;
            localSnake.chatTimer = serverSnake.chatTimer ? serverSnake.chatTimer * 60 : undefined;
            localSnake.spawnProtectedTimer = serverSnake.spawnProtectedTimer;
          } else {
            localSnake = {
              id: serverSnake.id,
              name: serverSnake.name,
              points: serverSnake.points.map((pt: any) => ({ ...pt })),
              targetPoints: serverSnake.points.map((pt: any) => ({ ...pt })),
              angle: serverSnake.angle,
              targetAngle: serverSnake.angle,
              speed: serverSnake.speed,
              size: serverSnake.size,
              color: serverSnake.color,
              secondaryColor: serverSnake.secondaryColor,
              isBot: serverSnake.isBot,
              botType: serverSnake.botType,
              carriedChips: serverSnake.carriedChips,
              isExtracting: serverSnake.isExtracting,
              extractionProgress: serverSnake.extractionProgress,
              score: serverSnake.score,
              isDead: serverSnake.isDead,
              chatMessage: serverSnake.chatMessage,
              chatTimer: serverSnake.chatTimer ? serverSnake.chatTimer * 60 : undefined,
              spawnProtectedTimer: serverSnake.spawnProtectedTimer
            };
          }
          updatedSnakes.push(localSnake);
        }
      });

      // Ensure local player is always present in updatedSnakes
      if (localPlayer && !updatedSnakes.includes(localPlayer)) {
        updatedSnakes.unshift(localPlayer);
      }

      snakesRef.current = updatedSnakes;
    });

    socket.on('powerup_collected', (data: {
      playerId: string;
      powerUpId: string;
      type: 'shield' | 'magnet' | 'double' | 'freeze';
      color: string;
      x: number;
      y: number;
    }) => {
      // Create visual collection sparks
      createSparks(data.x, data.y, data.color, 15);
      
      const eater = snakesRef.current.find(s => s.id === data.playerId) || (data.playerId === socket.id ? playerSnakeRef.current : null);
      if (eater) {
        if (eater.id === socket.id || eater.id === 'player') {
          gameAudio.playPowerUp();
          onToast(`POWER-UP ACQUIRED: ${data.type.toUpperCase()}! ⚡`, 'success');

          if (data.type === 'shield') {
            shieldActiveRef.current = true;
            setShieldActive(true);
          } else if (data.type === 'magnet') {
            magnetTimerRef.current = 10000;
          } else if (data.type === 'double') {
            doubleTimerRef.current = 12000;
          } else if (data.type === 'freeze') {
            freezeTimerRef.current = 8000;
          }
        } else {
          eater.chatMessage = `⚡ PowerUp: ${data.type.toUpperCase()}!`;
          eater.chatTimer = 2000;
        }
      }

      // Remove powerup from client array
      powerUpsRef.current = powerUpsRef.current.filter(p => p.id !== data.powerUpId);
    });

    socket.on('kill_confirmed', (data: { victimName: string }) => {
      setKillsCount((prev) => prev + 1);
      setRealKillsCount((prev) => prev + 1);
      triggerPlayerKillAnnouncement(data.victimName);
      triggerShake(16);
      onToast(`You eliminated ${data.victimName}! Grab their dropped star chips!`, 'success');
      
      const p = playerSnakeRef.current;
      if (p && Math.random() < 0.5) {
        p.chatMessage = 'Get Ripped! 💥🏆';
        p.chatTimer = 2200;
      }
    });

    socket.on('player_left', (data: { id: string }) => {
      const leavingPlayer = snakesRef.current.find((s) => s.id === data.id);
      if (leavingPlayer) {
        onToast(`${leavingPlayer.name.replace('🤝 ', '')} extracted or exited.`, 'info');
      }
      snakesRef.current = snakesRef.current.filter((s) => s.id !== data.id);
    });

    socket.on('beacon_placed', (beacon: any) => {
      onToast(`Syndicate Co-op Beacon active! 📡`, 'info');
      // Spawn tactical particle indicator
      for (let i = 0; i < 15; i++) {
        particlesRef.current.push({
          x: beacon.x,
          y: beacon.y,
          vx: (Math.random() - 0.5) * 8,
          vy: (Math.random() - 0.5) * 8,
          color: '#818cf8',
          size: 4 + Math.random() * 4,
          life: 0,
          maxLife: 60 + Math.random() * 40
        });
      }
    });

    socket.on('chat_received', (data: { id: string; message: string }) => {
      const chatter = snakesRef.current.find((s) => s.id === data.id);
      if (chatter) {
        chatter.chatMessage = data.message;
        chatter.chatTimer = 180;
      }
    });

    // 1. Authoritative Death Notice from Server
    socket.on('player_died', (data: { victimId: string; killerId: string; killerName: string }) => {
      if (data.victimId === socket.id || data.victimId === 'player') {
        // Local player was killed authoritatively by the server
        if (!isGameOverRef.current) {
          if (playerSnakeRef.current) {
            triggerDisintegrate(playerSnakeRef.current, false);
            onToast(`ELIMINATED: You collided with ${data.killerName || 'another player'}! 💀`, 'error');
          }
        }
      } else {
        // A remote player was eliminated
        const victim = snakesRef.current.find(s => s.id === data.victimId);
        if (victim) {
          triggerDisintegrate(victim, false);
          // Only show notification if the victim was a real player (not a bot) and player is alive to prevent lobby/game-over spam!
          const localPlayer = playerSnakeRef.current;
          const isLocalPlayerAlive = localPlayer && !localPlayer.isDead && !isGameOverRef.current;
          if (!victim.isBot && isLocalPlayerAlive) {
            onToast(`${victim.name} was eliminated by ${data.killerName || 'someone'}. 💀`, 'info');
          }
        }
        snakesRef.current = snakesRef.current.filter(s => s.id !== data.victimId);
      }
    });

    // 2. Authoritative Extraction Approval from Server
    socket.on('player_extracted', (data: { id: string; userTag: string; retainedChips: number; xpReward: number }) => {
      if (data.id === socket.id || data.id === 'player') {
        handleSuccessfulExtraction();
      } else {
        const extractor = snakesRef.current.find(s => s.id === data.id);
        if (extractor) {
          triggerDisintegrate(extractor, true);
          // Only show notification if the extractor was a real player (not a bot) and player is alive to prevent lobby/game-over spam!
          const localPlayer = playerSnakeRef.current;
          const isLocalPlayerAlive = localPlayer && !localPlayer.isDead && !isGameOverRef.current;
          if (!extractor.isBot && isLocalPlayerAlive) {
            onToast(`${extractor.name} extracted safely with ${data.retainedChips} chips! 🛰️`, 'info');
          }
        }
        snakesRef.current = snakesRef.current.filter(s => s.id !== data.id);
      }
    });

    // 3. Overseer Actions (Kick/Ban Notices)
    socket.on('kick_notice', (data: { reason: string }) => {
      onToast(data.reason || 'You have been disconnected by a server administrator.', 'error');
      setTimeout(() => {
        onExitGame();
      }, 1500);
    });

    // 4. Global Broadcast Messages from Intercom Panel
    socket.on('broadcast_announcement', (data: { message: string }) => {
      onToast(`📢 SYSTEM INTERCOM: ${data.message}`, 'info');
    });

    return () => {
      socket.disconnect();
    };
  }, [isOnline, selectedArena.id]);

  const initGame = () => {
    setIsGameOver(false);
    setIsSuccess(false);
    setKillerInfo(null);
    setIsAddedRival(false);
    setIsAddedFriend(false);
    playerServerPointsRef.current = [];
    setKillsCount(0);
    setRealKillsCount(0);
    setFinalChipsBanked(0);
    setExtractProgress(0);
    setIsHoldingExtract(false);
    setHasWatchedAd(false);

    // Set initial mouse direction facing left (matching Math.PI) relative to viewport center
    const w = window.innerWidth || 1000;
    const h = window.innerHeight || 800;
    mousePosRef.current = { x: w / 2 - 200, y: h / 2 };

    // Reset powerups, boss, and ally states
    powerUpsRef.current = [];
    shieldActiveRef.current = false;
    setShieldActive(false);
    magnetTimerRef.current = 0;
    setMagnetTimeLeft(0);
    doubleTimerRef.current = 0;
    setDoubleTimeLeft(0);
    freezeTimerRef.current = 0;
    setFreezeTimeLeft(0);
    gameTimeElapsedRef.current = 0;
    bossSpawnedRef.current = false;
    setBossAlert(null);
    allyCommandRef.current = 'protect';
    setAllyCommand('protect');
    setHasAlly(false);

    // 1. Spawn Player in Center
    const player: Snake = {
      id: 'player',
      name: playerStats.name,
      points: generateInitialBody(WORLD_SIZE / 2, WORLD_SIZE / 2, Math.PI),
      angle: Math.PI,
      targetAngle: Math.PI,
      speed: 3,
      size: 8,
      color: playerStats.useCustomSkin && playerStats.customSkinColors && playerStats.customSkinColors.length > 0
        ? playerStats.customSkinColors[0]
        : cosmeticSkin.color,
      secondaryColor: playerStats.useCustomSkin && playerStats.customSkinColors && playerStats.customSkinColors.length > 1
        ? playerStats.customSkinColors[1]
        : (cosmeticSkin.secondaryColor || '#15803d'),
      trailColor: cosmeticTrail.color,
      isBot: false,
      carriedChips: isOnline ? selectedArena.buyIn : 0,
      isExtracting: false,
      extractionProgress: 0,
      score: INITIAL_BODY_LENGTH,
      isDead: false,
      isPlayer: true,
      spawnProtectedTimer: 4000,
    };
    playerSnakeRef.current = player;

    // 2. Spawn Bots inside circular bounds (Offline Mode Only)
    const bots: Snake[] = [];
    if (!isOnline) {
      for (let i = 0; i < selectedArena.botsCount; i++) {
        const spawnRadius = 3500;
        const spawnAngle = Math.random() * Math.PI * 2;
        const spawnDist = Math.sqrt(Math.random()) * spawnRadius;
        const startX = WORLD_SIZE / 2 + Math.cos(spawnAngle) * spawnDist;
        const startY = WORLD_SIZE / 2 + Math.sin(spawnAngle) * spawnDist;
        const botAngle = Math.random() * Math.PI * 2;
        const botSkin = ALL_COSMETICS[Math.floor(Math.random() * 5)]; // random from first 5 skins

        // Distribute bot AI styles
        const aiStyles: ('scavenger' | 'opportunist' | 'hunter' | 'extractor' | 'coward')[] = [
          'scavenger', 'opportunist', 'hunter', 'extractor', 'coward'
        ];
        const botType = aiStyles[i % aiStyles.length];

        bots.push({
          id: `bot-${i}`,
          name: `${BOT_NAMES[i % BOT_NAMES.length]} [AI]`,
          points: generateInitialBody(startX, startY, botAngle),
          angle: botAngle,
          targetAngle: botAngle,
          speed: 4.4 + Math.random() * 1.6,
          size: 7 + Math.random() * 1.5,
          color: botSkin.color,
          secondaryColor: botSkin.secondaryColor || '#475569',
          isBot: true,
          botType,
          carriedChips: 0,
          isExtracting: false,
          extractionProgress: 0,
          score: INITIAL_BODY_LENGTH,
          isDead: false,
          spawnProtectedTimer: 4000,
        });
      }

      if (spectateTarget) {
        // Spawn the spectated friend's snake as an AI/ally
        const spectateFriendSnake: Snake = {
          id: 'friend-spectate',
          name: `👁️ ${spectateTarget.name} [Spectating]`,
          points: generateInitialBody(WORLD_SIZE / 2, WORLD_SIZE / 2, Math.PI / 4),
          angle: Math.PI / 4,
          targetAngle: Math.PI / 4,
          speed: 2.5,
          size: 8,
          color: spectateTarget.color,
          secondaryColor: '#ffffff',
          isBot: true,
          botType: 'ally',
          carriedChips: 0,
          isExtracting: false,
          extractionProgress: 0,
          score: INITIAL_BODY_LENGTH + 12,
          isDead: false,
          chatMessage: `Watch me dominate! 👁️🐍`,
          chatTimer: 4000,
        };

        // Hide and freeze player's actual snake so they can watch seamlessly
        player.speed = 0;
        player.size = 0;
        player.points = generateInitialBody(-9999, -9999, 0); // far off screen
        player.isDead = false;

        bots.push(spectateFriendSnake);
      }
    }

    snakesRef.current = [player, ...bots];

    // Check for pre-match active match invite
    if (!isOnline) {
      const inviteStr = localStorage.getItem('venom_active_match_invite');
      if (inviteStr) {
        try {
          const invite = JSON.parse(inviteStr);
          localStorage.removeItem('venom_active_match_invite'); // consume
          
          if (!invite.arenaId || invite.arenaId === selectedArena.id) {
            // Spawn friend after a brief 1.5s delay for realistic "joining..." simulation
            setTimeout(() => {
              spawnFriend(invite.name, invite.skinColor);
            }, 1500);
          } else {
            onToast(`Co-op invite with ${invite.name} cleared: you selected a different stakes tier.`, 'info');
          }
        } catch (err) {
          console.error('Failed to parse pre-match invite:', err);
        }
      }
    }

    // 3. Populate Orbs
    if (!isOnline) {
      const foodList: Food[] = [];
      for (let i = 0; i < 120; i++) {
        foodList.push(spawnRandomFood(false));
      }
      foodsRef.current = foodList;
    } else {
      foodsRef.current = [];
    }
    particlesRef.current = [];
    particlesRef.current = [];

    // Start synthesized ambient sci-fi soundtrack!
    gameAudio.setDangerLevel(1);
    gameAudio.startMusic();
  };

  const spawnFriend = (friendName: string, friendColor: string) => {
    const player = playerSnakeRef.current;
    if (!player || player.isDead) return;

    const offsetAngle = Math.random() * Math.PI * 2;
    const startX = Math.max(100, Math.min(WORLD_SIZE - 100, player.points[0].x + Math.cos(offsetAngle) * 150));
    const startY = Math.max(100, Math.min(WORLD_SIZE - 100, player.points[0].y + Math.sin(offsetAngle) * 150));
    const friendAngle = Math.random() * Math.PI * 2;

    const friendSnake: Snake = {
      id: `friend-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: `🤝 ${friendName} [Ally]`,
      points: generateInitialBody(startX, startY, friendAngle),
      angle: friendAngle,
      targetAngle: friendAngle,
      speed: 2.5,
      size: 8,
      color: friendColor,
      secondaryColor: '#ffffff',
      isBot: true,
      botType: 'ally',
      carriedChips: 0,
      isExtracting: false,
      extractionProgress: 0,
      score: INITIAL_BODY_LENGTH,
      isDead: false,
      chatMessage: `I'm here! Let's get these chips! 🤝🐍`,
      chatTimer: 3000,
    };

    snakesRef.current = [...snakesRef.current, friendSnake];
    onToast(`${friendName} joined the active Arena Shard! 🤝`, 'success');
  };

  const generateInitialBody = (headX: number, headY: number, angle: number): SnakePoint[] => {
    const points: SnakePoint[] = [];
    const spacing = 6.2; // Matched to 5.2 + size * 0.13 (~6.2 for size 8) to eliminate start step collapse
    for (let i = 0; i < INITIAL_BODY_LENGTH; i++) {
      points.push({
        x: headX - Math.cos(angle) * i * spacing,
        y: headY - Math.sin(angle) * i * spacing,
      });
    }
    return points;
  };

  const spawnRandomFood = (isStarChip: boolean, customX?: number, customY?: number, value = 1): Food => {
    return {
      id: Math.random().toString(),
      x: (() => {
        if (customX !== undefined) return customX;
        const radius = getMapRadius(gameTimeElapsedRef.current) - 100;
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.sqrt(Math.random()) * radius;
        return WORLD_SIZE / 2 + Math.cos(angle) * dist;
      })(),
      y: (() => {
        if (customY !== undefined) return customY;
        const radius = getMapRadius(gameTimeElapsedRef.current) - 100;
        const angle = Math.random() * Math.PI * 2;
        const dist = Math.sqrt(Math.random()) * radius;
        return WORLD_SIZE / 2 + Math.sin(angle) * dist;
      })(),
      size: isStarChip ? 8 : 4 + Math.random() * 4,
      value: isStarChip ? value : 1,
      isStarChip,
      color: isStarChip ? '#fbbf24' : `hsl(${Math.random() * 360}, 85%, 65%)`,
    };
  };

  const triggerPlayerChat = (msg: string) => {
    const player = playerSnakeRef.current;
    if (player && !player.isDead) {
      player.chatMessage = msg;
      player.chatTimer = 2500;
      onToast(`Emote: "${msg}"`, 'success');

      if (isOnlineRef.current && socketRef.current) {
        socketRef.current.emit('send_chat', { message: msg });
      }
    }
  };

  const triggerPlayerKillAnnouncement = (botName: string) => {
    const now = Date.now();
    const lastKillTime = lastKillTimeRef.current;
    lastKillTimeRef.current = now;

    if (now - lastKillTime < 5000) {
      killComboRef.current += 1;
    } else {
      killComboRef.current = 1;
    }

    let text = "RIVAL ELIMINATED";
    let sub = `You completely disintegrated ${botName}!`;
    let color = "from-cyan-500 via-blue-500 to-indigo-500 shadow-blue-500/25";

    if (killComboRef.current === 2) {
      text = "🔥 DOUBLE KILL! 🔥";
      sub = "Twice the dominance, twice the shards!";
      color = "from-fuchsia-500 via-purple-600 to-violet-600 shadow-purple-500/35";
    } else if (killComboRef.current === 3) {
      text = "⚡ TRIPLE KILL! ⚡";
      sub = "An absolute predator in this sector!";
      color = "from-amber-400 via-orange-500 to-red-500 shadow-orange-500/35";
    } else if (killComboRef.current >= 4) {
      text = "💀 UNSTOPPABLE STREAK! 💀";
      sub = `Disintegrated ${killComboRef.current} rivals in rapid succession!`;
      color = "from-rose-500 via-red-600 to-amber-500 shadow-red-500/40";
    }

    setCombatBanner({ text, sub, color, id: now });

    // Auto clear combat banner after 3.2 seconds
    setTimeout(() => {
      setCombatBanner((prev) => (prev && prev.id === now ? null : prev));
    }, 3200);
  };

  const triggerAllyCommand = (command: 'protect' | 'farm' | 'hunt') => {
    const ally = snakesRef.current.find(s => !s.isDead && s.botType === 'ally');
    if (!ally) {
      onToast("No active Ally in the shard! Invite a squad member. 🤝", "info");
      return;
    }
    
    allyCommandRef.current = command;
    setAllyCommand(command);
    
    const messages = {
      protect: [
        "Understood, chief! Defending your flanks! 🛡️🐍",
        "Forming orbit shield! Watch out, enemies! 🛡️",
        "Got your six! 🚀"
      ],
      farm: [
        "On it! Gathering star crystals! 💎",
        "Harvesting power nodes! 🔋",
        "Farming chips for the syndicate! 💎"
      ],
      hunt: [
        "Target lock-on! Engaging primary targets! 🎯🔥",
        "Hunting the leaderboard leaders! 💀",
        "Going aggressive! ⚔️"
      ]
    };
    
    const possibleMsgs = messages[command];
    ally.chatMessage = possibleMsgs[Math.floor(Math.random() * possibleMsgs.length)];
    ally.chatTimer = 3000;
    
    gameAudio.playStar();
    onToast(`Ally Command updated to: ${command.toUpperCase()}! 📡`, 'success');
  };

  // Keyboard and Mouse handlers
  const handleKeyDown = (e: KeyboardEvent) => {
    const key = e.key.toLowerCase();
    keysPressedRef.current[key] = true;

    // Switch to keyboard control mode on steering keypresses
    if (['w', 'a', 's', 'd', 'arrowup', 'arrowdown', 'arrowleft', 'arrowright'].includes(key)) {
      controlModeRef.current = 'keyboard';
    }

    // Check extraction hold starting via space or 'e' key
    if (e.key.toLowerCase() === 'e') {
      const player = playerSnakeRef.current;
      if (isOnlineRef.current && player && player.carriedChips < selectedArenaRef.current.minExtract) {
        const now = Date.now();
        if (now - lastWarningToastTimeRef.current > 3000) {
          onToast(`You need at least ${selectedArenaRef.current.minExtract} chips to extract! Keep eating star chips! 💎`, 'error');
          lastWarningToastTimeRef.current = now;
        }
        return;
      }
      setIsHoldingExtract(true);
      isHoldingExtractRef.current = true;
    }

    // Ally controls (Keys z, x, c)
    if (e.key.toLowerCase() === 'z') {
      triggerPlayerChat("Guard my tail! 🛡️");
      triggerAllyCommand('protect');
    }
    if (e.key.toLowerCase() === 'x') {
      triggerPlayerChat("Mine those shards! 💎");
      triggerAllyCommand('farm');
    }
    if (e.key.toLowerCase() === 'c') {
      triggerPlayerChat("Engage hostilities! 🎯");
      triggerAllyCommand('hunt');
    }

    // Place team beacon (Key b)
    if (e.key.toLowerCase() === 'b') {
      const player = playerSnakeRef.current;
      if (player && !player.isDead) {
        const head = player.points[0];
        onToast(`Co-op Beacon active! 📡`, 'success');
        
        // Spawn local beacon particles
        for (let i = 0; i < 15; i++) {
          particlesRef.current.push({
            x: head.x,
            y: head.y,
            vx: (Math.random() - 0.5) * 8,
            vy: (Math.random() - 0.5) * 8,
            color: '#818cf8',
            size: 4 + Math.random() * 4,
            life: 0,
            maxLife: 60 + Math.random() * 40
          });
        }

        if (isOnlineRef.current && socketRef.current) {
          socketRef.current.emit('place_beacon', {
            x: head.x,
            y: head.y,
            code: 'ALLY-RENDEZVOUS',
            type: 'coop'
          });
        }
      }
    }

    // Quick emotes
    if (e.key === '1') triggerPlayerChat('GG! 🏆');
    if (e.key === '2') triggerPlayerChat('Target Spotted! 🎯');
    if (e.key === '3') triggerPlayerChat('Help / Fleeing! 🏃💨');
    if (e.key === '4') triggerPlayerChat('Get Ripped! 💪🐍');
    if (e.key === '5') triggerPlayerChat('Extracting soon! ⚡');
  };

  const handleKeyUp = (e: KeyboardEvent) => {
    keysPressedRef.current[e.key.toLowerCase()] = false;

    if (e.key.toLowerCase() === 'e') {
      setIsHoldingExtract(false);
      isHoldingExtractRef.current = false;
      extractionStartAngleRef.current = null;
      setExtractProgress(0);
      if (playerSnakeRef.current) {
        playerSnakeRef.current.isExtracting = false;
        playerSnakeRef.current.extractionProgress = 0;
      }
    }
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (!canvasRef.current) return;
    const rect = canvasRef.current.getBoundingClientRect();
    mousePosRef.current = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    };
    controlModeRef.current = 'mouse';
  };

  // MAIN GAME LOOP (60fps)
  const gameLoop = (timestamp: number) => {
    if (!isMountedRef.current) return;

    updateGame();
    drawGame();

    // Broadcast player inputs to the server
    if (isOnlineRef.current && socketRef.current && playerSnakeRef.current) {
      const p = playerSnakeRef.current;
      if (!p.isDead) {
        const wantsBoost = !!(keysPressedRef.current[' '] || keysPressedRef.current['spacebar'] || keysPressedRef.current['space']);
        const isExtracting = isHoldingExtractRef.current;
        const targetAngle = p.targetAngle;
        const now = Date.now();

        const last = lastSentInputRef.current;
        const angleDiff = Math.abs(targetAngle - last.targetAngle);
        // Only send input if angle changed slightly, boost/extraction state changed, or 100ms heartbeat has passed
        const hasChanged = angleDiff > 0.015 || wantsBoost !== last.wantsBoost || isExtracting !== last.isExtracting;
        const reachedTimeout = now - last.time > 100;

        if (hasChanged || reachedTimeout) {
          socketRef.current.emit('client_input', {
            targetAngle,
            wantsBoost,
            isExtracting,
            points: p.points.map(pt => ({ x: Math.round(pt.x * 10) / 10, y: Math.round(pt.y * 10) / 10 }))
          });
          lastSentInputRef.current = { targetAngle, wantsBoost, isExtracting, time: now };
        }
      }
    }

    if (isMountedRef.current) {
      animFrameRef.current = requestAnimationFrame(gameLoop);
    }
  };

  // UPDATE ENGINE
  const updateGame = () => {
    if (isGameOverRef.current || isSuccessRef.current) return;

    const player = playerSnakeRef.current;
    if (!player || player.isDead) return;

    // --- TICK POWERUPS AND TIMERS (performance safe: state is set only on whole second change) ---
    gameTimeElapsedRef.current += 16.67;

    // Tick down spawn protected timers
    snakesRef.current.forEach((snake) => {
      if (snake.spawnProtectedTimer && snake.spawnProtectedTimer > 0) {
        snake.spawnProtectedTimer -= 16.67;
        if (snake.spawnProtectedTimer < 0) {
          snake.spawnProtectedTimer = 0;
        }
      }
    });

    if (magnetTimerRef.current > 0) {
      magnetTimerRef.current -= 16.67;
      const secs = Math.max(0, Math.ceil(magnetTimerRef.current / 1000));
      setMagnetTimeLeft((prev) => (prev !== secs ? secs : prev));
    } else {
      setMagnetTimeLeft((prev) => (prev !== 0 ? 0 : prev));
    }

    if (doubleTimerRef.current > 0) {
      doubleTimerRef.current -= 16.67;
      const secs = Math.max(0, Math.ceil(doubleTimerRef.current / 1000));
      setDoubleTimeLeft((prev) => (prev !== secs ? secs : prev));
    } else {
      setDoubleTimeLeft((prev) => (prev !== 0 ? 0 : prev));
    }

    if (freezeTimerRef.current > 0) {
      freezeTimerRef.current -= 16.67;
      const secs = Math.max(0, Math.ceil(freezeTimerRef.current / 1000));
      setFreezeTimeLeft((prev) => (prev !== secs ? secs : prev));
    } else {
      setFreezeTimeLeft((prev) => (prev !== 0 ? 0 : prev));
    }

    // Spawn random power-up organically inside circular bounds (approx 0.15% chance per frame if less than 4 exist) (offline only) - DISABLED as requested
    if (false) {
      const types: ('shield' | 'magnet' | 'double')[] = ['shield', 'magnet', 'double'];
      const chosenType = types[Math.floor(Math.random() * types.length)];
      const colors = {
        shield: '#06b6d4',
        magnet: '#a855f7',
        double: '#fbbf24'
      };
      const radius = getMapRadius(gameTimeElapsedRef.current) - 200;
      const angle = Math.random() * Math.PI * 2;
      const dist = Math.sqrt(Math.random()) * radius;
      powerUpsRef.current.push({
        id: `powerup-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        x: WORLD_SIZE / 2 + Math.cos(angle) * dist,
        y: WORLD_SIZE / 2 + Math.sin(angle) * dist,
        type: chosenType as any,
        color: (colors as any)[chosenType],
        pulse: 0
      });
    }

    // Tick power-up visual pulse
    powerUpsRef.current.forEach(p => {
      p.pulse = (p.pulse + 0.05) % (Math.PI * 2);
    });

    // Player collects powerups (offline only)
    if (!isOnlineRef.current) {
      const pHead = player.points[0];
      powerUpsRef.current = powerUpsRef.current.filter(p => {
        const dist = Math.hypot(p.x - pHead.x, p.y - pHead.y);
        if (dist < player.size + 15) {
          gameAudio.playPowerUp();
          createSparks(p.x, p.y, p.color, 15);
          onToast(`POWER-UP ACQUIRED: ${p.type.toUpperCase()}! ⚡`, 'success');

          if (p.type === 'shield') {
            shieldActiveRef.current = true;
            setShieldActive(true);
          } else if (p.type === 'magnet') {
            magnetTimerRef.current = 10000;
            setMagnetTimeLeft(10);
          } else if (p.type === 'double') {
            doubleTimerRef.current = 12000;
            setDoubleTimeLeft(12);
          } else if (p.type === 'freeze') {
            freezeTimerRef.current = 8000;
            setFreezeTimeLeft(8);
          }
          return false;
        }
        return true;
      });
    }

    // Check boss spawn condition (at 40 seconds) (offline only)
    if (!isOnlineRef.current && gameTimeElapsedRef.current > 40000 && !bossSpawnedRef.current) {
      bossSpawnedRef.current = true;
      setBossAlert("ALERT: Elite Hunter 'THE CORRUPTOR' has breached the shard! 💀👑");
      setTimeout(() => setBossAlert(null), 5000);

      const pHead = player.points[0];
      let bossX = pHead.x + (Math.random() < 0.5 ? -500 : 500);
      let bossY = pHead.y + (Math.random() < 0.5 ? -500 : 500);
      bossX = Math.max(100, Math.min(WORLD_SIZE - 100, bossX));
      bossY = Math.max(100, Math.min(WORLD_SIZE - 100, bossY));

      const boss: Snake = {
        id: 'boss-corruptor',
        name: '💀 THE CORRUPTOR [BOSS]',
        points: generateInitialBody(bossX, bossY, Math.random() * Math.PI * 2),
        angle: Math.random() * Math.PI * 2,
        targetAngle: Math.random() * Math.PI * 2,
        speed: 3.3,
        size: 26,
        color: '#f43f5e',
        secondaryColor: '#ec4899',
        trailColor: '#db2777',
        isBot: true,
        botType: 'hunter',
        carriedChips: 0,
        isExtracting: false,
        extractionProgress: 0,
        score: 30,
        isDead: false,
        chatMessage: "None shall extract alive! 💀🐍",
        chatTimer: 4000,
      };

      for (let g = 0; g < 15; g++) {
        const tail = boss.points[boss.points.length - 1];
        boss.points.push({ x: tail.x, y: tail.y });
      }
      boss.score = boss.points.length;

      snakesRef.current.push(boss);
      onToast("WARNING: Syndicate Elite Boss has entered the arena! Defeat them for a massive bounty! ⚔️", "error");
    }

    const activeAlly = snakesRef.current.some(s => !s.isDead && s.botType === 'ally');
    setHasAlly((prev) => (prev !== activeAlly ? activeAlly : prev));

    // --- 1. RESOLVE PLAYER DIRECTION AND STEERING ---
    let inputAngle: number | null = null;
    let hasKeyboardInput = false;

    // Keyboard steer check (WASD / Arrows)
    let moveX = 0;
    let moveY = 0;
    if (keysPressedRef.current['w'] || keysPressedRef.current['arrowup']) moveY -= 1;
    if (keysPressedRef.current['s'] || keysPressedRef.current['arrowdown']) moveY += 1;
    if (keysPressedRef.current['a'] || keysPressedRef.current['arrowleft']) moveX -= 1;
    if (keysPressedRef.current['d'] || keysPressedRef.current['arrowright']) moveX += 1;

    if (moveX !== 0 || moveY !== 0) {
      inputAngle = Math.atan2(moveY, moveX);
      hasKeyboardInput = true;
      controlModeRef.current = 'keyboard';
    }

    // If not actively steering with keyboard, check mouse steering if in mouse control mode
    if (!hasKeyboardInput && controlModeRef.current === 'mouse' && canvasRef.current) {
      const centerX = canvasRef.current.width / 2;
      const centerY = canvasRef.current.height / 2;
      const dx = mousePosRef.current.x - centerX;
      const dy = mousePosRef.current.y - centerY;
      const distFromCenter = Math.hypot(dx, dy);
      
      // Responsive steering anywhere on screen (deadzone minimal 5px)
      if (distFromCenter > 5) {
        inputAngle = Math.atan2(dy, dx);
      }
    }

    if (player.isExtracting) {
      // Only cancel extraction if user explicitly steers using keyboard WASD/Arrows
      if (hasKeyboardInput) {
        setIsHoldingExtract(false);
        isHoldingExtractRef.current = false;
        extractionStartAngleRef.current = null;
        extractionStartMousePosRef.current = null;
        setExtractProgress(0);
        player.isExtracting = false;
        player.extractionProgress = 0;
        onToast("Extraction canceled by keyboard movement! 🛑", "info");
      }
    } else {
      // Normal steering
      extractionStartAngleRef.current = null;
      extractionStartMousePosRef.current = null;
      if (inputAngle !== null) {
        player.targetAngle = inputAngle;
      }
    }

    // Smooth rotation lerp - size-dependent turn speed (larger snakes turn slower and wider, exactly like Slither.io!)
    let angleDiff = player.targetAngle - player.angle;
    while (angleDiff < -Math.PI) angleDiff += Math.PI * 2;
    while (angleDiff > Math.PI) angleDiff -= Math.PI * 2;
    const baseTurnSpeed = 0.15;
    const turnFactor = Math.max(0.045, baseTurnSpeed - (player.score * 0.0006));
    player.angle += angleDiff * turnFactor;

    // Boost speed validation
    const wantsBoost = keysPressedRef.current[' '] && player.points.length > 8 && !player.isExtracting;
    
    // Speed resolution: Glide forward during extraction, otherwise check boost (Doubled speed of snake and boost!)
    if (player.isExtracting) {
      player.speed = 3.2; // Graceful forward glide while extracting
    } else {
      player.speed = wantsBoost ? 11.6 : 6.4;
    }

    if (wantsBoost && Math.random() < 0.08) {
      gameAudio.playBoost();
    }

    // Boost penalty: lose size and drop food trails continuously every 8 frames
    if (wantsBoost) {
      if ((player as any).boostFrameCount === undefined) (player as any).boostFrameCount = 0;
      (player as any).boostFrameCount++;
      if ((player as any).boostFrameCount % 40 === 0) {
        const tail = player.points.pop();
        if (tail) {
          const droppedFood = spawnRandomFood(false, tail.x, tail.y, 1);
          if (isOnlineRef.current && socketRef.current) {
            socketRef.current.emit('spawn_chips', {
              chips: [{
                x: droppedFood.x,
                y: droppedFood.y,
                size: droppedFood.size,
                value: droppedFood.value,
                isStarChip: droppedFood.isStarChip,
                color: droppedFood.color
              }]
            });
          } else {
            foodsRef.current.push(droppedFood);
          }
          player.score = player.points.length;
          setSnakeLength(player.score);
        }
      }
    }

    // --- 2. EXTRACTION LOGIC ---
    if (isHoldingExtractRef.current && !player.isDead) {
      player.isExtracting = true;
      player.extractionProgress += 16.67; // Add delta time (~60fps)

      // Play tick sound every 500ms
      if (Math.floor(player.extractionProgress) % 500 < 17) {
        gameAudio.playExtractTick();
      }

      const percent = Math.min(100, Math.floor((player.extractionProgress / 3000) * 100));
      if (lastExtractProgressRef.current !== percent) {
        lastExtractProgressRef.current = percent;
        setExtractProgress(percent);
      }

      if (player.extractionProgress >= 3000) {
        // Safe extraction successful!
        handleSuccessfulExtraction();
        return;
      }
    } else {
      player.isExtracting = false;
      player.extractionProgress = 0;
    }

    // --- 3. RUN BOTS INTELLIGENT AI BEHAVIOR ---
    snakesRef.current.forEach((snake) => {
      if (isOnlineRef.current) return;
      if (!snake.isBot || snake.isDead) return;

      // Bot targets food or nearby player
      let targetX = snake.points[0].x;
      let targetY = snake.points[0].y;
      let targetAngle = snake.angle;

      if (snake.botType === 'ally') {
        const playerHead = player.points[0];
        const distToPlayer = Math.hypot(playerHead.x - snake.points[0].x, playerHead.y - snake.points[0].y);
        const cmd = allyCommandRef.current;

        if (spectateTarget) {
          // PRO PLAYER SPECTATE AI: Move dynamically to hunt or harvest!
          const closestFood = findClosestFood(snake, 500);
          const enemyBots = snakesRef.current.filter(s => !s.isDead && s.id !== 'player' && s.id !== 'friend-spectate');
          
          let closestEnemy: Snake | null = null;
          let minEnemyDist = 300;
          enemyBots.forEach(eb => {
            const d = Math.hypot(eb.points[0].x - snake.points[0].x, eb.points[0].y - snake.points[0].y);
            if (d < minEnemyDist) {
              minEnemyDist = d;
              closestEnemy = eb;
            }
          });

          if (closestEnemy) {
            // Cut off or trail enemy head
            const enemyHead = (closestEnemy as Snake).points[0];
            targetAngle = Math.atan2(enemyHead.y - snake.points[0].y, enemyHead.x - snake.points[0].x) + 0.2;
            snake.speed = 10.0; // Doubled!
          } else if (closestFood) {
            targetAngle = Math.atan2(closestFood.y - snake.points[0].y, closestFood.x - snake.points[0].x);
            snake.speed = 7.2; // Doubled!
          } else {
            targetAngle = snake.angle + (Math.random() - 0.5) * 0.2;
            snake.speed = 6.0; // Doubled!
          }
        } else if (distToPlayer > 450) {
          // Tether fallback: if too far, regardless of command, catch up!
          targetAngle = Math.atan2(playerHead.y - snake.points[0].y, playerHead.x - snake.points[0].x);
          snake.speed = 10.4; // Doubled!
        } else if (cmd === 'farm') {
          // Farm mode: search 600px radius for food
          const closestFood = findClosestFood(snake, 600);
          if (closestFood) {
            targetAngle = Math.atan2(closestFood.y - snake.points[0].y, closestFood.x - snake.points[0].x);
            snake.speed = 8.8; // Doubled!
          } else {
            targetAngle = Math.atan2(playerHead.y - snake.points[0].y, playerHead.x - snake.points[0].x) + (Math.random() - 0.5);
            snake.speed = 6.8; // Doubled!
          }
        } else if (cmd === 'hunt') {
          // Hunt mode: find largest enemy bot
          const enemyBots = snakesRef.current.filter(s => !s.isDead && s.id !== 'player' && !s.id.startsWith('friend'));
          let bestTarget: Snake | null = null;
          let maxChips = -1;

          enemyBots.forEach(eb => {
            if (eb.carriedChips > maxChips) {
              maxChips = eb.carriedChips;
              bestTarget = eb;
            }
          });

          if (bestTarget) {
            const btHead = (bestTarget as Snake).points[0];
            const btLeadX = btHead.x + Math.cos((bestTarget as Snake).angle) * 30;
            const btLeadY = btHead.y + Math.sin((bestTarget as Snake).angle) * 30;
            targetAngle = Math.atan2(btLeadY - snake.points[0].y, btLeadX - snake.points[0].x);
            snake.speed = 10.4; // Doubled!
          } else {
            targetAngle = Math.atan2(playerHead.y - snake.points[0].y, playerHead.x - snake.points[0].x) + (Math.random() - 0.5);
            snake.speed = 6.8; // Doubled!
          }
        } else {
          // Protect mode (Default): guard player
          const enemyBots = snakesRef.current.filter(s => !s.isDead && s.id !== 'player' && !s.id.startsWith('friend'));
          let closestThreat: Snake | null = null;
          let minThreatDist = 250;

          enemyBots.forEach(eb => {
            const ebHead = eb.points[0];
            const distToPl = Math.hypot(ebHead.x - playerHead.x, ebHead.y - playerHead.y);
            if (distToPl < minThreatDist) {
              minThreatDist = distToPl;
              closestThreat = eb;
            }
          });

          if (closestThreat) {
            const ctHead = (closestThreat as Snake).points[0];
            targetAngle = Math.atan2(ctHead.y - snake.points[0].y, ctHead.x - snake.points[0].x);
            snake.speed = 10.0; // Doubled!
            if (Math.random() < 0.05) {
              snake.chatMessage = "Get away from the boss! 🛡️⚡";
              snake.chatTimer = 1500;
            }
          } else {
            if (distToPlayer > 120) {
              targetAngle = Math.atan2(playerHead.y - snake.points[0].y, playerHead.x - snake.points[0].x);
              snake.speed = 7.6; // Doubled!
            } else {
              const baseAngle = Math.atan2(snake.points[0].y - playerHead.y, snake.points[0].x - playerHead.x);
              targetAngle = baseAngle + Math.PI / 2 + 0.15;
              snake.speed = 6.0; // Doubled!
            }
          }
        }
      } else if (snake.botType === 'coward') {
        // Cowards run from nearby heads and eat perimeter food
        const playerHead = player.points[0];
        const distToPlayer = Math.hypot(playerHead.x - snake.points[0].x, playerHead.y - snake.points[0].y);
        if (distToPlayer < 200) {
          // Steer directly away from player head
          targetAngle = Math.atan2(snake.points[0].y - playerHead.y, snake.points[0].x - playerHead.x);
        } else {
          // Wander to small food
          const closestFood = findClosestFood(snake, 150);
          if (closestFood) {
            targetAngle = Math.atan2(closestFood.y - snake.points[0].y, closestFood.x - snake.points[0].x);
          }
        }
      } else if (snake.botType === 'hunter') {
        // Hunter targets player body or nearest bot body to try and cut them off
        const playerHead = player.points[0];
        const distToPlayer = Math.hypot(playerHead.x - snake.points[0].x, playerHead.y - snake.points[0].y);
        if (distToPlayer < 250) {
          // Target slightly ahead of player head to trap them
          const leadX = playerHead.x + Math.cos(player.angle) * 45;
          const leadY = playerHead.y + Math.sin(player.angle) * 45;
          targetAngle = Math.atan2(leadY - snake.points[0].y, leadX - snake.points[0].x);
          // Hunter boost
          if (snake.points.length > 10 && Math.random() < 0.1) {
            snake.speed = 12.0; // Doubled!
            if (Math.random() < 0.2) snake.points.pop();
          } else {
            snake.speed = 6.8; // Doubled!
          }
        } else {
          // Seek star chips or rich food
          const closestFood = findClosestFood(snake, 300);
          if (closestFood) {
            targetAngle = Math.atan2(closestFood.y - snake.points[0].y, closestFood.x - snake.points[0].x);
          }
        }
      } else if (snake.botType === 'extractor' && snake.carriedChips > selectedArena.minExtract) {
        // Once an extractor bot accumulates target chips, it steers to outer wall and halts to "mock extract"
        const margin = 100;
        const targetWallX = snake.points[0].x < WORLD_SIZE / 2 ? margin : WORLD_SIZE - margin;
        const targetWallY = snake.points[0].y < WORLD_SIZE / 2 ? margin : WORLD_SIZE - margin;
        const distToWall = Math.hypot(targetWallX - snake.points[0].x, targetWallY - snake.points[0].y);

        if (distToWall < 80) {
          // Mocking extraction
          snake.speed = 0;
          snake.isExtracting = true;
          snake.extractionProgress += 16.67;
          if (snake.extractionProgress >= 3000) {
            // Disappear quietly as "extracted"
            triggerDisintegrate(snake, true);
          }
        } else {
          targetAngle = Math.atan2(targetWallY - snake.points[0].y, targetWallX - snake.points[0].x);
          snake.speed = 7.6; // Doubled!
        }
      } else {
        // Scavengers and Opportunists look for nearest star chips or default food
        const closestFood = findClosestFood(snake, 400);
        if (closestFood) {
          targetAngle = Math.atan2(closestFood.y - snake.points[0].y, closestFood.x - snake.points[0].x);
        } else {
          // Wander randomly
          if (Math.random() < 0.02) {
            targetAngle = snake.angle + (Math.random() - 0.5) * 2;
          }
        }
        snake.speed = 6.4; // Doubled!
      }

      // Avoid circular borders dynamically
      const head = snake.points[0];
      const distFromCenter = Math.hypot(head.x - WORLD_SIZE / 2, head.y - WORLD_SIZE / 2);
      const currentRadius = getMapRadius(gameTimeElapsedRef.current);
      if (distFromCenter > currentRadius - 250) {
        targetAngle = Math.atan2(WORLD_SIZE / 2 - head.y, WORLD_SIZE / 2 - head.x);
      }

      // --- Smart Body Collision Avoidance for Bots (Slither.io feeling) ---
      let avoidAngleX = 0;
      let avoidAngleY = 0;
      let nearSegmentsCount = 0;

      const activeSnakesForAvoidance = snakesRef.current.filter(s => !s.isDead);
      activeSnakesForAvoidance.forEach((other) => {
        if (other.id === snake.id) return;
        
        other.points.forEach((seg, sIdx) => {
          // Optimize: Check only every 4th segment
          if (sIdx % 4 !== 0) return;
          
          const dx = seg.x - head.x;
          const dy = seg.y - head.y;
          const dist = Math.hypot(dx, dy);

          // Vision range is increased to 180px for doubled speeds
          if (dist < 180) {
            const angleToSeg = Math.atan2(dy, dx);
            let angleDiffToSeg = angleToSeg - snake.angle;
            while (angleDiffToSeg < -Math.PI) angleDiffToSeg += Math.PI * 2;
            while (angleDiffToSeg > Math.PI) angleDiffToSeg -= Math.PI * 2;

            if (Math.abs(angleDiffToSeg) < 1.3) { // Front 75 degree vision cone
              // Accumulate steering vector pointing away from segment (weighted inversely by distance)
              avoidAngleX -= dx / (dist * dist);
              avoidAngleY -= dy / (dist * dist);
              nearSegmentsCount++;
            }
          }
        });
      });

      if (nearSegmentsCount > 0) {
        const avoidMagnitude = Math.hypot(avoidAngleX, avoidAngleY);
        if (avoidMagnitude > 0.0001) {
          targetAngle = Math.atan2(avoidAngleY, avoidAngleX);
        } else {
          // If forces canceled out, steer 90 degrees to side to break out cleanly
          targetAngle = snake.angle + Math.PI / 2;
        }
        if (Math.random() < 0.12 && snake.points.length > 15) {
          snake.speed = 7.8; // Tactical escape boost
        } else {
          snake.speed = 4.6;
        }
      }

      // Rotate towards target with responsive steering (slower for larger bots)
      let botDiff = targetAngle - snake.angle;
      while (botDiff < -Math.PI) botDiff += Math.PI * 2;
      while (botDiff > Math.PI) botDiff -= Math.PI * 2;
      const baseBotTurnSpeed = Math.max(0.05, 0.15 - (snake.score * 0.0006));
      // Triple turn rate responsiveness when actively avoiding obstacles to guarantee safety
      const botTurnSpeed = nearSegmentsCount > 0 ? baseBotTurnSpeed * 3.5 : baseBotTurnSpeed;
      snake.angle += botDiff * botTurnSpeed;
    });

    // --- 4. ADVANCE POSITION OF ALL ACTIVE SNAKES ---
    snakesRef.current.forEach((snake) => {
      if (snake.isDead) return;
      if (!isOnlineRef.current && snake.speed === 0) return;

      // In online mode, remote snakes (and server bots) advance head predicted at 60fps and soft-lerped towards server target points,
      // while body segments naturally follow using Slither.io trailing physics to prevent flickering or segment bunching.
      if (isOnlineRef.current && !snake.isPlayer) {
        if (snake.targetPoints && snake.targetPoints.length > 0) {
          const currHead = snake.points[0];
          const targHead = snake.targetPoints[0];

          if (currHead && targHead) {
            const headDist = Math.hypot(targHead.x - currHead.x, targHead.y - currHead.y);
            if (headDist > 250) {
              snake.points = snake.targetPoints.map((pt) => ({ ...pt }));
            } else {
              // Smooth rotation towards server target angle
              if (snake.targetAngle !== undefined) {
                let diffAngle = snake.targetAngle - snake.angle;
                while (diffAngle < -Math.PI) diffAngle += Math.PI * 2;
                while (diffAngle > Math.PI) diffAngle -= Math.PI * 2;
                snake.angle += diffAngle * 0.2;
              }

              // Advance head smoothly along predicted trajectory and soft lerp towards server target head
              const spd = snake.speed || 3.5;
              const predX = currHead.x + Math.cos(snake.angle) * spd;
              const predY = currHead.y + Math.sin(snake.angle) * spd;

              // Soft lerp (0.18) guarantees butter-smooth motion without 20Hz discrete ticks
              currHead.x = predX + (targHead.x - predX) * 0.18;
              currHead.y = predY + (targHead.y - predY) * 0.18;
            }
          }

          // Reconcile points length
          if (snake.points.length < snake.targetPoints.length) {
            const diff = snake.targetPoints.length - snake.points.length;
            for (let k = 0; k < diff; k++) {
              const basePoint = snake.points[snake.points.length - 1] || currHead || { x: 0, y: 0 };
              snake.points.push({ ...basePoint });
            }
          } else if (snake.points.length > snake.targetPoints.length) {
            snake.points.length = snake.targetPoints.length;
          }
        }
      }

      const head = snake.points[0];
      let currentSpeed = snake.speed;

      // Apply freeze power-up slow down on enemies!
      if (freezeTimerRef.current > 0 && !snake.isPlayer && snake.botType !== 'ally') {
        currentSpeed = currentSpeed * 0.45;
      }

      let nextHeadX: number;
      let nextHeadY: number;

      if (isOnlineRef.current && !snake.isPlayer) {
        // Head position was smoothly predicted & lerped above
        nextHeadX = head.x;
        nextHeadY = head.y;
      } else {
        nextHeadX = head.x + Math.cos(snake.angle) * currentSpeed;
        nextHeadY = head.y + Math.sin(snake.angle) * currentSpeed;
      }

      // Online player prediction reconciliation
      if (snake.isPlayer && isOnlineRef.current && playerServerPointsRef.current && playerServerPointsRef.current.length > 0) {
        const serverPoints = playerServerPointsRef.current;
        const serverHead = serverPoints[0];
        
        if (serverHead) {
          const dx = serverHead.x - nextHeadX;
          const dy = serverHead.y - nextHeadY;
          const headDesync = Math.hypot(dx, dy);

          if (headDesync > 450) {
            // Hard snap only on massive desync or respawn
            snake.points = serverPoints.map(pt => ({ ...pt }));
            return;
          }
          // No small pulling corrections! The client head moves completely smoothly under pure client-side authoritative inputs,
          // while the server continuously aligns with us.
        }
      }

      // Butter-smooth, unbreakable Slither.io trailing physics!
      // Space out segments dynamically based on snake thickness (preventing overlaps or rigid blocky lines)
      const currentSpacing = 5.2 + (snake.size * 0.13);
      const newPoints: SnakePoint[] = [{ x: nextHeadX, y: nextHeadY }];
      
      for (let i = 0; i < snake.points.length - 1; i++) {
        const prev = newPoints[i]; // newly-calculated position of segment before this one
        const curr = snake.points[i + 1]; // old position of this segment
        let dx = curr.x - prev.x;
        let dy = curr.y - prev.y;
        let dist = Math.hypot(dx, dy);

        // Fallback if segment points are collapsed on top of each other
        if (dist < 0.001) {
          const segAngle = i > 0
            ? Math.atan2(newPoints[i].y - newPoints[i - 1].y, newPoints[i].x - newPoints[i - 1].x)
            : snake.angle;
          dx = -Math.cos(segAngle) * currentSpacing;
          dy = -Math.sin(segAngle) * currentSpacing;
          dist = currentSpacing;
        }

        // Position it exactly currentSpacing distance behind the preceding segment
        newPoints.push({
          x: prev.x + (dx / dist) * currentSpacing,
          y: prev.y + (dy / dist) * currentSpacing
        });
      }

      // Reconcile points length smoothly with server authority to grow/shrink segments
      if (snake.isPlayer && isOnlineRef.current && playerServerPointsRef.current && playerServerPointsRef.current.length > 0) {
        const serverLen = playerServerPointsRef.current.length;
        if (newPoints.length < serverLen) {
          const diff = serverLen - newPoints.length;
          for (let k = 0; k < diff; k++) {
            const tail = newPoints[newPoints.length - 1] || { x: nextHeadX, y: nextHeadY };
            const prevTail = newPoints[newPoints.length - 2] || tail;
            const tailAngle = Math.atan2(tail.y - prevTail.y, tail.x - prevTail.x);
            newPoints.push({
              x: tail.x + Math.cos(tailAngle) * currentSpacing,
              y: tail.y + Math.sin(tailAngle) * currentSpacing
            });
          }
        } else if (newPoints.length > serverLen) {
          newPoints.length = serverLen;
        }
      }

      snake.points = newPoints;

      // In online mode, stream client inputs to server for authoritative synchronization (throttled to 30Hz / 33ms)
      if (snake.isPlayer && isOnlineRef.current && socketRef.current && !snake.isDead) {
        const now = Date.now();
        if (now - lastSentInputRef.current.time >= 33) {
          lastSentInputRef.current.time = now;
          const wantsBoost = keysPressedRef.current[' '] && snake.points.length > 8 && !snake.isExtracting;
          socketRef.current.emit('client_input', {
            targetAngle: snake.targetAngle,
            wantsBoost,
            isExtracting: isHoldingExtractRef.current
          });
        }
      }

      // Circular world wall collision death
      const distFromCenter = Math.hypot(nextHeadX - WORLD_SIZE / 2, nextHeadY - WORLD_SIZE / 2);
      const currentRadius = getMapRadius(gameTimeElapsedRef.current);
      if (distFromCenter > currentRadius) {
        triggerDisintegrate(snake, false, true); // true indicates isBoundaryDeath
      }
    });

    // --- 5. FOOD CONSUMPTION LOGIC ---
    const activeSnakes = snakesRef.current.filter((s) => !s.isDead);
    foodsRef.current = foodsRef.current.filter((food) => {
      // Magnet attraction pulls food to player head
      if (magnetTimerRef.current > 0 && player && !player.isDead) {
        const pHead = player.points[0];
        const distToPl = Math.hypot(food.x - pHead.x, food.y - pHead.y);
        if (distToPl < 160) {
          const speed = (160 - distToPl) * 0.15;
          const angle = Math.atan2(pHead.y - food.y, pHead.x - food.x);
          food.x += Math.cos(angle) * speed;
          food.y += Math.sin(angle) * speed;
        }
      }

      let eaten = false;

      for (let s = 0; s < activeSnakes.length; s++) {
        const snake = activeSnakes[s];
        
        // In online mode, ONLY the local player can consume food locally.
        // Remote players and bots are managed entirely on the server to prevent length/score jitter.
        if (isOnlineRef.current && !snake.isPlayer) {
          continue;
        }

        const head = snake.points[0];
        const dist = Math.hypot(food.x - head.x, food.y - head.y);

        if (dist < snake.size + 4) {
          eaten = true;
          if (snake.isPlayer && isOnlineRef.current && socketRef.current) {
            socketRef.current.emit('eat_food', { foodId: food.id });
          }
          // Grow body based on food type (cap segment length, increase score & thickness/size)
          const growSegments = food.isStarChip ? 3 : 1;
          snake.score += growSegments;
          for (let g = 0; g < growSegments; g++) {
            if (snake.points.length < 120) {
              const tail = snake.points[snake.points.length - 1];
              const prevTail = snake.points[snake.points.length - 2] || tail;
              const tailAngle = Math.atan2(tail.y - prevTail.y, tail.x - prevTail.x);
              snake.points.push({
                x: tail.x + Math.cos(tailAngle) * 5,
                y: tail.y + Math.sin(tailAngle) * 5
              });
            }
          }
          const baseSize = snake.isPlayer ? 8 : (snake.botType === 'boss' ? 16 : 7);
          snake.size = baseSize + Math.sqrt(snake.score) * 0.4;

          if (food.isStarChip) {
            // High-stakes direct chips value transfer - only in online mode for real players
            const earned = snake.isPlayer && doubleTimerRef.current > 0 ? food.value * 2 : food.value;
            if (isOnlineRef.current && !snake.isBot) {
              snake.carriedChips += earned;
              if (snake.isPlayer) {
                if (lastCarriedChipsRef.current !== snake.carriedChips) {
                  lastCarriedChipsRef.current = snake.carriedChips;
                  setCarriedChips(snake.carriedChips);
                }
                const doubleText = doubleTimerRef.current > 0 ? " (X2 MULTIPLIER!)" : "";
                onToast(`Star Chip Consumed! +${earned} carried chips value${doubleText}`, 'success');
              }
            }
            if (snake.isPlayer) {
              // Create dynamic star grab visual even in offline mode for satisfaction
              createSparks(food.x, food.y, '#fbbf24', 8);
              gameAudio.playStar();
              triggerShake(3.0);
            }
          } else {
            // General food does NOT increase carried chips (keeps economy clean and prevents bot exploitation)
            if (snake.isPlayer) {
              gameAudio.playEat();
              triggerShake(0.8);
            }
          }

          if (snake.isPlayer) {
            if (lastSnakeLengthRef.current !== snake.score) {
              lastSnakeLengthRef.current = snake.score;
              setSnakeLength(snake.score);
            }
          }
          break;
        }
      }

      return !eaten;
    });

    // Spawn replacement food inside circular bounds to keep the world populated (only in offline/practice mode)
    if (!isOnlineRef.current) {
      while (foodsRef.current.filter(f => !f.isStarChip).length < 1200) {
        foodsRef.current.push(spawnRandomFood(false));
      }
    }

    // --- 6. SNAKE BODY-TO-HEAD COLLISIONS (KILLS) (offline only) ---
    if (!isOnlineRef.current) {
      for (let i = 0; i < activeSnakes.length; i++) {
        const snakeA = activeSnakes[i];
        const headA = snakeA.points[0];

        for (let j = 0; j < activeSnakes.length; j++) {
          const snakeB = activeSnakes[j];
          if (snakeA.id === snakeB.id) continue; // skip self

          // Check if head of A touches any body segment of B
          for (let segmentIdx = 1; segmentIdx < snakeB.points.length; segmentIdx++) {
            const seg = snakeB.points[segmentIdx];
            const dist = Math.hypot(headA.x - seg.x, headA.y - seg.y);

            // Collision registered!
            if (dist < (snakeA.size * 0.75 + snakeB.size * 0.75)) {
              // Skip collision if either snake is spawn protected (ghosted)
              if ((snakeA.spawnProtectedTimer && snakeA.spawnProtectedTimer > 0) || 
                  (snakeB.spawnProtectedTimer && snakeB.spawnProtectedTimer > 0)) {
                continue;
              }

              // Check if snakeA is player AND has active shield!
              if (snakeA.isPlayer && shieldActiveRef.current) {
                shieldActiveRef.current = false;
                setShieldActive(false);
                gameAudio.playShieldBreak();
                createSparks(headA.x, headA.y, '#06b6d4', 25);
                onToast("SHIELD SHATTERED! Crash blocked! 🛡️⚡", "success");
                
                snakeA.chatMessage = "Shield absorbed it! 🛡️⚡";
                snakeA.chatTimer = 2000;
                
                const oppositeAngle = snakeA.angle + Math.PI;
                headA.x += Math.cos(oppositeAngle) * 35;
                headA.y += Math.sin(oppositeAngle) * 35;
                break;
              }

              // A crashed into B! A disintegrates.
              if (snakeA.isPlayer && !snakeB.isPlayer) {
                setKillerInfo({
                  name: snakeB.name.replace(' [AI]', '').replace('🤝 ', ''),
                  userTag: (snakeB as any).userTag || `BOT-${Math.floor(1000 + Math.random() * 8999)}`,
                  color: snakeB.color,
                  isBot: snakeB.isBot
                });
                setIsAddedRival(false);
                setIsAddedFriend(false);
              }

              triggerDisintegrate(snakeA, false);
              triggerShake(snakeA.isPlayer ? 22 : 10); // Heavy shake if player dies, medium if bot dies

              // If B was player, increment kills
              if (snakeB.isPlayer && !snakeA.isPlayer) {
                setKillsCount((prev) => prev + 1);
                if (!snakeA.isBot) {
                  setRealKillsCount((prev) => prev + 1);
                }
                triggerPlayerKillAnnouncement(snakeA.name);
                triggerShake(16); // Double impact feedback for user's kill!
                onToast(`You eliminated ${snakeA.name}! Grab their dropped star chips!`, 'success');
                if (Math.random() < 0.5) {
                  snakeB.chatMessage = 'Get Ripped! 💥🏆';
                  snakeB.chatTimer = 2200;
                }
              } else if (!snakeB.isPlayer && snakeA.isPlayer) {
                // Bot killed the player! Talk smack!
                snakeB.chatMessage = 'Get Ripped! Easy chips! 💀🪙';
                snakeB.chatTimer = 3000;
              } else if (!snakeB.isPlayer && !snakeA.isPlayer) {
                // Bot killed another bot
                if (Math.random() < 0.3) {
                  const smackMsgs = ['Out of my way! 🐍', 'Smashed! 💥', 'Easy food! 🍬', 'Slinky style! 😎'];
                  snakeB.chatMessage = smackMsgs[Math.floor(Math.random() * smackMsgs.length)];
                  snakeB.chatTimer = 2000;
                }
              }
              break;
            }
          }
        }
      }
    }

    // --- 7. UPDATE LEADERBOARD LIST LIVE (offline only - throttled to 2Hz) ---
    if (!isOnlineRef.current) {
      const now = Date.now();
      if (now - lastLeaderboardUpdateTimeRef.current > 500) {
        lastLeaderboardUpdateTimeRef.current = now;
        const sortedLeaderboard = [...activeSnakes]
          .sort((a, b) => b.score - a.score)
          .slice(0, 5)
          .map((s) => ({
            name: s.name,
            carried: s.carriedChips,
            isPlayer: s.isPlayer || false,
            isBot: s.isBot || false,
          }));
        setActiveLeaderboard(sortedLeaderboard);
      }
    }

    // --- 8. TICK PARTICLES ---
    particlesRef.current = particlesRef.current.filter((p) => {
      p.x += p.vx;
      p.y += p.vy;
      p.life -= 16.67;
      return p.life > 0;
    });

    // --- 9. TICK CHAT BUBBLES ---
    snakesRef.current.forEach((snake) => {
      if (snake.chatTimer && snake.chatTimer > 0) {
        snake.chatTimer -= 16.67;
        if (snake.chatTimer <= 0) {
          snake.chatMessage = undefined;
        }
      }

      // Random bot chat triggers
      if (snake.isBot && !snake.isDead) {
        if (Math.random() < 0.0015) { // 0.15% chance per frame
          let msg = '';
          if (snake.botType === 'ally') {
            const allyMessages = [
              "Need some help? I got your tail! 🤝",
              "Let's trap these vipers! 🎯",
              "Stay close to me, don't get trapped!",
              "GG team! 🏆🔥",
              "Carrying chips like a boss! 😎",
              "Watch out for the hunter bots! ☣️"
            ];
            msg = allyMessages[Math.floor(Math.random() * allyMessages.length)];
          } else if (snake.botType === 'coward') {
            const cowardMsgs = ['Watch out! 😱', 'Fleeing! 🏃', 'Don\'t eat me!', 'Retreating! 💨', 'Oops! 😅'];
            msg = cowardMsgs[Math.floor(Math.random() * cowardMsgs.length)];
          } else if (snake.botType === 'hunter') {
            const hunterMsgs = ['I see you! 😈', 'Venom strike! 🐍', 'Yield your chips! 🪙', 'No mercy!', 'Gotcha!'];
            msg = hunterMsgs[Math.floor(Math.random() * hunterMsgs.length)];
          } else if (snake.botType === 'extractor') {
            const extractorMsgs = ['Almost safe... 💎', 'Extracting! 🛰️', 'Hold the line! 🛡️', 'Cashing out!'];
            msg = extractorMsgs[Math.floor(Math.random() * extractorMsgs.length)];
          } else {
            const casualMsgs = ['GG! 🏆', 'Let\'s go! 🚀', 'Slinky style 😎', 'Apex predator!', 'Noob! 😂', 'Troll master 🤪'];
            msg = casualMsgs[Math.floor(Math.random() * casualMsgs.length)];
          }
          snake.chatMessage = msg;
          snake.chatTimer = 2450;
        }
      }
    });

    // Respawn bots inside circular bounds if any died to keep the arena packed and active! (Offline mode only)
    if (!isOnlineRef.current) {
      const activeBots = snakesRef.current.filter((s) => s.isBot && !s.isDead && s.botType !== 'ally');
      if (activeBots.length < selectedArena.botsCount) {
        const respawnCount = selectedArena.botsCount - activeBots.length;
        for (let r = 0; r < respawnCount; r++) {
          const spawnRadius = 3500;
          const spawnAngle = Math.random() * Math.PI * 2;
          const spawnDist = Math.sqrt(Math.random()) * spawnRadius;
          let startX = WORLD_SIZE / 2 + Math.cos(spawnAngle) * spawnDist;
          let startY = WORLD_SIZE / 2 + Math.sin(spawnAngle) * spawnDist;
          
          // Prevent spawning right on top of player
          const pHead = player.points[0];
          let tries = 0;
          while (Math.hypot(startX - pHead.x, startY - pHead.y) < 450 && tries < 10) {
            const retryAngle = Math.random() * Math.PI * 2;
            const retryDist = Math.sqrt(Math.random()) * spawnRadius;
            startX = WORLD_SIZE / 2 + Math.cos(retryAngle) * retryDist;
            startY = WORLD_SIZE / 2 + Math.sin(retryAngle) * retryDist;
            tries++;
          }

          const botAngle = Math.random() * Math.PI * 2;
          const botSkin = ALL_COSMETICS[Math.floor(Math.random() * Math.min(5, ALL_COSMETICS.length))];

          const aiStyles: ('scavenger' | 'opportunist' | 'hunter' | 'extractor' | 'coward')[] = [
            'scavenger', 'opportunist', 'hunter', 'extractor', 'coward'
          ];
          const botType = aiStyles[Math.floor(Math.random() * aiStyles.length)];
          const botId = `bot-${Math.random().toString(36).substring(2, 11)}`;

          snakesRef.current.push({
            id: botId,
            name: `${BOT_NAMES[Math.floor(Math.random() * BOT_NAMES.length)]} [AI]`,
            points: generateInitialBody(startX, startY, botAngle),
            angle: botAngle,
            targetAngle: botAngle,
            speed: 4.4 + Math.random() * 1.6,
            size: 9 + Math.random() * 3,
            color: botSkin.color,
            secondaryColor: botSkin.secondaryColor || '#475569',
            isBot: true,
            botType,
            carriedChips: 0,
            isExtracting: false,
            extractionProgress: 0,
            score: INITIAL_BODY_LENGTH,
            isDead: false,
            spawnProtectedTimer: 4000,
          });
        }
      }
    }

    // Dynamic Danger/Threat Level Calculation for the Cyberpunk Synthesizer track
    let computedDanger = 1;
    if (player.isExtracting) {
      computedDanger = 3;
    } else if (bossSpawnedRef.current && snakesRef.current.some(s => s.id === 'boss-corruptor' && !s.isDead)) {
      computedDanger = 3;
    } else {
      const playerHead = player.points[0];
      const closeHostilesCount = snakesRef.current.filter(s => {
        if (s.isPlayer || s.isDead || s.botType === 'ally') return false;
        const d = Math.hypot(s.points[0].x - playerHead.x, s.points[0].y - playerHead.y);
        return d < 350;
      }).length;

      if (closeHostilesCount >= 2) {
        computedDanger = 3;
      } else if (closeHostilesCount >= 1 || player.carriedChips >= selectedArena.minExtract) {
        computedDanger = 2;
      }
    }
    gameAudio.setDangerLevel(computedDanger);

    // Filter out dead snakes in offline mode to prevent memory leak and lag!
    if (!isOnlineRef.current) {
      snakesRef.current = snakesRef.current.filter(s => !s.isDead || s.isPlayer);
    }
  };

  const findClosestFood = (snake: Snake, radius: number): Food | null => {
    const head = snake.points[0];
    let closest: Food | null = null;
    let minDist = radius;

    foodsRef.current.forEach((food) => {
      // Prioritize star chips
      const weight = food.isStarChip ? 0.3 : 1.0;
      const dist = Math.hypot(food.x - head.x, food.y - head.y) * weight;
      if (dist < minDist) {
        minDist = dist;
        closest = food;
      }
    });

    return closest;
  };

  const triggerDisintegrate = (snake: Snake, extractedSafely: boolean, isBoundaryDeath = false) => {
    snake.isDead = true;

    // Disintegration effects
    const head = snake.points[0];
    const particleColor = extractedSafely ? '#6366f1' : (snake.isPlayer ? cosmeticDeath.color : snake.color);
    createSparks(head.x, head.y, particleColor, 25);

    if (extractedSafely) {
      if (snake.isPlayer) {
        handleSuccessfulExtraction();
      }
      return;
    }

    // On normal collision death: drop lootable stars corresponding to 80% of carried chips!
    // AI Bots never drop stars or chips under any circumstances
    const lootValueTotal = snake.isBot ? 0 : Math.floor(snake.carriedChips * 0.8);
    const dropCount = Math.min(15, Math.max(4, Math.floor(lootValueTotal / 2)));
    const valuePerDrop = Math.max(1, Math.floor(lootValueTotal / dropCount));

    const dropsToSpawn: any[] = [];
    if (lootValueTotal > 0) {
      for (let i = 0; i < dropCount; i++) {
        // Spread drops along body chain tightly on spot (max 10px random variance)
        const segmentIndex = Math.floor((i / dropCount) * snake.points.length);
        const segment = snake.points[segmentIndex] || head;
        const spreadX = segment.x + (Math.random() - 0.5) * 10;
        const spreadY = segment.y + (Math.random() - 0.5) * 10;

        const newFood = spawnRandomFood(true, spreadX, spreadY, valuePerDrop);
        if (isOnlineRef.current && socketRef.current) {
          dropsToSpawn.push({
            x: newFood.x,
            y: newFood.y,
            size: newFood.size,
            value: newFood.value,
            isStarChip: newFood.isStarChip,
            color: newFood.color
          });
        } else {
          foodsRef.current.push(newFood);
        }
      }
    }

    // Also spawn regular food (for growth/score) matching the snake's body length!
    // Rule: if bot hit boundary, they directly vanish and do not drop anything!
    // Rule: if real players die with boundary, they drop stars but NOT food!
    if (!isBoundaryDeath) {
      const foodDropCount = Math.min(25, Math.max(5, snake.points.length));
      for (let i = 0; i < foodDropCount; i++) {
        // Drop food tightly on the body segment points (max 8px random variance)
        const segmentIndex = Math.floor((i / foodDropCount) * snake.points.length);
        const segment = snake.points[segmentIndex] || head;
        const spreadX = segment.x + (Math.random() - 0.5) * 8;
        const spreadY = segment.y + (Math.random() - 0.5) * 8;

        const regularFood = spawnRandomFood(false, spreadX, spreadY);
        if (isOnlineRef.current && socketRef.current) {
          dropsToSpawn.push({
            x: regularFood.x,
            y: regularFood.y,
            size: regularFood.size,
            value: regularFood.value,
            isStarChip: regularFood.isStarChip,
            color: regularFood.color
          });
        } else {
          foodsRef.current.push(regularFood);
        }
      }
    }

    if (isOnlineRef.current && socketRef.current && dropsToSpawn.length > 0) {
      socketRef.current.emit('spawn_chips', { chips: dropsToSpawn });
    }

    // If player dies, trigger game-over modal
    if (snake.isPlayer) {
      setIsGameOver(true);
      gameAudio.playDeath();
      gameAudio.stopMusic();

      if (isOnlineRef.current) {
        // Update global metrics for local store
        const updatedTotalLost = playerStatsRef.current.totalChipsLost + selectedArenaRef.current.buyIn;
        onUpdateStats({
          lifetimeDeaths: playerStatsRef.current.lifetimeDeaths + 1,
          totalChipsLost: updatedTotalLost,
          lifetimeKills: playerStatsRef.current.lifetimeKills + realKillsCount,
        });

        // Record match to history
        try {
          const historyStr = localStorage.getItem('venom_match_history');
          const history = historyStr ? JSON.parse(historyStr) : [];
          const durationSec = Math.floor((Date.now() - gameStartTimeRef.current) / 1000);
          const newEntry = {
            id: 'match-' + Math.random().toString(36).substr(2, 9),
            arenaName: selectedArenaRef.current.name,
            isOnline: true,
            status: 'COLLIDED',
            chipsEarned: 0,
            chipsLost: selectedArenaRef.current.buyIn,
            kills: realKillsCount,
            snakeLength: snakeLength,
            timestamp: new Date().toISOString(),
            durationSec: Math.max(5, durationSec)
          };
          history.unshift(newEntry);
          localStorage.setItem('venom_match_history', JSON.stringify(history.slice(0, 25)));
          
          logMatchOutcome({
            id: newEntry.id,
            arenaName: newEntry.arenaName,
            isOnline: true,
            status: 'COLLIDED',
            chipsEarned: 0,
            chipsLost: newEntry.chipsLost,
            kills: newEntry.kills,
            snakeLength: newEntry.snakeLength,
            playerName: playerStatsRef.current.name,
            playerTag: playerStatsRef.current.userTag
          });
        } catch (err) {
          console.error(err);
        }

        onToast(`CRASH! You collided and forfeited ${selectedArenaRef.current.buyIn} carried chips!`, 'error');
      } else {
        // Offline: No chips wagered or lost
        onUpdateStats({
          lifetimeDeaths: playerStatsRef.current.lifetimeDeaths + 1,
        });

        try {
          const historyStr = localStorage.getItem('venom_match_history');
          const history = historyStr ? JSON.parse(historyStr) : [];
          const durationSec = Math.floor((Date.now() - gameStartTimeRef.current) / 1000);
          const newEntry = {
            id: 'match-' + Math.random().toString(36).substr(2, 9),
            arenaName: selectedArenaRef.current.name,
            isOnline: false,
            status: 'COLLIDED',
            chipsEarned: 0,
            chipsLost: 0,
            kills: 0, // No real player kills in offline practice mode
            snakeLength: snakeLength,
            timestamp: new Date().toISOString(),
            durationSec: Math.max(5, durationSec)
          };
          history.unshift(newEntry);
          localStorage.setItem('venom_match_history', JSON.stringify(history.slice(0, 25)));
        } catch (err) {
          console.error(err);
        }

        onToast(`CRASH! (Offline Practice Mode - No chips lost!)`, 'info');
      }
    }
  };

  const handleSuccessfulExtraction = () => {
    const player = playerSnakeRef.current;
    if (!player) return;

    setIsSuccess(true);
    isSuccessRef.current = true;
    gameAudio.playExtractSuccess();
    gameAudio.stopMusic();
    
    // AAA level impact visual celebration
    const head = player.points[0];
    createSparks(head.x, head.y, '#38bdf8', 60);
    createSparks(head.x, head.y, '#818cf8', 60);
    createSparks(head.x, head.y, '#f59e0b', 60);
    triggerShake(35);
    
    // 35% commission deduction, 65% retained
    const payoutRaw = player.carriedChips * 0.65;
    const finalRetained = isOnlineRef.current ? Math.floor(payoutRaw) : 0; // 0 for offline practice mode
    setFinalChipsBanked(finalRetained);

    // Update level XP progress based on length and kills
    const xpReward = Math.floor((player.score * 5 + realKillsCount * 50) * selectedArenaRef.current.rewardMultiplier);
    let newXp = playerStatsRef.current.xp + xpReward;
    let newLevel = playerStatsRef.current.level;
    const xpNeeded = newLevel * 200;

    if (newXp >= xpNeeded) {
      newXp = newXp - xpNeeded;
      newLevel += 1;
      onToast(`LEVEL UP! You reached Level ${newLevel}!`, 'success');
    }

    const currentStreak = playerStatsRef.current.bestStreak;
    const streakUpdate = isOnlineRef.current ? Math.max(currentStreak, playerStatsRef.current.bestStreak + 1) : currentStreak;

    if (isOnlineRef.current) {
      onUpdateStats({
        bankedChips: playerStatsRef.current.bankedChips + finalRetained,
        lifetimeExtracts: playerStatsRef.current.lifetimeExtracts + 1,
        lifetimeKills: playerStatsRef.current.lifetimeKills + realKillsCount,
        biggestExtract: Math.max(playerStatsRef.current.biggestExtract, finalRetained),
        bestStreak: streakUpdate,
        totalChipsEarned: playerStatsRef.current.totalChipsEarned + finalRetained,
        xp: newXp,
        level: newLevel,
      });

      // Record match to history
      try {
        const historyStr = localStorage.getItem('venom_match_history');
        const history = historyStr ? JSON.parse(historyStr) : [];
        const durationSec = Math.floor((Date.now() - gameStartTimeRef.current) / 1000);
        const newEntry = {
          id: 'match-' + Math.random().toString(36).substr(2, 9),
          arenaName: selectedArenaRef.current.name,
          isOnline: true,
          status: 'EXTRACTED',
          chipsEarned: finalRetained,
          chipsLost: 0,
          kills: realKillsCount,
          snakeLength: snakeLength,
          timestamp: new Date().toISOString(),
          durationSec: Math.max(5, durationSec)
        };
        history.unshift(newEntry);
        localStorage.setItem('venom_match_history', JSON.stringify(history.slice(0, 25)));

        logMatchOutcome({
          id: newEntry.id,
          arenaName: newEntry.arenaName,
          isOnline: true,
          status: 'EXTRACTED',
          chipsEarned: newEntry.chipsEarned,
          chipsLost: 0,
          kills: newEntry.kills,
          snakeLength: newEntry.snakeLength,
          playerName: playerStatsRef.current.name,
          playerTag: playerStatsRef.current.userTag
        });
      } catch (err) {
        console.error(err);
      }

      onToast(`EXTRACTED! Banked +${finalRetained} CHIPS (System commission applied)`, 'success');
    } else {
      // Offline Mode: No chips banked or lost
      onUpdateStats({
        xp: newXp,
        level: newLevel,
      });

      // Record match to history
      try {
        const historyStr = localStorage.getItem('venom_match_history');
        const history = historyStr ? JSON.parse(historyStr) : [];
        const durationSec = Math.floor((Date.now() - gameStartTimeRef.current) / 1000);
        const newEntry = {
          id: 'match-' + Math.random().toString(36).substr(2, 9),
          arenaName: selectedArenaRef.current.name,
          isOnline: false,
          status: 'EXTRACTED',
          chipsEarned: 0,
          chipsLost: 0,
          kills: 0,
          snakeLength: snakeLength,
          timestamp: new Date().toISOString(),
          durationSec: Math.max(5, durationSec)
        };
        history.unshift(newEntry);
        localStorage.setItem('venom_match_history', JSON.stringify(history.slice(0, 25)));
      } catch (err) {
        console.error(err);
      }

      onToast(`EXTRACTED! (Offline Practice Mode - No chips earned!)`, 'info');
    }
  };

  // PARTICLE GRAPHICS GENERATOR
  const createSparks = (x: number, y: number, color: string, count: number) => {
    for (let i = 0; i < count; i++) {
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.5 + Math.random() * 4.5;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        color,
        size: 2 + Math.random() * 3,
        life: 400 + Math.random() * 600,
        maxLife: 1000,
      });
    }
  };

  // RENDERING ENGINE
  const drawGame = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const player = playerSnakeRef.current;
    if (!player) return;

    // Clear Screen
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // CAMERA LOGIC: Centered relative to player head or spectated snake head
    let spectatedSnake = player;
    if (spectateTarget) {
      const found = snakesRef.current.find(s => s.id === 'friend-spectate');
      if (found) {
        spectatedSnake = found;
      }
    }
    const head = spectatedSnake.points[0];
    const cameraX = head.x - canvas.width / 2;
    const cameraY = head.y - canvas.height / 2;

    // Dynamic camera zoom scaling based on device size:
    // Mobile gets a 0.58x zoom to make gameplay look small/compact and responsive.
    // Desktop gets a 0.9x zoom for a clean, immersive tactical viewport.
    const zoomScale = canvas.width < 768 ? 0.58 : 0.9;

    // SCREEN SHAKE CALCULATIONS (AAA Impact Juice)
    let shakeX = 0;
    let shakeY = 0;
    if (screenShakeRef.current > 0.1) {
      shakeX = (Math.random() - 0.5) * screenShakeRef.current;
      shakeY = (Math.random() - 0.5) * screenShakeRef.current;
      screenShakeRef.current *= 0.88; // fast decay
    }

    // --- 1. DRAW COOP/ARENA NEON GRID BACKGROUND ---
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.scale(zoomScale, zoomScale);
    ctx.translate(-head.x + shakeX, -head.y + shakeY);

    const currentRadius = getMapRadius(gameTimeElapsedRef.current);
    ctx.save();
    ctx.beginPath();
    ctx.arc(WORLD_SIZE / 2, WORLD_SIZE / 2, currentRadius, 0, Math.PI * 2);
    ctx.clip(); // Restricts grid line drawings within the circle boundary organically

    // Draw dark tech background color
    ctx.fillStyle = '#020617'; // Deep Slate
    ctx.fillRect(WORLD_SIZE / 2 - currentRadius, WORLD_SIZE / 2 - currentRadius, currentRadius * 2, currentRadius * 2);

    // Grid layout
    ctx.strokeStyle = '#1e293b'; // slate-800
    ctx.lineWidth = 1;
    const gridSize = 60;
    const startGridX = Math.floor((WORLD_SIZE / 2 - currentRadius) / gridSize) * gridSize;
    const endGridX = Math.ceil((WORLD_SIZE / 2 + currentRadius) / gridSize) * gridSize;
    for (let x = startGridX; x < endGridX; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, WORLD_SIZE / 2 - currentRadius);
      ctx.lineTo(x, WORLD_SIZE / 2 + currentRadius);
      ctx.stroke();
    }
    for (let y = startGridX; y < endGridX; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(WORLD_SIZE / 2 - currentRadius, y);
      ctx.lineTo(WORLD_SIZE / 2 + currentRadius, y);
      ctx.stroke();
    }
    ctx.restore(); // Restores clip state

    // Outer dangerous circular boundaries with neon pulsing alarm style
    ctx.strokeStyle = '#f43f5e'; // Rose neon
    ctx.lineWidth = 10;
    ctx.shadowColor = '#f43f5e';
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.arc(WORLD_SIZE / 2, WORLD_SIZE / 2, currentRadius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.restore();

    // VIEWPORT FRUSTUM CULLING MARGINS
    const viewMargin = 150;
    const viewHalfW = (canvas.width / 2) / zoomScale + viewMargin;
    const viewHalfH = (canvas.height / 2) / zoomScale + viewMargin;
    const minViewX = head.x - viewHalfW;
    const maxViewX = head.x + viewHalfW;
    const minViewY = head.y - viewHalfH;
    const maxViewY = head.y + viewHalfH;

    // --- 2. DRAW PARTICLES ---
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.scale(zoomScale, zoomScale);
    ctx.translate(-head.x + shakeX, -head.y + shakeY);
    ctx.shadowBlur = 0; // reset shadow
    particlesRef.current.forEach((p) => {
      if (p.x < minViewX || p.x > maxViewX || p.y < minViewY || p.y > maxViewY) return;
      ctx.fillStyle = p.color;
      ctx.globalAlpha = p.life / p.maxLife;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();

    // --- 3. DRAW FOOD & STARS CHIPS ORBS ---
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.scale(zoomScale, zoomScale);
    ctx.translate(-head.x + shakeX, -head.y + shakeY);
    foodsRef.current.forEach((food) => {
      if (food.x < minViewX || food.x > maxViewX || food.y < minViewY || food.y > maxViewY) return;
      ctx.fillStyle = food.color;

      if (food.isStarChip) {
        // Draw elegant star path representing premium chips
        ctx.shadowColor = '#eab308';
        ctx.shadowBlur = 6;
        ctx.beginPath();
        drawStar(ctx, food.x, food.y, 5, food.size + 1, food.size / 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      } else {
        // Draw general glowing circles without expensive shadowBlur
        ctx.beginPath();
        ctx.arc(food.x, food.y, food.size, 0, Math.PI * 2);
        ctx.fill();
      }
    });
    ctx.restore();

    // --- DRAW GROUND POWER-UPS ---
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.scale(zoomScale, zoomScale);
    ctx.translate(-head.x + shakeX, -head.y + shakeY);
    powerUpsRef.current.forEach((p) => {
      if (p.x < minViewX || p.x > maxViewX || p.y < minViewY || p.y > maxViewY) return;
      const scale = 1 + Math.sin(p.pulse) * 0.15;
      const radius = 12 * scale;

      ctx.beginPath();
      ctx.arc(p.x, p.y, radius, 0, Math.PI * 2);
      ctx.strokeStyle = p.color;
      ctx.lineWidth = 2.5;
      ctx.stroke();

      ctx.fillStyle = `${p.color}22`;
      ctx.beginPath();
      ctx.arc(p.x, p.y, radius - 2, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      const symbol = p.type === 'shield' ? '🛡️' : p.type === 'magnet' ? '🧲' : p.type === 'double' ? 'X2' : '❄️';
      ctx.fillText(symbol, p.x, p.y);
    });
    ctx.restore();

    // --- DRAW CO-OP TEAM TETHER LINK ---
    const ally = snakesRef.current.find(s => !s.isDead && s.botType === 'ally');
    if (ally) {
      const allyHead = ally.points[0];
      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.scale(zoomScale, zoomScale);
      ctx.translate(-head.x + shakeX, -head.y + shakeY);
      ctx.beginPath();
      ctx.moveTo(head.x, head.y);
      ctx.lineTo(allyHead.x, allyHead.y);
      ctx.strokeStyle = 'rgba(129, 140, 248, 0.45)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([6, 6]);
      ctx.stroke();
      ctx.restore();
    }

    // --- 4. DRAW SNAKES (BODIES + HEADS) ---
    ctx.save();
    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.scale(zoomScale, zoomScale);
    ctx.translate(-head.x + shakeX, -head.y + shakeY);

    snakesRef.current.forEach((snake) => {
      if (snake.isDead) return;
      const sHead = snake.points[0];
      if (!sHead) return;
      if (sHead.x < minViewX - 600 || sHead.x > maxViewX + 600 || sHead.y < minViewY - 600 || sHead.y > maxViewY + 600) {
        return; // Skip rendering offscreen snake
      }

      // 4A. Render Body segments (drawn back to front)
      for (let i = snake.points.length - 1; i >= 1; i--) {
        const pt = snake.points[i];
        const prevPt = snake.points[i - 1] || pt;
        const segAngle = Math.atan2(pt.y - prevPt.y, pt.x - prevPt.x);
        
        const wiggle = 0;
        
        const perpAngle = segAngle + Math.PI / 2;
        const drawX = pt.x + Math.cos(perpAngle) * wiggle;
        const drawY = pt.y + Math.sin(perpAngle) * wiggle;

        const sizeRatio = 1 - (i / snake.points.length) * 0.35;
        
        let fillColor = snake.color;
        let segmentShape: 'circle' | 'square' | 'diamond' | 'spike' = 'circle';
        let segmentGlow = false;
        let segmentScale = 1.0;

        if (snake.isPlayer && playerStats.useCustomSkin && playerStats.customSkinSegments && playerStats.customSkinSegments.length > 0) {
          const segmentsList = playerStats.customSkinSegments;
          const segIdx = i < segmentsList.length ? i : 1 + ((i - 1) % (segmentsList.length - 1));
          const customSeg = segmentsList[segIdx] || segmentsList[0];
          
          fillColor = customSeg.color;
          segmentShape = customSeg.shape;
          segmentGlow = customSeg.glow;
          segmentScale = customSeg.sizeScale;
        } else {
          const isPlayer = snake.isPlayer;
          const isBoss = snake.id === 'boss-corruptor';
          
          let pattern: string | undefined = undefined;
          if (isPlayer) {
            const currentSkin = ALL_COSMETICS.find(c => c.id === playerStats.currentSkin);
            pattern = currentSkin?.pattern;
          } else if (isBoss) {
            pattern = 'neon';
          }

          if (pattern === 'rainbow') {
            const hue = (Date.now() * 0.045 + i * 14) % 360;
            fillColor = `hsl(${hue}, 85%, 55%)`;
            segmentGlow = true;
          } else if (pattern === 'neon') {
            const ratio = (Math.sin(Date.now() * 0.009 - i * 0.28) + 1) / 2;
            fillColor = ratio > 0.5 ? '#06b6d4' : '#a855f7';
            segmentGlow = true;
          } else if (pattern === 'metallic') {
            fillColor = i % 2 === 0 ? '#94a3b8' : '#475569';
          } else if (pattern === 'camo') {
            const camoColors = ['#15803d', '#854d0e', '#78350f', '#166534'];
            fillColor = camoColors[i % camoColors.length];
          } else {
            fillColor = i % 2 === 0 ? snake.color : (snake.secondaryColor || snake.color);
          }
        }

        const r = snake.size * sizeRatio * segmentScale;

        ctx.save();
        if (segmentGlow) {
          ctx.shadowBlur = 10;
          ctx.shadowColor = fillColor;
        } else {
          ctx.shadowBlur = 0;
        }

        let isMetallic = false;
        if (snake.isPlayer && !playerStats.useCustomSkin) {
          const currentSkin = ALL_COSMETICS.find(c => c.id === playerStats.currentSkin);
          isMetallic = currentSkin?.pattern === 'metallic';
        }

        if (isMetallic) {
          const specGrad = ctx.createRadialGradient(drawX - r * 0.35, drawY - r * 0.35, r * 0.08, drawX, drawY, r);
          specGrad.addColorStop(0, '#f8fafc'); // silver sheen highlights
          specGrad.addColorStop(0.35, '#94a3b8');
          specGrad.addColorStop(1, '#334155');
          ctx.fillStyle = specGrad;
        } else {
          ctx.fillStyle = fillColor;
        }

        ctx.beginPath();
        if (segmentShape === 'circle') {
          ctx.arc(drawX, drawY, r, 0, Math.PI * 2);
          ctx.fill();
        } else if (segmentShape === 'square') {
          ctx.rect(drawX - r, drawY - r, r * 2, r * 2);
          ctx.fill();
        } else if (segmentShape === 'diamond') {
          ctx.moveTo(drawX, drawY - r);
          ctx.lineTo(drawX + r, drawY);
          ctx.lineTo(drawX, drawY + r);
          ctx.lineTo(drawX - r, drawY);
          ctx.closePath();
          ctx.fill();
        } else if (segmentShape === 'spike') {
          // Sharp armored biological scales pointing backwards relative to movement direction
          const spikeAngle = segAngle + Math.PI; // inverse direction
          ctx.moveTo(drawX + Math.cos(segAngle) * r * 1.3, drawY + Math.sin(segAngle) * r * 1.3);
          ctx.lineTo(drawX + Math.cos(perpAngle) * r * 0.9, drawY + Math.sin(perpAngle) * r * 0.9);
          ctx.lineTo(drawX + Math.cos(spikeAngle) * r * 0.4, drawY + Math.sin(spikeAngle) * r * 0.4);
          ctx.lineTo(drawX + Math.cos(perpAngle - Math.PI) * r * 0.9, drawY + Math.sin(perpAngle - Math.PI) * r * 0.9);
          ctx.closePath();
          ctx.fill();
        }
        ctx.restore();
      }

      // 4B. Render Head segment
      const head = snake.points[0];
      let headColor = snake.color;
      let headShape: 'circle' | 'square' | 'diamond' | 'spike' = 'circle';
      let headGlow = false;
      let headScale = 1.0;

      if (snake.isPlayer && playerStats.useCustomSkin && playerStats.customSkinSegments && playerStats.customSkinSegments.length > 0) {
        const headSeg = playerStats.customSkinSegments[0];
        headColor = headSeg.color;
        headShape = headSeg.shape;
        headGlow = headSeg.glow;
        headScale = headSeg.sizeScale;
      } else {
        const isPlayer = snake.isPlayer;
        const currentSkin = ALL_COSMETICS.find(c => c.id === playerStats.currentSkin);
        const pattern = isPlayer ? currentSkin?.pattern : undefined;

        if (pattern === 'rainbow') {
          const hue = (Date.now() * 0.045) % 360;
          headColor = `hsl(${hue}, 85%, 55%)`;
          headGlow = true;
        } else if (pattern === 'neon') {
          headColor = '#06b6d4';
          headGlow = true;
        } else if (pattern === 'metallic') {
          headColor = '#cbd5e1';
          headGlow = false;
        } else if (pattern === 'camo') {
          headColor = '#166534'; // Dark forest green
          headGlow = false;
        } else {
          headColor = snake.color;
        }
      }

      ctx.save();
      if (headGlow) {
        ctx.shadowColor = headColor;
        ctx.shadowBlur = 16;
      } else {
        ctx.shadowColor = headColor;
        ctx.shadowBlur = 10;
      }

      const headRadius = (snake.size + 1.2) * headScale;
      ctx.fillStyle = headColor;
      ctx.beginPath();
      if (headShape === 'square') {
        ctx.rect(head.x - headRadius, head.y - headRadius, headRadius * 2, headRadius * 2);
        ctx.fill();
      } else if (headShape === 'diamond') {
        ctx.moveTo(head.x, head.y - headRadius);
        ctx.lineTo(head.x + headRadius, head.y);
        ctx.lineTo(head.x, head.y + headRadius);
        ctx.lineTo(head.x - headRadius, head.y);
        ctx.closePath();
        ctx.fill();
      } else {
        // Render perfect rounded head
        ctx.arc(head.x, head.y, headRadius, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // Render shield halo if player has shield active
      if (snake.isPlayer && shieldActiveRef.current) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(head.x, head.y, snake.size + 14, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.85)';
        ctx.lineWidth = 3.5;
        ctx.shadowColor = '#06b6d4';
        ctx.shadowBlur = 12;
        ctx.stroke();
        ctx.fillStyle = 'rgba(6, 182, 212, 0.12)';
        ctx.fill();
        ctx.restore();
      }

      // Render spawn protection aura if snake has active spawn protection
      if (snake.spawnProtectedTimer && snake.spawnProtectedTimer > 0) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(head.x, head.y, snake.size + 12, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(245, 158, 11, 0.85)'; // beautiful amber glow
        ctx.lineWidth = 2.5;
        ctx.shadowColor = '#f59e0b';
        ctx.shadowBlur = 10;
        ctx.stroke();
        ctx.fillStyle = 'rgba(245, 158, 11, 0.08)';
        ctx.fill();
        ctx.restore();
      }

      // Red Forked Snake Tongue flicker animation based on time/speed
      if (snake.speed > 0.5 && Math.sin(Date.now() * 0.016) > 0.5) {
        ctx.save();
        ctx.strokeStyle = '#f43f5e'; // cybernetic crimson pink tongue
        ctx.lineWidth = 2.5;
        ctx.lineCap = 'round';
        ctx.beginPath();
        
        const tongueStartDist = headRadius;
        const tongueLength = snake.size * 0.75;
        
        const tongueStartX = head.x + Math.cos(snake.angle) * tongueStartDist;
        const tongueStartY = head.y + Math.sin(snake.angle) * tongueStartDist;
        
        const tongueEndX = head.x + Math.cos(snake.angle) * (tongueStartDist + tongueLength);
        const tongueEndY = head.y + Math.sin(snake.angle) * (tongueStartDist + tongueLength);
        
        ctx.moveTo(tongueStartX, tongueStartY);
        ctx.lineTo(tongueEndX, tongueEndY);
        
        // Split tips (Fork)
        const forkAngle = 0.45;
        const forkLength = snake.size * 0.38;
        ctx.lineTo(tongueEndX + Math.cos(snake.angle + forkAngle) * forkLength, tongueEndY + Math.sin(snake.angle + forkAngle) * forkLength);
        ctx.moveTo(tongueEndX, tongueEndY);
        ctx.lineTo(tongueEndX + Math.cos(snake.angle - forkAngle) * forkLength, tongueEndY + Math.sin(snake.angle - forkAngle) * forkLength);
        
        ctx.stroke();
        ctx.restore();
      }

      // Draw real moving cyber eyes looking towards snake target direction
      ctx.save();
      ctx.shadowBlur = 0;
      
      const eyeOffset = snake.size * 0.46 * headScale;
      const eyeR = snake.size * 0.23 * headScale;

      const eyeLeftX = head.x + Math.cos(snake.angle + 0.46) * eyeOffset;
      const eyeLeftY = head.y + Math.sin(snake.angle + 0.46) * eyeOffset;
      const eyeRightX = head.x + Math.cos(snake.angle - 0.46) * eyeOffset;
      const eyeRightY = head.y + Math.sin(snake.angle - 0.46) * eyeOffset;

      // Sclera (White)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(eyeLeftX, eyeLeftY, eyeR, 0, Math.PI * 2);
      ctx.arc(eyeRightX, eyeRightY, eyeR, 0, Math.PI * 2);
      ctx.fill();

      // Pupil (Obsidian dark core) tracking targetAngle
      const pupilR = eyeR * 0.58;
      const pupilOffset = eyeR * 0.38;
      
      const lookX = Math.cos(snake.targetAngle) * pupilOffset;
      const lookY = Math.sin(snake.targetAngle) * pupilOffset;

      ctx.fillStyle = '#0f172a'; // Obsidian deep slate
      ctx.beginPath();
      ctx.arc(eyeLeftX + lookX, eyeLeftY + lookY, pupilR, 0, Math.PI * 2);
      ctx.arc(eyeRightX + lookX, eyeRightY + lookY, pupilR, 0, Math.PI * 2);
      ctx.fill();

      // Specular reflections (lifelike eye shine highlight)
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(eyeLeftX + lookX + pupilR * 0.25, eyeLeftY + lookY - pupilR * 0.25, pupilR * 0.28, 0, Math.PI * 2);
      ctx.arc(eyeRightX + lookX + pupilR * 0.25, eyeRightY + lookY - pupilR * 0.25, pupilR * 0.28, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // 4C. Render Text Name above head
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px Inter, sans-serif';
      ctx.textAlign = 'center';
      
      if (snake.isBot) {
        // Bots don't show chips or carried text. Center their name tag vertically.
        ctx.fillText(`${snake.name}`, head.x, head.y - snake.size - 6);
      } else {
        if (isOnlineRef.current) {
          ctx.fillText(`${snake.name}`, head.x, head.y - snake.size - 14);

          // Render carried chip balance text (only for real human players)
          ctx.fillStyle = '#34d399'; // light emerald
          ctx.font = 'mono 10px monospace';
          ctx.fillText(`${snake.carriedChips.toLocaleString()} c`, head.x, head.y - snake.size - 4);
        } else {
          // Offline mode player: No "0 c" text, name tag is centered vertically like a bot!
          ctx.fillText(`${snake.name}`, head.x, head.y - snake.size - 6);
        }
      }

      // 4D. Render Floating Speech Emote Bubble
      if (snake.chatMessage && snake.chatTimer && snake.chatTimer > 0) {
        ctx.save();
        ctx.font = 'bold 11px Inter, sans-serif';
        const textWidth = ctx.measureText(snake.chatMessage).width;
        const bubbleW = textWidth + 16;
        const bubbleH = 22;
        const bubbleX = head.x - bubbleW / 2;
        const bubbleY = head.y - snake.size - 48;

        // Draw bubble background
        ctx.fillStyle = 'rgba(15, 23, 42, 0.95)'; // dark slate with transparency
        ctx.strokeStyle = '#6366f1'; // elegant indigo border
        ctx.lineWidth = 1.5;
        
        // Rounded rect path
        ctx.beginPath();
        if (typeof (ctx as any).roundRect === 'function') {
          (ctx as any).roundRect(bubbleX, bubbleY, bubbleW, bubbleH, 6);
        } else {
          ctx.rect(bubbleX, bubbleY, bubbleW, bubbleH);
        }
        ctx.fill();
        ctx.stroke();

        // Draw bubble pointer arrow
        ctx.beginPath();
        ctx.moveTo(head.x - 5, bubbleY + bubbleH);
        ctx.lineTo(head.x, bubbleY + bubbleH + 4);
        ctx.lineTo(head.x + 5, bubbleY + bubbleH);
        ctx.closePath();
        ctx.fillStyle = 'rgba(15, 23, 42, 0.95)';
        ctx.fill();
        ctx.strokeStyle = '#6366f1';
        ctx.stroke();

        // Draw text
        ctx.fillStyle = '#f8fafc';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(snake.chatMessage, head.x, bubbleY + bubbleH / 2);
        ctx.restore();
      }

      // 4E. EXTRACTION RADIAL PROGRESS ABOVE HEAD
      if (snake.isExtracting) {
        const time = Date.now() / 250;
        const progressPercent = Math.min(1.0, snake.extractionProgress / 3000);

        // Swirling Cyber rings (AAA Visuals)
        ctx.save();
        ctx.shadowColor = '#6366f1';
        ctx.shadowBlur = 15;
        
        // Ring 1: Rotating dashed line
        ctx.beginPath();
        ctx.arc(head.x, head.y, snake.size + 18, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(99, 102, 241, 0.6)';
        ctx.lineWidth = 2;
        ctx.setLineDash([8, 12]);
        ctx.lineDashOffset = -time * 12;
        ctx.stroke();

        // Ring 2: Faster counter-rotating ring
        ctx.beginPath();
        ctx.arc(head.x, head.y, snake.size + 24, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.4)';
        ctx.lineWidth = 1.5;
        ctx.setLineDash([5, 8]);
        ctx.lineDashOffset = time * 18;
        ctx.stroke();

        // Gravitational tethers pulling space-time inwards!
        for (let r = 0; r < 6; r++) {
          const beamAngle = time + (r * Math.PI) / 3;
          const beamLength = 45 + Math.sin(time * 3 + r) * 15;
          const startX = head.x + Math.cos(beamAngle) * beamLength;
          const startY = head.y + Math.sin(beamAngle) * beamLength;
          const endX = head.x + Math.cos(beamAngle + 0.4) * (snake.size + 5);
          const endY = head.y + Math.sin(beamAngle + 0.4) * (snake.size + 5);

          ctx.beginPath();
          ctx.moveTo(startX, startY);
          ctx.lineTo(endX, endY);
          ctx.strokeStyle = r % 2 === 0 ? 'rgba(99, 102, 241, 0.8)' : 'rgba(6, 182, 212, 0.8)';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }

        // Emit micro-particles swirling into player head in real-time
        if (Math.random() < 0.25) {
          const partAngle = Math.random() * Math.PI * 2;
          const partR = 50 + Math.random() * 20;
          createSparks(head.x + Math.cos(partAngle) * partR, head.y + Math.sin(partAngle) * partR, '#6366f1', 1);
        }

        ctx.restore();

        // Draw progress circle
        ctx.beginPath();
        ctx.arc(head.x, head.y, snake.size + 13, 0, Math.PI * 2);
        ctx.strokeStyle = '#1e293b';
        ctx.lineWidth = 4;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(head.x, head.y, snake.size + 13, -Math.PI / 2, -Math.PI / 2 + progressPercent * Math.PI * 2);
        ctx.strokeStyle = '#6366f1'; // Premium indigo portal color
        ctx.lineWidth = 4;
        ctx.stroke();
      }
    });

    ctx.restore();
  };

  // Helper star shape drawer
  const drawStar = (ctx: CanvasRenderingContext2D, cx: number, cy: number, spikes: number, outerRadius: number, innerRadius: number) => {
    let rot = (Math.PI / 2) * 3;
    let x = cx;
    let y = cy;
    let step = Math.PI / spikes;

    ctx.beginPath();
    ctx.moveTo(cx, cy - outerRadius);
    for (let i = 0; i < spikes; i++) {
      x = cx + Math.cos(rot) * outerRadius;
      y = cy + Math.sin(rot) * outerRadius;
      ctx.lineTo(x, y);
      rot += step;

      x = cx + Math.cos(rot) * innerRadius;
      y = cy + Math.sin(rot) * innerRadius;
      ctx.lineTo(x, y);
      rot += step;
    }
    ctx.lineTo(cx, cy - outerRadius);
    ctx.closePath();
  };

  return (
    <div className="w-full h-screen bg-slate-950 flex flex-col relative select-none font-sans text-white">
      {/* SPECTATING BANNER OVERLAY */}
      {spectateTarget && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center gap-2">
          <div className="bg-slate-950/95 border-2 border-fuchsia-500/80 rounded-2xl px-6 py-2.5 shadow-2xl backdrop-blur-md flex items-center gap-3 animate-pulse">
            <div className="w-2.5 h-2.5 rounded-full bg-fuchsia-500 animate-ping" />
            <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-fuchsia-300 font-sans">
              👁️ Spectating Mode: Watching <strong className="text-white text-base">{spectateTarget.name}</strong>
            </span>
            <button
              onClick={onExitGame}
              className="ml-3 px-3 py-1 bg-rose-600/20 text-rose-300 hover:bg-rose-600 hover:text-white rounded-lg border border-rose-500/30 text-xs font-bold transition cursor-pointer"
            >
              Leave
            </button>
          </div>
          {/* INTERACTIVE CHEER TOOLBAR */}
          <div className="bg-slate-900/95 border border-slate-800 rounded-xl px-4 py-1.5 shadow-xl flex items-center gap-2 backdrop-blur-md">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mr-1">Cheer:</span>
            {[
              { emoji: '🔥', label: 'Fire', text: 'You got this! 🔥' },
              { emoji: '💖', label: 'Heart', text: 'Amazing play! ❤️' },
              { emoji: '👑', label: 'Crown', text: 'Viper King! 👑' },
              { emoji: '🚀', label: 'Boost', text: 'Speed up! 🚀' }
            ].map((cheer) => (
              <button
                key={cheer.label}
                onClick={() => {
                  // Find friend-spectate snake
                  const friend = snakesRef.current.find(s => s.id === 'friend-spectate');
                  if (friend && !friend.isDead) {
                    friend.chatMessage = cheer.text;
                    friend.chatTimer = 3000;
                    // Spawn custom sparks at their head position
                    const head = friend.points[0];
                    createSparks(head.x, head.y, '#f59e0b', 12);
                    gameAudio.playStar();
                    onToast(`Sent ${cheer.emoji} cheer to ${spectateTarget.name}!`, 'success');
                  }
                }}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 active:bg-slate-600 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1"
                title={`Send ${cheer.label} Cheer`}
              >
                <span>{cheer.emoji}</span>
              </button>
            ))}
          </div>
        </div>
      )}
      {/* HUD HEADER PANEL */}
      <div className="absolute top-2 left-2 sm:top-4 sm:left-4 z-20 flex flex-col gap-1.5 sm:gap-2.5 max-w-sm">
        {/* Carried chips stats card */}
        {isOnline && (
          <div className="bg-slate-950/90 border border-slate-800 rounded-xl p-2 sm:p-3 shadow-lg flex items-center gap-2 sm:gap-4 backdrop-blur-md">
            <div className="p-1.5 sm:p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg">
              <Landmark className="w-4 h-4 sm:w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <span className="text-[9px] sm:text-[10px] text-slate-500 font-mono tracking-wider block uppercase">Carried Chips</span>
              <span className="text-sm sm:text-lg font-bold font-mono text-emerald-400 leading-none">
                {(carriedChips || 0).toLocaleString()} <span className="text-[10px] sm:text-xs font-sans text-slate-500 font-medium">c</span>
              </span>
            </div>
          </div>
        )}

        {/* Speed / length / kills card */}
        <div className="bg-slate-950/90 border border-slate-800 rounded-xl px-2.5 py-1.5 sm:px-3 sm:py-2 shadow-lg flex items-center justify-between gap-3 sm:gap-4 backdrop-blur-md text-[10px] sm:text-xs">
          <div className="flex items-center gap-1">
            <Trophy className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-yellow-400" />
            <span className="text-slate-400">Rank: <strong className="text-yellow-400 font-mono">#{getPlayerRank()}</strong></span>
          </div>
          <div className="flex items-center gap-1 border-l border-slate-800/60 pl-2">
            <Shield className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-indigo-400" />
            <span className="text-slate-400">Score: <strong className="text-white font-mono">{snakeLength}</strong></span>
          </div>
          <div className="flex items-center gap-1 border-l border-slate-800/60 pl-2">
            <Skull className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-rose-500" />
            <span className="text-slate-400">Kills: <strong className="text-rose-400 font-mono">{killsCount}</strong></span>
          </div>
          <div className="flex items-center gap-1 border-l border-slate-800/60 pl-2">
            <Zap className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-amber-500" />
            <span className="text-slate-400">Boost: <strong className="text-amber-400 font-mono">SPACE</strong></span>
          </div>
        </div>

        {/* Active competitors / players online stats card */}
        <div className="bg-slate-950/90 border border-slate-800 rounded-xl px-2.5 py-1.5 sm:px-3 sm:py-2 shadow-lg flex items-center justify-between gap-3 sm:gap-4 backdrop-blur-md text-[10px] sm:text-xs">
          <div className="flex items-center gap-1.5">
            <Globe className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            <span className="text-slate-400">
              {isOnline ? (
                <>Real Players: <strong className="text-indigo-400 font-mono">{activeRealPlayers} Active</strong></>
              ) : (
                <>Offline Mode: <strong className="text-amber-400 font-mono">1 Player</strong></>
              )}
            </span>
          </div>
          <div className="flex items-center gap-1.5 border-l border-slate-800/60 pl-3">
            <Users className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-slate-400">
              Bots: <strong className="text-slate-300 font-mono">
                {isOnline
                  ? snakesRef.current.filter((s) => !s.isDead && s.isBot).length
                  : selectedArena.botsCount}
              </strong>
            </span>
          </div>
        </div>

        {/* Co-Op Invite and Mute Button */}
        <div className="flex gap-1.5">
          <button
            onClick={() => setShowInviteDrawer(true)}
            className="flex-1 bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-500 hover:to-indigo-500 border border-violet-500/30 rounded-xl px-2.5 py-1.5 sm:px-3 bg-slate-950/80 shadow-lg flex items-center justify-between gap-1 backdrop-blur-md text-[10px] sm:text-[11px] font-bold text-white transition duration-205 cursor-pointer"
          >
            <div className="flex items-center gap-1 sm:gap-1.5">
              <Swords className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-violet-300 animate-pulse" />
              <span>Invite Squad</span>
            </div>
            <span className="bg-violet-950 border border-violet-800 text-[8px] sm:text-[9px] text-violet-300 font-mono font-bold px-1.5 py-0.5 rounded-full">
              CO-OP
            </span>
          </button>

          <button
            onClick={() => {
              const nextMute = gameAudio.toggleMute();
              setIsMuted(nextMute);
              onToast(nextMute ? "Audio muted 🔇" : "Cyberpunk Synth track activated! 🔊🛰️", "info");
            }}
            className="px-2.5 py-1.5 sm:px-3 sm:py-2.5 bg-slate-950/90 hover:bg-slate-900 border border-slate-800 rounded-xl shadow-lg text-slate-400 hover:text-white transition cursor-pointer flex items-center justify-center backdrop-blur-md"
            title={isMuted ? "Unmute Sound & Music" : "Mute Sound & Music"}
          >
            {isMuted ? (
              <VolumeX className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 text-rose-400" />
            ) : (
              <div className="flex items-center gap-1">
                <Volume2 className="w-3.5 h-3.5 sm:w-4.5 sm:h-4.5 text-emerald-400" />
                <div className="flex items-end gap-0.5 h-2">
                  <span className="w-0.5 bg-emerald-400 rounded-full animate-pulse" style={{ height: '60%', animationDuration: '0.5s' }} />
                  <span className="w-0.5 bg-emerald-400 rounded-full animate-pulse" style={{ height: '100%', animationDuration: '0.3s' }} />
                  <span className="w-0.5 bg-emerald-400 rounded-full animate-pulse" style={{ height: '40%', animationDuration: '0.7s' }} />
                </div>
              </div>
            )}
          </button>
        </div>
      </div>

      {/* --- LIVE CO-OP INVITE SIDE DRAWER --- */}
      {showInviteDrawer && (
        <div className="absolute inset-y-0 left-0 w-80 bg-slate-950/95 border-r border-slate-800/80 z-30 flex flex-col p-5 shadow-2xl backdrop-blur-md">
          <div className="flex items-center justify-between border-b border-slate-800/60 pb-3 mb-4">
            <div className="flex items-center gap-2">
              <Swords className="w-5 h-5 text-violet-400" />
              <h4 className="font-bold text-white text-sm font-sans">Active Shard Squad</h4>
            </div>
            <button
              onClick={() => setShowInviteDrawer(false)}
              className="p-1 hover:bg-slate-900 rounded-lg text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-[11px] text-slate-400 font-sans leading-relaxed mb-4">
            Invite your online Syndicate friends into your active shard. Spawned allies hunt enemies and gather chips together with you!
          </p>

          <div className="flex-1 overflow-y-auto flex flex-col gap-2.5 pr-1.5 custom-scrollbar">
            {activeFriends.length === 0 ? (
              <p className="text-xs text-slate-500 font-sans text-center my-6">No friends added yet. Add friends in the social panel!</p>
            ) : (
              activeFriends.map((friend) => {
                const isOffline = friend.status === 'offline';
                const isPending = pendingInvites[friend.id];
                const hasJoined = snakesRef.current.some(s => s.id.startsWith(`friend-`) && s.name.includes(friend.name));

                return (
                  <div
                    key={friend.id}
                    className="bg-slate-900/40 border border-slate-800/60 p-3 rounded-xl flex flex-col gap-2 transition"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div
                          className="w-7 h-7 rounded-full flex items-center justify-center border border-slate-800"
                          style={{ backgroundColor: `${friend.skinColor}22` }}
                        >
                          <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: friend.skinColor }} />
                        </div>
                        <div>
                          <span className="text-xs font-bold text-white block">{friend.name}</span>
                          <span className="text-[9px] text-slate-500 font-mono leading-none">{friend.userTag}</span>
                        </div>
                      </div>
                      <span className={`text-[8px] font-bold uppercase px-1.5 py-0.5 rounded ${
                        isOffline ? 'text-slate-500 bg-slate-950 border border-slate-900' : 'text-emerald-400 bg-emerald-950 border border-emerald-900/30'
                      }`}>
                        {friend.status === 'offline' ? 'Offline' : 'Online'}
                      </span>
                    </div>

                    <button
                      onClick={() => {
                        if (isOffline || isPending || hasJoined) return;
                        setPendingInvites(prev => ({ ...prev, [friend.id]: true }));
                        onToast(`Sending invite signal to ${friend.name}... 📡`, 'info');
                        
                        setTimeout(() => {
                          setPendingInvites(prev => ({ ...prev, [friend.id]: false }));
                          spawnFriend(friend.name, friend.skinColor);
                        }, 1200);
                      }}
                      disabled={isOffline || isPending || hasJoined}
                      className={`w-full py-1.5 text-xs font-sans font-bold rounded-lg border transition cursor-pointer flex items-center justify-center gap-1 ${
                        hasJoined
                          ? 'bg-emerald-950 border-emerald-800/40 text-emerald-300 cursor-default'
                          : isPending
                          ? 'bg-slate-900 border-slate-800 text-slate-500 animate-pulse cursor-default'
                          : isOffline
                          ? 'bg-slate-950 border-slate-950 text-slate-600 cursor-not-allowed'
                          : 'bg-violet-600/20 text-violet-300 border-violet-500/30 hover:bg-violet-600 hover:text-white'
                      }`}
                    >
                      {hasJoined ? (
                        <>Active in Shard 🤝</>
                      ) : isPending ? (
                        <>Connecting... 📡</>
                      ) : isOffline ? (
                        <>Unavailable</>
                      ) : (
                        <>Invite to Shard</>
                      )}
                    </button>
                  </div>
                );
              })
            )}
          </div>
          
          <div className="border-t border-slate-800/60 pt-3 mt-4 text-center">
            <span className="text-[9px] text-slate-500 font-mono tracking-wider block">COOPERATIVE ARENA MULTIPLAYER v1.2</span>
          </div>
        </div>
      )}

      {/* ARENA SHARD LIVE LEADERBOARD */}
      <div className={`absolute top-2 right-2 sm:top-4 sm:right-4 z-20 bg-slate-950/95 border border-slate-800 rounded-xl shadow-2xl backdrop-blur-md transition-all duration-205 ${
        showLeaderboard ? 'w-64 p-3 sm:p-4' : 'w-10 h-10 p-0 flex items-center justify-center cursor-pointer hover:bg-slate-900'
      }`}
      onClick={() => {
        if (!showLeaderboard) setShowLeaderboard(true);
      }}
      >
        {!showLeaderboard ? (
          <button 
            onClick={(e) => {
              e.stopPropagation();
              setShowLeaderboard(true);
            }}
            className="w-full h-full flex items-center justify-center text-amber-500 hover:text-amber-400 transition cursor-pointer"
            title="Show Leaderboard"
          >
            <Compass className="w-5 h-5 animate-pulse" />
          </button>
        ) : (
          <>
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-2 mb-2.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                <Compass className="w-3.5 h-3.5 text-amber-500" /> Shard Leaders
              </span>
              <div className="flex items-center gap-1.5">
                <span className="text-[9px] bg-indigo-500/20 border border-indigo-500/30 text-indigo-300 px-1.5 py-0.5 rounded uppercase font-bold leading-3">
                  {isOnline ? 'Online' : 'Practice'}
                </span>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowLeaderboard(false);
                  }}
                  className="p-1 hover:bg-slate-900 rounded text-slate-400 hover:text-white transition cursor-pointer"
                  title="Collapse"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            <div className="flex flex-col gap-1.5 text-xs">
              {activeLeaderboard.map((entry, idx) => (
                <div
                  key={`${entry.name}-${idx}`}
                  className={`flex items-center justify-between py-1 px-1.5 rounded transition ${
                    entry.isPlayer ? 'bg-amber-500/10 border border-amber-500/20 font-semibold' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 truncate">
                    <span className={`font-mono font-bold ${idx === 0 ? 'text-yellow-400' : 'text-slate-500'}`}>
                      {idx + 1}.
                    </span>
                    <span className={`truncate ${entry.isPlayer ? 'text-amber-300' : 'text-slate-300'}`}>
                      {entry.name}
                    </span>
                  </div>
                  {!entry.isBot && (
                    <span className="font-mono text-emerald-400 text-right shrink-0">
                      {(entry.carried || 0).toLocaleString()} <span className="text-[9px] text-slate-500">c</span>
                    </span>
                  )}
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* WORLD MINIMAP RADAR */}
      <div className={`absolute bottom-2 right-2 sm:bottom-4 sm:right-4 z-20 bg-slate-950/90 border border-slate-800 rounded-xl shadow-lg backdrop-blur-md flex flex-col items-center gap-1.5 transition-all ${
        showMinimap ? 'p-2 sm:p-2.5' : 'w-10 h-10 p-0 flex items-center justify-center cursor-pointer hover:bg-slate-900'
      }`}
      onClick={() => {
        if (!showMinimap) setShowMinimap(true);
      }}
      >
        {!showMinimap ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowMinimap(true);
            }}
            className="w-full h-full flex items-center justify-center text-indigo-400 hover:text-indigo-300 transition cursor-pointer"
            title="Show Minimap"
          >
            <Navigation className="w-5 h-5 rotate-45" />
          </button>
        ) : (
          <>
            <div className="flex items-center justify-between w-full border-b border-slate-900 pb-1 mb-1 gap-2">
              <span className="text-[9px] font-mono tracking-widest text-slate-500 uppercase flex items-center gap-1">
                <Navigation className="w-2.5 h-2.5 text-indigo-500 rotate-45" /> Arena Radar
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowMinimap(false);
                }}
                className="p-0.5 hover:bg-slate-900 rounded text-slate-500 hover:text-white transition cursor-pointer"
                title="Collapse"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            
            <div className="w-20 h-20 sm:w-24 sm:h-24 bg-slate-950/90 rounded-full border border-indigo-500/30 overflow-hidden relative shadow-inner">
              {/* Scanline radial radar effect */}
              <div className="absolute inset-0 bg-[conic-gradient(from_0deg,rgba(99,102,241,0.15),transparent_45%,transparent_100%)] rounded-full animate-[spin_3s_linear_infinite]" />
              {/* Center crosshair */}
              <div className="absolute top-1/2 left-0 right-0 h-px bg-slate-900/40 -translate-y-1/2 pointer-events-none" />
              <div className="absolute left-1/2 top-0 bottom-0 w-px bg-slate-900/40 -translate-x-1/2 pointer-events-none" />
              {/* Radar circular sweep lines */}
              <div className="absolute inset-2 border border-indigo-500/5 rounded-full pointer-events-none" />
              <div className="absolute inset-5 border border-indigo-500/10 rounded-full pointer-events-none" />
              <div className="absolute inset-8 border border-indigo-500/5 rounded-full pointer-events-none" />

              {/* Player at center */}
              <div className="absolute w-1.5 h-1.5 bg-indigo-400 rounded-full border border-white/40 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 shadow shadow-indigo-500/50" />

              {/* Arena circular boundary on radar showing player position relative to the wall */}
              {playerSnakeRef.current && (() => {
                const playerHead = playerSnakeRef.current.points[0];
                const radarRange = 1800; // units of distance
                const currentRadius = getMapRadius(gameTimeElapsedRef.current);
                
                // World center relative to player
                const wcx = WORLD_SIZE / 2 - playerHead.x;
                const wcy = WORLD_SIZE / 2 - playerHead.y;
                
                // Radar screen percentage coordinates of world center
                const wcxPercent = 50 + (wcx / radarRange) * 50;
                const wcyPercent = 50 + (wcy / radarRange) * 50;
                
                // Radius of boundary circle in percent
                const boundaryRadiusPercent = (currentRadius / radarRange) * 50;

                return (
                  <div
                    className="absolute border border-dashed border-rose-500/60 rounded-full pointer-events-none"
                    style={{
                      left: `${wcxPercent}%`,
                      top: `${wcyPercent}%`,
                      width: `${boundaryRadiusPercent * 2}%`,
                      height: `${boundaryRadiusPercent * 2}%`,
                      transform: 'translate(-50%, -50%)',
                    }}
                  />
                );
              })()}

              {/* Nearby snakes/competitors */}
              {playerSnakeRef.current && (() => {
                const playerHead = playerSnakeRef.current.points[0];
                const radarRange = 1800; // units of distance
                return snakesRef.current
                  .filter(s => !s.isDead && s.id !== 'player')
                  .map((other) => {
                    const head = other.points[0];
                    const dx = head.x - playerHead.x;
                    const dy = head.y - playerHead.y;
                    const dist = Math.hypot(dx, dy);
                    if (dist > radarRange) return null;

                    // Calculate radar screen positions (-1 to 1) mapped to relative percentages
                    const rx = dx / radarRange;
                    const ry = dy / radarRange;
                    const left = 50 + rx * 50;
                    const top = 50 + ry * 50;

                    const colorClass = other.isBot ? 'bg-rose-500 shadow-rose-500/50' : 'bg-emerald-400 shadow-emerald-400/50';

                            return (
                      <div
                        key={other.id}
                        className={`absolute w-1 h-1 rounded-full shadow-sm animate-pulse ${colorClass}`}
                        style={{
                          left: `${left}%`,
                          top: `${top}%`,
                          transform: 'translate(-50%, -50%)',
                        }}
                      />
                    );
                  });
              })()}
            </div>
          </>
        )}
      </div>

      {/* SURVIVAL PRESSURE / HOLD TO EXTRACT POPUP HUD */}
      {(
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-3">
          {/* Helper guide */}
          <p className="text-[11px] text-slate-400 bg-slate-950/80 px-3 py-1 rounded-full border border-slate-900 backdrop-blur-sm shadow font-sans text-center">
            Hold <kbd className="bg-slate-800 text-white font-mono px-1.5 py-0.5 rounded text-xs">E</kbd> or press the button below to cash out safely!
          </p>

          {/* Circle Hold Trigger Button */}
          <button
            id="btn-extract-hold"
            onMouseDown={() => {
              const player = playerSnakeRef.current;
              if (isOnlineRef.current && player && player.carriedChips < selectedArenaRef.current.minExtract) {
                const now = Date.now();
                if (now - lastWarningToastTimeRef.current > 3000) {
                  onToast(`You need at least ${selectedArenaRef.current.minExtract} chips to extract! Keep eating star chips! 💎`, 'error');
                  lastWarningToastTimeRef.current = now;
                }
                return;
              }
              setIsHoldingExtract(true);
              isHoldingExtractRef.current = true;
            }}
            onMouseUp={() => {
              setIsHoldingExtract(false);
              isHoldingExtractRef.current = false;
              extractionStartAngleRef.current = null;
              setExtractProgress(0);
              if (playerSnakeRef.current) {
                playerSnakeRef.current.isExtracting = false;
                playerSnakeRef.current.extractionProgress = 0;
              }
            }}
            onTouchStart={() => {
              const player = playerSnakeRef.current;
              if (isOnlineRef.current && player && player.carriedChips < selectedArenaRef.current.minExtract) {
                const now = Date.now();
                if (now - lastWarningToastTimeRef.current > 3000) {
                  onToast(`You need at least ${selectedArenaRef.current.minExtract} chips to extract! Keep eating star chips! 💎`, 'error');
                  lastWarningToastTimeRef.current = now;
                }
                return;
              }
              setIsHoldingExtract(true);
              isHoldingExtractRef.current = true;
            }}
            onTouchEnd={() => {
              setIsHoldingExtract(false);
              isHoldingExtractRef.current = false;
              extractionStartAngleRef.current = null;
              setExtractProgress(0);
              if (playerSnakeRef.current) {
                playerSnakeRef.current.isExtracting = false;
                playerSnakeRef.current.extractionProgress = 0;
              }
            }}
            className={`px-8 py-4 rounded-2xl font-bold font-sans tracking-wide shadow-2xl transition duration-200 border cursor-pointer select-none relative overflow-hidden ${
              (!isOnline || carriedChips >= selectedArena.minExtract)
                ? 'bg-gradient-to-r from-yellow-500 to-amber-500 border-yellow-400 text-black shadow-amber-950/40 animate-pulse'
                : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-slate-400'
            }`}
          >
            {/* Radial progress filling overlay */}
            <div
              className="absolute left-0 bottom-0 top-0 bg-yellow-400/25 transition-all duration-75"
              style={{ width: `${extractProgress}%` }}
            />

            <span className="relative z-10 flex items-center justify-center gap-2">
              <Compass className="w-5 h-5 animate-spin-slow" />
              {isHoldingExtract
                ? `EXTRACTING CHIPS (${extractProgress}%)`
                : (!isOnline || carriedChips >= selectedArena.minExtract)
                ? (isOnline ? 'HOLD TO EXTRACT SUCCESSFUL!' : 'HOLD TO LEAVE PRACTICE ARENA')
                : `CHIPS NEEDED TO EXIT: ${carriedChips}/${selectedArena.minExtract}`}
            </span>
          </button>
        </div>
      )}

      {/* QUICK CHAT EMOTES BAR */}
      <div className={`absolute bottom-2 left-2 sm:bottom-4 sm:left-4 z-20 bg-slate-950/90 border border-slate-800 rounded-xl shadow-xl backdrop-blur-md transition-all duration-200 ${
        showEmotes ? 'p-2.5 max-w-[280px] sm:max-w-xs' : 'w-10 h-10 p-0 flex items-center justify-center cursor-pointer hover:bg-slate-900'
      }`}
      onClick={() => {
        if (!showEmotes) setShowEmotes(true);
      }}
      >
        {!showEmotes ? (
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowEmotes(true);
            }}
            className="w-full h-full flex items-center justify-center text-indigo-400 hover:text-indigo-300 transition cursor-pointer"
            title="Show Emotes"
          >
            <MessageSquare className="w-5 h-5" />
          </button>
        ) : (
          <div className="flex flex-col gap-1.5">
            <div className="flex items-center justify-between gap-4">
              <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider flex items-center gap-1">
                <MessageSquare className="w-3 h-3 text-indigo-400" /> Emotes (Keys 1-5)
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowEmotes(false);
                }}
                className="p-0.5 hover:bg-slate-900 rounded text-slate-500 hover:text-white transition cursor-pointer"
                title="Collapse"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
            <div className="flex flex-wrap gap-1">
              <button
                onClick={() => triggerPlayerChat('GG! 🏆')}
                className="px-2 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800/80 rounded text-[10px] font-sans font-medium transition cursor-pointer text-slate-300 active:bg-slate-750"
              >
                GG! 🏆
              </button>
              <button
                onClick={() => triggerPlayerChat('Target Spot! 🎯')}
                className="px-2 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800/80 rounded text-[10px] font-sans font-medium transition cursor-pointer text-slate-300 active:bg-slate-750"
              >
                Target! 🎯
              </button>
              <button
                onClick={() => triggerPlayerChat('Fleeing! 🏃💨')}
                className="px-2 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800/80 rounded text-[10px] font-sans font-medium transition cursor-pointer text-slate-300 active:bg-slate-750"
              >
                Flee! 🏃💨
              </button>
              <button
                onClick={() => triggerPlayerChat('Get Ripped! 💪')}
                className="px-2 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800/80 rounded text-[10px] font-sans font-medium transition cursor-pointer text-slate-300 active:bg-slate-750"
              >
                Ripped! 💪
              </button>
              <button
                onClick={() => triggerPlayerChat('Extracting soon! ⚡')}
                className="px-2 py-1 bg-slate-900 hover:bg-slate-850 border border-slate-800/80 rounded text-[10px] font-sans font-medium transition cursor-pointer text-slate-300 active:bg-slate-750"
              >
                Extracting! ⚡
              </button>
            </div>
          </div>
        )}
      </div>

      {/* TACTICAL ALLY COMMANDS */}
        {hasAlly && (
          <div className="absolute bottom-20 left-4 z-20 flex flex-col gap-2 bg-slate-950/95 border border-slate-800 rounded-xl p-3 backdrop-blur-md max-w-xs shadow-xl animate-fade-in">
            <div className="flex items-center justify-between">
              <span className="text-[10px] text-indigo-400 font-bold uppercase tracking-wider flex items-center gap-1">
                <Swords className="w-3.5 h-3.5" /> Ally Companion Tactics
              </span>
              <span className="text-[8px] px-1.5 py-0.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 font-mono font-bold rounded">
                ACTIVE
              </span>
            </div>
            <div className="grid grid-cols-3 gap-1 mt-1">
              <button
                onClick={() => triggerAllyCommand('protect')}
                className={`py-1.5 text-[10px] font-sans font-bold rounded-lg border transition flex flex-col items-center justify-center cursor-pointer ${
                  allyCommand === 'protect'
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                    : 'bg-slate-900 border-slate-850 hover:bg-slate-850 text-slate-400'
                }`}
              >
                <Shield className="w-4 h-4 mb-0.5 text-emerald-400" />
                <span>Protect</span>
                <span className="text-[7px] text-slate-500 font-mono font-medium">[Z]</span>
              </button>
              <button
                onClick={() => triggerAllyCommand('farm')}
                className={`py-1.5 text-[10px] font-sans font-bold rounded-lg border transition flex flex-col items-center justify-center cursor-pointer ${
                  allyCommand === 'farm'
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                    : 'bg-slate-900 border-slate-850 hover:bg-slate-850 text-slate-400'
                }`}
              >
                <Sparkles className="w-4 h-4 mb-0.5 text-amber-400" />
                <span>Farm</span>
                <span className="text-[7px] text-slate-500 font-mono font-medium">[X]</span>
              </button>
              <button
                onClick={() => triggerAllyCommand('hunt')}
                className={`py-1.5 text-[10px] font-sans font-bold rounded-lg border transition flex flex-col items-center justify-center cursor-pointer ${
                  allyCommand === 'hunt'
                    ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                    : 'bg-slate-900 border-slate-850 hover:bg-slate-850 text-slate-400'
                }`}
              >
                <Flame className="w-4 h-4 mb-0.5 text-rose-400" />
                <span>Hunt</span>
                <span className="text-[7px] text-slate-500 font-mono font-medium">[C]</span>
              </button>
            </div>
          </div>
        )}

      {/* ACTIVE POWER-UPS HUD COUNTDOWNS */}
      <div className="absolute top-4 left-1/2 -translate-x-1/2 z-20 flex gap-2">
        {shieldActive && (
          <div className="bg-cyan-950/90 border border-cyan-500/40 text-cyan-200 px-3 py-1.5 rounded-xl shadow-lg flex items-center gap-1.5 text-xs font-sans font-medium backdrop-blur-md animate-pulse">
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            <span>Shield: <strong className="text-white font-mono font-bold">ACTIVE</strong></span>
          </div>
        )}
        {magnetTimeLeft > 0 && (
          <div className="bg-purple-950/90 border border-purple-500/40 text-purple-200 px-3 py-1.5 rounded-xl shadow-lg flex items-center gap-1.5 text-xs font-sans font-medium backdrop-blur-md">
            <Magnet className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
            <span>Magnet: <strong className="text-white font-mono font-bold">{magnetTimeLeft}s</strong></span>
          </div>
        )}
        {doubleTimeLeft > 0 && (
          <div className="bg-amber-950/90 border border-amber-500/40 text-amber-200 px-3 py-1.5 rounded-xl shadow-lg flex items-center gap-1.5 text-xs font-sans font-medium backdrop-blur-md">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
            <span>Double: <strong className="text-white font-mono font-bold">{doubleTimeLeft}s</strong></span>
          </div>
        )}
        {freezeTimeLeft > 0 && (
          <div className="bg-blue-950/90 border border-blue-500/40 text-blue-200 px-3 py-1.5 rounded-xl shadow-lg flex items-center gap-1.5 text-xs font-sans font-medium backdrop-blur-md">
            <Zap className="w-3.5 h-3.5 text-blue-400 animate-pulse" />
            <span>Freeze: <strong className="text-white font-mono font-bold">{freezeTimeLeft}s</strong></span>
          </div>
        )}
      </div>

      {/* SYN-01 BOSS ALARM BREACH BANNER */}
      {bossAlert && (
        <div className="absolute top-20 left-1/2 -translate-x-1/2 z-30 max-w-md w-full px-4 animate-bounce">
          <div className="bg-rose-950/95 border-2 border-rose-600/60 rounded-xl p-3.5 shadow-2xl backdrop-blur-md flex items-center gap-3 text-rose-200">
            <Skull className="w-6 h-6 text-rose-500 animate-pulse flex-shrink-0" />
            <div>
              <span className="text-[9px] font-mono uppercase tracking-wider text-rose-400 block font-bold">SYN-01 SECTOR BREACH</span>
              <span className="text-xs font-sans font-bold leading-tight block">{bossAlert}</span>
            </div>
          </div>
        </div>
      )}

      {/* COMPACT SECURE COMBAT ANNOUNCER BANNER */}
      {combatBanner && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 z-45 max-w-xs w-full px-4 pointer-events-none transition-all duration-300">
          <div className={`bg-slate-950/95 border border-indigo-500/40 px-3 py-1.5 rounded-full shadow-lg backdrop-blur-md text-center flex items-center justify-center gap-2 relative overflow-hidden`}>
            <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse" />
            <span className="text-[10px] font-mono tracking-wide uppercase text-white font-bold">
              {combatBanner.text}: <span className="text-slate-300 font-sans font-normal normal-case">{combatBanner.sub}</span>
            </span>
          </div>
        </div>
      )}

      {/* CORE CANVAS ELEMENT */}
      <div ref={containerRef} className="w-full flex-1 relative overflow-hidden">
        <canvas ref={canvasRef} className="block w-full h-full cursor-crosshair" />
      </div>

      {/* --- SUCCESS EXTRACTION WIN MODAL --- */}
      {isSuccess && (
        <div className="absolute inset-0 z-30 bg-slate-950/80 flex items-center justify-center p-4 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl max-w-md w-full shadow-2xl text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-yellow-500 to-amber-500" />
            <div className="w-16 h-16 bg-yellow-500/10 border border-yellow-500/20 rounded-2xl flex items-center justify-center mx-auto mb-5 text-yellow-400">
              <Compass className="w-9 h-9 animate-spin-slow" />
            </div>

            <h3 className="text-2xl font-bold text-white font-sans tracking-tight">
              {isOnline ? (carriedChips > 0 ? 'Extraction Completed!' : 'Secure Extraction!') : 'Practice Run Completed!'}
            </h3>
            <p className="text-xs text-slate-400 font-sans mt-2 leading-relaxed">
              {isOnline ? (
                carriedChips > 0 ? (
                  `Tactical extraction successful! You secured ${(carriedChips || 0).toLocaleString()} star chips, eliminated ${killsCount} rivals, reached a max size of ${snakeLength}, and survived for ${Math.floor(gameTimeElapsedRef.current / 60000)}m ${Math.floor((gameTimeElapsedRef.current % 60000) / 1000)}s.`
                ) : (
                  `Tactical extraction successful! You exited safely after surviving for ${Math.floor(gameTimeElapsedRef.current / 60000)}m ${Math.floor((gameTimeElapsedRef.current % 60000) / 1000)}s, eliminating ${killsCount} rivals, with a final snake size of ${snakeLength}.`
                )
              ) : (
                `Practice run finished! You eliminated ${killsCount} training bots, reached a max size of ${snakeLength}, and survived for ${Math.floor(gameTimeElapsedRef.current / 60000)}m ${Math.floor((gameTimeElapsedRef.current % 60000) / 1000)}s.`
              )}
            </p>

            {/* Match Performance Stats */}
            <div className="grid grid-cols-3 gap-2.5 my-5">
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 text-center">
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-mono">Kills</span>
                <span className="text-base font-bold text-rose-400 font-mono mt-0.5 block">{killsCount}</span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 text-center">
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-mono">Max Length</span>
                <span className="text-base font-bold text-indigo-400 font-mono mt-0.5 block">{snakeLength}</span>
              </div>
              <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80 text-center">
                <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-mono">Survival Time</span>
                <span className="text-base font-bold text-sky-400 font-mono mt-0.5 block">
                  {Math.floor(gameTimeElapsedRef.current / 60000)}:
                  {Math.floor((gameTimeElapsedRef.current % 60000) / 1000).toString().padStart(2, '0')}
                </span>
              </div>
            </div>

            {/* Results table */}
            {isOnline ? (
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 my-4 text-left text-xs font-sans text-slate-400 flex flex-col gap-2.5">
                <div className="flex justify-between">
                  <span>Carried Value:</span>
                  <span className="font-mono text-white font-semibold">{(carriedChips || 0).toLocaleString()} chips</span>
                </div>
                <div className="flex justify-between text-yellow-500">
                  <span>System Commission (35%):</span>
                  <span className="font-mono font-semibold">-{Math.floor((carriedChips || 0) * 0.35).toLocaleString()} chips</span>
                </div>
                <div className="h-px bg-slate-900 my-1" />
                <div className="flex justify-between text-emerald-400 font-bold text-sm">
                  <span>BANKED TO ACCOUNT:</span>
                  <span className="font-mono">+{ (finalChipsBanked || 0).toLocaleString() } c</span>
                </div>
              </div>
            ) : (
              <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 my-4 text-center text-xs font-sans text-slate-400">
                <p className="text-amber-400/95 font-semibold uppercase tracking-wider text-[10px] font-mono">Offline Training Complete</p>
                <p className="text-[11px] text-slate-500 mt-1 leading-normal">
                  No buy-in or banking fees. Great job sharpening your skills and maneuvers!
                </p>
              </div>
            )}

            <div className="flex flex-col gap-2.5 w-full">
              {/* Play Again Button */}
              <button
                id="btn-success-play-again"
                onClick={onPlayAgain}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-black font-sans font-bold rounded-xl text-sm transition cursor-pointer shadow-lg shadow-emerald-950/20 flex items-center justify-center gap-1.5"
              >
                <Compass className="w-4 h-4" />
                PLAY AGAIN
              </button>

              {/* Watch Ad Button */}
              <button
                disabled={hasWatchedAd}
                onClick={handleWatchAd}
                className={`w-full py-2.5 border text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
                  hasWatchedAd 
                    ? 'border-slate-800 bg-slate-900/40 text-slate-500 cursor-not-allowed'
                    : 'border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 cursor-pointer'
                }`}
              >
                📺 {hasWatchedAd ? 'Ad Completed (+50 Chips Claimed)' : 'Watch Video (Get +50 Chips)'}
              </button>

              {/* Return to Lobby */}
              <button
                id="btn-success-close"
                onClick={onExitGame}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-sans font-bold rounded-xl text-xs border border-slate-700 transition"
              >
                {isOnline ? (carriedChips > 0 ? 'SECURE CHIPS & RETURN TO LOBBY' : 'SECURE EXIT & RETURN TO LOBBY') : 'RETURN TO LOBBY'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* --- COLLISION GAME-OVER DEFEAT MODAL --- */}
      {isGameOver && (
        <div className="absolute inset-0 z-30 bg-slate-950/80 flex items-center justify-center p-4 backdrop-blur-md">
          <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl max-w-md w-full shadow-2xl text-center relative overflow-hidden">
            <div className="absolute top-0 left-0 right-0 h-1.5 bg-red-600" />
            <div className="w-16 h-16 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-center justify-center mx-auto mb-5 text-red-500">
              <Skull className="w-9 h-9" />
            </div>

            <h3 className="text-2xl font-bold text-white font-sans tracking-tight">Arena Disintegration!</h3>
            <p className="text-xs text-slate-400 font-sans mt-1.5 leading-relaxed">
              Your snake head collided with a rival. All unbanked carried chips were lost in-match.
            </p>

            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800/80 my-4 text-left text-xs font-sans text-slate-400 flex flex-col gap-2">
              <div className="flex justify-between">
                <span>Stakes Buy-In Cost:</span>
                <span className="font-mono text-red-400 font-semibold">-{(selectedArena?.buyIn || 0).toLocaleString()} chips</span>
              </div>
              <div className="flex justify-between">
                <span>Match Carried Value Forfeited:</span>
                <span className="font-mono text-slate-500">-{(carriedChips || 0).toLocaleString()} c</span>
              </div>
              <div className="flex justify-between">
                <span>Opponents Eliminated:</span>
                <span className="font-mono text-white">{killsCount} Kills</span>
              </div>
            </div>

            {/* Killer & Rival Action Card */}
            {killerInfo && (
              <div className="bg-slate-950 p-3.5 rounded-xl border border-rose-900/50 mb-5 text-left shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-rose-400 font-bold flex items-center gap-1">
                    <Skull className="w-3.5 h-3.5 text-rose-500" /> Collided With / Eliminated By
                  </span>
                  <span className="text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    {killerInfo.userTag}
                  </span>
                </div>

                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5">
                    <div 
                      className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs shadow shrink-0"
                      style={{ backgroundColor: killerInfo.color || '#ef4444', color: '#000' }}
                    >
                      {killerInfo.name.substring(0, 2).toUpperCase()}
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-white font-sans">{killerInfo.name}</h4>
                      <span className="text-[10px] text-slate-400 font-sans block">
                        {killerInfo.isBot ? 'Arena AI Combatant' : 'Online Rival Player'}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={handleAddRival}
                      disabled={isAddedRival}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-sans font-bold transition flex items-center gap-1 cursor-pointer ${
                        isAddedRival
                          ? 'bg-rose-950 text-rose-300 border border-rose-800/60'
                          : 'bg-rose-600 hover:bg-rose-500 text-white shadow-md shadow-rose-950/40'
                      }`}
                    >
                      <Swords className="w-3.5 h-3.5" />
                      {isAddedRival ? 'Rival Added ⚔️' : 'Add Rival'}
                    </button>

                    <button
                      onClick={handleAddFriend}
                      disabled={isAddedFriend}
                      className={`px-2.5 py-1.5 rounded-lg text-xs font-sans font-bold transition flex items-center gap-1 cursor-pointer ${
                        isAddedFriend
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-800/60'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700'
                      }`}
                    >
                      <UserPlus className="w-3.5 h-3.5" />
                      {isAddedFriend ? 'Friend Added 🤝' : 'Add Friend'}
                    </button>
                  </div>
                </div>
              </div>
            )}

            <div className="flex flex-col gap-2.5 w-full">
              {/* Play Again Button */}
              <button
                id="btn-defeat-play-again"
                onClick={onPlayAgain}
                className="w-full py-3 bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-sans font-bold rounded-xl text-sm transition cursor-pointer shadow-lg shadow-red-950/20 flex items-center justify-center gap-1.5"
              >
                <Compass className="w-4 h-4" />
                PLAY AGAIN
              </button>

              {/* Watch Ad Button */}
              <button
                disabled={hasWatchedAd}
                onClick={handleWatchAd}
                className={`w-full py-2.5 border text-xs font-bold rounded-xl transition flex items-center justify-center gap-1.5 ${
                  hasWatchedAd 
                    ? 'border-slate-800 bg-slate-900/40 text-slate-500 cursor-not-allowed'
                    : 'border-amber-500/30 bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 cursor-pointer'
                }`}
              >
                📺 {hasWatchedAd ? 'Ad Completed (+50 Chips Claimed)' : 'Watch Video (Get +50 Chips)'}
              </button>

              {/* Return to Lobby */}
              <button
                id="btn-defeat-close"
                onClick={onExitGame}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-sans font-bold rounded-xl text-xs border border-slate-700 transition"
              >
                RETURN TO LOBBY
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MOCK AD OVERLAY */}
      {isWatchingAd && (
        <div className="absolute inset-0 z-50 bg-black flex flex-col items-center justify-center p-6 text-center select-none">
          <div className="max-w-xs w-full bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-2xl relative overflow-hidden flex flex-col items-center gap-4">
            <div className="w-12 h-12 rounded-full border-4 border-indigo-500 border-t-transparent animate-spin" />
            <div>
              <span className="text-[10px] bg-indigo-500/20 border border-indigo-500/35 text-indigo-300 font-mono font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">
                Sponsor Video Ad
              </span>
              <h4 className="text-lg font-bold text-white mt-3 font-sans">Tuning Snake Engines...</h4>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed font-sans">
                Ad rewards credited in <strong className="text-amber-400 font-mono text-sm">{adCountdown}s</strong>. Please do not close this screen.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
