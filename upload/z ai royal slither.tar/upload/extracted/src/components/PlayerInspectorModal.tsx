import React, { useState } from 'react';
import { X, UserPlus, Swords, Ban, Shield, ExternalLink, Globe, Check, Trophy, Flame, Target, Award, Zap, History, Sparkles, Users, Flag, Clock } from 'lucide-react';

export interface InspectedPlayer {
  name: string;
  userTag: string;
  country: string;
  flag?: string;
  bankedChips: number;
  level: number;
  avatar?: string;
  clanTag?: string;
  clanName?: string;
  championshipRank?: number;
  countryRank?: number;
  regionalRank?: number;
  achievedAt?: string;
  instagram?: string;
  youtube?: string;
  twitch?: string;
  twitter?: string;
}

interface PlayerInspectorModalProps {
  player: InspectedPlayer | null;
  onClose: () => void;
  onToast: (msg: string, type?: 'success' | 'error' | 'info') => void;
}

export default function PlayerInspectorModal({ player, onClose, onToast }: PlayerInspectorModalProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'stats' | 'history' | 'loadout'>('overview');
  const [friendRequested, setFriendRequested] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);

  if (!player) return null;

  const flagEmoji = player.flag || (player.country === 'IN' ? '🇮🇳' : player.country === 'US' ? '🇺🇸' : player.country === 'JP' ? '🇯🇵' : player.country === 'KR' ? '🇰🇷' : player.country === 'GB' ? '🇬🇧' : '🌐');
  const clanTag = player.clanTag || 'APEX';
  const clanName = player.clanName || 'Viper Apex Syndicate';
  const globalRank = player.championshipRank || Math.max(1, 15 - Math.floor(player.level / 3));
  const countryRank = player.countryRank || Math.max(1, Math.floor(globalRank / 1.4));
  const regionalRank = player.regionalRank || Math.max(1, Math.floor(globalRank / 2));

  const handleAddFriend = () => {
    setFriendRequested(true);
    onToast(`Friend request sent to ${player.name} (${player.userTag})! 🤝`, 'success');
  };

  const handleChallenge = () => {
    onToast(`Arena challenge dispatch sent to ${player.name}! ⚔️`, 'info');
  };

  const handleBlock = () => {
    setIsBlocked(true);
    onToast(`Player ${player.name} has been added to your block list. 🚫`, 'error');
  };

  // Simulated match history logs for deep inspection
  const matchHistoryLogs = [
    { id: 1, arena: 'Tier-05 Crore High Roller', outcome: 'Extracted', chips: player.bankedChips > 10000000 ? 10000000 : 2500000, time: '10 mins ago', kills: 14 },
    { id: 2, arena: 'Tier-04 Platinum Arena', outcome: 'Extracted', chips: 1500000, time: '2 hours ago', kills: 8 },
    { id: 3, arena: 'Tier-03 Viper Boundary', outcome: 'Extracted', chips: 500000, time: '1 day ago', kills: 5 },
    { id: 4, arena: 'Tier-05 Crore High Roller', outcome: 'Eliminated', chips: -200000, time: '2 days ago', kills: 3 }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 max-w-xl w-full shadow-2xl relative space-y-5 overflow-hidden max-h-[90vh] flex flex-col">
        {/* Glow accent */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-amber-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-white p-1.5 rounded-lg bg-slate-950 border border-slate-800 transition-colors z-20"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Notice Banner for Current Year and 30-min sync */}
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl px-3.5 py-1.5 text-[11px] text-amber-300 font-mono flex items-center justify-between shrink-0">
          <span className="flex items-center gap-1.5 font-bold">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" /> Current Year (2026) Official Standings
          </span>
          <span className="text-[10px] text-slate-400 flex items-center gap-1">
            <Zap className="w-3 h-3 text-emerald-400" /> Auto-updates every 30 mins
          </span>
        </div>

        {/* Header Avatar & Identity */}
        <div className="flex items-center gap-4 shrink-0 pr-8">
          <div className="w-16 h-16 rounded-2xl bg-slate-950 border-2 border-amber-500/40 flex items-center justify-center text-3xl shadow-inner shrink-0 relative">
            {player.avatar || flagEmoji}
            <div className="absolute -bottom-1 -right-1 bg-indigo-600 text-white font-mono text-[9px] font-bold px-1.5 py-0.5 rounded border border-indigo-400">
              Lvl {player.level}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-xl font-bold text-white font-sans flex items-center gap-1.5">
                <span>{player.name}</span>
                <span className="text-xl">{flagEmoji}</span>
              </h3>
              <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-[10px] font-mono font-bold px-1.5 py-0.5 rounded">
                [{clanTag}]
              </span>
            </div>
            <p className="text-xs text-slate-400 font-sans mt-0.5 flex items-center gap-2">
              <span>Ledger Tag: <strong className="font-mono text-amber-400">{player.userTag}</strong></span>
              <span>•</span>
              <span className="text-emerald-400 font-mono font-bold">{player.bankedChips.toLocaleString()} c Bank</span>
            </p>
            <div className="flex flex-wrap items-center gap-1.5 text-[10px] text-slate-400 font-mono mt-1">
              <span className="bg-amber-500/10 text-amber-300 border border-amber-500/30 px-1.5 py-0.5 rounded flex items-center gap-1">
                <Trophy className="w-3 h-3 text-amber-400" /> Global Rank #{globalRank}
              </span>
              <span className="bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 px-1.5 py-0.5 rounded flex items-center gap-1">
                <Flag className="w-3 h-3 text-emerald-400" /> {flagEmoji} Country Rank #{countryRank}
              </span>
              <span className="bg-indigo-500/10 text-indigo-300 border border-indigo-500/30 px-1.5 py-0.5 rounded flex items-center gap-1">
                <Globe className="w-3 h-3 text-indigo-400" /> Region Rank #{regionalRank}
              </span>
              <span className="bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 px-1.5 py-0.5 rounded flex items-center gap-1 font-bold">
                <Clock className="w-3 h-3 text-cyan-400" /> Achieved: {player.achievedAt || '26 Jul 2026, 05:42 PM UTC'}
              </span>
            </div>
          </div>
        </div>

        {/* Dossier Tabs */}
        <div className="flex bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs font-sans font-bold shrink-0">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
              activeTab === 'overview' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
              activeTab === 'stats' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Career Stats
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
              activeTab === 'history' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Extraction Logs
          </button>
          <button
            onClick={() => setActiveTab('loadout')}
            className={`flex-1 py-1.5 rounded-lg transition-all flex items-center justify-center gap-1 ${
              activeTab === 'loadout' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            Loadout
          </button>
        </div>

        {/* Tab 1: Overview & Socials */}
        {activeTab === 'overview' && (
          <div className="space-y-4 overflow-y-auto pr-1">
            {/* Joined Clan & Guild */}
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <div className="text-[10px] font-bold uppercase text-slate-400 font-sans flex items-center justify-between">
                <span className="flex items-center gap-1"><Shield className="w-3.5 h-3.5 text-indigo-400" /> Syndicate Clan Membership</span>
                <span className="text-[9px] text-emerald-400 font-mono font-bold">Active Member</span>
              </div>
              <div className="flex items-center justify-between p-2.5 bg-slate-900 rounded-lg border border-slate-800">
                <div className="flex items-center gap-2.5">
                  <span className="text-2xl">🐍</span>
                  <div>
                    <div className="font-bold text-white text-xs flex items-center gap-1.5">
                      <span>{player.clanName || 'Viper Apex Syndicate'}</span>
                      <span className="bg-indigo-500/20 text-indigo-300 text-[9px] font-mono font-bold px-1 py-0.2 rounded border border-indigo-500/30">
                        [{player.clanTag || 'APEX'}]
                      </span>
                    </div>
                    <div className="text-[10px] text-slate-400">Role: Officer • Clan Rank #1</div>
                  </div>
                </div>
                <span className="text-xs font-mono text-amber-400 font-bold">1,45,00,000 c Bank</span>
              </div>
            </div>

            {/* Friends & Allies Roster Categorized by Region & Global */}
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-3">
              <div className="text-[10px] font-bold uppercase text-slate-400 font-sans flex items-center justify-between border-b border-slate-900 pb-1.5">
                <span className="flex items-center gap-1"><Users className="w-3.5 h-3.5 text-emerald-400" /> Connected Allies & Friends Roster</span>
                <span className="text-[9px] text-slate-500 font-mono">Region & Global Split</span>
              </div>

              {/* Regional Allies */}
              <div className="space-y-1.5">
                <div className="text-[10px] font-mono text-indigo-400 font-bold flex items-center justify-between">
                  <span>🇮🇳 REGIONAL ALLIES ({player.country || 'IN'} NETWORK)</span>
                  <span className="text-[9px] text-slate-500 font-normal">2 Members</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs font-sans">
                  <div className="p-2 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span>🇮🇳</span>
                      <div>
                        <div className="font-bold text-white text-[11px]">Hari</div>
                        <div className="text-[9px] text-amber-400 font-mono">#IND-001</div>
                      </div>
                    </div>
                    <span className="text-[9px] bg-amber-500/20 text-amber-300 font-bold px-1 rounded">Leader</span>
                  </div>
                  <div className="p-2 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span>🇮🇳</span>
                      <div>
                        <div className="font-bold text-white text-[11px]">Rookie_Striker</div>
                        <div className="text-[9px] text-slate-400 font-mono">#IND-104</div>
                      </div>
                    </div>
                    <span className="text-[9px] bg-slate-800 text-slate-300 font-bold px-1 rounded">Member</span>
                  </div>
                </div>
              </div>

              {/* Global Allies */}
              <div className="space-y-1.5 pt-1">
                <div className="text-[10px] font-mono text-purple-400 font-bold flex items-center justify-between">
                  <span>🌐 GLOBAL ALLIES & INTERNATIONAL ALLIANCES</span>
                  <span className="text-[9px] text-slate-500 font-normal">2 Members</span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs font-sans">
                  <div className="p-2 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span>🇺🇸</span>
                      <div>
                        <div className="font-bold text-white text-[11px]">Apex_Viper</div>
                        <div className="text-[9px] text-slate-400 font-mono">#USA-882</div>
                      </div>
                    </div>
                    <span className="text-[9px] bg-indigo-500/20 text-indigo-300 font-bold px-1 rounded">Officer</span>
                  </div>
                  <div className="p-2 bg-slate-900 rounded-lg border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span>🇰🇷</span>
                      <div>
                        <div className="font-bold text-white text-[11px]">K-Snake</div>
                        <div className="text-[9px] text-slate-400 font-mono">#KOR-114</div>
                      </div>
                    </div>
                    <span className="text-[9px] bg-emerald-500/20 text-emerald-300 font-bold px-1 rounded">Ally</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Social Channels */}
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <div className="text-[10px] font-bold uppercase text-slate-400 font-sans flex items-center justify-between">
                <span className="flex items-center gap-1"><Globe className="w-3.5 h-3.5 text-purple-400" /> Creator Social Channels</span>
                <span className="text-[9px] text-slate-500">Verified Handles</span>
              </div>

              <div className="flex flex-wrap gap-2">
                <a
                  href={`https://instagram.com/${(player.instagram || player.name).replace('@', '')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1 bg-pink-500/10 hover:bg-pink-500/20 text-pink-400 border border-pink-500/30 rounded-lg text-xs font-sans font-bold flex items-center gap-1 transition-all"
                >
                  📸 Instagram
                  <ExternalLink className="w-3 h-3 ml-0.5 opacity-60" />
                </a>

                <a
                  href={player.youtube && player.youtube.startsWith('http') ? player.youtube : `https://youtube.com/@${player.name.toLowerCase()}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 rounded-lg text-xs font-sans font-bold flex items-center gap-1 transition-all"
                >
                  🎥 YouTube
                  <ExternalLink className="w-3 h-3 ml-0.5 opacity-60" />
                </a>

                <a
                  href={`https://twitch.tv/${player.twitch || player.name.toLowerCase()}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-2.5 py-1 bg-purple-500/10 hover:bg-purple-500/20 text-purple-400 border border-purple-500/30 rounded-lg text-xs font-sans font-bold flex items-center gap-1 transition-all"
                >
                  📱 Twitch
                  <ExternalLink className="w-3 h-3 ml-0.5 opacity-60" />
                </a>
              </div>
            </div>

            {/* Badges & Achievements */}
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <div className="text-[10px] font-bold uppercase text-slate-400 font-sans flex items-center gap-1">
                <Award className="w-3.5 h-3.5 text-amber-400" /> Earned Badges & Honors
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs font-sans">
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800 flex items-center gap-2">
                  <span className="text-lg">👑</span>
                  <div>
                    <div className="font-bold text-amber-300 text-[11px]">1 Crore Immortal</div>
                    <div className="text-[9px] text-slate-400">Extracted over 10M Chips</div>
                  </div>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800 flex items-center gap-2">
                  <span className="text-lg">⚡</span>
                  <div>
                    <div className="font-bold text-indigo-300 text-[11px]">Apex Vanguard</div>
                    <div className="text-[9px] text-slate-400">Top 1% Arena Leaderboard</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Career Statistics */}
        {activeTab === 'stats' && (
          <div className="space-y-3 overflow-y-auto pr-1 text-xs font-sans">
            {/* Live Leaderboard Standing Matrix */}
            <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
              <div className="text-[10px] font-bold uppercase text-slate-400 flex items-center justify-between border-b border-slate-900 pb-1.5">
                <span className="flex items-center gap-1"><Trophy className="w-3.5 h-3.5 text-amber-400" /> Live Leaderboard Standings</span>
                <span className="text-[9px] text-emerald-400 font-mono font-bold">Real-Time Sync</span>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center font-mono">
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800">
                  <div className="text-[9px] text-slate-400 font-sans">Global World Rank</div>
                  <div className="font-bold text-amber-400 text-sm mt-0.5">#{globalRank}</div>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800">
                  <div className="text-[9px] text-slate-400 font-sans">{flagEmoji} Country Rank</div>
                  <div className="font-bold text-emerald-400 text-sm mt-0.5">#{countryRank}</div>
                </div>
                <div className="p-2 bg-slate-900 rounded-lg border border-slate-800">
                  <div className="text-[9px] text-slate-400 font-sans">Regional Arena Rank</div>
                  <div className="font-bold text-indigo-400 text-sm mt-0.5">#{regionalRank}</div>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Total Banked Chips</span>
                <span className="font-mono font-bold text-emerald-400 text-sm">{player.bankedChips.toLocaleString()} c</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Highest Extraction</span>
                <span className="font-mono font-bold text-amber-400 text-sm">1,00,00,000 c</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Extraction Success Rate</span>
                <span className="font-mono font-bold text-indigo-400 text-sm">88.4%</span>
              </div>
              <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 font-bold uppercase block">Snake Eliminations</span>
                <span className="font-mono font-bold text-red-400 text-sm">412 Kills</span>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Extraction Logs */}
        {activeTab === 'history' && (
          <div className="space-y-2 overflow-y-auto pr-1 max-h-56">
            {matchHistoryLogs.map((log) => (
              <div key={log.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs font-sans">
                <div>
                  <div className="font-bold text-white flex items-center gap-1.5">
                    <span>{log.arena}</span>
                    <span className={`text-[9px] font-mono font-bold px-1.5 py-0.2 rounded ${log.outcome === 'Extracted' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}`}>
                      {log.outcome}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">{log.time} • {log.kills} Snake Kills</div>
                </div>
                <div className={`font-mono font-bold ${log.chips > 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                  {log.chips > 0 ? `+${log.chips.toLocaleString()} c` : `${log.chips.toLocaleString()} c`}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Tab 4: Equipped Loadout */}
        {activeTab === 'loadout' && (
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3 text-xs font-sans">
            <div className="flex justify-between py-1.5 border-b border-slate-900">
              <span className="text-slate-400">Snake DNA Skin:</span>
              <span className="font-bold text-amber-400">👑 Cyber Serpent God</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-900">
              <span className="text-slate-400">Tail Trail FX:</span>
              <span className="font-bold text-purple-400">⚡ Hyper Plasma Arc</span>
            </div>
            <div className="flex justify-between py-1.5 border-b border-slate-900">
              <span className="text-slate-400">Kill Sound Effect:</span>
              <span className="font-bold text-indigo-400">🔊 Cyber Siren Roar</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-slate-400">Victory Emote:</span>
              <span className="font-bold text-emerald-400">👑 Royal Throne Taunt</span>
            </div>
          </div>
        )}

        {/* Interactive Action Controls */}
        <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-800 shrink-0">
          <button
            onClick={handleAddFriend}
            disabled={friendRequested}
            className={`py-2.5 px-3 border rounded-xl text-xs font-sans font-bold flex items-center justify-center gap-1.5 transition-all ${
              friendRequested
                ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 cursor-default'
                : 'bg-emerald-600 hover:bg-emerald-500 text-white border-emerald-500/30 shadow'
            }`}
          >
            {friendRequested ? <Check className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
            {friendRequested ? 'Request Sent' : 'Add Friend'}
          </button>

          <button
            onClick={handleChallenge}
            className="py-2.5 px-3 bg-indigo-600 hover:bg-indigo-500 text-white border border-indigo-500/30 rounded-xl text-xs font-sans font-bold flex items-center justify-center gap-1.5 transition-all shadow"
          >
            <Swords className="w-4 h-4" /> Challenge
          </button>

          <button
            onClick={handleBlock}
            disabled={isBlocked}
            className={`col-span-2 py-2 border rounded-xl text-xs font-sans font-bold flex items-center justify-center gap-1.5 transition-all ${
              isBlocked
                ? 'bg-red-950/60 text-slate-400 border-slate-800'
                : 'bg-red-950/20 hover:bg-red-950/40 text-red-400 border-red-500/20'
            }`}
          >
            <Ban className="w-3.5 h-3.5" /> {isBlocked ? 'Player Blocked' : 'Block Player'}
          </button>
        </div>
      </div>
    </div>
  );
}
