import { useState, useEffect } from 'react';
import { Trophy, Globe, Flag, Landmark, Sparkles, Medal, Shield, Crown, ChevronRight, User, Eye, X, Zap, Search, Filter } from 'lucide-react';
import { LeaderboardEntry, PlayerStats, CountryChampion } from '../types';
import { MOCK_LEADERBOARD } from '../data';
import { subscribeToLeaderboard } from '../utils/firebaseSync';

import PlayerInspectorModal, { InspectedPlayer } from './PlayerInspectorModal';

interface LeaderboardsProps {
  playerStats: PlayerStats;
  onInspectPlayer?: (player: InspectedPlayer) => void;
}

const COUNTRIES_LIST = [
  { code: 'IN', name: 'India', flag: '🇮🇳' },
  { code: 'US', name: 'United States', flag: '🇺🇸' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧' },
  { code: 'JP', name: 'Japan', flag: '🇯🇵' },
  { code: 'KR', name: 'South Korea', flag: '🇰🇷' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪' },
  { code: 'BR', name: 'Brazil', flag: '🇧🇷' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦' },
  { code: 'AU', name: 'Australia', flag: '🇦🇺' },
  { code: 'FR', name: 'France', flag: '🇫🇷' },
  { code: 'SG', name: 'Singapore', flag: '🇸🇬' },
  { code: 'NL', name: 'Netherlands', flag: '🇳🇱' },
];

const MILESTONE_TIERS = [
  { id: 'all', name: 'All Milestone Tiers', minChips: 0, badge: '⭐ All Tiers', color: 'from-slate-700 to-slate-900 border-slate-600' },
  { id: 'omega', name: 'Omega Legend (1 Crore / 10M+)', minChips: 10000000, badge: '👑 Omega', color: 'from-purple-500 via-pink-500 to-amber-500 border-amber-300' },
  { id: 'diamond', name: 'Diamond Warlord (50 Lakhs / 5M+)', minChips: 5000000, badge: '🔮 Diamond', color: 'from-purple-600 to-indigo-900 border-purple-400' },
  { id: 'platinum', name: 'Platinum Sovereign (25 Lakhs / 2.5M+)', minChips: 2500000, badge: '💎 Platinum', color: 'from-cyan-400 to-indigo-600 border-cyan-300' },
  { id: 'gold', name: 'Gold Apex Vanguard (10 Lakhs / 1M+)', minChips: 1000000, badge: '🥇 Gold', color: 'from-yellow-500 to-amber-600 border-yellow-400' },
  { id: 'silver', name: 'Silver Commander (5 Lakhs / 500K+)', minChips: 500000, badge: '🥈 Silver', color: 'from-slate-400 to-slate-600 border-slate-300' },
  { id: 'bronze', name: 'Bronze Elite (1 Lakh / 100K+)', minChips: 100000, badge: '🥉 Bronze', color: 'from-amber-700 to-amber-900 border-amber-600' },
];

export default function Leaderboards({ playerStats, onInspectPlayer }: LeaderboardsProps) {
  const [levelTab, setLevelTab] = useState<'level3_world' | 'level2_national' | 'level1_milestone'>('level3_world');
  const [level3SubTab, setLevel3SubTab] = useState<'summit' | 'global'>('summit');
  const [selectedMilestoneTierId, setSelectedMilestoneTierId] = useState<string>('all');
  const [selectedCountryCode, setSelectedCountryCode] = useState<string>(playerStats.country || 'IN');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [liveLeaderboard, setLiveLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [selectedInspectedPlayer, setSelectedInspectedPlayer] = useState<InspectedPlayer | null>(null);

  const getTierInfo = (chips: number) => {
    if (chips >= 10000000) return { name: 'Omega Legend', badge: '👑 Omega', color: 'text-amber-400' };
    if (chips >= 5000000) return { name: 'Diamond Warlord', badge: '🔮 Diamond', color: 'text-purple-400' };
    if (chips >= 2500000) return { name: 'Platinum Sovereign', badge: '💎 Platinum', color: 'text-cyan-300' };
    if (chips >= 1000000) return { name: 'Gold Apex Vanguard', badge: '🥇 Gold', color: 'text-yellow-400' };
    if (chips >= 500000) return { name: 'Silver Commander', badge: '🥈 Silver', color: 'text-slate-300' };
    if (chips >= 100000) return { name: 'Bronze Elite', badge: '🥉 Bronze', color: 'text-amber-600' };
    return { name: 'Challenger', badge: '🛡️ Rookie', color: 'text-slate-400' };
  };

  const generateAchievedTimestamp = (rank: number) => {
    const baseMinutesAgo = Math.min(10000, rank * 38 + 12);
    const date = new Date(Date.now() - baseMinutesAgo * 60 * 1000);
    const day = date.getUTCDate().toString().padStart(2, '0');
    const month = date.toLocaleString('en-US', { month: 'short', timeZone: 'UTC' });
    const year = 2026;
    const hours = date.getUTCHours();
    const minutes = date.getUTCMinutes().toString().padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';
    const formattedHours = (hours % 12 || 12).toString().padStart(2, '0');
    return `${day} ${month} ${year}, ${formattedHours}:${minutes} ${ampm} UTC`;
  };

  const handleInspect = (entry: any) => {
    const globalRank = entry.rank || entry.globalRank || 1;
    const countryRank = entry.countryRank || Math.max(1, Math.floor(globalRank / 1.4));
    const regionalRank = entry.regionalRank || Math.max(1, Math.floor(globalRank / 2));

    const formatted: InspectedPlayer = {
      name: entry.name || entry.playerName,
      userTag: entry.userTag || `#${entry.country || entry.countryCode || 'IN'}-00${globalRank}`,
      country: entry.country || entry.countryCode || 'IN',
      flag: entry.flag || COUNTRIES_LIST.find((c) => c.code === (entry.country || entry.countryCode))?.flag,
      bankedChips: entry.bankedChips,
      level: entry.level,
      avatar: entry.avatar,
      championshipRank: globalRank,
      countryRank: countryRank,
      regionalRank: regionalRank,
      achievedAt: entry.achievedAt || generateAchievedTimestamp(globalRank),
      clanTag: 'APEX',
      clanName: 'Viper Apex Syndicate'
    };

    if (onInspectPlayer) {
      onInspectPlayer(formatted);
    } else {
      setSelectedInspectedPlayer(formatted);
    }
  };

  // Subscribe to live leaderboard from Firestore and seed rich pool
  useEffect(() => {
    const unsubscribe = subscribeToLeaderboard((entries) => {
      const typedEntries: LeaderboardEntry[] = entries.map((e) => ({
        name: e.name,
        bankedChips: e.bankedChips,
        level: e.level,
        country: e.country || 'IN',
        rank: 0,
        avatar: e.avatar,
        isPlayer: e.userTag === playerStats.userTag
      }));

      // Ensure current user is present
      const hasUser = typedEntries.some((e) => e.isPlayer);
      if (!hasUser) {
        typedEntries.push({
          name: playerStats.name,
          bankedChips: playerStats.bankedChips,
          level: playerStats.level,
          country: playerStats.country || 'IN',
          rank: 0,
          avatar: playerStats.avatar,
          isPlayer: true
        });
      }

      // Seed with rich mock entries if sparse
      if (typedEntries.length < 30) {
        MOCK_LEADERBOARD.forEach((mock) => {
          if (!typedEntries.some((e) => e.name === mock.name)) {
            typedEntries.push({ ...mock, isPlayer: false });
          }
        });

        // Add additional sample competitors to make full rankings from 1 to 100+
        const flags = ['🇮🇳', '🇺🇸', '🇬🇧', '🇯🇵', '🇰🇷', '🇩🇪', '🇧🇷', '🇨🇦', '🇦🇺', '🇫🇷'];
        const countryCodes = ['IN', 'US', 'GB', 'JP', 'KR', 'DE', 'BR', 'CA', 'AU', 'FR'];

        for (let i = typedEntries.length + 1; i <= 100; i++) {
          const code = countryCodes[i % countryCodes.length];
          typedEntries.push({
            name: `Viper_Challenger_${i}`,
            bankedChips: Math.max(50000, Math.floor(10000000 - i * 95000 + Math.random() * 20000)),
            level: Math.max(5, 50 - Math.floor(i / 2.2)),
            country: code,
            rank: i,
            avatar: flags[i % flags.length],
            isPlayer: false
          });
        }
      }

      typedEntries.sort((a, b) => b.bankedChips - a.bankedChips);
      const finalRanked = typedEntries.map((e, idx) => ({
        ...e,
        rank: idx + 1,
        achievedAt: e.achievedAt || generateAchievedTimestamp(idx + 1)
      }));
      setLiveLeaderboard(finalRanked);
    });

    return () => unsubscribe();
  }, [playerStats.bankedChips, playerStats.name, playerStats.level, playerStats.country, playerStats.userTag]);

  // LEVEL 3: Aggregates ONLY the single #1 player from each country
  const getWorldSummitChampions = (): CountryChampion[] => {
    const championsMap: { [country: string]: LeaderboardEntry } = {};

    liveLeaderboard.forEach((entry) => {
      const country = entry.country || 'IN';
      if (!championsMap[country] || entry.bankedChips > championsMap[country].bankedChips) {
        championsMap[country] = entry;
      }
    });

    COUNTRIES_LIST.forEach((c, idx) => {
      if (!championsMap[c.code]) {
        championsMap[c.code] = {
          name: `Apex_${c.code}_Leader`,
          bankedChips: 10000000 - idx * 450000,
          level: 50 - idx,
          country: c.code,
          rank: idx + 1,
          avatar: c.flag,
          isPlayer: false
        };
      }
    });

    const list = Object.entries(championsMap).map(([code, entry]) => {
      const countryObj = COUNTRIES_LIST.find((c) => c.code === code) || { name: code, flag: '🌐' };
      return {
        countryCode: code,
        countryName: countryObj.name,
        flag: countryObj.flag,
        playerName: entry.name,
        userTag: `#${code}-001`,
        bankedChips: entry.bankedChips,
        level: entry.level,
        avatar: entry.avatar || countryObj.flag,
        globalRank: 0
      };
    });

    list.sort((a, b) => b.bankedChips - a.bankedChips);
    return list.map((c, i) => ({ ...c, globalRank: i + 1 }));
  };

  const worldSummitList = getWorldSummitChampions();

  // LEVEL 2: National Leaderboard filtered by selected country
  const nationalList = liveLeaderboard
    .filter((entry) => entry.country === selectedCountryCode || entry.isPlayer)
    .filter((e) => searchQuery === '' || e.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .map((e, idx) => ({ ...e, rank: idx + 1 }));

  // LEVEL 1: Milestone Tier Leaderboard
  const selectedTierObj = MILESTONE_TIERS.find((t) => t.id === selectedMilestoneTierId) || MILESTONE_TIERS[0];
  const milestoneList = liveLeaderboard
    .filter((entry) => {
      if (selectedMilestoneTierId === 'all') return true;
      return entry.bankedChips >= selectedTierObj.minChips;
    })
    .filter((e) => searchQuery === '' || e.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .map((e, idx) => ({ ...e, tierRank: idx + 1 }));

  return (
    <div id="leaderboard-panel" className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-2xl relative overflow-hidden space-y-5">
      {/* Background neon style */}
      <div className="absolute top-0 right-0 w-36 h-36 bg-amber-500/5 rounded-full blur-3xl pointer-events-none" />

      {/* Notice Banner for 2026 Season and 30-min auto updates */}
      <div className="bg-gradient-to-r from-amber-500/15 via-yellow-500/10 to-indigo-500/15 border border-amber-500/30 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 shadow-inner">
        <div className="flex items-center gap-2 text-xs font-mono font-bold text-amber-300">
          <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
          <span>CURRENT YEAR (2026) CONCURRENT TOURNAMENT HIERARCHY</span>
        </div>
        <div className="flex items-center gap-1.5 text-[10px] font-mono font-bold text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-full shrink-0">
          <Zap className="w-3 h-3 text-emerald-400" /> Live Ranks Update Every 30 Minutes
        </div>
      </div>

      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold font-sans tracking-tight text-white flex items-center gap-2">
            <Trophy className="w-5 h-5 text-amber-400" /> Official World Tournament Leaderboards
          </h2>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Complete real-time standings for Level 1 (Milestone Tiers), Level 2 (National Boards), and Level 3 (World Summit). Click any player row to inspect full profile & rank status!
          </p>
        </div>

        {/* Level Navigation Tabs */}
        <div className="flex flex-wrap bg-slate-950 p-1 rounded-xl border border-slate-800/80 shrink-0">
          <button
            onClick={() => setLevelTab('level3_world')}
            className={`px-3 py-1.5 rounded-lg text-xs font-sans font-bold flex items-center gap-1.5 transition-all ${
              levelTab === 'level3_world'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Crown className="w-3.5 h-3.5 text-yellow-400" /> Level 3: World Summit & Global
          </button>
          <button
            onClick={() => setLevelTab('level2_national')}
            className={`px-3 py-1.5 rounded-lg text-xs font-sans font-bold flex items-center gap-1.5 transition-all ${
              levelTab === 'level2_national'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-indigo-400" /> Level 2: National Boards
          </button>
          <button
            onClick={() => setLevelTab('level1_milestone')}
            className={`px-3 py-1.5 rounded-lg text-xs font-sans font-bold flex items-center gap-1.5 transition-all ${
              levelTab === 'level1_milestone'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Medal className="w-3.5 h-3.5 text-emerald-400" /> Level 1: Milestone Tier Ranks
          </button>
        </div>
      </div>

      {/* LEVEL 3: WORLD LEADERBOARD SUMMIT & GLOBAL */}
      {levelTab === 'level3_world' && (
        <div className="space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950 p-3 rounded-xl border border-slate-800">
            <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-800">
              <button
                onClick={() => setLevel3SubTab('summit')}
                className={`px-3 py-1 rounded text-xs font-bold font-sans flex items-center gap-1.5 transition-all ${
                  level3SubTab === 'summit'
                    ? 'bg-amber-500 text-black shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Crown className="w-3.5 h-3.5" /> #1 Country Champions (World Summit)
              </button>
              <button
                onClick={() => setLevel3SubTab('global')}
                className={`px-3 py-1 rounded text-xs font-bold font-sans flex items-center gap-1.5 transition-all ${
                  level3SubTab === 'global'
                    ? 'bg-amber-500 text-black shadow'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Globe className="w-3.5 h-3.5" /> All Players Global Rankings (Rank #1 to N)
              </button>
            </div>

            <div className="text-xs font-mono text-slate-400">
              Total Global Competitors: <strong className="text-amber-400">{liveLeaderboard.length} Players</strong>
            </div>
          </div>

          {level3SubTab === 'summit' ? (
            <div className="space-y-3">
              <div className="p-3.5 bg-amber-950/20 border border-amber-500/30 rounded-xl text-xs text-amber-200 flex items-center gap-3">
                <Crown className="w-5 h-5 text-yellow-400 shrink-0" />
                <span>
                  <strong>WORLD CUP SUMMIT MECHANIC:</strong> This master leaderboard aggregates <strong>ONLY the #1 Ranked Player</strong> from each country. Dec 31 midnight UTC #1 wins the World Championship!
                </span>
              </div>

              <div className="bg-slate-950/80 border border-slate-800/60 rounded-xl overflow-hidden shadow-xl">
                <div className="grid grid-cols-12 gap-2 px-5 py-3 border-b border-slate-800/80 bg-slate-950 text-slate-500 font-sans text-[10px] font-bold uppercase tracking-wider">
                  <div className="col-span-2">Global Rank</div>
                  <div className="col-span-4">Country #1 Champion</div>
                  <div className="col-span-3 text-center">Nation</div>
                  <div className="col-span-3 text-right">Banked Chips</div>
                </div>

                <div className="divide-y divide-slate-900 max-h-96 overflow-y-auto">
                  {worldSummitList.map((champ) => {
                    const isWinner = champ.globalRank === 1;
                    return (
                      <div
                        key={champ.countryCode}
                        onClick={() => handleInspect(champ)}
                        className={`grid grid-cols-12 gap-2 items-center px-5 py-3 text-sm font-sans transition-colors cursor-pointer hover:bg-slate-900/60 ${
                          isWinner ? 'bg-amber-500/15 border-y border-amber-500/30' : ''
                        }`}
                      >
                        <div className="col-span-2 flex items-center gap-2">
                          {isWinner ? (
                            <span className="flex items-center gap-1 font-bold text-yellow-400 font-mono">
                              <Crown className="w-4 h-4 text-yellow-400" /> #1
                            </span>
                          ) : (
                            <span className="font-mono text-slate-400 font-bold">#{champ.globalRank}</span>
                          )}
                        </div>

                        <div className="col-span-4 flex items-center gap-2">
                          <span className="text-base select-none">{champ.flag}</span>
                          <span className="font-bold text-white truncate">{champ.playerName}</span>
                        </div>

                        <div className="col-span-3 text-center text-xs text-slate-400 font-sans">
                          {champ.countryName}
                        </div>

                        <div className="col-span-3 text-right font-mono font-bold text-emerald-400">
                          {champ.bankedChips.toLocaleString()} c
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-slate-950/80 border border-slate-800/60 rounded-xl overflow-hidden shadow-xl">
              <div className="grid grid-cols-12 gap-2 px-5 py-3 border-b border-slate-800/80 bg-slate-950 text-slate-500 font-sans text-[10px] font-bold uppercase tracking-wider">
                <div className="col-span-2">Global Rank</div>
                <div className="col-span-5">Player & User Tag</div>
                <div className="col-span-2 text-center">Milestone Badge</div>
                <div className="col-span-3 text-right">Banked Chips</div>
              </div>

              <div className="divide-y divide-slate-900 max-h-96 overflow-y-auto">
                {liveLeaderboard.map((entry) => {
                  const tierInfo = getTierInfo(entry.bankedChips);
                  return (
                    <div
                      key={`${entry.name}-${entry.rank}`}
                      onClick={() => handleInspect(entry)}
                      className={`grid grid-cols-12 gap-2 items-center px-5 py-3 text-sm font-sans transition-colors cursor-pointer ${
                        entry.isPlayer ? 'bg-amber-500/10 text-amber-100 font-semibold border-y border-amber-500/20' : 'hover:bg-slate-900/40 text-slate-300'
                      }`}
                    >
                      <div className="col-span-2 flex items-center gap-1 font-mono text-slate-400">
                        {entry.rank === 1 ? (
                          <span className="text-yellow-400 font-bold flex items-center gap-1">👑 #1</span>
                        ) : entry.rank <= 3 ? (
                          <span className="text-slate-200 font-bold">🥈 #{entry.rank}</span>
                        ) : (
                          <span>#{entry.rank}</span>
                        )}
                        {entry.isPlayer && (
                          <span className="text-[9px] bg-amber-500 text-black px-1 rounded font-bold font-sans">YOU</span>
                        )}
                      </div>

                      <div className="col-span-5 flex items-center gap-2.5">
                        <span className="text-base select-none">{COUNTRIES_LIST.find((c) => c.code === entry.country)?.flag || '🌐'}</span>
                        <div>
                          <div className="font-bold text-white truncate">{entry.name}</div>
                          <div className="text-[10px] font-mono text-slate-400 flex items-center gap-1.5">
                            <span>#{entry.country || 'IN'}-00{entry.rank}</span>
                            <span>•</span>
                            <span className="text-cyan-400/90 font-mono">🕒 {entry.achievedAt || generateAchievedTimestamp(entry.rank)}</span>
                          </div>
                        </div>
                      </div>

                      <div className="col-span-2 text-center text-xs font-mono font-bold">
                        <span className={`px-2 py-0.5 rounded bg-slate-900 border border-slate-800 ${tierInfo.color}`}>
                          {tierInfo.badge}
                        </span>
                      </div>

                      <div className="col-span-3 text-right font-mono font-bold text-emerald-400">
                        {entry.bankedChips.toLocaleString()} c
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* LEVEL 2: NATIONAL COUNTRY LEADERBOARD */}
      {levelTab === 'level2_national' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-4 flex-wrap bg-slate-950 p-3.5 rounded-xl border border-slate-800">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-300 font-sans flex items-center gap-1.5">
                <Globe className="w-4 h-4 text-indigo-400" /> Select Country Leaderboard (197 Supported):
              </span>
              <select
                value={selectedCountryCode}
                onChange={(e) => setSelectedCountryCode(e.target.value)}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-sans font-bold focus:outline-none focus:border-indigo-500 cursor-pointer"
              >
                {COUNTRIES_LIST.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.flag} {c.name} ({c.code})
                  </option>
                ))}
              </select>
            </div>

            {/* Search Input */}
            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5" />
              <input
                type="text"
                placeholder="Search player in country..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="bg-slate-950/80 border border-slate-800/60 rounded-xl overflow-hidden shadow-xl">
            <div className="grid grid-cols-12 gap-2 px-5 py-3 border-b border-slate-800/80 bg-slate-950 text-slate-500 font-sans text-[10px] font-bold uppercase tracking-wider">
              <div className="col-span-2">National Rank</div>
              <div className="col-span-5">Local Challenger</div>
              <div className="col-span-2 text-center">Level</div>
              <div className="col-span-3 text-right">Banked Chips</div>
            </div>

            <div className="divide-y divide-slate-900 max-h-96 overflow-y-auto">
              {nationalList.map((entry) => (
                <div
                  key={`${entry.name}-${entry.rank}`}
                  onClick={() => handleInspect(entry)}
                  className={`grid grid-cols-12 gap-2 items-center px-5 py-3.5 text-sm font-sans transition-colors cursor-pointer ${
                    entry.isPlayer ? 'bg-amber-500/10 text-amber-100 font-semibold border-y border-amber-500/20' : 'hover:bg-slate-900/40 text-slate-300'
                  }`}
                >
                  <div className="col-span-2 flex items-center gap-1 font-mono text-slate-400 font-bold">
                    #{entry.rank}
                    {entry.isPlayer && (
                      <span className="text-[9px] bg-amber-500 text-black px-1 rounded font-bold font-sans">YOU</span>
                    )}
                  </div>

                  <div className="col-span-5 flex items-center gap-2.5">
                    <span className="text-base select-none">{COUNTRIES_LIST.find((c) => c.code === entry.country)?.flag || '🌐'}</span>
                    <div>
                      <span className="font-medium text-white truncate block">{entry.name}</span>
                      <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1.5">
                        <span>#{entry.country}-00{entry.rank}</span>
                        <span>•</span>
                        <span className="text-cyan-400/90 font-mono">🕒 {entry.achievedAt || generateAchievedTimestamp(entry.rank)}</span>
                      </span>
                    </div>
                  </div>

                  <div className="col-span-2 text-center font-mono text-slate-300 text-xs">
                    Lvl {entry.level}
                  </div>

                  <div className="col-span-3 text-right font-mono font-bold text-emerald-400">
                    {entry.bankedChips.toLocaleString()} c
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* LEVEL 1: MILESTONE TIER LEADERBOARDS (COMPLETE RANKINGS FROM 1 TO INFINITE) */}
      {levelTab === 'level1_milestone' && (
        <div className="space-y-4">
          <div className="p-3.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 font-sans flex items-center justify-between flex-wrap gap-2">
            <div>
              <strong>LEVEL 1 MILESTONE TIER RANKING BOARD:</strong> All players who have reached each chip milestone are ranked from #1 to all joined competitors! Click any player to inspect profile & dossier.
            </div>
          </div>

          {/* Milestone Selector Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {MILESTONE_TIERS.map((tier) => (
              <button
                key={tier.id}
                onClick={() => setSelectedMilestoneTierId(tier.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-sans font-bold shrink-0 transition-all border ${
                  selectedMilestoneTierId === tier.id
                    ? 'bg-amber-500 text-black border-amber-400 shadow-lg scale-105'
                    : 'bg-slate-950 text-slate-400 border-slate-800 hover:text-white'
                }`}
              >
                {tier.badge}
              </button>
            ))}
          </div>

          {/* Milestone Tier Rankings Table */}
          <div className="bg-slate-950/80 border border-slate-800/60 rounded-xl overflow-hidden shadow-xl">
            <div className="grid grid-cols-12 gap-2 px-5 py-3 border-b border-slate-800/80 bg-slate-950 text-slate-500 font-sans text-[10px] font-bold uppercase tracking-wider">
              <div className="col-span-2">Tier Rank</div>
              <div className="col-span-5">Player Name & User Tag</div>
              <div className="col-span-2 text-center">Country</div>
              <div className="col-span-3 text-right">Banked Chips</div>
            </div>

            <div className="divide-y divide-slate-900 max-h-96 overflow-y-auto">
              {milestoneList.map((entry) => {
                const tierInfo = getTierInfo(entry.bankedChips);
                return (
                  <div
                    key={`${entry.name}-${entry.tierRank}`}
                    onClick={() => handleInspect(entry)}
                    className={`grid grid-cols-12 gap-2 items-center px-5 py-3.5 text-sm font-sans transition-colors cursor-pointer ${
                      entry.isPlayer ? 'bg-amber-500/10 text-amber-100 font-semibold border-y border-amber-500/20' : 'hover:bg-slate-900/40 text-slate-300'
                    }`}
                  >
                    <div className="col-span-2 flex items-center gap-1 font-mono text-amber-400 font-bold">
                      {entry.tierRank === 1 ? (
                        <span className="text-yellow-400 flex items-center gap-1 font-bold">👑 #1</span>
                      ) : (
                        <span>#{entry.tierRank}</span>
                      )}
                      {entry.isPlayer && (
                        <span className="text-[9px] bg-amber-500 text-black px-1 rounded font-bold font-sans">YOU</span>
                      )}
                    </div>

                    <div className="col-span-5 flex items-center gap-2.5">
                      <span className="text-base select-none">{COUNTRIES_LIST.find((c) => c.code === entry.country)?.flag || '🌐'}</span>
                      <div>
                        <span className="font-bold text-white truncate block">{entry.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono flex items-center gap-1.5">
                          <span>#{entry.country || 'IN'}-00{entry.tierRank}</span>
                          <span>•</span>
                          <span className="text-cyan-400/90 font-mono">🕒 {entry.achievedAt || generateAchievedTimestamp(entry.tierRank)}</span>
                        </span>
                      </div>
                    </div>

                    <div className="col-span-2 text-center text-xs font-mono font-bold">
                      <span className={`px-2 py-0.5 rounded bg-slate-900 border border-slate-800 ${tierInfo.color}`}>
                        {tierInfo.badge}
                      </span>
                    </div>

                    <div className="col-span-3 text-right font-mono font-bold text-emerald-400">
                      {entry.bankedChips.toLocaleString()} c
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* INSPECTED PLAYER MODAL */}
      {selectedInspectedPlayer && (
        <PlayerInspectorModal
          player={selectedInspectedPlayer}
          onClose={() => setSelectedInspectedPlayer(null)}
          onToast={(msg) => alert(msg)}
        />
      )}
    </div>
  );
}

