import { 
  collection, doc, setDoc, updateDoc, onSnapshot, query, orderBy, limit, 
  addDoc, serverTimestamp, getDocs, getDoc, arrayUnion, arrayRemove
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';
import { PlayerStats, Friend, Clan, ClanMessage, ClanMember } from '../types';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Helper to convert Firestore timestamp to human-readable string
const formatTimestamp = (ts: any): string => {
  if (!ts) return 'Just now';
  const date = ts.toDate ? ts.toDate() : new Date(ts);
  const diffMs = Date.now() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  return date.toLocaleDateString();
};

/**
 * Sync Player Profile & Leaderboard Metrics in real-time.
 */
export async function syncPlayerProfile(stats: PlayerStats) {
  if (!stats.userTag) return;
  const path = `players/${stats.userTag}`;
  const playerRef = doc(db, 'players', stats.userTag);
  try {
    await setDoc(playerRef, {
      name: stats.name || 'Striker',
      userTag: stats.userTag,
      level: stats.level || 1,
      xp: stats.xp || 0,
      bankedChips: stats.bankedChips || 0,
      lifetimeKills: stats.lifetimeKills || 0,
      lifetimeDeaths: stats.lifetimeDeaths || 0,
      lifetimeExtracts: stats.lifetimeExtracts || 0,
      bestStreak: stats.bestStreak || 0,
      biggestExtract: stats.biggestExtract || 0,
      totalChipsEarned: stats.totalChipsEarned || 0,
      totalChipsLost: stats.totalChipsLost || 0,
      currentSkin: stats.currentSkin || 'skin-default',
      country: stats.country || 'US',
      avatar: stats.avatar || null,
      clanId: stats.clanId || null,
      clanRank: stats.clanRank || null,
      championshipRank: stats.championshipRank || 999,
      updatedAt: serverTimestamp()
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Retrieve the latest player profile stats directly from Firestore.
 */
export async function fetchPlayerProfile(userTag: string): Promise<PlayerStats | null> {
  if (!userTag) return null;
  try {
    const playerRef = doc(db, 'players', userTag);
    const docSnap = await getDoc(playerRef);
    if (docSnap.exists()) {
      return docSnap.data() as PlayerStats;
    }
  } catch (error) {
    console.error("Failed to fetch player profile from Firestore:", error);
  }
  return null;
}

/**
 * Listen to real-time competitive Leaderboard entries.
 */
export function subscribeToLeaderboard(callback: (entries: any[]) => void) {
  const path = 'players';
  const q = query(
    collection(db, 'players'),
    orderBy('bankedChips', 'desc'),
    limit(50)
  );

  return onSnapshot(q, (snapshot) => {
    const entries: any[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data();
      entries.push({
        name: data.name,
        bankedChips: data.bankedChips,
        level: data.level,
        country: data.country || 'US',
        userTag: data.userTag,
        avatar: data.avatar || null,
        clanId: data.clanId || null,
        rank: 0 // Will be set sequentially in frontend
      });
    });
    callback(entries);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
  });
}

/**
 * Register Active Multiplayer Game Session (so friends see X is 'in-match: Neon Grid' live)
 */
export async function registerActiveSession(
  userTag: string, 
  name: string, 
  level: number, 
  skinColor: string,
  arenaName: string, 
  status: 'online' | 'offline' | 'in-match'
) {
  if (!userTag) return;
  const path = `active_sessions/${userTag}`;
  const sessionRef = doc(db, 'active_sessions', userTag);
  try {
    if (status === 'offline') {
      await setDoc(sessionRef, {
        userTag,
        name,
        level,
        skinColor,
        status: 'offline',
        arenaName: '',
        updatedAt: serverTimestamp()
      }, { merge: true });
    } else {
      await setDoc(sessionRef, {
        userTag,
        name,
        level,
        skinColor,
        status,
        arenaName: status === 'in-match' ? arenaName : '',
        updatedAt: serverTimestamp()
      }, { merge: true });
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Subscribe to all online player sessions in real-time.
 */
export function subscribeToActiveSessions(callback: (sessions: Record<string, any>) => void) {
  const path = 'active_sessions';
  const q = query(collection(db, 'active_sessions'));
  return onSnapshot(q, (snapshot) => {
    const sessions: Record<string, any> = {};
    snapshot.forEach((doc) => {
      sessions[doc.id] = doc.data();
    });
    callback(sessions);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
  });
}

/**
 * Log Matches globally to a centralized matches ledger.
 */
export async function logMatchOutcome(match: {
  id: string;
  arenaName: string;
  isOnline: boolean;
  status: 'EXTRACTED' | 'COLLIDED';
  chipsEarned: number;
  chipsLost: number;
  kills: number;
  snakeLength: number;
  playerName: string;
  playerTag: string;
}) {
  const path = `matches/${match.id}`;
  try {
    const matchRef = doc(db, 'matches', match.id);
    await setDoc(matchRef, {
      ...match,
      timestamp: new Date().toISOString(),
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Listen to live Match Operations (Ticker / Global Activity Feed).
 */
export function subscribeToLiveMatches(callback: (matches: any[]) => void) {
  const path = 'matches';
  const q = query(
    collection(db, 'matches'),
    orderBy('createdAt', 'desc'),
    limit(20)
  );
  return onSnapshot(q, (snapshot) => {
    const matchesList: any[] = [];
    snapshot.forEach((doc) => {
      matchesList.push(doc.data());
    });
    callback(matchesList);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
  });
}

/**
 * Clan Syndicates (Real-time shared groups, rosters and banking vaults).
 */
export function subscribeToClans(callback: (clans: Clan[]) => void) {
  const path = 'clans';
  const q = query(collection(db, 'clans'));
  return onSnapshot(q, (snapshot) => {
    const clansList: Clan[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data();
      clansList.push({
        id: doc.id,
        name: data.name,
        tag: data.tag,
        emblem: data.emblem || '🐍',
        level: data.level || 1,
        xp: data.xp || 0,
        bankedChips: data.bankedChips || 0,
        description: data.description || '',
        members: data.members || [],
        maxMembers: data.maxMembers || 20
      });
    });
    callback(clansList);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
  });
}

export async function createOrUpdateClan(clan: Clan) {
  const path = `clans/${clan.id}`;
  const clanRef = doc(db, 'clans', clan.id);
  try {
    await setDoc(clanRef, {
      name: clan.name,
      tag: clan.tag,
      emblem: clan.emblem,
      level: clan.level,
      xp: clan.xp,
      bankedChips: clan.bankedChips,
      description: clan.description,
      members: clan.members,
      maxMembers: clan.maxMembers,
      updatedAt: serverTimestamp()
    }, { merge: true });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

/**
 * Subscribe to a Clan's Real-time Syndicate Chat messages.
 */
export function subscribeToClanMessages(clanId: string, callback: (messages: ClanMessage[]) => void) {
  const path = `clans/${clanId}/messages`;
  const q = query(
    collection(db, path),
    orderBy('createdAt', 'asc'),
    limit(50)
  );

  return onSnapshot(q, (snapshot) => {
    const messages: ClanMessage[] = [];
    snapshot.forEach((doc) => {
      const data = doc.data();
      messages.push({
        id: doc.id,
        sender: data.sender,
        senderRank: data.senderRank,
        message: data.message,
        timestamp: formatTimestamp(data.createdAt)
      });
    });
    callback(messages);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
  });
}

export async function sendClanMessage(clanId: string, message: {
  sender: string;
  senderRank: string;
  message: string;
}) {
  const path = `clans/${clanId}/messages`;
  try {
    await addDoc(collection(db, path), {
      ...message,
      createdAt: serverTimestamp()
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}
