/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

class GameAudio {
  private ctx: AudioContext | null = null;
  public isMuted: boolean = false;
  private droneInterval: any = null;
  private droneStep: number = 0;
  private isMusicPlaying: boolean = false;
  public dangerLevel: number = 1; // scale 1 to 3

  init() {
    if (this.isMuted) return;
    if (!this.ctx) {
      try {
        this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      } catch (e) {
        console.warn('Web Audio API not supported', e);
      }
    }
    // Resume if suspended (browsers block autoplay unless user interacts)
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  startMusic() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    if (this.isMusicPlaying) return;
    this.isMusicPlaying = true;

    // Start a rhythmic synth sequencer loop (cyberpunk atmosphere heartbeat)
    this.droneInterval = setInterval(() => {
      if (this.isMuted || !this.ctx) return;
      if (this.ctx.state === 'suspended') return;
      
      const now = this.ctx.currentTime;
      const step = this.droneStep % 8;
      
      // Dynamic base frequencies based on current tactical threat level
      // Base tones: Low E (41.2 Hz), Low G (49.0 Hz), Low A (55.0 Hz), Extreme (82.4 Hz)
      let baseFreq = 41.2;
      if (this.dangerLevel === 2) {
        baseFreq = 49.0;
      } else if (this.dangerLevel === 3) {
        baseFreq = 61.7; // extreme tension B1 note
      }
      
      // Pulsing low bass drone beats
      if (step === 0 || step === 2 || step === 4 || step === 6) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        const filter = this.ctx.createBiquadFilter();
        
        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);
        
        osc.type = 'sawtooth';
        
        // Dynamic octave and rhythm accenting
        let noteFreq = baseFreq;
        if (step === 4) noteFreq *= 1.5; // fifth accent
        if (this.dangerLevel === 3 && step === 6) noteFreq *= 2; // double frequency panic octave
        
        osc.frequency.setValueAtTime(noteFreq, now);
        
        // Retro low-pass cyber sweep
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(140, now);
        filter.frequency.exponentialRampToValueAtTime(380, now + 0.1);
        filter.frequency.exponentialRampToValueAtTime(80, now + 0.35);
        
        // Low volumes to keep it beautifully ambient and unobtrusive
        const volume = this.dangerLevel === 3 ? 0.05 : 0.035;
        gain.gain.setValueAtTime(volume, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
        
        osc.start(now);
        osc.stop(now + 0.45);
      }
      
      // Space ambient echo chirps/blips to fill the soundscape
      if ((this.dangerLevel >= 2 && step === 3) || step === 7) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        
        osc.type = 'triangle';
        const blipFreq = step === 3 ? 659.25 : 880.00;
        osc.frequency.setValueAtTime(blipFreq, now);
        osc.frequency.exponentialRampToValueAtTime(blipFreq / 2, now + 0.15);
        
        gain.gain.setValueAtTime(0.005, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
        
        osc.start(now);
        osc.stop(now + 0.18);
      }
      
      this.droneStep++;
    }, 280); // Fast pacing 280ms intervals
  }

  stopMusic() {
    this.isMusicPlaying = false;
    if (this.droneInterval) {
      clearInterval(this.droneInterval);
      this.droneInterval = null;
    }
  }

  setDangerLevel(level: number) {
    this.dangerLevel = Math.max(1, Math.min(3, level));
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.isMuted) {
      this.stopMusic();
    } else {
      this.startMusic();
    }
    return this.isMuted;
  }

  playEat() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.frequency.setValueAtTime(600, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(800, this.ctx.currentTime + 0.08);

    gain.gain.setValueAtTime(0.05, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.08);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.08);
  }

  playStar() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    
    // Play an ascending double beep
    const playTone = (freq: number, start: number, duration: number) => {
      if (this.isMuted || !this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.12, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + duration);

      osc.start(start);
      osc.stop(start + duration);
    };

    playTone(523.25, now, 0.12); // C5
    playTone(659.25, now + 0.08, 0.18); // E5
  }

  playBoost() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(100, this.ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(50, this.ctx.currentTime + 0.12);

    gain.gain.setValueAtTime(0.03, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.12);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.12);
  }

  playDeath() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(150, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(30, this.ctx.currentTime + 0.5);

    gain.gain.setValueAtTime(0.2, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.5);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.5);
  }

  playExtractTick() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.frequency.setValueAtTime(350, this.ctx.currentTime);
    gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.05);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.05);
  }

  playExtractSuccess() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    
    // Play victory chord C4 -> E4 -> G4 -> C5
    const playTone = (freq: number, start: number, duration: number) => {
      if (this.isMuted || !this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.12, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + duration);

      osc.start(start);
      osc.stop(start + duration);
    };

    playTone(261.63, now, 0.15); // C4
    playTone(329.63, now + 0.1, 0.15); // E4
    playTone(392.00, now + 0.2, 0.15); // G4
    playTone(523.25, now + 0.3, 0.4); // C5
  }

  playPowerUp() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    // Play a cyber power up arpeggio
    const playTone = (freq: number, start: number, duration: number) => {
      if (this.isMuted || !this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, start);
      gain.gain.setValueAtTime(0.15, start);
      gain.gain.exponentialRampToValueAtTime(0.001, start + duration);

      osc.start(start);
      osc.stop(start + duration);
    };

    playTone(440.00, now, 0.1); // A4
    playTone(554.37, now + 0.08, 0.1); // C#5
    playTone(659.25, now + 0.16, 0.1); // E5
    playTone(880.00, now + 0.24, 0.3); // A5
  }

  playShieldBreak() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.connect(gain);
    gain.connect(this.ctx.destination);

    // Metallic laser clash
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(800, this.ctx.currentTime);
    osc.frequency.linearRampToValueAtTime(100, this.ctx.currentTime + 0.35);

    gain.gain.setValueAtTime(0.25, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + 0.35);

    osc.start();
    osc.stop(this.ctx.currentTime + 0.35);
  }
}

export const gameAudio = new GameAudio();
