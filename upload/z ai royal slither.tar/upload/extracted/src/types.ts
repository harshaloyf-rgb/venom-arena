export interface Skin {
  id: string;
  name: string;
  cost: number;
  type: 'skin' | 'trail' | 'death' | 'flag' | 'banner' | 'head' | 'body' | 'tail';
  color: string;
  secondaryColor?: string;
  description: string;
  emoji?: string;
  pattern?: 'rainbow' | 'neon' | 'glow' | 'metallic' | 'pulse' | 'zebra' | 'camo' | 'cyber';
}

export interface ModularSkinConfig {
  headPiece: 'fish' | 'lion' | 'motorbike' | 'coin' | 'default';
  bodyPiece: 'scales' | 'fur' | 'engine' | 'coins' | 'default';
  tailPiece: 'fin' | 'tuft' | 'exhaust' | 'sparkles' | 'default';
  colorShader: string;
  eliminationEffect: 'gold_coins' | 'toxic_splash' | 'hypernova' | 'cyber_burst';
  useModular: boolean;
}

export interface PlayerSettings {
  controlType: 'dynamic-joystick' | 'static-joystick' | 'tap-to-move' | 'mouse-follow' | 'keyboard';
  turnSensitivity: number; // 1 to 10
  fpsCap: 30 | 60 | 120;
  detailLevel: 'high' | 'low';
  bgSmoke: boolean;
  glowingTrails: boolean;
  explosionParticles: boolean;
}

export interface TournamentHistoryItem {
  year: number;
  rank: number;
  country: string;
  title: string;
}

export interface TrophyShowcase {
  pinnedSkins: string[]; // up to 3 skin ids
  pinnedBadges: string[]; // up to 3 badge labels
  customTitle: string; // e.g. "Top 50 India", "World Cup Contender"
}

export interface CustomSegment {
  color: string;
  sizeScale: number; // 0.5 to 1.8
  shape: 'circle' | 'square' | 'diamond' | 'spike';
  glow: boolean;
}

export interface PlayerStats {
  name: string;
  level: number;
  xp: number;
  bankedChips: number;
  lifetimeKills: number;
  lifetimeDeaths: number;
  lifetimeExtracts: number;
  bestStreak: number;
  biggestExtract: number;
  totalChipsEarned: number;
  totalChipsLost: number;
  unlockedSkins: string[];
  currentSkin: string;
  currentTrail: string;
  currentDeath: string;
  currentFlag?: string;
  currentBanner?: string;
  customSkinColors?: string[];
  customSkinSegments?: CustomSegment[];
  useCustomSkin?: boolean;
  modularSkin?: ModularSkinConfig;
  settings?: PlayerSettings;
  trophyShowcase?: TrophyShowcase;
  tournamentHistory?: TournamentHistoryItem[];
  avgLifespanSeconds?: number;
  highestStolenInMatch?: number;
  matchesPlayedThisYear?: number; // Cap 10,000 / year
  yearlySpentINR?: number; // Cap ₹15,000 / year (~$175 USD)
  yearlyPurchasedChips?: number; // Cap 25 Lakh Chips / year (2,500,000 max)
  adsWatchedToday?: number; // Cap 12 / day
  lastAdResetDate?: string;
  dailyStreak: number;
  lastDailyClaim: string | null;
  championshipRank: number;
  title?: string;
  userTag: string; // e.g. #VENOM-8291
  clanId: string | null; // null if not in a clan
  clanTag?: string; // e.g. APEX, NINJA
  clanRank?: 'Leader' | 'Co-Leader' | 'Viper';
  country?: string;
  avatar?: string;
  lastIdentityChange?: string; // ISO timestamp of the last name or country change
  // Social Handles & Posts
  instagram?: string;
  youtube?: string;
  twitch?: string;
  contentPosts?: PlayerContentPost[];
  blockedUsers?: string[];
  friendRequestsSent?: string[];
  rivals?: Rival[];
}

export interface Rival {
  id: string;
  name: string;
  userTag: string;
  status: 'online' | 'offline' | 'in-match' | 'idle';
  currentArenaId?: string;
  currentArenaName?: string;
  level: number;
  skinColor: string;
  timesKilledByYou: number;
  timesKilledYou: number;
  lastEncounterDate?: string;
}

export interface PlayerContentPost {
  id: string;
  title: string;
  url: string;
  timestamp: string;
  likes: number;
}

export interface HallOfFameMilestone {
  id: string;
  title: string; // e.g. "First 1 Crore Chip Wallet Balance"
  playerName: string;
  userTag: string;
  country: string;
  flag: string;
  dateStr: string; // e.g. "23 Jan 2027, 5:00 PM WST"
  chipRecord?: string;
  category: 'wallet' | 'extraction' | 'streak' | 'championship';
  avatar?: string;
}

export interface HallOfFameChampionshipRecord {
  year: number;
  worldChampion: {
    name: string;
    country: string;
    flag: string;
    chips: number;
    userTag: string;
  };
  runnerUp: {
    name: string;
    country: string;
    flag: string;
    chips: number;
  };
  totalParticipants: string;
  prizePoolDesc: string;
}

export interface LiveCommentaryMessage {
  id: string;
  timestamp: string;
  text: string;
  type: 'extraction' | 'elimination' | 'milestone' | 'high_stakes' | 'world_cup';
  playerName?: string;
  country?: string;
  flag?: string;
}

export interface CountryChampion {
  countryCode: string;
  countryName: string;
  flag: string;
  playerName: string;
  userTag: string;
  bankedChips: number;
  level: number;
  avatar?: string;
  globalRank: number;
}

export interface SupportTicket {
  id: string;
  userTag: string;
  userName: string;
  country: string;
  issueType: 'store_purchase' | 'disconnect_loss' | 'gameplay_bug' | 'offensive_player';
  receiptId?: string;
  chipAmount?: number;
  message: string;
  status: 'OPEN' | 'RESOLVED' | 'REFUNDED';
  timestamp: string;
}

export interface FlaggedPlayer {
  id: string;
  userTag: string;
  userName: string;
  country: string;
  reason: 'speed_hack' | 'teleportation' | 'modified_client' | 'offensive_skin';
  speedLogged: string;
  status: 'FLAGGED' | 'BANNED' | 'DISMISSED';
  timestamp: string;
}

export interface Friend {
  id: string;
  name: string;
  userTag: string;
  status: 'online' | 'offline' | 'in-match' | 'idle';
  currentArenaId?: string;
  currentArenaName?: string;
  level: number;
  skinColor: string;
  giftSentToday: boolean;
  giftReceivedToday: boolean;
}

export interface ClanMember {
  id: string;
  name: string;
  userTag: string;
  rank: 'Leader' | 'Co-Leader' | 'Viper';
  level: number;
  totalContributedChips: number;
  isOnline: boolean;
}

export interface Clan {
  id: string;
  name: string;
  tag: string;
  emblem: string; // Emoji representing emblem
  level: number;
  xp: number;
  bankedChips: number;
  description: string;
  members: ClanMember[];
  maxMembers: number;
}

export interface ClanMessage {
  id: string;
  sender: string;
  senderRank: string;
  message: string;
  timestamp: string;
}


export interface ArenaTier {
  id: string;
  name: string;
  buyIn: number;
  description: string;
  difficulty: 'Beginner' | 'Medium' | 'High Stakes' | 'Extreme' | 'Legendary';
  color: string; // Tailwind class
  accentColor: string; // hex
  borderAccent: string; // hex
  minExtract: number;
  botsCount: number;
  rewardMultiplier: number;
}

export interface SnakePoint {
  x: number;
  y: number;
}

export interface Snake {
  id: string;
  name: string;
  points: SnakePoint[];
  angle: number;
  targetAngle: number;
  speed: number;
  size: number;
  color: string;
  secondaryColor?: string;
  trailColor?: string;
  isBot: boolean;
  botType?: 'scavenger' | 'opportunist' | 'hunter' | 'extractor' | 'coward' | 'ally';
  carriedChips: number;
  isExtracting: boolean;
  extractionProgress: number; // 0 to 3000ms
  score: number;
  isDead: boolean;
  isPlayer?: boolean;
  chatMessage?: string;
  chatTimer?: number;
  spawnProtectedTimer?: number;
  targetPoints?: SnakePoint[];
}

export interface Food {
  id: string;
  x: number;
  y: number;
  size: number;
  value: number;
  isStarChip: boolean; // Special high-stakes chip dropped by players
  color: string;
}

export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
  maxLife: number;
}

export interface Mission {
  id: string;
  title: string;
  description: string;
  reward: number;
  target: number;
  current: number;
  completed: boolean;
}

export interface LeaderboardEntry {
  name: string;
  bankedChips: number;
  level: number;
  country: string;
  rank: number;
  avatar?: string;
  isPlayer?: boolean;
  achievedAt?: string;
}
