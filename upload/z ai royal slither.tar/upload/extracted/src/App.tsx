import { useState, useEffect } from 'react';
import { Landmark, Compass, Shield, User, Trophy, Gift, ShoppingBag, Coins, Sparkles, X, Check, Flame, Swords, Users, ChevronLeft, ChevronRight, Play, Globe, Zap, ListTodo, Award, LogOut, Film, BookOpen, Crown } from 'lucide-react';
import { PlayerStats, ArenaTier, Mission } from './types';
import { DEFAULT_PLAYER_STATS, INITIAL_MISSIONS, ARENA_TIERS } from './data';
import ArenaSelector from './components/ArenaSelector';
import CosmeticsShop from './components/CosmeticsShop';
import PlayerProfile from './components/PlayerProfile';
import Leaderboards from './components/Leaderboards';
import DailyRewards from './components/DailyRewards';
import GameCanvas from './components/GameCanvas';
import ChipStore from './components/ChipStore';
import SocialPanel from './components/SocialPanel';
import AdminPanel from './components/AdminPanel';
import HallOfFame from './components/HallOfFame';
import PlayerInspectorModal, { InspectedPlayer } from './components/PlayerInspectorModal';
import ClanSystem from './components/ClanSystem';
import ClipShowcase from './components/ClipShowcase';
import SeasonPass from './components/SeasonPass';
import Championships from './components/Championships';
import { GameRulesModal } from './components/GameRulesModal';
import { syncPlayerProfile, registerActiveSession, fetchPlayerProfile } from './utils/firebaseSync';
import AuthGate from './components/AuthGate';

interface ToastMessage {
  id: string;
  msg: string;
  type: 'success' | 'info' | 'error';
}

export default function App() {
  // --- STATE PERSISTENCE ENGINE ---
  const [playerStats, setPlayerStats] = useState<PlayerStats>(() => {
    const saved = localStorage.getItem('venom_arena_player_stats_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DEFAULT_PLAYER_STATS;
      }
    }
    return DEFAULT_PLAYER_STATS;
  });

  const [missions, setMissions] = useState<Mission[]>(() => {
    const saved = localStorage.getItem('venom_arena_missions_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_MISSIONS;
      }
    }
    return INITIAL_MISSIONS;
  });

  const [activeTab, setActiveTab] = useState<'dashboard' | 'arena' | 'shop' | 'profile' | 'leaderboard' | 'halloffame' | 'clans' | 'championships' | 'seasonpass' | 'clips' | 'rewards' | 'store' | 'social' | 'admin'>('dashboard');
  const [arenaSelectionMode, setArenaSelectionMode] = useState<'select-type' | 'active-selector'>('select-type');
  const [preSelectedOnline, setPreSelectedOnline] = useState<boolean>(true);
  const [activeArena, setActiveArena] = useState<ArenaTier | null>(null);
  const [activeIsOnline, setActiveIsOnline] = useState(true);
  const [spectateTarget, setSpectateTarget] = useState<{ name: string; color: string; } | null>(null);
  const [inspectedPlayer, setInspectedPlayer] = useState<InspectedPlayer | null>(null);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return !!localStorage.getItem('venom_jwt');
  });

  // Sync player metrics to local storage on modification
  useEffect(() => {
    localStorage.setItem('venom_arena_player_stats_v1', JSON.stringify(playerStats));
    if (isAuthenticated) {
      syncPlayerProfile(playerStats);
    }
  }, [playerStats, isAuthenticated]);

  useEffect(() => {
    localStorage.setItem('venom_arena_missions_v1', JSON.stringify(missions));
  }, [missions]);

  // Sync user's real-time match/online status to Firestore active_sessions
  useEffect(() => {
    if (!isAuthenticated) return;
    const status = activeArena ? 'in-match' : 'online';
    const arenaName = activeArena ? activeArena.name : '';
    const primaryColor = playerStats.useCustomSkin && playerStats.customSkinColors && playerStats.customSkinColors.length > 0
      ? playerStats.customSkinColors[0]
      : '#4f46e5';

    registerActiveSession(
      playerStats.userTag,
      playerStats.name,
      playerStats.level,
      primaryColor,
      arenaName,
      status
    );

    const handleBeforeUnload = () => {
      registerActiveSession(
        playerStats.userTag,
        playerStats.name,
        playerStats.level,
        primaryColor,
        arenaName,
        'offline'
      );
    };

    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => {
      window.removeEventListener('beforeunload', handleBeforeUnload);
      handleBeforeUnload();
    };
  }, [playerStats.userTag, playerStats.name, playerStats.level, playerStats.customSkinColors, playerStats.useCustomSkin, activeArena, isAuthenticated]);

  // --- TOAST NOTIFICATIONS MANAGER ---
  const triggerToast = (msg: string, type: 'success' | 'info' | 'error' = 'info') => {
    const id = Math.random().toString();
    setToasts((prev) => [...prev, { id, msg, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const handleUpdateStats = (statsUpdate: Partial<PlayerStats>) => {
    setPlayerStats((prev) => {
      const updated = { ...prev, ...statsUpdate };
      return updated;
    });
  };

  const handleLogout = () => {
    // Sync offline status first
    if (playerStats.userTag) {
      const primaryColor = playerStats.useCustomSkin && playerStats.customSkinColors && playerStats.customSkinColors.length > 0
        ? playerStats.customSkinColors[0]
        : '#4f46e5';
      registerActiveSession(
        playerStats.userTag,
        playerStats.name,
        playerStats.level,
        primaryColor,
        '',
        'offline'
      );
    }
    localStorage.removeItem('venom_jwt');
    setIsAuthenticated(false);
    setActiveTab('dashboard');
    triggerToast('Secure session disconnected successfully. 🔒', 'info');
  };

  // --- LAUNCH GAME ARENA ---
  const handleSelectArena = (arena: ArenaTier, isOnline: boolean) => {
    if (isOnline) {
      if (playerStats.bankedChips < arena.buyIn) {
        triggerToast('Insufficient chips! Grab daily rewards or earn more first.', 'error');
        return;
      }

      // Process buy-in transaction
      const newBanked = playerStats.bankedChips - arena.buyIn;
      handleUpdateStats({
        bankedChips: newBanked,
      });

      // Check high stakes buy-in mission
      if (arena.buyIn >= 100) {
        incrementMissionProgress('mission-4', 1);
      }
      triggerToast(`Staked Buy-In confirmed: -${arena.buyIn} chips! Entering ${arena.name}...`, 'info');
    } else {
      triggerToast(`Entering ${arena.name} (OFFLINE PRACTICE MODE) - No chips wagered!`, 'info');
    }

    setActiveArena(arena);
    setActiveIsOnline(isOnline);
  };

  // --- LEAVE ARENA / SYNC ---
  const handleExitGame = () => {
    setActiveArena(null);
    setSpectateTarget(null);

    // Fetch latest stats from Firestore after leaving the game to sync lobby UI in real-time
    if (playerStats.userTag) {
      fetchPlayerProfile(playerStats.userTag).then((latestProfile) => {
        if (latestProfile) {
          setPlayerStats((prev) => {
            const updated = {
              ...prev,
              bankedChips: latestProfile.bankedChips !== undefined ? latestProfile.bankedChips : prev.bankedChips,
              level: latestProfile.level || prev.level,
              xp: latestProfile.xp !== undefined ? latestProfile.xp : prev.xp,
              lifetimeKills: latestProfile.lifetimeKills !== undefined ? latestProfile.lifetimeKills : prev.lifetimeKills,
              lifetimeDeaths: latestProfile.lifetimeDeaths !== undefined ? latestProfile.lifetimeDeaths : prev.lifetimeDeaths,
              lifetimeExtracts: latestProfile.lifetimeExtracts !== undefined ? latestProfile.lifetimeExtracts : prev.lifetimeExtracts,
              bestStreak: latestProfile.bestStreak !== undefined ? latestProfile.bestStreak : prev.bestStreak,
              biggestExtract: latestProfile.biggestExtract !== undefined ? latestProfile.biggestExtract : prev.biggestExtract,
            };
            localStorage.setItem('venom_arena_player_stats_v1', JSON.stringify(updated));
            return updated;
          });
        }
      });
    }
  };

  const handlePlayAgain = () => {
    const arena = activeArena;
    const isOnline = activeIsOnline;
    if (!arena) return;

    handleExitGame();

    setTimeout(() => {
      handleSelectArena(arena, isOnline);
    }, 100);
  };

  const handleSpectateFriend = (name: string, color: string) => {
    const mockArena = ARENA_TIERS[0];
    setSpectateTarget({ name, color });
    setActiveArena(mockArena);
    setActiveIsOnline(true);
    triggerToast(`Joining spectating server for ${name}... 👁️`, 'success');
  };

  const handleJoinArenaById = (arenaTierId: string) => {
    const targetArena = ARENA_TIERS.find((a) => a.id === arenaTierId) || ARENA_TIERS[0];
    handleSelectArena(targetArena, true);
  };

  // --- MISSIONS PROGRESS TRACKER ---
  const incrementMissionProgress = (id: string, amount: number) => {
    setMissions((prevMissions) =>
      prevMissions.map((mission) => {
        if (mission.id === id && !mission.completed) {
          const nextVal = Math.min(mission.target, mission.current + amount);
          const isDone = nextVal >= mission.target;
          if (isDone) {
            triggerToast(`CHALLENGE COMPLETED: "${mission.title}"! Claim your chips!`, 'success');
          }
          return {
            ...mission,
            current: nextVal,
            completed: isDone,
          };
        }
        return mission;
      })
    );
  };

  const claimMissionReward = (mission: Mission) => {
    if (!mission.completed) return;

    // Credit chips
    handleUpdateStats({
      bankedChips: playerStats.bankedChips + mission.reward,
      totalChipsEarned: playerStats.totalChipsEarned + mission.reward,
    });

    // Reset mission so player can repeatedly complete daily tasks
    setMissions((prev) =>
      prev.map((m) => {
        if (m.id === mission.id) {
          return {
            ...m,
            current: 0,
            completed: false,
          };
        }
        return m;
      })
    );

    triggerToast(`Claimed challenge reward: +${mission.reward} CHIPS!`, 'success');
  };

  // Require authentication / Guest registration before entering the dashboard
  if (!isAuthenticated) {
    return (
      <>
        <AuthGate
          onAuthSuccess={(stats, token) => {
            setPlayerStats(stats);
            setIsAuthenticated(true);
          }}
          onToast={triggerToast}
        />
        {/* GLOBAL TOAST FLOATER */}
        <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
          {toasts.map((toast) => {
            const borderStyle =
              toast.type === 'success'
                ? 'border-emerald-500 bg-emerald-950/90 text-emerald-200'
                : toast.type === 'error'
                ? 'border-red-500 bg-red-950/90 text-red-200'
                : 'border-blue-500 bg-blue-950/90 text-blue-200';

            return (
              <div
                key={toast.id}
                className={`p-4 rounded-xl border shadow-xl flex items-center justify-between gap-4 backdrop-blur-md transition-all duration-300 animate-slide-in pointer-events-auto ${borderStyle}`}
              >
                <span className="text-xs font-sans font-semibold leading-relaxed">{toast.msg}</span>
                <button
                  onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
                  className="text-white/40 hover:text-white p-0.5 transition cursor-pointer"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            );
          })}
        </div>
      </>
    );
  }

  // If a game is active, render full-screen canvas
  if (activeArena) {
    return (
      <GameCanvas
        playerStats={playerStats}
        selectedArena={activeArena}
        isOnline={activeIsOnline}
        onUpdateStats={handleUpdateStats}
        onExitGame={handleExitGame}
        onPlayAgain={handlePlayAgain}
        onToast={triggerToast}
        spectateTarget={spectateTarget}
      />
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* GLOBAL TOAST FLOATER */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 max-w-sm pointer-events-none">
        {toasts.map((toast) => {
          const borderStyle =
            toast.type === 'success'
              ? 'border-emerald-500 bg-emerald-950/90 text-emerald-200'
              : toast.type === 'error'
              ? 'border-red-500 bg-red-950/90 text-red-200'
              : 'border-blue-500 bg-blue-950/90 text-blue-200';

          return (
            <div
              key={toast.id}
              className={`p-4 rounded-xl border shadow-xl flex items-center justify-between gap-4 backdrop-blur-md transition-all duration-300 animate-slide-in pointer-events-auto ${borderStyle}`}
            >
              <span className="text-xs font-sans font-semibold leading-relaxed">{toast.msg}</span>
              <button
                onClick={() => setToasts((prev) => prev.filter((t) => t.id !== toast.id))}
                className="text-white/40 hover:text-white p-0.5 transition cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          );
        })}
      </div>

      {/* HEADER HUD */}
      <header className="border-b border-slate-900 bg-slate-950/80 sticky top-0 z-40 backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Logo */}
          <div 
            onClick={() => {
              setActiveTab('dashboard');
              setArenaSelectionMode('select-type');
            }}
            className="flex items-center gap-3 cursor-pointer group select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-950/40 border border-indigo-400/20 group-hover:scale-105 transition duration-200">
              <Compass className="w-5.5 h-5.5 text-white animate-spin-slow" />
            </div>
            <div>
              <h1 className="text-lg font-extrabold tracking-tight text-white font-sans flex items-center gap-1.5 uppercase group-hover:text-indigo-400 transition duration-200">
                Project Venom <span className="text-xs px-2 py-0.5 bg-indigo-500 text-white font-bold rounded-full leading-none tracking-widest font-mono">Arena</span>
              </h1>
              <span className="text-[10px] text-slate-500 block font-mono">STORES-SAFE COMPLIANT VERSION</span>
            </div>
          </div>

          {/* Account balance indicators */}
          <div className="flex items-center gap-3 w-full sm:w-auto justify-end">
            {/* Player basic stats badge with custom avatar support */}
            <div className="bg-slate-900/60 border border-slate-800/80 px-4 py-2 rounded-xl flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-slate-950 flex items-center justify-center border border-slate-800/80 text-xs overflow-hidden shrink-0 shadow-inner">
                {playerStats.avatar ? (
                  playerStats.avatar.startsWith('data:') || playerStats.avatar.startsWith('http') ? (
                    <img src={playerStats.avatar} alt={playerStats.name} className="w-full h-full object-cover" referrerpolicy="no-referrer" />
                  ) : (
                    <span className="select-none">{playerStats.avatar}</span>
                  )
                ) : (
                  <span className="select-none text-[10px] font-mono font-bold text-slate-400">{playerStats.level}</span>
                )}
              </div>
              <div className="text-left leading-none">
                <span className="text-[9px] text-slate-500 block uppercase font-semibold">Challenger (Lvl {playerStats.level})</span>
                <span className="text-xs font-bold font-sans text-white truncate max-w-28 block">
                  {playerStats.name}
                </span>
              </div>
            </div>

            {/* Chips wallet balance */}
            <div className="bg-emerald-500/10 border border-emerald-500/20 px-4 py-2 rounded-xl flex items-center gap-2.5">
              <Coins className="w-4.5 h-4.5 text-emerald-400 animate-pulse" />
              <div className="text-left leading-none">
                <span className="text-[9px] text-emerald-500/60 block uppercase font-semibold">Secure Chips</span>
                <span className="text-sm font-bold font-mono text-emerald-400">
                  {playerStats.bankedChips.toLocaleString()}
                </span>
              </div>
            </div>

            {/* Rules & Guide Modal Trigger Button */}
            <button
              onClick={() => setIsRulesModalOpen(true)}
              className="bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white border border-indigo-500/30 p-2 py-2.5 rounded-xl transition duration-200 cursor-pointer flex items-center gap-1.5 shadow"
              title="Official Guide, Rules & FAQ"
            >
              <BookOpen className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-bold font-sans hidden sm:inline">Rules & Guide</span>
            </button>

            {/* Sign Out Action */}
            <button
              onClick={handleLogout}
              className="bg-slate-900/60 hover:bg-red-950/40 hover:text-red-400 hover:border-red-500/20 border border-slate-800/80 p-2 py-2.5 rounded-xl transition duration-200 cursor-pointer flex items-center gap-1.5"
              title="Secure Logout"
            >
              <LogOut className="w-4 h-4" />
              <span className="text-xs font-bold font-sans hidden md:inline">Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      {/* CORE CONTENT LAYOUT */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex-1 w-full flex flex-col justify-start">
        {/* ==============================================
            LOBBY DASHBOARD LANDING LOBBY (activeTab === 'dashboard')
            ============================================== */}
        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start w-full animate-fade-in">
            {/* LEFT COLUMN: HERO PANEL + FEATURE GATES (8 cols) */}
            <div className="lg:col-span-8 flex flex-col gap-6">
              {/* Futuristic AAA Greeting Banner */}
              <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 to-indigo-950/80 border border-indigo-500/10 shadow-2xl relative overflow-hidden flex flex-col sm:flex-row items-center justify-between gap-6">
                <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
                
                <div className="flex items-center gap-4.5">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg shadow-indigo-950/40 border border-indigo-400/20 shrink-0">
                    <Award className="w-7 h-7 text-white animate-pulse" />
                  </div>
                  <div>
                    <span className="text-[10px] text-indigo-400 font-mono font-bold tracking-widest block uppercase">Lobby Headquarters</span>
                    <h2 className="text-xl font-black text-white font-sans tracking-tight mt-0.5">
                      WELCOME BACK, {playerStats.name.toUpperCase()}
                    </h2>
                    
                    {/* XP Progress Bar */}
                    <div className="flex items-center gap-3 mt-2">
                      <span className="text-[10px] font-mono text-slate-400">LVL {playerStats.level}</span>
                      <div className="w-36 h-1.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                        <div 
                          className="h-full bg-indigo-500 rounded-full"
                          style={{ width: `${Math.min(100, (playerStats.xp / (playerStats.level * 100)) * 100)}%` }}
                        />
                      </div>
                      <span className="text-[9px] font-mono text-slate-500">{playerStats.xp} / {playerStats.level * 100} XP</span>
                    </div>
                  </div>
                </div>

                {/* Instant Play Call to Action */}
                <button
                  onClick={() => {
                    setActiveTab('arena');
                    setArenaSelectionMode('select-type');
                  }}
                  className="px-5 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-sans font-bold text-xs flex items-center gap-2 transition duration-200 cursor-pointer shadow-lg shadow-indigo-950/40 border border-indigo-500 shrink-0 self-stretch sm:self-auto justify-center"
                >
                  <Play className="w-3.5 h-3.5 fill-current" /> LAUNCH MATCHMAKER
                </button>
              </div>

              {/* Bento Grid Page Gates */}
              <div className="flex flex-col gap-3">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest px-1">Lobby Stations</span>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Gate 1: Play Endless Arenas */}
                  <div
                    onClick={() => {
                      setActiveTab('arena');
                      setArenaSelectionMode('select-type');
                    }}
                    className="p-5 bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-indigo-500/40 rounded-2xl cursor-pointer transition-all duration-300 group shadow-md flex flex-col justify-between h-44"
                  >
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
                        <Compass className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] px-2 py-0.5 bg-indigo-500/15 border border-indigo-500/20 text-indigo-400 font-bold font-sans rounded-full uppercase">
                        Battle Gate
                      </span>
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-indigo-400 transition-colors">
                        Play Endless Arenas
                      </h3>
                      <p className="text-xs text-slate-400 font-sans mt-1 line-clamp-2 leading-relaxed">
                        Risk chips to compete in simulated multiplayer shards. Harvest dropping stars and escape safely.
                      </p>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 border-t border-slate-800/40 pt-2 flex justify-between">
                      <span>STAKES FROM: 10 chips</span>
                      <span className="text-indigo-400 group-hover:translate-x-1 transition-transform">Enter →</span>
                    </div>
                  </div>

                  {/* Gate 2: Identity Shop & DNA Lab */}
                  <div
                    onClick={() => setActiveTab('shop')}
                    className="p-5 bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-purple-500/40 rounded-2xl cursor-pointer transition-all duration-300 group shadow-md flex flex-col justify-between h-44"
                  >
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform">
                        <ShoppingBag className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] px-2 py-0.5 bg-purple-500/15 border border-purple-500/20 text-purple-400 font-bold font-sans rounded-full uppercase">
                        Customize Lab
                      </span>
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-purple-400 transition-colors">
                        Identity Workshop & Shop
                      </h3>
                      <p className="text-xs text-slate-400 font-sans mt-1 line-clamp-2 leading-relaxed">
                        Unlock glowing skins, trials, death burst novas, or design a custom repeating body segment sequence.
                      </p>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 border-t border-slate-800/40 pt-2 flex justify-between">
                      <span>EQUIPPED: {playerStats.useCustomSkin ? 'Custom DNA' : 'Gallery Skin'}</span>
                      <span className="text-purple-400 group-hover:translate-x-1 transition-transform">Modify →</span>
                    </div>
                  </div>

                  {/* Gate 3: Challenger Dossier */}
                  <div
                    onClick={() => setActiveTab('profile')}
                    className="p-5 bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-blue-500/40 rounded-2xl cursor-pointer transition-all duration-300 group shadow-md flex flex-col justify-between h-44"
                  >
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center text-blue-400 group-hover:scale-110 transition-transform">
                        <User className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] px-2 py-0.5 bg-blue-500/15 border border-blue-500/20 text-blue-400 font-bold font-sans rounded-full uppercase">
                        My Record
                      </span>
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-blue-400 transition-colors">
                        Challenger Dossier
                      </h3>
                      <p className="text-xs text-slate-400 font-sans mt-1 line-clamp-2 leading-relaxed">
                        Examine your records, high scores, total banked wealth, and change your operative callsign.
                      </p>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 border-t border-slate-800/40 pt-2 flex justify-between">
                      <span>HIGH SCORE: {(playerStats.biggestExtract || 0).toLocaleString()}</span>
                      <span className="text-blue-400 group-hover:translate-x-1 transition-transform">Inspect →</span>
                    </div>
                  </div>

                  {/* Gate 4: Global Standings */}
                  <div
                    onClick={() => setActiveTab('leaderboard')}
                    className="p-5 bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-amber-500/40 rounded-2xl cursor-pointer transition-all duration-300 group shadow-md flex flex-col justify-between h-44"
                  >
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-500 group-hover:scale-110 transition-transform">
                        <Trophy className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] px-2 py-0.5 bg-amber-500/15 border border-amber-500/20 text-amber-400 font-bold font-sans rounded-full uppercase">
                        Elite Standings
                      </span>
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-amber-400 transition-colors">
                        Global Standings
                      </h3>
                      <p className="text-xs text-slate-400 font-sans mt-1 line-clamp-2 leading-relaxed">
                        Track rank placements and compare your banked chip balance against other elite venom snake operators.
                      </p>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 border-t border-slate-800/40 pt-2 flex justify-between">
                      <span>LEADERBOARD RANK: Tier 1</span>
                      <span className="text-amber-400 group-hover:translate-x-1 transition-transform">View →</span>
                    </div>
                  </div>

                  {/* Gate 5: Daily Free Claims */}
                  <div
                    onClick={() => setActiveTab('rewards')}
                    className="p-5 bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-emerald-500/40 rounded-2xl cursor-pointer transition-all duration-300 group shadow-md flex flex-col justify-between h-44"
                  >
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform">
                        <Gift className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] px-2 py-0.5 bg-emerald-500/15 border border-emerald-500/20 text-emerald-400 font-bold font-sans rounded-full uppercase">
                        Complimentary
                      </span>
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors">
                        Daily Free Claims
                      </h3>
                      <p className="text-xs text-slate-400 font-sans mt-1 line-clamp-2 leading-relaxed">
                        Secure your complimentary login chips. Claim hourly or daily packages to rebuild your wallet!
                      </p>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 border-t border-slate-800/40 pt-2 flex justify-between">
                      <span>STREAK: {playerStats.dailyStreak || 1} Days</span>
                      <span className="text-emerald-400 group-hover:translate-x-1 transition-transform">Claim →</span>
                    </div>
                  </div>

                  {/* Gate 6: Virtual Chip Store */}
                  <div
                    onClick={() => setActiveTab('store')}
                    className="p-5 bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-green-500/40 rounded-2xl cursor-pointer transition-all duration-300 group shadow-md flex flex-col justify-between h-44"
                  >
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 rounded-xl bg-green-500/10 border border-green-500/20 flex items-center justify-center text-green-400 group-hover:scale-110 transition-transform">
                        <Coins className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] px-2 py-0.5 bg-green-500/15 border border-green-500/20 text-green-400 font-bold font-sans rounded-full uppercase">
                        Secure Vault
                      </span>
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-green-400 transition-colors">
                        Virtual Chip Store
                      </h3>
                      <p className="text-xs text-slate-400 font-sans mt-1 line-clamp-2 leading-relaxed">
                        Acquire secure safe-guarded chip packs immediately to compete in high-stakes premium arena tables.
                      </p>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 border-t border-slate-800/40 pt-2 flex justify-between">
                      <span>WALLET: {playerStats.bankedChips.toLocaleString()} c</span>
                      <span className="text-green-400 group-hover:translate-x-1 transition-transform">Shop →</span>
                    </div>
                  </div>

                  {/* Gate 7: Syndicate & Friends */}
                  <div
                    onClick={() => setActiveTab('social')}
                    className="p-5 bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-violet-500/40 rounded-2xl cursor-pointer transition-all duration-300 group shadow-md flex flex-col justify-between h-44 sm:col-span-2"
                  >
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center text-violet-400 group-hover:scale-110 transition-transform">
                        <Users className="w-5 h-5" />
                      </div>
                      <span className="text-[9px] px-2 py-0.5 bg-cyan-500/15 border border-cyan-500/20 text-cyan-300 font-bold font-sans rounded-full uppercase">
                        Friends & Global Search
                      </span>
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-white group-hover:text-violet-400 transition-colors">
                        Friends, Global Search & Syndicate Hub
                      </h3>
                      <p className="text-xs text-slate-400 font-sans mt-1 leading-relaxed">
                        Search and connect with players globally by tag or country flag (🇮🇳, 🇺🇸, 🇯🇵, etc.), send daily chip gifts (+25c), spectate matches, and create co-op team codes!
                      </p>
                    </div>
                    <div className="text-[10px] font-mono text-slate-500 border-t border-slate-800/40 pt-2 flex justify-between">
                      <span>GLOBAL PLAYER NETWORK READY</span>
                      <span className="text-violet-400 group-hover:translate-x-1 transition-transform">Search & Connect →</span>
                    </div>
                  </div>

                </div>
              </div>
            </div>

            {/* RIGHT COLUMN: DAILY CHALLENGES STATION (4 cols) */}
            <div className="lg:col-span-4 flex flex-col gap-4">
              <section id="challenges-dashboard-panel" className="bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 shadow-xl flex flex-col gap-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <ListTodo className="w-4 h-4 text-indigo-400 animate-pulse" />
                    <span className="text-xs font-bold text-white font-sans uppercase tracking-wider">Tactical Challenges</span>
                  </div>
                  <Sparkles className="w-4 h-4 text-indigo-400" />
                </div>

                <div className="flex flex-col gap-3.5">
                  {missions.map((m) => {
                    const percent = Math.min(100, Math.floor((m.current / m.target) * 100));

                    return (
                      <div key={m.id} className="p-3.5 bg-slate-950/90 rounded-xl border border-slate-850 flex flex-col gap-2.5">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <h4 className="text-xs font-bold text-white font-sans leading-snug">{m.title}</h4>
                            <p className="text-[10.5px] text-slate-400 font-sans mt-1 leading-normal">
                              {m.description}
                            </p>
                          </div>
                        </div>

                        {/* Progress bar */}
                        <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 mt-0.5">
                          <span>PROGRESS:</span>
                          <span>{m.current} / {m.target} ({percent}%)</span>
                        </div>

                        <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-indigo-500 to-indigo-600 rounded-full transition-all duration-300"
                            style={{ width: `${percent}%` }}
                          />
                        </div>

                        {/* Claim Reward */}
                        <div className="flex justify-between items-center mt-1 pt-2 border-t border-slate-900/40">
                          <span className="text-[10px] font-mono font-bold text-emerald-400">
                            +{m.reward} CHIPS
                          </span>
                          <button
                            onClick={() => claimMissionReward(m)}
                            disabled={!m.completed}
                            className={`px-3 py-1 rounded-lg text-[10px] font-sans font-bold transition-all cursor-pointer ${
                              m.completed
                                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:brightness-110 text-black shadow shadow-emerald-950/20'
                                : 'bg-slate-900 text-slate-500 border border-slate-850 cursor-not-allowed'
                            }`}
                          >
                            Claim
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </section>
            </div>
          </div>
        )}

        {/* ==============================================
            SUB-PAGES CONTENT WRAPPER (activeTab !== 'dashboard')
            ============================================== */}
        {activeTab !== 'dashboard' && (
          <div className="w-full animate-fade-in">
            {/* Dedicated Top Navigation & Breadcrumbs Header */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/40 border border-slate-900 rounded-2xl p-4 mb-6 shadow-md">
              <div className="flex items-center gap-3">
                <button
                  onClick={() => {
                    setActiveTab('dashboard');
                    setArenaSelectionMode('select-type');
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-900 transition-all cursor-pointer flex items-center gap-1.5 shadow"
                >
                  <ChevronLeft className="w-4 h-4 text-indigo-400" /> Lobby HQ
                </button>
                <div className="h-4 w-[1px] bg-slate-800 hidden sm:block" />
                <div className="text-[10px] text-slate-500 font-mono hidden sm:block">
                  STATION / {activeTab.toUpperCase()} {activeTab === 'arena' && `_ ${arenaSelectionMode.toUpperCase()}`}
                </div>
              </div>
              
              {/* Elegant horizontal switcher for other pages */}
              <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-xl border border-slate-900/60 overflow-x-auto max-w-full">
                {([
                  { id: 'arena', label: 'Play', icon: Compass, activeColor: 'text-indigo-400 bg-indigo-600/10 border-indigo-500/20' },
                  { id: 'shop', label: 'Shop & Lab', icon: ShoppingBag, activeColor: 'text-purple-400 bg-purple-600/10 border-purple-500/20' },
                  { id: 'profile', label: 'Dossier', icon: User, activeColor: 'text-blue-400 bg-blue-600/10 border-blue-500/20' },
                  { id: 'leaderboard', label: 'Leaderboard', icon: Trophy, activeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/20' },
                  { id: 'championships', label: 'Championships 👑', icon: Crown, activeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/20' },
                  { id: 'halloffame', label: 'Hall of Fame', icon: Award, activeColor: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20' },
                  { id: 'clans', label: 'Syndicates', icon: Shield, activeColor: 'text-indigo-400 bg-indigo-600/10 border-indigo-500/20' },
                  { id: 'seasonpass', label: 'Pass', icon: Sparkles, activeColor: 'text-purple-400 bg-purple-600/10 border-purple-500/20' },
                  { id: 'clips', label: 'Highlights', icon: Film, activeColor: 'text-red-400 bg-red-600/10 border-red-500/20' },
                  { id: 'rewards', label: 'Claims', icon: Gift, activeColor: 'text-emerald-400 bg-emerald-600/10 border-emerald-500/20' },
                  { id: 'store', label: 'Vault', icon: Coins, activeColor: 'text-emerald-400 bg-emerald-600/10 border-emerald-500/20' },
                  { id: 'social', label: 'Friends & Search', icon: Users, activeColor: 'text-violet-400 bg-violet-600/10 border-violet-500/20' },
                  { id: 'admin', label: 'Admin', icon: Shield, activeColor: 'text-red-400 bg-red-600/10 border-red-500/20' },
                ] as const).map((tab) => {
                  const active = activeTab === tab.id;
                  const TabIcon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => {
                        setActiveTab(tab.id);
                        if (tab.id === 'arena') {
                          setArenaSelectionMode('select-type');
                        }
                      }}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 border border-transparent shrink-0 ${
                        active
                          ? tab.activeColor + ' border'
                          : 'text-slate-500 hover:text-slate-300'
                      }`}
                    >
                      <TabIcon className="w-3.5 h-3.5" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Render sub-page contents */}
            <div className="w-full">
              {/* ARENA GATE (Intermediate selection vs Active selector) */}
              {activeTab === 'arena' && (
                <div>
                  {/* Mode Selector Intermediate Page */}
                  {arenaSelectionMode === 'select-type' ? (
                    <div className="max-w-4xl mx-auto py-6 animate-fade-in flex flex-col gap-6">
                      <div className="text-center">
                        <span className="text-[10px] text-indigo-400 font-mono font-bold tracking-widest block uppercase">EXTRACTION CHANNELS</span>
                        <h2 className="text-2xl sm:text-3xl font-black text-white font-sans tracking-tight mt-1">
                          SELECT COMBAT PROTOCOL
                        </h2>
                        <p className="text-xs text-slate-400 font-sans mt-2 max-w-lg mx-auto leading-relaxed">
                          Enter high-stakes PvP simulation shards against smart bots to extract banked wealth, or configure offline practice modules to master venom snake physics.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
                        {/* PORTAL CARD 1: ONLINE PVP */}
                        <div
                          onClick={() => {
                            setPreSelectedOnline(true);
                            setArenaSelectionMode('active-selector');
                          }}
                          className="group relative p-6 rounded-2xl border bg-slate-900 hover:bg-slate-900/85 border-slate-800 hover:border-indigo-500/40 shadow-xl cursor-pointer transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between overflow-hidden"
                        >
                          <div className="absolute top-0 right-0 w-48 h-48 bg-indigo-500/5 rounded-full blur-3xl group-hover:bg-indigo-500/10 transition-colors pointer-events-none" />
                          
                          <div>
                            <div className="flex items-center justify-between mb-6">
                              <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
                                <Globe className="w-6 h-6 text-indigo-400" />
                              </div>
                              <span className="text-[9px] px-2.5 py-1 bg-indigo-500/10 border border-indigo-500/30 text-indigo-300 font-bold font-sans rounded-full uppercase tracking-wider">
                                RECOMMENDED
                              </span>
                            </div>

                            <h3 className="text-lg font-bold text-white group-hover:text-indigo-400 transition-colors">
                              ONLINE PVP SHARDS
                            </h3>
                            <p className="text-xs text-slate-400 font-sans mt-2 leading-relaxed">
                              Compete in dynamic multiplayer shards with continuous bot spawning. Collect chips dropped by other venom snakes and trigger co-op beacons.
                            </p>

                            <ul className="mt-5 flex flex-col gap-2.5 text-xs text-slate-400 font-sans">
                              <li className="flex items-center gap-2">
                                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                                <span>High-stakes bot lobbies with variable risks</span>
                              </li>
                              <li className="flex items-center gap-2">
                                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                                <span>Defeated rivals drop raw chips (stars) to harvest</span>
                              </li>
                              <li className="flex items-center gap-2">
                                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                                <span>35% extraction fee (escape to bank 65%)</span>
                              </li>
                              <li className="flex items-center gap-2">
                                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                                <span>Supports Syndicate co-op lobby codes</span>
                              </li>
                            </ul>
                          </div>

                          <div className="mt-8 pt-4 border-t border-slate-800/40">
                            <button className="w-full py-3 rounded-xl bg-indigo-600 group-hover:bg-indigo-500 text-white font-sans font-bold text-xs transition duration-200 uppercase tracking-wider flex items-center justify-center gap-1.5">
                              ACCESS SHARDS <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                        {/* PORTAL CARD 2: OFFLINE PRACTICE */}
                        <div
                          onClick={() => {
                            setPreSelectedOnline(false);
                            setArenaSelectionMode('active-selector');
                          }}
                          className="group relative p-6 rounded-2xl border bg-slate-900 hover:bg-slate-900/85 border-slate-800 hover:border-amber-500/40 shadow-xl cursor-pointer transition-all duration-300 hover:-translate-y-1 flex flex-col justify-between overflow-hidden"
                        >
                          <div className="absolute top-0 right-0 w-48 h-48 bg-amber-500/5 rounded-full blur-3xl group-hover:bg-amber-500/10 transition-colors pointer-events-none" />

                          <div>
                            <div className="flex items-center justify-between mb-6">
                              <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 group-hover:scale-110 transition-transform">
                                <Swords className="w-6 h-6 text-amber-400" />
                              </div>
                              <span className="text-[9px] px-2.5 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-300 font-bold font-sans rounded-full uppercase tracking-wider">
                                PRACTICE GRID
                              </span>
                            </div>

                            <h3 className="text-lg font-bold text-white group-hover:text-amber-400 transition-colors">
                              LOCAL PRACTICE SANCTORUM
                            </h3>
                            <p className="text-xs text-slate-400 font-sans mt-2 leading-relaxed">
                              Safe local training environment with moderated venom snake bots. Practice steering, try custom DNA skins, and master your maneuvers.
                            </p>

                            <ul className="mt-5 flex flex-col gap-2.5 text-xs text-slate-400 font-sans">
                              <li className="flex items-center gap-2">
                                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                                <span>Free to play with three difficulty levels (Easy, Medium, Hard)</span>
                              </li>
                              <li className="flex items-center gap-2">
                                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                                <span>No entry fee and zero-stakes risk-free practice</span>
                              </li>
                              <li className="flex items-center gap-2">
                                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                                <span>Exit anytime (no minimum chips needed to leave)</span>
                              </li>
                              <li className="flex items-center gap-2">
                                <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                                <span>Ideal for safe skill building and testing skins</span>
                              </li>
                            </ul>
                          </div>

                          <div className="mt-8 pt-4 border-t border-slate-800/40">
                            <button className="w-full py-3 rounded-xl bg-amber-600/20 border border-amber-500/30 group-hover:bg-amber-600 text-amber-300 group-hover:text-white font-sans font-bold text-xs transition duration-200 uppercase tracking-wider flex items-center justify-center gap-1.5">
                              ACCESS SANCTORUM <ChevronRight className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                      </div>
                    </div>
                  ) : (
                    /* Active Tier Selector + Challenges side-panel for active choice */
                    <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
                      <div className="xl:col-span-8">
                        <ArenaSelector
                          playerStats={playerStats}
                          onSelectArena={handleSelectArena}
                          onToast={triggerToast}
                          initialOnline={preSelectedOnline}
                          onBack={() => setArenaSelectionMode('select-type')}
                        />
                      </div>
                      
                      {/* Interactive challenges panel */}
                      <div className="xl:col-span-4 flex flex-col gap-4 bg-slate-900/50 border border-slate-900 rounded-2xl p-5 shadow">
                        <div className="flex items-center justify-between border-b border-slate-800 pb-2 mb-1">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest px-1">Arena Objectives</span>
                          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
                        </div>

                        <div className="flex flex-col gap-3">
                          {missions.map((m) => {
                            const percent = Math.min(100, Math.floor((m.current / m.target) * 100));

                            return (
                              <div key={m.id} className="p-3 bg-slate-950/80 rounded-xl border border-slate-900 flex flex-col gap-2">
                                <div className="flex items-start justify-between gap-2">
                                  <div>
                                    <h4 className="text-xs font-bold text-white font-sans">{m.title}</h4>
                                    <p className="text-[10px] text-slate-400 font-sans mt-0.5 leading-normal">
                                      {m.description}
                                    </p>
                                  </div>
                                </div>

                                <div className="flex items-center justify-between text-[9px] font-mono text-slate-500 mt-1">
                                  <span>Progress:</span>
                                  <span>{m.current} / {m.target} ({percent}%)</span>
                                </div>

                                <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-indigo-500 rounded-full transition-all duration-300"
                                    style={{ width: `${percent}%` }}
                                  />
                                </div>

                                <div className="flex justify-between items-center mt-2 pt-1 border-t border-slate-900/40">
                                  <span className="text-[9px] font-mono font-bold text-emerald-400">
                                    +{m.reward} chips
                                  </span>
                                  <button
                                    onClick={() => claimMissionReward(m)}
                                    disabled={!m.completed}
                                    className={`px-2.5 py-0.5 rounded text-[9px] font-sans font-bold transition cursor-pointer ${
                                      m.completed
                                        ? 'bg-emerald-500 hover:bg-emerald-400 text-black shadow'
                                        : 'bg-slate-900 text-slate-500 border border-slate-850 cursor-not-allowed'
                                    }`}
                                  >
                                    Claim
                                  </button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* OTHER PANELS RENDER FULL-WIDTH FOR GORGEOUS SPACING */}
              {activeTab === 'shop' && (
                <CosmeticsShop
                  playerStats={playerStats}
                  onUpdateStats={handleUpdateStats}
                  onToast={triggerToast}
                />
              )}

              {activeTab === 'profile' && (
                <PlayerProfile
                  playerStats={playerStats}
                  onUpdateStats={handleUpdateStats}
                  onToast={triggerToast}
                  onLogout={handleLogout}
                  onSelectArena={handleSelectArena}
                  onSpectateFriend={handleSpectateFriend}
                />
              )}

              {activeTab === 'leaderboard' && (
                <Leaderboards playerStats={playerStats} onInspectPlayer={(p) => setInspectedPlayer(p)} />
              )}

              {activeTab === 'rewards' && (
                <DailyRewards
                  playerStats={playerStats}
                  onUpdateStats={handleUpdateStats}
                  onToast={triggerToast}
                />
              )}

              {activeTab === 'store' && (
                <ChipStore
                  playerStats={playerStats}
                  onUpdateStats={handleUpdateStats}
                  onToast={triggerToast}
                />
              )}

              {activeTab === 'social' && (
                <SocialPanel
                  playerStats={playerStats}
                  onUpdateStats={handleUpdateStats}
                  onToast={triggerToast}
                  onSpectateFriend={handleSpectateFriend}
                  onJoinArena={handleJoinArenaById}
                />
              )}

              {activeTab === 'championships' && (
                <Championships
                  playerStats={playerStats}
                  onUpdateStats={handleUpdateStats}
                  onToast={triggerToast}
                  onSelectArena={handleSelectArena}
                />
              )}

              {activeTab === 'halloffame' && (
                <HallOfFame
                  playerStats={playerStats}
                  onInspectPlayer={(p) => setInspectedPlayer(p)}
                  onToast={triggerToast}
                />
              )}

              {activeTab === 'clans' && (
                <ClanSystem
                  playerStats={playerStats}
                  onUpdatePlayerStats={handleUpdateStats}
                  onToast={triggerToast}
                  onInspectPlayer={(p) => setInspectedPlayer(p)}
                />
              )}

              {activeTab === 'seasonpass' && (
                <SeasonPass
                  playerStats={playerStats}
                  onUpdatePlayerStats={handleUpdateStats}
                  onToast={triggerToast}
                />
              )}

              {activeTab === 'clips' && (
                <ClipShowcase
                  playerStats={playerStats}
                  onToast={triggerToast}
                  onInspectPlayer={(p) => setInspectedPlayer(p)}
                />
              )}

              {activeTab === 'admin' && (
                <AdminPanel
                  playerStats={playerStats}
                  onUpdateStats={handleUpdateStats}
                  onToast={triggerToast}
                />
              )}
            </div>
          </div>
        )}
      </main>

      {/* MOBILE COMPLIANT FOOTER */}
      <footer className="border-t border-slate-900/60 bg-slate-950/40 py-6 mt-auto text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-sans">
            &copy; 2026 Project Venom Arena. All Rights Reserved. Fully store-safe, non-gambling gameplay edition.
          </p>
          <div className="flex gap-4 font-mono text-[10px] text-slate-400">
            <span>APP_VERSION: 1.0.0-MVP</span>
            <span>ENGINE: TSX_CANVAS</span>
          </div>
        </div>
      </footer>

      {/* GLOBAL PLAYER INSPECTOR MODAL */}
      <PlayerInspectorModal
        player={inspectedPlayer}
        onClose={() => setInspectedPlayer(null)}
        onToast={triggerToast}
      />

      {/* OFFICIAL GUIDE, RULES & FAQ MODAL */}
      <GameRulesModal
        isOpen={isRulesModalOpen}
        onClose={() => setIsRulesModalOpen(false)}
      />
    </div>
  );
}
