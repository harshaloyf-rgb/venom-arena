# BUILD-10 — Game Canvas Fix (Venom Arena)

**Agent:** game-canvas-fixer
**Task ID:** BUILD-10
**Scope:** Adapt `src/components/game/render-helpers.ts` and `src/components/game/game-canvas.tsx` to the BUILD-6a game-server changes (extractZone removed, score field added, breathing circular wall, gold-star chips, body-length boost cost) and align HUD / end-screen / mobile-control text with AUDIT-A character-for-character.

## Files modified

| File | Action | Notes |
|------|--------|-------|
| `src/components/game/render-helpers.ts` | Full rewrite (was 595 → ~620 lines) | Removed `extractZoneRadius` from `FrameRenderCtx` and `MinimapArgs`. `drawGrid` now renders the breathing circular arena boundary (`#f43f5e`, lineWidth 10, shadowBlur 16) over a `#020617` deep-slate fill clipped to the circle, with a subtle `#1e293b` gridSize-60 grid inside. `drawFood` star chips are now 5-pointed gold stars with `shadowColor #eab308`, `shadowBlur 6`. `drawMinimap` renders the arena boundary as a dashed rose circle, player as indigo dot, bots as rose dots, other real players as emerald dots (matches AUDIT-A radar). All skin patterns (rainbow / neon / metallic / camo) preserved; added `neon` + `camo` body-pattern rendering (the old BUILD-3 file only handled `metallic` + `rainbow`). |
| `src/components/game/game-canvas.tsx` | Full rewrite (~1180 lines) | Removed `extractZoneRadius` from `JoinedPayload`. HUD now reads `snake.score` directly. HUD text matches AUDIT-A exactly: "Carried Chips" (emerald-400) / "Rank: #N" (yellow-400 Trophy) / "Score: N" (white Shield) / "Kills: N" (rose-400 Skull) / "Boost: SPACE" (amber-400 Zap) / "Real Players: N Active" or "Offline Mode: 1 Player" / "Bots: N" (Users) / "BANKED" / FPS / Ping. Death screen renders "Arena Disintegration!" with "Stakes Buy-In Cost:", "Match Carried Value Forfeited:", "Opponents Eliminated:" stats, killer card with "Collided With / Eliminated By" / "Arena AI Combatant" or "Online Rival Player" / "Add Rival" + "Add Friend" buttons, and "PLAY AGAIN" (gradient red) + "📺 Watch Video (Get +50 Chips)" + "RETURN TO LOBBY" buttons. Offline death hides buy-in/carried-value stats and shows "Offline Training — No chips lost." Extraction screen renders title variants ("Extraction Completed!" / "Secure Extraction!" / "Practice Run Completed!") + 3-column stats grid (Kills / Max Length / Survival Time) + online results table ("Carried Value:" / "System Commission (35%):" / "BANKED TO ACCOUNT:") or offline results ("Offline Training Complete" + "No buy-in or banking fees…") + "PLAY AGAIN" (gradient emerald) + "📺 Watch Video (Get +50 Chips)" + "SECURE CHIPS & RETURN TO LOBBY" (online) or "RETURN TO LOBBY" (offline). Hold-to-extract popup shows "Hold E or press the button below to cash out safely!" / "EXTRACTING CHIPS ({progress}%)" / "HOLD TO EXTRACT SUCCESSFUL!" (online) or "HOLD TO LEAVE PRACTICE ARENA" (offline) / "CHIPS NEEDED TO EXIT: {carriedChips}/{minExtract}" + warning toast when below min. Quick Chat Emotes Bar (bottom-left) with "Emotes (Keys 1-5)" header + 5 buttons ("GG! 🏆" / "Target! 🎯" / "Flee! 🏃💨" / "Ripped! 💪" / "Extracting! ⚡"). Mobile controls: virtual joystick in bottom-left canvas quadrant (touch-action:none, magnitude >0.6 = boost), BOOST button (bottom-right, hold to boost), EXTRACT button (next to boost, hold to extract). Boost sends `wantsBoost: true` when SPACE held OR boost button held OR joystick magnitude > 0.6. Reconnect: `connect` and `reconnect` both re-emit `join_arena`. rAF cancelled on unmount; all socket listeners removed via paired `.off(...)` calls. |
| `src/app/api/auth/token/route.ts` | Verified exists | Returns `{ token }` from session cookie via `getSession()` + `signSession()`. No changes needed. |

## Key adaptations to BUILD-6a game-server changes

1. **`GameSnapshot.extractZoneRadius` removed** → removed from `FrameRenderCtx`, `MinimapArgs`, and `JoinedPayload`. Extraction zone circle is no longer drawn on the map or the minimap. The minimap now renders the breathing arena boundary as a dashed rose circle instead.

2. **`SnakeSnapshot.score` added** → HUD "Score:" label reads `snake.score` directly (the body-length score, not chips). End-screen "Max Length" stat uses the same score value. A separate `hudScore` state + `scoreRef` was added to the canvas component for throttled updates.

3. **Food mechanic changed** → regular food rendering unchanged (filled circle in its color). Star chips now render as 5-pointed gold stars with a soft `#eab308` shadowBlur 6 (was a 4-point sparkle in BUILD-3). HUD "Carried Chips" only increments from star-chip collection (server-side), no client-side chip inference.

4. **Boost costs body length** → client sends `wantsBoost: true` whenever SPACE is held OR the BOOST button is held OR the touch-joystick magnitude > 0.6 (`JOYSTICK_BOOST_MAGNITUDE` const). The server enforces the `BOOST_MIN_LENGTH=8` gate and the `BOOST_DROP_INTERVAL=40` tail-drop. Client never touches body length.

5. **No extraction zone** → player can hold E or the EXTRACT button anywhere. The extraction popup appears top-center whenever the player is alive and there is no end-screen.

6. **Breathing circular wall** → `drawGrid` calls `getArenaRadius(now)` (uses `MAP_BASE_RADIUS=3800` + `MAP_BREATH_AMPLITUDE=40` + `MAP_BREATH_CYCLE_MS=10000`) and strokes the boundary at that radius in `#f43f5e` (rose), lineWidth 10, shadowBlur 16, shadowColor `#f43f5e`. Background fill is `#020617` (deep slate) clipped to the circle. Grid inside is `#1e293b` lineWidth 1 gridSize 60.

## Mobile controls (NEW — the original BUILD-3 had a touch joystick but the user explicitly requested explicit BOOST/EXTRACT buttons + boost-by-joystick-magnitude)

- **Virtual joystick**: `touchstart` in the bottom-left canvas quadrant records origin; `touchmove` computes delta → `atan2` for the angle + `min(1, dist/70)` for magnitude. Magnitude > 0.6 → boost. Drawn on the canvas itself (translucent indigo outer ring + indigo stick) so it follows the finger rather than a fixed DOM element.
- **BOOST button**: bottom-right circle, `pointerdown`/`pointerup` with pointer capture, `touch-action: none`. Adds ' ' to the keys set so the keyboard-boost path is reused.
- **EXTRACT button**: next to BOOST, same pointer-capture pattern, emits `extract`/`cancel_extract`.
- All three work alongside the existing mouse + keyboard controls (the `computeAngleAndBoost` function checks joystick → keyboard → mouse in that order).

## Verification

- `bun run lint` → exit 0 (no errors, no warnings).
- `npx tsc --noEmit` → zero errors in `src/components/game/` and `src/app/api/auth/token/`. (Pre-existing TS errors in `upload/extracted/` are not in scope — they're the original audited reference code from ANALYSIS-2.)
- `rg "extractZoneRadius" src/` → only matches inside docstring comments of the two BUILD-10 files (no live code references).
- Dev server log shows no compile errors after the rewrites.

## Things deliberately NOT done (out of scope)

- Power-up rendering (shield / magnet / double / freeze) is not implemented — the BUILD-6a server does not spawn power-ups, and AUDIT-A's power-up HUD countdowns would have no data source. Skipped per task spec.
- Spectating mode, Co-Op invite drawer, ally tactics, SYN-01 boss banner, combat announcer — all auxiliary features that the BUILD-6a server doesn't emit. Skipped per task spec.
- Audio (mute/unmute button, synth track, SFX) — original had audio; BUILD-10 does not restore it because the BUILD-3 file never wired it and the task didn't ask for it.
