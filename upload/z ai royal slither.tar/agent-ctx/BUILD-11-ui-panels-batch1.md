# BUILD-11 — UI Panels Batch 1 (CosmeticsShop, PlayerProfile, ArenaSelector, AuthGate, GameRulesModal)

Agent: BUILD-11 implementer
Scope: 5 faithful panel replicas in `/home/z/my-project/src/components/panels/` matching
the original `upload/extracted/src/components/*` text + visuals verbatim.

## Files written
| File | Lines | Status |
|------|-------|--------|
| `src/components/panels/cosmetics-shop.tsx` | ~1620 | ✅ rebuilt |
| `src/components/panels/player-profile.tsx` | ~1290 | ✅ rebuilt |
| `src/components/panels/arena-selector.tsx` | ~385 | ✅ rebuilt |
| `src/components/panels/auth-gate.tsx` | ~330 | ✅ NEW file |
| `src/components/panels/game-rules-modal.tsx` | ~205 | ✅ rebuilt |

## Source-of-truth audits read
- `worklog.md` AUDIT-C (lines 2410–3160) — every cosmetics + profile text string
- `worklog.md` AUDIT-D (lines 4770–6064) — every menu panel text string + ARENA_TIERS / PRACTICE_TIERS data
- Original source files: `CosmeticsShop.tsx` (1810), `PlayerProfile.tsx` (1429), `ArenaSelector.tsx` (328), `AuthGate.tsx` (376), `GameRulesModal.tsx` (173)
- `src/lib/game-config.ts` — exact cosmetics list (13 skins + 3 trails + 2 deaths + 6 flags + 3 banners), ARENA_TIERS / PRACTICE_TIERS, COUNTRIES (12)
- `src/components/providers/auth-provider.tsx` — `useAuth()` API

## Adaptations to BUILD-2 server-authoritative stack
1. **CosmeticsShop**
   - Premium `ALL_COSMETICS` items go through `POST /api/player/cosmetic` with `{action, skinId}` per task spec.
   - 20 free SLITHER_PRESETS + Genetic Pattern Lab custom skin persist to `localStorage['venom_custom_skin_state']` (server has no concept of custom-skin segments; GameCanvas reads this key client-side).
   - Live canvas previews preserved verbatim:
     - `SkinsCanvasPreview` — 180×80 canvas, 10 segments, 60fps RAF loop with exact `Math.sin(time - i*0.42)*9` wiggle formula.
     - `TryOnPreview` — 450×180 canvas, 26 segments, mouse-steerable with auto-patrol fallback + forked tongue blink when `Math.sin(Date.now()*0.012) > 0.45`. Caption: `"LAB HOLO-PREVIEW (STEER TO TEST)"`.
   - All 20 SLITHER_PRESETS colors/shape/taper/glow replicated from AUDIT-C C.3.
   - All 18 PALETTE_COLORS from AUDIT-C A.1.
   - All 6 BODY_STYLE_OPTIONS + 4 TAPER_OPTIONS + glow toggle.
   - 4-step Pattern Lab (Construct Stripe Sequence / Choose Segment Geometry / Body Taper Physics / Bioluminescent Aura) with Deploy button.
   - SSR-safe localStorage reads via `readCustomSkinStateSafe()` + lazy `useState` initializers (avoids `react-hooks/set-state-in-effect` lint error).

2. **PlayerProfilePanel**
   - 4 tabs (`stats | history | friends | identityLog`) + Co-Op Invite modal.
   - Reads `player`/`refresh`/`logout` from `useAuth()`.
   - Identity changes go through `PUT /api/player` `{name, country, avatar, instagram, youtube, twitch}` (server whitelists name/country/avatar; socials persist via `localStorage['venom_social_channels']`).
   - Friends / matches / identity-logs persist to original localStorage keys (`venom_friends`, `venom_match_history`, `venom_identity_history_log`).
   - Co-Op modal writes `localStorage['venom_active_match_invite']` (consumed by ArenaSelector).
   - 8 stat cards + Annual Tournament Guardrails card (3 caps: 10k matches/yr, 25L chips/yr, 12 ads/day).
   - 4 default friends + 3 sample matches seeded exactly as original.
   - 12 FACTION_COUNTRIES, 8 PRESET_AVATARS.

3. **ArenaSelector**
   - Props: `{ onPlay: (arenaId: string, isOnline: boolean) => void }`. Page's `handlePlayArena = (arenaId: string) => void` is assignable (narrower callback).
   - Reads `player.bankedChips` from `useAuth()` for affordability checks.
   - Polls `/api/arena-stats` every 5s while in online mode.
   - 7 ARENA_TIERS + 3 free PRACTICE_TIERS.
   - Selected arena detail card with Stake Buy-In / Target Value / Active Challengers / XP Multiplier rows.
   - Launch button label: online=`BUY IN ARENA (-N c)` / `STAKE AMOUNT EXCEEDS BANK`; offline=`START PRACTICE MODE (FREE)`.

4. **AuthGate** (NEW file — coexists with `src/components/auth/auth-gate.tsx`)
   - Calls `/api/auth/login`, `/api/auth/register`, `/api/auth/guest`.
   - After success calls `useAuth().refresh()` to populate the dashboard.
   - 3 tabs (Login / Register / Guest), 5 region dropdown values, Google + Apple social connectors.
   - Guest warning preserves original "results" typo per AUDIT-D.

5. **GameRulesModal**
   - Props: `{ open: boolean, onOpenChange: (open: boolean) => void }` (shadcn Dialog signature).
   - 6 sections with EXACT text from AUDIT-D O (Steering & Controls / Online vs Offline / Star Chips & Orbs / Extraction / Global Friends / FAQ).
   - Close button: `"Understood & Ready to Play"`.

## Lint status
After running `bun run lint`, my 5 files report **0 errors / 0 warnings**.
The 3 remaining lint errors (`clan-system.tsx`, `player-inspector-modal.tsx`, `social-panel.tsx`) are pre-existing in OTHER agents' files and were not touched by BUILD-11.

## TypeScript status
`bunx tsc --noEmit` reports **0 errors** for my 5 files. (Remaining tsc errors are all in `upload/extracted/src/**` and unrelated `mini-services/` files.)

## Dev server
Dev server (`bun run dev`) compiles cleanly. `curl http://localhost:3000/` returns HTTP 200. The page renders the AuthGate loading spinner, and authenticated routes can mount `<ArenaSelector />`, `<CosmeticsShop />`, `<PlayerProfilePanel />`.

## Notes for next agents
- `panels/auth-gate.tsx` is the faithful replica. The page currently imports `AuthGate` from `@/components/auth/auth-gate` (existing implementation). To swap in the new replica, change the import in `src/app/page.tsx` from `@/components/auth/auth-gate` to `@/components/panels/auth-gate`.
- `panels/game-rules-modal.tsx` uses the new `{open, onOpenChange}` API. The page imports from `@/components/modals/game-rules-modal` (old API `{isOpen, onClose}`). To swap, update the page import + call site.
- `localStorage['venom_custom_skin_state']` is the canonical source-of-truth for the equipped custom skin (preset or DNA-lab). GameCanvas should read this key client-side to render the custom wiggle pattern. If `useCustomSkin === true`, ignore `player.currentSkin`; otherwise use `player.currentSkin` for premium cosmetics.
