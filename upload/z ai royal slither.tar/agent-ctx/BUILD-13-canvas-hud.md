# BUILD-13 — Canvas HUD (arena leaderboard, rank, commission, minimap/full-map toggles)

**Agent:** canvas-hud
**Scope:** Update `src/components/game/render-helpers.ts` and
`src/components/game/game-canvas.tsx` to render the new HUD elements driven
by the BUILD-13 server snapshot fields (`realPlayerCount`, `yourRank`,
`arenaLeaderboard`, `commissionRate`).

## Files modified

| File | Action | Lines (before → after) |
|------|--------|------------------------|
| `src/components/game/render-helpers.ts` | Added `range?` to `MinimapArgs`; added `drawFullMap()` function | 706 → 856 |
| `src/components/game/game-canvas.tsx` | Added arena-leaderboard / minimap / full-map HUD state + refs; updated `onSnapshot` to consume new server fields; added M-key handler; canvas loop draws full-map overlay + respects minimap visibility; new JSX for leaderboard panel, minimap toggle, commission display, full-map close button | 2015 → 2392 |

## What was added

### 1. Arena Leaderboard Panel (top-right, below BANKED/FPS + chat/minimap row)
- Title: `"ARENA LEADERS"` (mono uppercase, slate-500, Trophy icon)
- Lists up to 10 entries from `snapshot.arenaLeaderboard` (online) or
  client-built from snakes by score (offline edge-case where
  `realPlayerCount === 0` in a non-practice arena).
- Each row: rank #, country flag emoji (via `countryFlag()`), name
  (truncated with `title=` tooltip), chips (emerald, `c` suffix) for
  online OR score (indigo-300, no suffix) for offline-mode.
- Player's own row highlighted with `bg-indigo-500/15` border +
  `"YOU"` badge (indigo).
- Collapsible: header has a `ChevronUp` collapse button; collapsed state
  renders a small `ChevronDown` + "Show Leaderboard" pill button.
- Mobile: defaults to collapsed on screens < 640px (via `useEffect`
  that checks `window.innerWidth`).
- Empty state: "No real players yet." placeholder.

### 2. "Rank: #X of Y" Display (top-left HUD)
- Online (`realPlayerCount > 1`): `"Rank: #X of Y"` where
  X = `snapshot.yourRank`, Y = `snapshot.realPlayerCount`.
  Falls back to client-computed `hudRank` if `yourRank === 0`.
- Online with `realPlayerCount <= 1`: `"Rank: #1 of 1"`.
- Offline (`isOfflineMode === true`): `"Rank: #X"` computed client-side
  by sorting all snakes by score and finding the player's index.
- Yellow-400 color, Trophy icon (unchanged from AUDIT-A).

### 3. Dynamic Commission Display (extraction popup)
- Added below the extraction progress bar, only when `!isOfflineMode`.
- `commissionRate > 0`: `"FEE: 35%"` (yellow-500).
- `commissionRate === 0`: `"FEE: 0% (LOW POPULATION)"` (emerald-400).

### 4. Offline Mode HUD Changes
- **Note:** BUILD-14 already routes practice arenas (`arenaId.startsWith('practice-')`)
  to a separate `OfflineGameEngine` that owns the canvas + HUD. The React
  component returns early with just a bare `<canvas>` for offline mode.
  Therefore the offline HUD changes (hide chips, hide minimap, score-only
  leaderboard, rank by score) are already handled by the offline engine.
- This task's offline changes apply to the **online-mode edge case** where
  `realPlayerCount === 0` (server reports no real humans in a regular
  arena). In that case `isOfflineMode = isOffline || hudRealPlayerCount === 0`
  becomes true and the React HUD:
  - Hides the "Carried Chips" card.
  - Shows "Offline Mode: 1 Player" instead of "Real Players: N Active".
  - Builds the leaderboard from snakes by score (not server chips).
  - Rank display switches to `"#X"` (score-based).

### 5. Minimap + Full Map Toggle (online mode)
- **Minimap toggle button**: added next to the chat button in a row at
  `top-[92px] right-3`. Shows `MapIcon` + "Collapse" / "Show Minimap"
  text (text hidden on mobile via `hidden sm:inline`). Toggles
  `minimapVisible` state → `minimapVisibleRef` → canvas loop skips
  `drawMinimap()` when false.
- **Small corner minimap**: `drawMinimap()` now receives `range: 1800`
  so only snakes within ~1800 world units of the player render (per
  BUILD-13 spec). The radar disc itself still shows the arena boundary
  and concentric rings.
- **Full map overlay (M key)**: pressing `M` toggles `fullMapOpen` state
  → `fullMapOpenRef` → canvas loop calls `drawFullMap()` instead of the
  regular scene. The overlay shows the ENTIRE arena (boundary circle
  scaled to fit the screen), all snakes as dots (player=indigo+ring,
  bots=rose, other humans=emerald), concentric range rings, crosshairs,
  a legend (top-left), title "ARENA OVERVIEW — ALL SNAKES", and
  "Press M to close" hint. An HTML close button (X icon) also appears
  at `top-right` for pointer access. Input + ping still emit while the
  map is open so the snake keeps moving.

### 6. Live Collection Feed
- Skipped per task instructions (no server event yet). Placeholder note
  left in the worklog.

## Implementation details

### render-helpers.ts
- `MinimapArgs.range?: number` — optional world-space radius. Defaults
  to `WORLD_SIZE / 2` (legacy full-radar). Small corner minimap passes
  `1800`.
- `drawFullMap(args: FullMapArgs)` — new exported function. Draws in
  screen-space (no camera transform). Scales the arena diameter to fit
  `min(w, h) - 160px`. Uses `setTransform(1,0,0,1,0,0)` to reset any
  prior DPR transform, then draws in raw CSS pixels.

### game-canvas.tsx
- **New state**: `hudCommissionRate`, `hudLeaderboard`
  (`ArenaLeaderboardEntry[]`), `hudYourRank`, `hudRealPlayerCount`
  (defaults to `isOffline ? 0 : 1` to avoid a brief "offline" flash
  before the first snapshot), `leaderboardOpen`, `minimapVisible`,
  `fullMapOpen`.
- **New refs**: `minimapVisibleRef`, `fullMapOpenRef`, `isOfflineModeRef`
  — synced via `useEffect` so the rAF loop reads only refs.
- **`onSnapshot` handler**: reads `realPlayerCount`, `yourRank`,
  `commissionRate`, `arenaLeaderboard` from the server payload. Sets
  the new state. Rank logic: online (`realPlayerCount > 0 && yourRank > 0`)
  → `setHudRank(yourRank)`; otherwise falls back to score-sort.
  Leaderboard: online → `serverLeaderboard`; offline → builds top-10 by
  score from `data.snakes` with `isPlayer: s.id === myId`.
- **Keyboard handler**: `M` key toggles `setFullMapOpen((prev) => !prev)`.
  Only active in online mode (offline returns early from the input
  effect).
- **Canvas loop**: after the clear, checks `fullMapOpenRef.current`. If
  true and a snapshot exists, calls `drawFullMap()` + emits input/ping +
  early-returns (skips the regular scene). Minimap drawing gated by
  `minimapVisibleRef.current` and passes `range: 1800`.
- **`playAgain()` / `onJoined`**: reset all new state to defaults.
- **Derived values**: `isOfflineMode = isOffline || hudRealPlayerCount === 0`;
  `rankDisplay` string built from mode + `hudYourRank` / `hudRealPlayerCount`.

## Verification
- `bun run lint` → exit 0 (no errors, no warnings).
- `bunx tsc --noEmit` → zero errors in `game-canvas.tsx` and
  `render-helpers.ts` (pre-existing errors in other files are not in
  scope).
- Dev server compiles cleanly (`✓ Compiled in …ms`).
- `curl http://localhost:3000/` → HTTP 200.

## Things deliberately NOT done (out of scope)
- **Live collection feed** (section 6 of the task): skipped per task
  instructions ("we don't have that event yet, skip this for now —
  leave a placeholder").
- **Offline engine changes**: BUILD-14's `OfflineGameEngine` already
  owns the offline HUD (no chips, no minimap, score-based leaderboard,
  rank by score). No changes needed there.
