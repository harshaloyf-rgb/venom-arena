# BUILD-14 — Offline client-side game engine

**Agent**: Build (offline engine)
**Task ID**: BUILD-14
**Scope**: Pure client-side snake game engine for the three `practice-*` arenas (Easy 30 / Medium 50 / Hard 75 bots). No Socket.IO, no chips, no minimap, no XP. Runs entirely in the browser via `requestAnimationFrame`.

## Context references
- Read `worklog.md` Phase 1 specs + AUDIT-A (HUD strings) + AUDIT-B (game mechanics).
- Read `src/lib/game-config.ts` for constants (WORLD_SIZE=8000, MAP_BASE_RADIUS=3800, BASE_SPEED=6.4, BOOST_SPEED=11.6, INITIAL_BODY_LENGTH=12, FOOD_COUNT_TARGET=1200, COLLISION_HIT_FACTOR=0.75, BOOST_DROP_INTERVAL=40, TURN_BASE=0.15, TURN_MIN=0.045, TURN_SCORE_FACTOR=0.0006, EXTRACT_DURATION_MS=3000, etc.) + PRACTICE_TIERS (3 free arenas).
- Read `src/lib/types.ts` for `SnakeSnapshot`, `FoodSnapshot`, `MatchResult`, `PlayerProfile`.
- Read `src/components/game/game-canvas.tsx` (2016 lines) — existing online-only flow with Socket.IO.
- Read `src/components/game/render-helpers.ts` — pure render functions (`drawGrid`, `drawFood`, `drawSnake`, `drawParticles`, `getArenaRadius`, `FrameRenderCtx`, `Particle`).
- Read `mini-services/game-server/game-state.ts` + `spatial-grid.ts` — server-authoritative game logic that this engine mirrors (turn rate, speed, boost cost, food eating, collision, bot AI personalities).

## Files written

### `src/components/game/offline-engine.ts` (~960 lines, new)
Pure TypeScript class `OfflineGameEngine` with no React dependency.

**Public API**:
```typescript
class OfflineGameEngine {
  constructor(arena: ArenaTier, playerProfile: PlayerProfile, canvas: HTMLCanvasElement)
  start(): void
  stop(): void
  onExit: (result: { score: number; kills: number; durationSeconds: number }) => void
  onStateChange: (state: 'playing' | 'dead' | 'extracted') => void
}
```

**Architecture**:
- **World init**: 8000×8000 world, circular arena radius 3800 (breathes ±40 over 10 s cycle via `getArenaRadius`). Player spawns at world center (WORLD_RADIUS=4000) facing east with INITIAL_BODY_LENGTH=12 segments. `arena.botsCount` bots spawned at random positions inside the disc (capped at 1000). 1200 food pellets spawned (8-color palette, value 2-6, size 4-7).
- **Game loop**: `requestAnimationFrame` at 60 Hz. Physics runs in fixed `TICK_MS` (33.3 ms) steps via accumulator pattern (max 4 sub-steps per frame to prevent spiral-of-death). Render runs every rAF.
- **Player movement**: server-authoritative formula — turn rate `max(0.045, 0.15 - score*0.0006)`, speed 6.4 normal / 11.6 boost / 3.2 extracting-glide. Body trails via `points.unshift(newHead)` + `pop()` to target length `min(120, 12 + score)`. Size = `8 + sqrt(score) * 0.4`. Boost drops 1 tail segment every 40 frames (requires `points.length > 8`), score floor 0.
- **Bot AI**: 5 personalities (scavenger/opportunist/hunter/extractor/coward) cycled by index. Re-evaluates target angle every ~150 ms (120 + random 80 ms). Scans grid for nearest food within 260 px and nearest foreign body segment within 150 px. Cowards/extractors/opportunists flee threats < 140 px; hunters occasionally boost (5% chance when score > 5); all seek nearest food otherwise. Edge avoidance turns back toward center when within 250 px of the wall.
- **Spatial hash grid** (`SpatialHashGrid` class, cellSize=120): rebuilt every tick. Stores snake body segments (every 2nd segment for perf) + food pellets. `queryRadius` returns a deduplicated Map. Turns collision/food checks from O(n²) to O(n).
- **Food eating**: head queries grid within `snake.size + 20`. If distance < `snake.size + food.size + 6`, +1 score and zero the food (sentinel `value=0`). No star chips ever (`isStarChip: false` always). Player gets a 4-particle burst; bots don't (perf).
- **Collision detection**: for each living, non-spawn-protected snake, check (a) wall — head outside breathing map radius → death; (b) body — head vs foreign non-head segment, distance < `(head.size + seg.radius) * 0.75` → death. No self-collision. Head-to-head ignored (segIdx===0 skipped). Deaths collected and applied after iteration (no Map mutation mid-iter).
- **Death handling**: player death → spawn 24-particle burst, show death screen, allow restart. Bot death → mark dead, credit kill to player if player was the killer, remove bot, respawn a new bot to maintain count. No drops (chip-less — no food drop, no star drop).
- **Extraction**: hold E key or EXTRACT button → `isExtracting=true`, glide at 3.2 speed, accumulate `extractionProgress` toward 3000 ms. On completion → state='extracted', show "Practice Run Completed!" screen.
- **Camera**: follows player head with lerp factor 0.18. Zoom: 0.58 mobile / 0.9 desktop, zooms out as body grows (`baseZoom - (len - 12) * 0.005`, floored at `baseZoom * 0.65`). No minimap.
- **Rendering**: reuses `render-helpers.ts` functions (`drawGrid` for breathing boundary + grid + bg, `drawFood` for batched-by-color food circles, `drawSnake` for snake bodies with skin patterns, `drawParticles` for additive-blend particles). Snake snapshots downsampled to max 60 points before passing to `drawSnake`. Touch joystick drawn in screen space.
- **HUD** (DOM overlays appended to `canvas.parentElement`, root has `pointer-events: none`, interactive children have `pointer-events: auto`):
  - Top-left stack: Score card (white dot + value) + Kills (rose) + Rank (yellow, by score vs bots) + Boost: SPACE (amber) + Bots count (slate).
  - Top-right stack: BANKED `{bankedChips}c` (amber, from profile, reference only) + FPS row + ping=`"— ms"` (slate).
  - Arena leaderboard panel (top-right, below BANKED): top 10 by score (player highlighted emerald, bots slate). Collapsible via header click (▾/▸ toggle). Rebuilds only when order/scores change (signature string compare).
  - Top-center extract hint: "Hold E or tap EXTRACT to end your practice run."
  - Extract progress bar (hidden by default): percentage + amber gradient bar.
  - Quick chat emotes bar (bottom-left): "Emotes (Keys 1-5)" + 5 buttons (GG! 🏆 / Target! 🎯 / Flee! 🏃💨 / Ripped! 💪 / Extracting! ⚡). Sets a 4-second chat bubble above the player's head.
  - Mobile controls (bottom-right): BOOST button (amber, hold via pointerdown/up, adds ' ' to keys set) + EXTRACT button (emerald, hold to extract).
  - Leave button (bottom-left): "⨯ Leave" → immediate exit to lobby.
- **End screen** (death or extract): full-screen overlay with the exact AUDIT-A strings — extract: "Practice Run Completed!" + subtitle with kills/length/duration + stats panel (Opponents Eliminated / Max Length / Survival Time) + "Offline Training Complete" notice + "PLAY AGAIN" (emerald gradient) + "RETURN TO LOBBY" buttons. Death: "Arena Disintegration!" + "Offline Training — No chips lost." + same stats panel + "No chips were wagered or lost — offline practice only." notice + "PLAY AGAIN" (red gradient) + "RETURN TO LOBBY". ESC also exits.
- **Input**: mouse follow (15 px deadzone), keyboard (WASD/arrows + SPACE boost + E extract + 1-5 emotes + ESC exit), touch joystick (bottom-left quadrant, 70 px max radius, 0.18 deadzone, magnitude > 0.6 = boost). `touch-action: none` on canvas. Window blur clears all keys + cancels extract.
- **Performance**:
  - Spatial hash grid → O(n)-ish collision + food queries.
  - Snake bodies capped at MAX_BODY_LENGTH=120; rendered via downsampled stride (max 60 stroke points).
  - Viewport culling via `computeVisibleRect` in `render-helpers` (skips off-screen snakes/food inside `drawSnake`/`drawFood`).
  - Adaptive quality: FPS < 40 for 2 s → `lowQuality=true` (disables glow/shadow in `drawGrid` boundary, `drawSnake` head halo, particle bursts). FPS > 55 for 5 s → re-enables. Hysteresis band 40-55 prevents flapping.
  - Particles capped at MAX_PARTICLES=200 (splices oldest when exceeded).
  - DPR capped at 2.
  - ResizeObserver on canvas → DPR-aware resize, invalidates metallic gradient cache.
- **Skin resolution**: reads `localStorage['venom_custom_skin_state']`; if `useCustomSkin===true` and `currentSkin` is a real preset id (not `'custom-lab-skin'`), uses `getCosmeticById(currentSkin)`. Otherwise falls back to `getCosmeticById(profile.currentSkin)`. The resolved `Skin` is passed via `FrameRenderCtx.playerSkin` so `drawSnake` applies the rainbow/neon/metallic/camo patterns to the player's body.

### `src/components/game/game-canvas.tsx` (edits)
- Imported `OfflineGameEngine`, `OfflineExitResult`, `OfflineState` from `./offline-engine`.
- Added `offlineEngineRef` + `offlineFinalStateRef` refs.
- **Socket.IO effect**: added early-return guard `if (isOffline) { setPhase('playing'); setConnectingMsg(''); return; }` at the top. Practice arenas never fetch a JWT, never connect Socket.IO.
- **New OFFLINE ENGINE EFFECT** (mount-once, deps `[arena, isOffline, player]`): when `isOffline`, instantiates `OfflineGameEngine(arena, player, canvas)`, wires `onStateChange` (tracks final state for outcome) and `onExit` (adapts `OfflineExitResult` → `MatchResult` with `chipsExtracted=0`, `commission=0`, `bankedAmount=0`, `xpGained=0`, `newLevel=player.level`, `newBankedChips=player.bankedChips`, `deaths=(outcome==='death'?1:0)`). Calls `engine.start()`. Cleanup: `engine.stop()`.
- **Canvas render loop effect**: added `if (isOffline) return;` guard (engine owns the rAF + canvas). Added `isOffline` to deps.
- **Input effect**: added `if (isOffline) return;` guard (engine attaches its own listeners). Added `isOffline` to deps.
- **JSX**: added early-return for offline mode — renders ONLY `<div className="fixed inset-0 ..."><canvas .../></div>`. All React HUD/overlays/end-screens/chat-dialog are skipped (engine builds its own DOM overlays as children of `canvas.parentElement`).

## Verification
- `bun run lint` → 0 errors, 0 warnings.
- `npx tsc --noEmit --skipLibCheck` → no errors in `offline-engine.ts` or `game-canvas.tsx` (fixed one initial type error: `Food` interface needed `isStarChip: boolean` field to be structurally compatible with `FoodSnapshot[]` passed to `drawFood`).
- `dev.log` shows successful Next.js compiles after every save ("✓ Compiled in …ms"), no runtime errors.
- The `Food` interface in `offline-engine.ts` is now structurally compatible with `FoodSnapshot` from `src/lib/types.ts` (all 7 fields match), so `drawFood(rc, this.foods)` type-checks.

## Notes / deviations
- The original server's `tickSnakeMovement` has a quirky `Math.max(BOOST_MIN_LENGTH, snake.score - 1)` floor when boost drops a segment — that would *increase* score from 0 to 8 on the first boost drop (clearly a server bug). I used `Math.max(0, snake.score - 1)` instead, which is the correct behavior (score floor at 0, body length naturally bounded by the `targetLen` clamping to `min(120, 12 + score)`).
- Bots are spawned with personality cycled by index (`PERSONALITIES[idx % 5]`) rather than random — deterministic and guarantees an even mix of all 5 personalities across the bot population.
- Bots never drop food on death (chip-less mode per spec — "No drops"). They simply vanish and a new bot spawns elsewhere to maintain count.
- The leaderboard panel rebuilds its DOM only when the top-10 signature changes (joined `id:score` string compare), avoiding per-frame innerHTML thrash.
- HUD "icon" dots are simple colored `<span>` circles (8×8 px) instead of SVG icons — keeps the engine file lean and avoids pulling lucide-react into a non-React module.
- The `onExit` adapter constructs a `MatchResult` with `outcome='extract'|'death'` based on `offlineFinalStateRef`, so the existing `handleExitGame` callback in `page.tsx` works unchanged (shows "🏆 Extracted 0c from {arenaName}! +0 XP" or "💀 Eliminated in {arenaName}. N kill(s) this match.").
