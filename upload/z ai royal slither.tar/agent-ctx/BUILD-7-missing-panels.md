# BUILD-7 — Missing UI Panels

**Task ID:** BUILD-7
**Agent:** missing-panels
**Scope:** 6 missing UI panels + 2 admin API endpoints, replicating the original `upload/extracted/src/components/` designs with proper dark-slate styling.

## Files created

### Panels (`src/components/panels/`)
| File | Lines | Export |
|------|-------|--------|
| `championships.tsx` | 472 | `Championships` |
| `season-pass.tsx` | 330 | `SeasonPass` |
| `clip-showcase.tsx` | 371 | `ClipShowcase` |
| `admin-panel.tsx` | 431 | `AdminPanel` |
| `game-rules-modal.tsx` | 221 | `GameRulesModal` |
| `player-inspector-modal.tsx` | 513 | `PlayerInspectorModal` + `InspectedPlayer` interface |

### API routes (`src/app/api/admin/`)
| File | Lines | Purpose |
|------|-------|---------|
| `modify-chips/route.ts` | 50 | Admin-only. Atomically adjusts `bankedChips` (clamped at 0). |
| `ban/route.ts` | 39 | Admin-only. Sets `banned` flag. Refuses self/admin bans. |

Total: **8 files, 2428 lines.**

## Visual style (matches task spec)

- `bg-slate-950`, `bg-slate-900/60`, `border-slate-800/80`, `rounded-2xl`, `shadow-md`
- Color semantics: indigo (primary), purple (season), amber (trophies/chips), emerald (success), red (admin), yellow (championships)
- Labels: `text-[10px] font-mono uppercase tracking-widest text-slate-500`
- Headings: `font-black text-white tracking-tight`
- `lucide-react` icons throughout
- shadcn `Dialog` for both modals

## Admin security model

Both API routes use the same gate:
1. `getSession()` reads httpOnly `va_session` cookie
2. 401 if not authenticated
3. 403 if `session.role !== 'admin'`
4. 404 if target userTag doesn't exist
5. 400 if banning self or another admin

This replaces the old `AdminPanel.tsx` fake "Quick Unlock" button with proper server-side authorization.

## Verification

- `bun run lint` → exit 0
- `npx tsc --noEmit | grep BUILD-7-files` → empty
- `curl http://localhost:3000/` → HTTP 200
- dev.log shows no new compile errors

## Wiring note for next agent

These panels are NOT yet wired into `src/app/page.tsx`. To mount them, add tabs and import the named exports. Suggested tab additions:
- `championships` → `<Championships onPlayChampionship={…} />`
- `season` → `<SeasonPass />`
- `clips` → `<ClipShowcase />`
- `admin` → `<AdminPanel />` (only visible if `player.role === 'admin'`; the component self-gates and shows "Access Denied" otherwise)

The two modals (`GameRulesModal`, `PlayerInspectorModal`) should be mounted at the app-shell level with `open`/`onOpenChange` props controlled by parent state. `PlayerInspectorModal` accepts an `InspectedPlayer | null` prop — populate it from the Leaderboards or Social panels when a player row is clicked.
