# BUILD-8 — Rebuild existing UI panels (match original visual style)

## Task

Rewrote the 8 panels in `/home/z/my-project/src/components/panels/` so their
visual design matches the dark-slate / indigo-accent style of the original
`upload/extracted/src/components/*.tsx` reference files.

Also added a shared primitive module `_panel-primitives.tsx` that all panels
import from, so the design language (cards, headings, micro-labels, primary
button, ghost button, glow blobs, skeletons, error cards) is consistent and
DRY across the 8 panels.

## Files created / rewritten

| File | Lines | Purpose |
|------|-------|---------|
| `_panel-primitives.tsx` | 207 | Shared: `PanelShell`, `GlowBlob`, `MicroLabel`, `PanelTitle`, `PrimaryButton`, `GhostButton`, `PanelSkeleton`, `ErrorCard`, `NotSignedIn`, `notify()` toast helper. |
| `arena-selector.tsx` | 434 | Two-stage flow: portal select (Online PVP / Offline Practice) → tier grid with detail panel. |
| `cosmetics-shop.tsx` | 330 | Tabs: Skins/Trails/Death/Flags/Banners. Grid of cosmetic cards with emoji preview, color swatches, Buy/Equip/Equipped states. |
| `player-profile.tsx` | 528 | Editable avatar/name/country popover pickers, userTag with copy button, clan tag, XP bar, 8-stat lifetime grid, equipped loadout (skin/trail/death/flag/banner), logout. |
| `leaderboards.tsx` | 215 | Tabs: Top Chips / Top Level. Scrollable 50-row list with 🥇🥈🥉 medals, country flags, YOU highlight, refresh. |
| `daily-rewards.tsx` | 229 | 7-day calendar with claimed/today/future states. Big claim button or "Already claimed" disabled state. Streak badge. |
| `chip-store.tsx` | 211 | 4-pack grid with POPULAR badge on Grinder pack. "Demo store — no real charges" note. Compliance footer. |
| `social-panel.tsx` | 1022 | 3-tab social hub: Friends (accept/decline/gift 25c/remove), Syndicates (create form + browse + chat with 5s polling + leave), Find Player (by userTag). |
| `hall-of-fame.tsx` | 325 | Top 10 legends table (gold accents, crown on rank #1) + 3 milestone cards (First 1M Chips, First 100K Banked, Apex Veteran Lvl 30) computed from real leaderboard data — NO fabricated names. |

Total new/rewritten code: **9 files, 3841 lines**.

## Visual style applied (matches original reference)

- Outer card: `rounded-2xl border border-slate-800/80 bg-slate-900/60 shadow-md p-5 sm:p-6`
- Headings: `font-sans font-black text-white tracking-tight` (text-xl/2xl/3xl)
- Micro labels: `text-[10px] font-mono uppercase tracking-widest text-slate-500`
- Primary button: `bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs uppercase tracking-wider`
- Hover lift: `hover:border-{accent}-500/40 hover:-translate-y-0.5 transition-all duration-300`
- Stat values: `font-mono text-emerald-400` for chips, `font-mono text-white` for numbers
- Per-panel accent: indigo (arena), purple (cosmetics/profile-loadout), violet (social), amber (leaderboards), emerald (daily/store), yellow (halloffame)
- Glow blobs: `absolute rounded-full blur-3xl bg-{color}/10` for ambient color
- Custom scrollbar (`.va-scroll`) on all long lists

## Behavioral notes / decisions

1. **ArenaSelector two-stage flow** — original was a single page with mode
   toggle. Per spec, I built a "SELECT COMBAT PROTOCOL" landing page with two
   big portal cards (Online PVP = indigo, Offline Practice = emerald), each
   with a checkmark feature list. Clicking a portal advances to the tier
   grid. A back button + mode toggle persist in stage 2 for easy switching.

2. **Affordability enforcement** — arena cards the player can't afford are
   dimmed (`opacity-60`) and the buy-in amount is shown in rose. Trying to
   enter an unaffordable arena triggers an error toast. The detail panel's
   launch button stays enabled but `handleEnter` re-checks and toasts.

3. **PlayerProfile inline-edit** — both debounced (800ms) AND immediate-on-blur
   save (same pattern as BUILD-4). Avatar and country use popover-style
   dropdowns (custom; not the shadcn Popover) so the visual stays inside the
   panel's dark theme. UserTag has a copy-to-clipboard button with a 1.5s
   green-checkmark feedback.

4. **DailyRewards calendar logic** — mirrors BUILD-4: if `lastDailyClaim ===
   today`, the just-claimed day is `(dailyStreak - 1) % 7`; otherwise the
   upcoming claimable day is `dailyStreak % 7`. The "Today" pill is shown
   above the current claimable day; claimed days get a green checkmark.

5. **Hall of Fame milestones** — only computed from real leaderboard payload
   (bankedChips + level). Three milestones:
   - First 1M Chips → first entry with `bankedChips >= 1,000,000`
   - First 100K Banked → first entry with `bankedChips >= 100,000`
   - Apex Veteran → first entry with `level >= 30`
   All others honestly show "Unclaimed — No challenger has claimed this yet."
   No fabricated player names (per spec).

6. **CosmeticsShop preview** — replaced the original 200-line `<canvas>`
   animated preview with a simpler static emoji-in-glowing-box preview that
   uses the cosmetic's `color` as a radial gradient + drop-shadow. Visually
   on-brand, far cheaper to render, and avoids the per-frame canvas work the
   audit flagged as a FPS killer.

7. **SocialPanel chat polling** — kept the 5-second polling pattern from
   BUILD-4. Used a ref (`errorRef`) for the error message inside the
   `fetchMessages` callback to avoid the stale-closure lint warning. Auto-
   scrolls to bottom on new messages. Sends on Enter (without Shift).

8. **Shared primitives** — `_panel-primitives.tsx` exports `notify()` which
   routes through `onToast` prop if provided, else falls back to `sonner`'s
   `toast.success/error/info`. Every panel uses this so toasts are
   consistent. `ErrorCard` and `NotSignedIn` are used in every panel for
   consistent error / unauth states.

## Verification

- `bun run lint` → exit 0 (no errors, no warnings) across the whole project.
- `npx eslint src/components/panels/` → exit 0.
- Dev server `bun run dev` (auto-run): all 8 panels compiled and rendered
  without errors in `dev.log`.
- Verified end-to-end via `agent-browser`:
  - **Play tab** → "SELECT COMBAT PROTOCOL" page shows two portal cards
    (Online PVP / Offline Practice). Clicking Online PVP → tier grid with all
    7 arenas (Training Pit, Slum Alley, Neon Grid, Viper Syndicate,
    Championship Hub, The Apex Vault, Venom Syndicate Grand). Selecting Slum
    Alley → detail panel shows BEGINNER MATCH, 10 CHIPS buy-in, 22 snakes,
    x1 XP multiplier, "BUY IN ARENA (-10C)" button.
  - **Shop & Lab** → "IDENTITY WORKSHOP & SHOP", chips balance (150c), 5
    tabs (Skins/Trails/Death Bursts/Flags/Banners) with emoji + Equipped
    badge on active item.
  - **Dossier** → "CHALLENGER DOSSIER" with avatar 🐍, editable name,
    userTag VENOM-9069 with copy button, country (🇺🇸 US), Level 10 XP bar,
    clan "No clan", Sign Out button.
  - **Leaderboard** → "GLOBAL LEADERBOARDS" with Top Chips / Top Level tabs,
    🥇 medal + 🇺🇸 flag + Guest entry (current player).
  - **Claims** → "DAILY CLAIMS CALENDAR" with 7-day grid, "Today" pill on
    Day 1 (25c), Current Streak 0 days.
  - **Vault** → "CHIP VAULT" with 4 packs (Starter, Grinder [POPULAR],
    High Roller, Whale) and chips balance.
  - **Hall of Fame** → "HALL OF FAME" with top 10 legends table (🥇🥈🥉
    medals, crown on rank #1) and 3 milestone cards.
  - **Syndicates** → "SOCIAL HUB" with Friends / Syndicates (Clans) / Find
    Player tabs. Default Friends tab shows "No friends yet" empty state.

All panels match the dark slate + indigo/purple/amber/emerald/violet/yellow
accent palette of the original reference components.
