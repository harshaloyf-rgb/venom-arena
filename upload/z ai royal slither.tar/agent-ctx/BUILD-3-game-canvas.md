# BUILD-3 — Game Canvas

## Summary

Built a clean, crashless, performant `<GameCanvas />` React component that
replaces the 4110-line monster audited in ANALYSIS-2. The new canvas talks
to the Socket.IO game server (port 3001) via the Caddy gateway and fixes
every bug class flagged in the 117-issue audit.

## Files created

| File | Lines | Purpose |
|------|-------|---------|
| `src/app/api/auth/token/route.ts` | 29 | Returns a short-lived JWT (re-signed from the httpOnly session cookie) for socket auth. |
| `src/components/game/render-helpers.ts` | 595 | Pure canvas drawing functions: `drawGrid`, `drawFood`, `drawSnake`, `drawParticles`, `drawMinimap`, `computeVisibleRect`. No React dependency. |
| `src/components/game/game-canvas.tsx` | 1655 | The main component: socket lifecycle, rAF render loop, input (mouse + keyboard + touch), HUD, controls, chat dialog, death/extract overlays. |
| `src/app/page.tsx` | (updated) | Demo lobby: auth gate → arena selector → `<GameCanvas />` mount. |

## Props

```ts
interface GameCanvasProps {
  arenaId: string;
  player: PlayerProfile; // from useAuth()
  onExit: (result?: MatchResult) => void;
}
```

## Event contract used

Client → Server: `join_arena {arenaId}`, `input {angle, wantsBoost}`,
`extract {}`, `cancel_extract {}`, `chat {message}`, `leave {}`, `ping {t, id}`

Server → Client (all handled): `joined`, `join_error`, `snapshot`
(20 Hz), `match_result`, `extract_start`, `extract_progress`,
`extract_fail`, `death`, `chat`, `kicked`, `server_shutdown`, `error`,
`pong`, `connect`, `disconnect`, `connect_error`, `reconnect_attempt`

17 `socket.on(...)` calls ↔ 17 paired `s.off(...)` in cleanup.

## Key fixes vs ANALYSIS-2

- **C3**: `matchEndedRef` idempotency guard prevents double-credit on
  duplicate `death`/`match_result`.
- **C7/C8/S1/S2/S3**: All socket events wired with cleanup; `join_arena`
  re-emitted on every `connect`/`reconnect`; `connect_error`/`disconnect`
  handled with UI feedback.
- **C10**: Particle array capped at 200.
- **C11/P11**: Food batched by color into single `Path2D` + `fill()`.
- **C13**: All `points[0]` accesses guarded.
- **C15/S14**: No client-side `chatTimer` — server snapshot drives chat
  bubbles.
- **C19/I6/I11**: Pointer capture on Extract + Boost buttons.
- **I1**: Touch joystick implemented (bottom-left quadrant, tracked by
  `touch.identifier`).
- **I2**: 15px mouse deadzone (was 5px).
- **I4**: `preventDefault` on arrows/space.
- **I9**: `window blur` clears keys.
- **P1**: No `shadowBlur` per body segment — bodies are single stroked
  `Path2D`. Glow only on player's own head, high-quality only.
- **P2**: Metallic gradient cached in `Map`, invalidated on resize.
- **P13/S4/D9**: Single input emit site, throttled to 20 Hz.
- **P15**: Adaptive quality (FPS < 40 for 2s → low-quality; FPS > 55 for
  5s → high).
- **P16**: Viewport culling for snakes + food (+ 100px margin).
- **R1**: Single camera transform per frame.
- **R8**: Valid `ctx.font` shorthand.
- **R10/R11**: `setLineDash([])` reset after every dashed line.
- **U1/U2/U3**: ESC dismisses end-screen; "Play Again" re-emits
  `join_arena`.
- **U4**: FPS counter + ping indicator in HUD.
- **U5/U16**: Adaptive LQ mode with `🎨 LQ` indicator; no invalid
  Tailwind classes.
- **U11**: Extract button label says "EXTRACT" (not "SUCCESSFUL!").
- **U17**: Toast deduplication via shadcn `useToast`.

## How to mount

```tsx
import { GameCanvas } from '@/components/game/game-canvas';

<GameCanvas
  arenaId="tier-1"
  player={player}  // from useAuth()
  onExit={(result) => {
    // result?: MatchResult
    // Return to lobby
  }}
/>
```

## Verification

- `bun run lint` — 0 errors / 0 warnings for new files.
- `npx tsc --noEmit` — 0 type errors for new files.
- Dev server serves `/` with 200 OK.
- Game server (port 3001) is running and accepts the event contract.
- `/api/auth/token` returns 401 `{token:null}` when unauthenticated, 200
  `{token:"..."}` when authenticated.
