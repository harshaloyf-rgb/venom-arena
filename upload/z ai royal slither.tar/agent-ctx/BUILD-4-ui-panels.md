# BUILD-4 — UI Panels (8 components)

## Summary

Built 8 clean, server-backed, working panel components in
`src/components/panels/` that replace the 9k-line broken UI audited in
ANALYSIS-3. Every panel mounts without runtime errors, every button does
something real (no dead buttons), every fetch handles errors gracefully,
and **no data is duplicated** — all arenas, cosmetics, daily rewards,
chip packs, and countries are imported from `src/lib/game-config.ts`.

All 8 panels pass ESLint (exit 0) and TypeScript (exit 0) cleanly.

## Files created

| File | Lines | Purpose |
|------|-------|---------|
| `src/components/panels/arena-selector.tsx` | 217 | `ArenaSelector` — grid of `ARENA_TIERS` cards with difficulty badges, buy-in, reward mult, bots, min extract. Unaffordable cards dim + disabled. Header shows player chips+level. Calls `onPlay(arenaId)`. |
| `src/components/panels/cosmetics-shop.tsx` | 311 | `CosmeticsShop` — tabs by cosmetic type (Skins/Trails/Death/Flags/Banners). Grid of `ALL_COSMETICS` filtered by type. Buy/Equip/Equipped states. Color swatch + emoji + pattern label. NO duplicate items (single source: game-config). |
| `src/components/panels/player-profile.tsx` | 431 | `PlayerProfilePanel` — avatar (popover of 16 snake emojis), inline-editable name (debounced 800ms save + blur-save), country select, level/XP progress, lifetime stats 2-col/4-col grid, daily streak, clan tag, equipped cosmetics preview, logout. |
| `src/components/panels/leaderboards.tsx` | 177 | `Leaderboards` — tabs "Top Chips" / "Top Level", fetches `/api/leaderboard?type=chips\|level&limit=50`, Skeleton loading, 🥇🥈🥉 medals, current-player row highlight, max-h-60vh va-scroll, refresh button. |
| `src/components/panels/daily-rewards.tsx` | 191 | `DailyRewards` — 7-day cycle from `DAILY_REWARDS`, marks claimed days based on `dailyStreak` and `lastDailyClaim`, big claim button (disabled when already claimed today). |
| `src/components/panels/chip-store.tsx` | 174 | `ChipStore` — grid of `CHIP_PACKS`, "Popular" badge on `popular` pack, demo store note, "Get Pack" calls `/api/chips/pack` and refreshes player. |
| `src/components/panels/social-panel.tsx` | 877 | `SocialPanel` — 3 tabs: Friends (pending/accepted + gift 25c + remove), Clans (create form + browse + chat with 5s polling + leave), Find Player (by userTag). All actions persist via API. |
| `src/components/panels/hall-of-fame.tsx` | 266 | `HallOfFame` — top 10 by chips (`/api/leaderboard?type=chips&limit=10`), 3 milestone cards. Only the "First 1M Chips" milestone is computed from real data; the other two (100 extracts, 50-streak) honestly show "Unclaimed" since those fields aren't in the leaderboard payload — **no fabricated player names**. |

Total: **8 files, 2644 lines**.

## Shared patterns applied
- `'use client'` at top of every panel
- `import { useAuth } from '@/components/providers/auth-provider'` — for `player`, `refresh`, `logout`
- `import { toast } from 'sonner'` — fallback if `onToast` prop not provided
- Loading: `Skeleton` for grids/lists, `Loader2` spinners for buttons
- Error: small rose-bordered card with message + Retry button
- Empty: friendly message ("No friends yet. Find players in the Find Player tab!")
- All `fetch` wrapped in try/catch with `busy` state
- After mutations (buy/equip/daily/gift/pack): `await refresh()` from useAuth to sync header chips
- Responsive: 1-col mobile → 2-col sm → 3-4-col lg
- Accessible: `aria-label` on icon-only buttons, `aria-busy`, `aria-live="polite"` on chat, `sr-only` text where needed, no color-only signals
- NO `any` types — all API responses typed via `as { error?: string; ... }`
- NO `JSON.parse` without try/catch (none used — server returns typed JSON)
- NO localStorage — everything server-backed

## API endpoints used (all pre-existing)
- `GET /api/auth/me` (via useAuth)
- `POST /api/auth/logout` (via useAuth)
- `PUT /api/player` — name/country/avatar updates
- `POST /api/player/cosmetic {action, skinId}` — buy or equip
- `POST /api/player/daily` — daily reward claim
- `POST /api/chips/pack {packId}` — chip pack grant
- `GET /api/leaderboard?type=...&limit=...`
- `GET /api/friends/list` / `request` / `accept` / `remove` / `gift`
- `GET /api/clans/list` / `POST create` / `join` / `leave`
- `GET /api/clans/chat?tag=...` / `POST /api/clans/chat {tag, message}`

No new API endpoints were needed — all required routes already exist.

## Deviations / decisions
1. **DailyRewards claim logic**: The spec asked to "highlight today's claimable day based on `player.dailyStreak % 7`". The server uses `newStreak % 7` to index `DAILY_REWARDS`, where `newStreak` is `dailyStreak + 1` (if continued streak) or `0` (if reset). The client mirrors this: if `lastDailyClaim === today`, today's claimed day is `(dailyStreak - 1) % 7`; otherwise the upcoming claimable day is `dailyStreak % 7`. Marked claimed days as 0..`claimedCount-1`.
2. **Hall of Fame milestones**: Per spec, milestones "COMPUTED from the leaderboard data where possible". The leaderboard payload only includes `bankedChips`, `level`, `name`, `userTag`, `country`, `rank`. Only the 1M-chips milestone can be truthfully computed. The 100-extracts and 50-streak milestones honestly show "Unclaimed" rather than fabricating names (the old UI had `Hari #IND-001`, `Apex_Viper #USA-882` etc. — fake). A future `/api/leaderboard?type=extracts|streak` endpoint would let us fill these in.
3. **PlayerProfile save**: Implemented as both debounced (800ms) AND immediate-on-blur. Used refs for `onRefresh`/`onToast` to avoid stale-closure issues and to keep the debounce callback stable. Cleanup clears the timer on unmount.
4. **Clans chat polling**: 5-second interval via `setInterval`, with manual refresh button. Auto-scrolls to bottom on new messages. Stops polling on unmount.
5. **CosmeticsShop free presets**: All `cost: 0` cosmetics are auto-granted at registration per the API's `unlockedSkins` initialization. If a free item somehow isn't owned, the card shows "Claim Free" (calls `buy` with cost 0). NO duplicate free/paid conflicts — single source of truth is `ALL_COSMETICS` in game-config.
6. **SocialPanel gift**: Implemented as "Gift 25c" per spec (hard-coded 25). The API accepts any amount 1-1000; a future enhancement could add an amount picker.

## Pre-existing lint errors NOT in scope
`bun run lint` reports 4 errors + 1 warning, all in `upload/extracted/src/components/` (the OLD audited code kept as reference for ANALYSIS-3). My panel files in `src/components/panels/` pass ESLint with exit code 0 (verified with `npx eslint src/components/panels/`). The old reference files are out of scope for BUILD-4.

## Verification
- `npx eslint src/components/panels/` → exit 0 (no errors, no warnings)
- `npx tsc --noEmit` → no errors in `src/components/panels/` (only pre-existing errors in `upload/extracted/`)
- Mounted all 8 panels in a temporary `/test-panels` route and requested it from the running Next.js dev server → HTTP 200, no compile errors in dev.log, all panel headings rendered in the HTML output.
- Test route was removed after verification (per spec: only `/` route should exist).
