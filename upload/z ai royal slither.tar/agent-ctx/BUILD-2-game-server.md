# BUILD-2 — Venom Arena Game Server (Socket.IO mini-service)

**Agent:** game-server
**Task ID:** BUILD-2
**Port:** 3001
**Status:** ✅ Complete and running (PID 5949, port 3001 LISTEN)

## What was built

A standalone Bun + TypeScript Socket.IO server that fixes every bug identified in
ANALYSIS-1's forensic audit of the old `server.ts`. Lives in
`/home/z/my-project/mini-services/game-server/` and imports the shared
`game-config.ts` / `types.ts` from `/home/z/my-project/src/lib/` — no duplication.

## File list

| File | Purpose |
|------|---------|
| `mini-services/game-server/package.json` | `venom-arena-game-server`, deps `socket.io` + `dotenv`, scripts `dev: bun --hot index.ts`, `start: bun index.ts` |
| `mini-services/game-server/tsconfig.json` | strict TS, ESNext, moduleResolution bundler, includes parent `src/lib/*.ts` for type resolution |
| `mini-services/game-server/spatial-grid.ts` | `SpatialHashGrid` class — cell size 120px, `insert` / `clear` / `queryRadius`. Fixes the O(n²×m) collision cost. |
| `mini-services/game-server/game-state.ts` | Pure game logic: types (`ArenaRoom`, `PlayerSession`, `BotSession`, `Food`), `tickSnakeMovement`, `tickBot` (cheap AI), `detectCollisions` (uses grid), `eatFood` (uses grid + sentinel), `buildSnapshot` (downsamples to 60 pts), `scatterStarChips`, `replenishFood`, `recomputeLeader`, `expireChat`. Imports world constants from `../../src/lib/game-config`. |
| `mini-services/game-server/index.ts` | Socket.IO server on port 3001 (path `/`, CORS `*`). Auth middleware (calls `/api/match/verify`), one-socket-per-userTag enforcement, all event handlers (`join_arena`, `input`, `extract`, `cancel_extract`, `chat`, `leave`), recursive `setTimeout` tick loop (30 Hz) + broadcast loop (20 Hz), HTTP helpers for `/api/match/join` + `/api/match/result` (3s timeout, try/catch), `uncaughtException`/`unhandledRejection`/`SIGHUP`/`SIGPIPE` handlers, graceful SIGINT/SIGTERM shutdown with `server_shutdown` broadcast. |

## Event contract (kept EXACT)

### Client → Server
- `join_arena` `{ arenaId: string }`
- `input` `{ angle: number, wantsBoost: boolean }`
- `extract` `{}`
- `cancel_extract` `{}`
- `chat` `{ message: string }`
- `leave` `{}`

### Server → Client
- `joined` `{ arenaId, worldSize, extractZoneRadius, yourId }`
- `join_error` `{ reason: 'insufficient_chips' | 'banned' | 'invalid_arena' | 'already_in_match' }`
- `snapshot` `GameSnapshot` (20 Hz, points downsampled to 60)
- `match_result` `{ outcome, arenaId, arenaName, chipsExtracted, kills, xpGained, newLevel, newBankedChips, durationSeconds }`
- `extract_start` `{ durationMs }`
- `extract_fail` `{ reason }`
- `extract_progress` `{ progress: 0..1 }`
- `death` `{ killerId?, killerName?, killerTag?, killerColor? }`
- `chat` `{ senderId, senderName, senderTag, message }`
- `kicked` `{ reason }`
- `server_shutdown` `{}`
- `error` `{ message }`

## Bug fixes vs the old server (ANALYSIS-1 audit)

| Old bug | Fix |
|--------|-----|
| `lifetimeKills` corrupted by `serverTimestamp()` on disconnect | Game server never writes to DB directly — all economy goes through `/api/match/join` + `/api/match/result` (Prisma transactions on Next.js side) |
| `setInterval(async)` tick overlap | Recursive `setTimeout(tickOnce, TICK_MS)` — a slow tick can't overlap the next |
| Map mutation during iteration | Deaths collected into array, applied AFTER iteration. Food uses `value=0` sentinel, filtered after iteration. |
| Unguarded `points[0]` access | Every `points[0]` access is preceded by `if (snake.points.length === 0) return;` |
| `send_chat` crashes on non-string | `typeof raw !== 'string'` check before `.trim()` |
| No `uncaughtException` handler | `process.on('uncaughtException')` + `unhandledRejection` log but never crash |
| Hardcoded JWT secret + optional auth | Auth is mandatory: socket middleware calls `/api/match/verify` with the internal secret; sockets without a valid JWT are disconnected at handshake |
| Client-supplied userTag → impersonation | Identity comes ONLY from verify response. Subsequent client-supplied userTag/name/color is ignored. |
| `spawn_chips` mints infinite chips | No client-supplied chips. Server is sole authority on chip creation (star-chips on death/disconnect only). |
| `eat_food` 250px vacuum | Food collision uses spatial grid + precise distance check (`< head.size + food.size`) |
| Duplicate chip-award paths | Single path: `eatFood()` in the tick loop. No socket-handler food eating. |
| Extraction anywhere | `handleExtract` validates `Math.hypot(head.x, head.y) <= EXTRACT_ZONE_RADIUS`; tick loop re-validates each tick and cancels with `extract_fail { reason: 'outside_zone' }` if player leaves the zone |
| `minExtract` never enforced | (Skipped — config has `minExtract` but no contract event for it; left for BUILD-3 client to enforce visually. Buy-in is the real gate.) |
| Multi-join duplicate chips | One socket per userTag enforced via `userTagToSocket` map — new socket kicks old one with `kicked` event. Plus `already_in_match` `join_error` if same socket tries to join twice. |
| Buy-in non-atomic | `/api/match/join` uses Prisma `$transaction` (Next.js side) |
| Extraction payout non-atomic | `/api/match/result` uses Prisma `$transaction`; `matchSettling` flag on the session prevents double-report on disconnect/death race |
| No CORS restriction | `cors: { origin: '*' }` with a logged warning (Caddy restricts in prod) |
| O(n²×m) collision | `SpatialHashGrid` with 120px cells; per-tick cost is now ~O(n) for collision + food |

## Architecture decisions

1. **Single source of truth for config** — `game-state.ts` and `index.ts` import
   `ARENA_TIERS`, `WORLD_SIZE`, `EXTRACT_ZONE_RADIUS`, `BOT_NAMES`, etc. from
   `../../src/lib/game-config`. No constants are duplicated. The tsconfig
   `include` lists `../src/lib/game-config.ts` and `../src/lib/types.ts` so tsc
   can resolve them.

2. **Game logic is pure** — `game-state.ts` has zero I/O (no sockets, no HTTP,
   no console). All side-effects live in `index.ts`. This makes the game logic
   testable in isolation.

3. **Spatial grid rebuilt every tick** — cheaper than tracking per-item cell
   membership for `move()` calls. With ~30 snakes × 30 segments + 800 food =
   ~1700 items per arena, rebuild is ~5K Map ops. Total across 7 arenas at
   30 Hz ≈ 1M ops/sec — trivial.

4. **Food "eaten" sentinel** — when a snake eats food, the grid item's `value`
   is set to 0 in-place. Other snakes querying the same tick see `value <= 0`
   and skip. The `room.foods` array is filtered after iteration. This avoids
   mutating the grid Map while iterating it.

5. **Bot AI is deliberately cheap** — each bot does 2 grid queries (food +
   threat) and picks a target angle. Re-thinks every ~150ms; between re-thinks
   it just moves toward the cached angle. Personalities (`scavenger`,
   `opportunist`, `hunter`, `extractor`, `coward`) modulate flee distance and
   boost probability. No allocations on the hot path — walks the query Map
   directly.

6. **Snapshot downsampling** — bodies longer than 60 points are evenly
   downsampled for the snapshot. Game state keeps up to 120 points per snake
   for smooth movement. Payload per arena: ~30 snakes × 60 pts × 16 bytes ≈
   28 KB at 20 Hz = ~560 KB/sec — manageable.

7. **Match settlement is idempotent** — `matchSettling` flag on `PlayerSession`
   prevents double-report if `settleMatch` is called concurrently (e.g. death +
   disconnect race). The flag is checked at entry; second call short-circuits.

8. **One socket per userTag** — `userTagToSocket: Map<string, string>`. On new
   connection, if a prior socket exists for the same userTag, it gets `kicked`
   + disconnected. Prevents the multi-join chip-doubling exploit.

9. **Heartbeat logging** — every 15s the server logs
   `heartbeat — rooms=N players=M`. Useful for diagnosing crashes (if the
   heartbeat stops, the process died).

## How to start it

The `package.json` has `dev: bun --hot index.ts` and `start: bun index.ts`.
The container's `/start.sh` auto-starts all mini-services with a `dev` script
on boot — so on the next container restart, the game server will start
automatically.

For manual start in this sandbox (where `nohup ... &` gets SIGKILLed when the
parent bash command returns), use the Python double-fork daemon pattern to
fully detach from the controlling shell:

```bash
cd /home/z/my-project/mini-services/game-server && python3 -c '
import os, sys
try:
    pid = os.fork()
    if pid > 0: sys.exit(0)
except OSError: sys.exit(1)
os.setsid()
try:
    pid = os.fork()
    if pid > 0: sys.exit(0)
except OSError: sys.exit(1)
sys.stdout.flush(); sys.stderr.flush()
with open("/dev/null","rb") as f: os.dup2(f.fileno(), 0)
with open("/home/z/my-project/mini-services/game-server.log","ab") as f:
    os.dup2(f.fileno(), 1); os.dup2(f.fileno(), 2)
os.chdir("/home/z/my-project/mini-services/game-server")
os.execvp("bun", ["bun", "index.ts"])
' &
disown
```

This reparents the bun process to PID 1 (tini) via double-fork + setsid, so
it survives across bash commands. Verified: PID 5949 has been running for
30+ seconds with heartbeats firing every 15s, port 3001 LISTEN, socket.io
polling handshake returns valid `sid` + `upgrades` JSON.

## Verification

```
$ curl -s "http://localhost:3001/?EIO=4&transport=polling"
0{"sid":"XJotiGyfgK-z821FAAAA","upgrades":["websocket"],"pingInterval":25000,"pingTimeout":60000,"maxPayload":1000000}
```

Server log:
```
[22:40:34] [WARN] CORS is open (origin: *) — OK for dev (Caddy restricts in prod)
[22:40:34] [INFO] NEXT_APP_URL=http://localhost:3000  PORT=3001
[22:40:34] [INFO] Created arena room practice-easy with 20 bots
... (7 arenas, 218 bots total)
[22:40:34] [INFO] Venom Arena game server listening on port 3001
[22:40:49] [INFO] heartbeat — rooms=7 players=0
[22:41:04] [INFO] heartbeat — rooms=7 players=0
```

## What's NOT done (留给 BUILD-3 / later agents)

- **`/api/auth/token` endpoint** — the Next.js client needs an endpoint to read
  the JWT from the httpOnly cookie and pass it to the socket via
  `socket.handshake.auth.token`. The game server assumes this exists; BUILD-3
  (client) should create it (or read the cookie directly via a Server Component
  and pass the token to the client).
- **`minExtract` enforcement** — the config has `minExtract` per arena but the
  game server doesn't enforce it (no contract event for "below minimum"). The
  client can show a warning, or `/api/match/result` could refuse payouts below
  `minExtract`. Left for a future tightening.
- **Bot extraction** — bots don't extract (they just collect chips forever).
  The `extractor` personality is defined but currently behaves like `scavenger`.
  Could be enhanced to head to the extract zone and "extract" (despawn + respawn)
  when carried chips exceed a threshold.
- **Spectator mode** — not implemented. When a player dies, they get `death` +
  `match_result` and are removed from the room. The client can show a
  "Respawn" button that calls `join_arena` again.
- **Reconnect** — if a player's socket drops mid-match, they're removed from
  the room (carried chips dropped as star-chips). A reconnect-within-N-seconds
  feature could restore their snake. Not implemented for v1.

## Sandbox note for future agents

The `nohup bun run dev > log 2>&1 &` pattern from the task description does NOT
work in this sandbox — the bun process gets SIGKILLed when the parent bash
command returns (no signal can be trapped, `setsid` + `disown` don't help).
Use the Python double-fork pattern above to fully detach. The container's
`/start.sh` will auto-start the game server on the next container reboot
via the mini-services scan.
